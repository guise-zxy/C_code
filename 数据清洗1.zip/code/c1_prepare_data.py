from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "附件_raw.xlsx"
RESULT_DIR = ROOT / "results" / "C1-v1.0"

RAW_COLUMNS = [
    "sample_id",
    "mother_id",
    "age",
    "height",
    "weight",
    "last_menstrual_period",
    "ivf_method",
    "test_date",
    "blood_draw_count",
    "gestational_week_raw",
    "bmi",
    "raw_reads",
    "mapping_ratio",
    "duplicate_ratio",
    "unique_mapped_reads",
    "gc_content",
    "z13",
    "z18",
    "z21",
    "zx",
    "zy",
    "y_concentration",
    "x_concentration",
    "gc13",
    "gc18",
    "gc21",
    "filtered_ratio",
    "aneuploidy",
    "pregnancy_count",
    "birth_count",
    "fetal_health",
]

CHINESE_COLUMNS = {
    "sample_id": "样本序号",
    "mother_id": "孕妇代码",
    "age": "年龄",
    "height": "身高",
    "weight": "体重",
    "last_menstrual_period": "末次月经",
    "ivf_method": "IVF妊娠",
    "test_date": "检测日期",
    "blood_draw_count": "检测抽血次数",
    "gestational_week_raw": "检测孕周",
    "bmi": "孕妇BMI",
    "raw_reads": "原始读段数",
    "mapping_ratio": "在参考基因组上比对的比例",
    "duplicate_ratio": "重复读段的比例",
    "unique_mapped_reads": "唯一比对读段数",
    "gc_content": "GC含量",
    "z13": "13号染色体Z值",
    "z18": "18号染色体Z值",
    "z21": "21号染色体Z值",
    "zx": "X染色体Z值",
    "zy": "Y染色体Z值",
    "y_concentration": "Y染色体浓度",
    "x_concentration": "X染色体浓度",
    "gc13": "13号染色体GC含量",
    "gc18": "18号染色体GC含量",
    "gc21": "21号染色体GC含量",
    "filtered_ratio": "被过滤读段比例",
    "aneuploidy": "染色体非整倍体",
    "pregnancy_count": "怀孕次数",
    "birth_count": "生产次数",
    "fetal_health": "胎儿是否健康",
}

NUMERIC_COLUMNS = [
    "age",
    "height",
    "weight",
    "bmi",
    "raw_reads",
    "mapping_ratio",
    "duplicate_ratio",
    "unique_mapped_reads",
    "gc_content",
    "z13",
    "z18",
    "z21",
    "zx",
    "zy",
    "y_concentration",
    "x_concentration",
    "gc13",
    "gc18",
    "gc21",
    "filtered_ratio",
]

CONTINUOUS_AGG_COLUMNS = [
    "age",
    "height",
    "weight",
    "bmi",
    "raw_reads",
    "mapping_ratio",
    "duplicate_ratio",
    "unique_mapped_reads",
    "gc_content",
    "z13",
    "z18",
    "z21",
    "zx",
    "zy",
    "y_concentration",
    "x_concentration",
    "gc13",
    "gc18",
    "gc21",
    "filtered_ratio",
]

EVENT_CONSTANT_COLUMNS = [
    "mother_id",
    "gestational_week_raw",
    "week_num",
    "test_date_key",
    "blood_draw_count",
    "last_menstrual_period_key",
    "ivf_method",
    "pregnancy_count",
    "birth_count",
    "fetal_health",
    "aneuploidy",
]

EVENT_EXCLUSION_CONFLICT_COLUMNS = [
    "mother_id",
    "gestational_week_raw",
    "week_num",
    "test_date_key",
    "blood_draw_count",
    "last_menstrual_period_key",
    "ivf_method",
    "pregnancy_count",
    "birth_count",
    "fetal_health",
]


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def parse_week(value: object) -> tuple[float, str, str]:
    if pd.isna(value):
        return np.nan, "", "missing"
    raw = str(value).strip()
    match = re.fullmatch(r"(\d+)\s*[wW]\s*(?:\+\s*([0-6]))?", raw)
    if not match:
        return np.nan, "", "invalid_format"
    weeks = int(match.group(1))
    days = int(match.group(2) or 0)
    week_num = weeks + days / 7.0
    back = f"{weeks}w" if days == 0 else f"{weeks}w+{days}"
    status = "ok" if raw.lower().replace(" ", "") == back.lower() else "ok_normalized"
    return week_num, back, status


def normalize_date_key(value: object) -> str:
    if pd.isna(value):
        return ""
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d")
    raw = str(value).strip()
    if raw.endswith(".0"):
        raw = raw[:-2]
    if re.fullmatch(r"\d{8}", raw):
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"
    parsed = pd.to_datetime(value, errors="coerce")
    if not pd.isna(parsed):
        return parsed.strftime("%Y-%m-%d")
    return raw


def normalize_text(value: object) -> str:
    if pd.isna(value):
        return ""
    return str(value).strip()


def add_sample_flow(rows: list[dict], step: str, df: pd.DataFrame, excluded: int, reason: str) -> None:
    event_count = df["event_id"].nunique() if "event_id" in df else ""
    mother_count = df["mother_id"].nunique() if "mother_id" in df else ""
    rows.append(
        {
            "step": step,
            "records": int(len(df)),
            "events": "" if event_count == "" else int(event_count),
            "mothers": "" if mother_count == "" else int(mother_count),
            "excluded_records": int(excluded),
            "exclusion_reason": reason,
        }
    )


def hard_error_reasons(row: pd.Series) -> list[str]:
    reasons: list[str] = []
    if not (10 <= row["week_num"] <= 25):
        reasons.append("week_outside_10_25")
    for col in ["mapping_ratio", "duplicate_ratio", "gc_content", "filtered_ratio", "y_concentration"]:
        val = row.get(col)
        if pd.notna(val) and not (0 <= float(val) <= 1):
            reasons.append(f"{col}_outside_0_1")
    x_val = row.get("x_concentration")
    if pd.notna(x_val) and not (-1 <= float(x_val) <= 1):
        reasons.append("x_concentration_outside_-1_1")
    if pd.notna(row.get("height")) and pd.notna(row.get("weight")) and pd.notna(row.get("bmi")):
        calc = float(row["weight"]) / (float(row["height"]) / 100.0) ** 2
        if abs(calc - float(row["bmi"])) > 0.25:
            reasons.append("bmi_inconsistent_with_height_weight")
    return reasons


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare C1 male fetus NIPT event-level data.")
    parser.add_argument("--input", default=str(DATA_FILE))
    parser.add_argument("--output-dir", default=str(RESULT_DIR))
    args = parser.parse_args()

    started = time.time()
    input_path = Path(args.input)
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    xls = pd.ExcelFile(input_path)
    male_sheet = xls.sheet_names[0]
    raw = pd.read_excel(input_path, sheet_name=male_sheet)
    original_columns = [str(c) for c in raw.columns]
    if len(raw.columns) != len(RAW_COLUMNS):
        raise ValueError(f"Expected 31 columns, found {len(raw.columns)}")
    raw.columns = RAW_COLUMNS
    raw.insert(0, "raw_row_id", np.arange(1, len(raw) + 1))

    for col in NUMERIC_COLUMNS:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    for col in ["mother_id", "ivf_method", "gestational_week_raw", "aneuploidy", "pregnancy_count", "birth_count", "fetal_health"]:
        raw[col] = raw[col].map(normalize_text)
    raw["test_date_key"] = raw["test_date"].map(normalize_date_key)
    raw["last_menstrual_period_key"] = raw["last_menstrual_period"].map(normalize_date_key)

    parsed = raw["gestational_week_raw"].map(parse_week)
    raw["week_num"] = [x[0] for x in parsed]
    raw["week_roundtrip"] = [x[1] for x in parsed]
    raw["week_parse_status"] = [x[2] for x in parsed]

    event_key = ["mother_id", "test_date_key", "blood_draw_count", "gestational_week_raw"]
    raw["event_id"] = raw[event_key].astype(str).agg("|".join, axis=1)

    required = ["mother_id", "week_num", "bmi", "y_concentration"]
    raw["required_missing"] = raw[required].isna().any(axis=1) | (raw["mother_id"] == "")
    raw["hard_error_reason"] = raw.apply(lambda row: ";".join(hard_error_reasons(row)), axis=1)
    raw["hard_error"] = raw["hard_error_reason"] != ""
    raw["in_main_record_scope"] = (
        raw["week_num"].between(10, 25, inclusive="both")
        & raw["y_concentration"].notna()
        & raw["bmi"].notna()
        & (raw["mother_id"] != "")
    )

    week_parse = raw[
        [
            "raw_row_id",
            "sample_id",
            "mother_id",
            "gestational_week_raw",
            "week_num",
            "week_roundtrip",
            "week_parse_status",
        ]
    ].copy()
    week_parse.to_csv(out_dir / "c1_week_parse_check.csv", index=False, encoding="utf-8-sig")

    main_records = raw[raw["in_main_record_scope"]].copy()
    grouped = main_records.groupby(event_key, dropna=False, sort=False)
    rep_rows: list[dict] = []
    event_records: list[dict] = []
    conflict_event_ids: set[str] = set()

    for _, group in grouped:
        event_id = group["event_id"].iloc[0]
        record: dict[str, object] = {
            "event_id": event_id,
            "source_raw_rows": ";".join(group["raw_row_id"].astype(str)),
            "tech_rep_n": int(len(group)),
            "y_concentration_range": float(group["y_concentration"].max() - group["y_concentration"].min()),
            "y_concentration_std": "" if len(group) == 1 else float(group["y_concentration"].std(ddof=1)),
        }

        conflict_cols: list[str] = []
        non_exclusion_conflict_cols: list[str] = []
        for col in EVENT_CONSTANT_COLUMNS:
            vals = [v for v in group[col].dropna().astype(str).unique() if v != ""]
            if len(vals) > 1:
                if col in EVENT_EXCLUSION_CONFLICT_COLUMNS:
                    conflict_cols.append(col)
                else:
                    non_exclusion_conflict_cols.append(col)
            record[col] = ";".join(vals) if len(vals) > 1 else (vals[0] if vals else "")
        if conflict_cols:
            conflict_event_ids.add(event_id)
        record["event_conflict_columns"] = ";".join(conflict_cols)
        record["event_conflict"] = bool(conflict_cols)
        record["non_exclusion_conflict_columns"] = ";".join(non_exclusion_conflict_cols)
        record["non_exclusion_conflict"] = bool(non_exclusion_conflict_cols)

        for col in CONTINUOUS_AGG_COLUMNS:
            record[col] = float(group[col].mean()) if group[col].notna().any() else ""

        rep_rows.append(
            {
                "event_id": event_id,
                "mother_id": record["mother_id"],
                "test_date_key": record["test_date_key"],
                "blood_draw_count": record["blood_draw_count"],
                "gestational_week_raw": record["gestational_week_raw"],
                "week_num": record["week_num"],
                "tech_rep_n": record["tech_rep_n"],
                "source_raw_rows": record["source_raw_rows"],
                "y_concentration_mean": record["y_concentration"],
                "y_concentration_std": record["y_concentration_std"],
                "y_concentration_range": record["y_concentration_range"],
                "event_conflict": record["event_conflict"],
                "event_conflict_columns": record["event_conflict_columns"],
                "non_exclusion_conflict": record["non_exclusion_conflict"],
                "non_exclusion_conflict_columns": record["non_exclusion_conflict_columns"],
            }
        )
        event_records.append(record)

    technical_reps = pd.DataFrame(rep_rows)
    technical_reps.to_csv(out_dir / "c1_technical_replicates.csv", index=False, encoding="utf-8-sig")

    events = pd.DataFrame(event_records)
    if not events.empty:
        events["keep_for_main_model"] = ~events["event_id"].isin(conflict_event_ids)
        events["exclude_reason"] = np.where(events["keep_for_main_model"], "", "event_constant_field_conflict")
        events["y_ge_4pct"] = events["y_concentration"].astype(float) >= 0.04
        events["week_c"] = events["week_num"].astype(float) - events.loc[events["keep_for_main_model"], "week_num"].astype(float).mean()
        events["bmi_c"] = events["bmi"].astype(float) - events.loc[events["keep_for_main_model"], "bmi"].astype(float).mean()
        events["age_c"] = events["age"].astype(float) - events.loc[events["keep_for_main_model"], "age"].astype(float).mean()
        events["log_reads"] = np.log(events["raw_reads"].astype(float))
        events["assisted_reproduction"] = ~events["ivf_method"].astype(str).str.contains("自然", na=False)

    ordered_cols = [
        "event_id",
        "mother_id",
        "source_raw_rows",
        "tech_rep_n",
        "keep_for_main_model",
        "exclude_reason",
        "test_date_key",
        "blood_draw_count",
        "gestational_week_raw",
        "week_num",
        "week_c",
        "bmi",
        "bmi_c",
        "y_concentration",
        "y_ge_4pct",
        "age",
        "age_c",
        "height",
        "weight",
        "ivf_method",
        "assisted_reproduction",
        "raw_reads",
        "log_reads",
        "mapping_ratio",
        "duplicate_ratio",
        "unique_mapped_reads",
        "gc_content",
        "filtered_ratio",
        "z13",
        "z18",
        "z21",
        "zx",
        "zy",
        "x_concentration",
        "gc13",
        "gc18",
        "gc21",
        "aneuploidy",
        "pregnancy_count",
        "birth_count",
        "fetal_health",
        "y_concentration_std",
        "y_concentration_range",
        "event_conflict",
        "event_conflict_columns",
        "non_exclusion_conflict",
        "non_exclusion_conflict_columns",
    ]
    events = events[[c for c in ordered_cols if c in events.columns]]
    events.to_csv(out_dir / "c1_clean_events.csv", index=False, encoding="utf-8-sig")

    excluded_required = int(raw["required_missing"].sum())
    excluded_week = int((raw["week_num"].notna() & ~raw["week_num"].between(10, 25, inclusive="both")).sum())
    invalid_week = int((raw["week_parse_status"] == "invalid_format").sum())
    flow: list[dict] = []
    add_sample_flow(flow, "raw_male_sheet", raw, 0, "男胎检测数据原始记录")
    valid_y = raw[raw["y_concentration"].notna()].copy()
    add_sample_flow(flow, "non_missing_y_concentration", valid_y, len(raw) - len(valid_y), "剔除Y染色体浓度缺失")
    parsed_week_df = raw[raw["week_num"].notna()].copy()
    add_sample_flow(flow, "parsed_gestational_week", parsed_week_df, invalid_week, "剔除孕周格式无法解析")
    main_scope = raw[raw["in_main_record_scope"]].copy()
    add_sample_flow(flow, "main_record_scope_10_25_week", main_scope, len(raw) - len(main_scope), "主分析范围：10<=week<=25，且关键字段非缺失")
    add_sample_flow(flow, "event_level_after_technical_replicate_aggregation", events, len(main_scope) - len(events), "同一检测事件技术重复取均值")
    kept_events = events[events["keep_for_main_model"]].copy()
    add_sample_flow(flow, "main_model_events", kept_events, len(events) - len(kept_events), "剔除事件内固定字段冲突")
    pd.DataFrame(flow).to_csv(out_dir / "c1_sample_flow.csv", index=False, encoding="utf-8-sig")

    raw_detail_cols = [
        "raw_row_id",
        "sample_id",
        "event_id",
        "mother_id",
        "test_date_key",
        "blood_draw_count",
        "gestational_week_raw",
        "week_num",
        "bmi",
        "y_concentration",
        "in_main_record_scope",
        "required_missing",
        "hard_error",
        "hard_error_reason",
    ]
    raw[raw_detail_cols].to_csv(out_dir / "c1_clean_raw_detail.csv", index=False, encoding="utf-8-sig")

    manifest = {
        "task": "C1-v1.0 data preparation",
        "input_file": str(input_path),
        "input_sha256": file_sha256(input_path),
        "sheet_used": male_sheet,
        "original_columns": original_columns,
        "standardized_columns": RAW_COLUMNS,
        "raw_rows": int(len(raw)),
        "raw_mothers": int(raw["mother_id"].nunique()),
        "main_raw_records": int(len(main_records)),
        "main_events": int(len(events)),
        "main_model_events": int(kept_events["event_id"].nunique()),
        "main_model_mothers": int(kept_events["mother_id"].nunique()),
        "technical_repeat_events": int((technical_reps["tech_rep_n"] > 1).sum()),
        "technical_repeat_rows": int(technical_reps.loc[technical_reps["tech_rep_n"] > 1, "tech_rep_n"].sum()),
        "week_parse_invalid": invalid_week,
        "required_missing_records": excluded_required,
        "outside_10_25_week_records": excluded_week,
        "event_conflicts": int(len(conflict_event_ids)),
        "outputs": [
            "c1_sample_flow.csv",
            "c1_week_parse_check.csv",
            "c1_technical_replicates.csv",
            "c1_clean_events.csv",
            "c1_clean_raw_detail.csv",
            "c1_run_manifest.json",
        ],
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "runtime_seconds": round(time.time() - started, 3),
    }
    (out_dir / "c1_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
