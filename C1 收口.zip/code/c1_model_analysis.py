from __future__ import annotations

import argparse
import json
import math
import platform
import time
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import pandas as pd
import c1_prepare_data as prep
from scipy import optimize, stats
from sklearn.model_selection import GroupKFold


ROOT = Path(__file__).resolve().parents[1]
RESULT_DIR = ROOT / "results" / "C1-v1.0"
INPUT = RESULT_DIR / "c1_clean_events.csv"
FIG_DIR = RESULT_DIR / "figures"
FIG_DATA_DIR = RESULT_DIR / "figure_data"
SEED = 2025
BOOTSTRAP_N = 1000

MODEL_SPECS = {
    "M0_cluster_OLS": (["week_c", "bmi_c"], "cluster_robust_ols"),
    "M1_additive_LMM": (["week_c", "bmi_c"], "random_intercept"),
    "M1_linear_interaction_LMM": (["week_c", "bmi_c", "week_bmi"], "random_intercept"),
    "M2_quadratic_LMM": (["week_c", "bmi_c", "week_bmi", "week_c2", "bmi_c2"], "random_intercept"),
    "M3_adjusted_LMM": (
        ["week_c", "bmi_c", "week_bmi", "week_c2", "bmi_c2", "age_c", "assisted_reproduction", "log_reads", "mapping_ratio", "duplicate_ratio", "gc_content", "filtered_ratio"],
        "random_intercept",
    ),
    "M4_random_slope_sensitivity": (["week_c", "bmi_c", "week_bmi"], "random_slope_week"),
}


@dataclass
class FitResult:
    name: str
    fixed_terms: list[str]
    beta: np.ndarray
    se: np.ndarray
    p_values: np.ndarray
    ci_low: np.ndarray
    ci_high: np.ndarray
    cov_beta: np.ndarray
    loglike: float
    aic: float
    bic: float
    sigma_e2: float
    G: np.ndarray
    random_structure: str
    converged: bool
    message: str
    marginal_r2: float
    conditional_r2: float
    icc: float
    fixed_pred: np.ndarray
    conditional_pred: np.ndarray
    residual: np.ndarray


def setup_style() -> None:
    preferred = ["Noto Sans CJK SC", "Source Han Sans SC", "Microsoft YaHei", "SimHei", "SimSun"]
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for font in preferred:
        if font in installed:
            plt.rcParams["font.sans-serif"] = [font]
            break
    plt.rcParams.update(
        {
            "axes.unicode_minus": False,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "font.size": 9,
            "axes.titlesize": 10.5,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
        }
    )


def savefig(fig: plt.Figure, stem: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(FIG_DIR / f"{stem}.svg", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def load_data(input_path: Path = INPUT) -> pd.DataFrame:
    df = pd.read_csv(input_path, encoding="utf-8-sig")
    df = df[df["keep_for_main_model"].astype(str).str.lower().eq("true")].copy()
    numeric_cols = [
        "week_num",
        "week_c",
        "bmi",
        "bmi_c",
        "y_concentration",
        "age",
        "age_c",
        "height",
        "weight",
        "raw_reads",
        "log_reads",
        "mapping_ratio",
        "duplicate_ratio",
        "unique_mapped_reads",
        "gc_content",
        "filtered_ratio",
        "y_concentration_range",
    ]
    for col in numeric_cols:
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df["assisted_reproduction"] = df["assisted_reproduction"].astype(str).str.lower().eq("true").astype(int)
    df["week_c2"] = df["week_c"] ** 2
    df["bmi_c2"] = df["bmi_c"] ** 2
    df["week_bmi"] = df["week_c"] * df["bmi_c"]
    return df


def add_derived_terms(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in [
        "week_num",
        "week_c",
        "bmi",
        "bmi_c",
        "y_concentration",
        "age",
        "age_c",
        "height",
        "weight",
        "raw_reads",
        "log_reads",
        "mapping_ratio",
        "duplicate_ratio",
        "unique_mapped_reads",
        "gc_content",
        "filtered_ratio",
    ]:
        if col in out:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    if "assisted_reproduction" in out:
        out["assisted_reproduction"] = out["assisted_reproduction"].astype(str).str.lower().eq("true").astype(int)
    out["week_c2"] = out["week_c"] ** 2
    out["bmi_c2"] = out["bmi_c"] ** 2
    out["week_bmi"] = out["week_c"] * out["bmi_c"]
    return out


def aggregate_events(raw: pd.DataFrame, scope_mask: pd.Series) -> pd.DataFrame:
    event_key = ["mother_id", "test_date_key", "blood_draw_count", "gestational_week_raw"]
    records: list[dict] = []
    conflict_event_ids: set[str] = set()
    for _, group in raw[scope_mask].groupby(event_key, dropna=False, sort=False):
        event_id = group["event_id"].iloc[0]
        record: dict[str, object] = {
            "event_id": event_id,
            "source_raw_rows": ";".join(group["raw_row_id"].astype(str)),
            "tech_rep_n": int(len(group)),
            "y_concentration_range": float(group["y_concentration"].max() - group["y_concentration"].min()),
            "y_concentration_std": "" if len(group) == 1 else float(group["y_concentration"].std(ddof=1)),
        }
        conflict_cols: list[str] = []
        non_exclusion_conflict_cols: list[str] = []
        for col in prep.EVENT_CONSTANT_COLUMNS:
            vals = [v for v in group[col].dropna().astype(str).unique() if v != ""]
            if len(vals) > 1:
                if col in prep.EVENT_EXCLUSION_CONFLICT_COLUMNS:
                    conflict_cols.append(col)
                else:
                    non_exclusion_conflict_cols.append(col)
            record[col] = ";".join(vals) if len(vals) > 1 else (vals[0] if vals else "")
        if conflict_cols:
            conflict_event_ids.add(event_id)
        record["event_conflict_columns"] = ";".join(conflict_cols)
        record["event_conflict"] = bool(conflict_cols)
        record["non_exclusion_conflict_columns"] = ";".join(non_exclusion_conflict_cols)
        record["non_exclusion_conflict"] = bool(non_exclusion_conflict_cols)
        for col in prep.CONTINUOUS_AGG_COLUMNS:
            record[col] = float(group[col].mean()) if group[col].notna().any() else np.nan
        records.append(record)

    events = pd.DataFrame(records)
    if events.empty:
        return events
    events["keep_for_main_model"] = ~events["event_id"].isin(conflict_event_ids)
    events["exclude_reason"] = np.where(events["keep_for_main_model"], "", "event_constant_field_conflict_or_physical_hard_error")
    keep = events["keep_for_main_model"]
    events["y_ge_4pct"] = events["y_concentration"].astype(float) >= 0.04
    events["week_c"] = events["week_num"].astype(float) - events.loc[keep, "week_num"].astype(float).mean()
    events["bmi_c"] = events["bmi"].astype(float) - events.loc[keep, "bmi"].astype(float).mean()
    events["age_c"] = events["age"].astype(float) - events.loc[keep, "age"].astype(float).mean()
    events["log_reads"] = np.log(events["raw_reads"].astype(float))
    events["assisted_reproduction"] = ~events["ivf_method"].astype(str).str.contains("自然", na=False)
    return events[events["keep_for_main_model"]].copy()


def load_all_valid_events() -> pd.DataFrame:
    xls = pd.ExcelFile(prep.DATA_FILE)
    raw = pd.read_excel(prep.DATA_FILE, sheet_name=prep.EXPECTED_MALE_SHEET)
    actual = [prep.normalize_header(c) for c in raw.columns]
    expected = [prep.normalize_header(c) for c in prep.EXPECTED_RAW_FIELD_NAMES]
    if actual != expected:
        raise ValueError("男胎检测数据字段与清洗阶段预期不一致，停止灵敏度样本构造")
    if prep.normalize_header(prep.EXPECTED_MALE_SHEET) not in [prep.normalize_header(s) for s in xls.sheet_names]:
        raise ValueError("未找到男胎检测数据工作表，停止灵敏度样本构造")
    raw.columns = prep.RAW_COLUMNS
    raw.insert(0, "raw_row_id", np.arange(1, len(raw) + 1))
    for col in prep.NUMERIC_COLUMNS:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    for col in ["mother_id", "ivf_method", "gestational_week_raw", "aneuploidy", "pregnancy_count", "birth_count", "fetal_health"]:
        raw[col] = raw[col].map(prep.normalize_text)
    raw["test_date_key"] = raw["test_date"].map(prep.normalize_date_key)
    raw["last_menstrual_period_key"] = raw["last_menstrual_period"].map(prep.normalize_date_key)
    parsed = raw["gestational_week_raw"].map(prep.parse_week)
    raw["week_num"] = [x[0] for x in parsed]
    event_key = ["mother_id", "test_date_key", "blood_draw_count", "gestational_week_raw"]
    raw["event_id"] = raw[event_key].astype(str).agg("|".join, axis=1)
    raw["physical_hard_error_reason"] = raw.apply(lambda row: ";".join(prep.physical_hard_error_reasons(row)), axis=1)
    raw["physical_hard_error"] = raw["physical_hard_error_reason"] != ""
    scope = raw["week_num"].between(11, 29, inclusive="both") & raw["y_concentration"].notna() & raw["bmi"].notna() & (raw["mother_id"] != "") & ~raw["physical_hard_error"]
    out = aggregate_events(raw, scope)
    out.to_csv(RESULT_DIR / "c1_all_valid_week_11_29_events.csv", index=False, encoding="utf-8-sig")
    return add_derived_terms(out)


def describe(df: pd.DataFrame) -> pd.DataFrame:
    vars_ = [
        "week_num",
        "bmi",
        "y_concentration",
        "age",
        "height",
        "weight",
        "raw_reads",
        "mapping_ratio",
        "duplicate_ratio",
        "gc_content",
        "filtered_ratio",
    ]
    rows = []
    for col in vars_:
        s = df[col].dropna()
        rows.append(
            {
                "variable": col,
                "n": int(s.size),
                "mean": s.mean(),
                "std": s.std(ddof=1),
                "median": s.median(),
                "q1": s.quantile(0.25),
                "q3": s.quantile(0.75),
                "min": s.min(),
                "max": s.max(),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(RESULT_DIR / "c1_descriptive_stats.csv", index=False, encoding="utf-8-sig")
    return out


def corr_one(x: np.ndarray, y: np.ndarray, method: str) -> float:
    if method == "pearson":
        return stats.pearsonr(x, y).statistic
    return stats.spearmanr(x, y).statistic


def cluster_bootstrap_correlations(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    vars_ = ["week_num", "bmi", "age", "height", "weight", "gc_content", "raw_reads", "filtered_ratio"]
    mothers = df["mother_id"].drop_duplicates().to_numpy()
    rows = []
    for var in vars_:
        sub = df[[var, "y_concentration", "mother_id"]].dropna()
        x = sub[var].to_numpy(float)
        y = sub["y_concentration"].to_numpy(float)
        for method in ["pearson", "spearman"]:
            estimate = corr_one(x, y, method)
            sub = sub.reset_index(drop=True)
            mother_to_idx = {m: idx.to_numpy() for m, idx in sub.groupby("mother_id").groups.items()}
            boots = []
            for _ in range(BOOTSTRAP_N):
                chosen = rng.choice(mothers, size=len(mothers), replace=True)
                idx = np.concatenate([mother_to_idx[m] for m in chosen if m in mother_to_idx])
                sx = sub.loc[idx, var].to_numpy(float)
                sy = sub.loc[idx, "y_concentration"].to_numpy(float)
                if len(np.unique(sx)) <= 1 or len(np.unique(sy)) <= 1:
                    continue
                boots.append(corr_one(sx, sy, method))
            rows.append(
                {
                    "variable": var,
                    "method": method,
                    "estimate": estimate,
                    "cluster_bootstrap_n": len(boots),
                    "ci_low": np.percentile(boots, 2.5),
                    "ci_high": np.percentile(boots, 97.5),
                    "same_direction_rate": np.mean(np.sign(boots) == np.sign(estimate)),
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(RESULT_DIR / "c1_correlations.csv", index=False, encoding="utf-8-sig")
    return out


def design_matrix(df: pd.DataFrame, terms: list[str]) -> np.ndarray:
    return np.column_stack([np.ones(len(df))] + [df[t].to_numpy(float) for t in terms])


def cluster_robust_ols(name: str, df: pd.DataFrame, terms: list[str]) -> FitResult:
    df = df.reset_index(drop=True)
    y = df["y_concentration"].to_numpy(float)
    X = design_matrix(df, terms)
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    resid = y - X @ beta
    n, p = X.shape
    xtx_inv = np.linalg.pinv(X.T @ X)
    meat = np.zeros((p, p))
    for _, idx in df.groupby("mother_id").indices.items():
        Xg = X[idx, :]
        eg = resid[idx][:, None]
        meat += Xg.T @ eg @ eg.T @ Xg
    g = df["mother_id"].nunique()
    scale = (g / (g - 1)) * ((n - 1) / (n - p))
    cov = scale * xtx_inv @ meat @ xtx_inv
    se = np.sqrt(np.diag(cov))
    t_values = beta / se
    p_values = 2 * stats.t.sf(np.abs(t_values), df=g - 1)
    ci_low = beta - stats.t.ppf(0.975, g - 1) * se
    ci_high = beta + stats.t.ppf(0.975, g - 1) * se
    sigma_e2 = float(np.sum(resid**2) / n)
    ll = float(np.sum(stats.norm.logpdf(resid, loc=0, scale=math.sqrt(sigma_e2))))
    aic = 2 * (p + 1) - 2 * ll
    bic = math.log(n) * (p + 1) - 2 * ll
    var_fixed = float(np.var(X @ beta, ddof=1))
    total = var_fixed + sigma_e2
    return FitResult(
        name=name,
        fixed_terms=["Intercept"] + terms,
        beta=beta,
        se=se,
        p_values=p_values,
        ci_low=ci_low,
        ci_high=ci_high,
        cov_beta=cov,
        loglike=ll,
        aic=aic,
        bic=bic,
        sigma_e2=sigma_e2,
        G=np.zeros((1, 1)),
        random_structure="cluster_robust_ols",
        converged=True,
        message="OLS with mother-cluster robust standard errors",
        marginal_r2=var_fixed / total if total > 0 else np.nan,
        conditional_r2=var_fixed / total if total > 0 else np.nan,
        icc=0.0,
        fixed_pred=X @ beta,
        conditional_pred=X @ beta,
        residual=resid,
    )


def group_arrays(df: pd.DataFrame, X: np.ndarray, Z: np.ndarray, y: np.ndarray):
    return [(idx, X[idx, :], Z[idx, :], y[idx]) for _, idx in df.groupby("mother_id").indices.items()]


def unpack_variance(theta: np.ndarray, random_structure: str) -> tuple[np.ndarray, float]:
    sigma_e2 = float(np.exp(theta[-1]))
    if random_structure == "random_intercept":
        return np.array([[float(np.exp(theta[0]))]]), sigma_e2
    l00 = np.exp(theta[0])
    l10 = theta[1]
    l11 = np.exp(theta[2])
    L = np.array([[l00, 0.0], [l10, l11]])
    return L @ L.T, sigma_e2


def fit_lmm(name: str, df: pd.DataFrame, terms: list[str], random_structure: str, maxiter: int = 500) -> FitResult:
    cols = list(dict.fromkeys(["y_concentration", "mother_id", "week_c"] + terms))
    model_df = df[cols].dropna().reset_index(drop=True).copy()
    y = model_df["y_concentration"].to_numpy(float)
    X = design_matrix(model_df, terms)
    Z = np.ones((len(model_df), 1)) if random_structure == "random_intercept" else np.column_stack([np.ones(len(model_df)), model_df["week_c"].to_numpy(float)])
    groups = group_arrays(model_df, X, Z, y)
    n, p = X.shape

    def beta_and_ll(theta: np.ndarray) -> tuple[np.ndarray, float, np.ndarray]:
        G, sigma_e2 = unpack_variance(theta, random_structure)
        xt_v_x = np.zeros((p, p))
        xt_v_y = np.zeros(p)
        logdet = 0.0
        quad_const = 0.0
        vinv_blocks = []
        for _, Xg, Zg, yg in groups:
            V = Zg @ G @ Zg.T + sigma_e2 * np.eye(len(yg))
            cf = np.linalg.cholesky(V)
            logdet += 2 * np.log(np.diag(cf)).sum()
            vinv_X = np.linalg.solve(cf.T, np.linalg.solve(cf, Xg))
            vinv_y = np.linalg.solve(cf.T, np.linalg.solve(cf, yg))
            xt_v_x += Xg.T @ vinv_X
            xt_v_y += Xg.T @ vinv_y
            vinv_blocks.append((vinv_X, vinv_y, cf, Xg, yg, Zg))
        beta = np.linalg.lstsq(xt_v_x, xt_v_y, rcond=None)[0]
        quad = 0.0
        for _, _, cf, Xg, yg, _ in vinv_blocks:
            resid = yg - Xg @ beta
            tmp = np.linalg.solve(cf.T, np.linalg.solve(cf, resid))
            quad += resid @ tmp
        ll = -0.5 * (n * np.log(2 * np.pi) + logdet + quad)
        cov_beta = np.linalg.pinv(xt_v_x)
        return beta, float(ll), cov_beta

    def objective(theta: np.ndarray) -> float:
        try:
            return -beta_and_ll(theta)[1]
        except np.linalg.LinAlgError:
            return 1e30

    ols = np.linalg.lstsq(X, y, rcond=None)[0]
    resid = y - X @ ols
    base_var = max(float(np.var(resid)), 1e-8)
    if random_structure == "random_intercept":
        starts = [np.log([base_var * 0.2, base_var * 0.8])]
    else:
        starts = [
            np.array([math.log(math.sqrt(base_var * 0.1)), 0.0, math.log(math.sqrt(base_var * 0.01)), math.log(base_var * 0.8)]),
        ]
    best = None
    for start in starts:
        if random_structure == "random_intercept":
            opt = optimize.minimize(objective, start, method="L-BFGS-B", options={"maxiter": maxiter, "ftol": 1e-9, "gtol": 1e-6})
        else:
            opt = optimize.minimize(objective, start, method="Nelder-Mead", options={"maxiter": maxiter, "xatol": 1e-6, "fatol": 1e-6})
        if best is None or opt.fun < best.fun:
            best = opt
    theta = best.x
    beta, ll, cov_beta = beta_and_ll(theta)
    se = np.sqrt(np.diag(cov_beta))
    z_values = beta / se
    p_values = 2 * stats.norm.sf(np.abs(z_values))
    ci_low = beta - 1.96 * se
    ci_high = beta + 1.96 * se
    G, sigma_e2 = unpack_variance(theta, random_structure)
    var_params = 2 if random_structure == "random_intercept" else 4
    k = p + var_params
    aic = 2 * k - 2 * ll
    bic = math.log(n) * k - 2 * ll
    fixed_pred = X @ beta
    conditional_pred = fixed_pred.copy()
    for idx, Xg, Zg, yg in groups:
        V = Zg @ G @ Zg.T + sigma_e2 * np.eye(len(yg))
        resid_g = yg - Xg @ beta
        b_hat = G @ Zg.T @ np.linalg.solve(V, resid_g)
        conditional_pred[idx] += Zg @ b_hat
    residual = y - conditional_pred
    var_fixed = float(np.var(fixed_pred, ddof=1))
    random_var = float(np.mean(np.sum((Z @ G) * Z, axis=1)))
    total = var_fixed + random_var + sigma_e2
    icc = float(G[0, 0] / (G[0, 0] + sigma_e2)) if G[0, 0] + sigma_e2 > 0 else np.nan
    return FitResult(
        name=name,
        fixed_terms=["Intercept"] + terms,
        beta=beta,
        se=se,
        p_values=p_values,
        ci_low=ci_low,
        ci_high=ci_high,
        cov_beta=cov_beta,
        loglike=ll,
        aic=aic,
        bic=bic,
        sigma_e2=sigma_e2,
        G=G,
        random_structure=random_structure,
        converged=bool(best.success),
        message=str(best.message),
        marginal_r2=var_fixed / total if total > 0 else np.nan,
        conditional_r2=(var_fixed + random_var) / total if total > 0 else np.nan,
        icc=icc,
        fixed_pred=fixed_pred,
        conditional_pred=conditional_pred,
        residual=residual,
    )


def grouped_cv(df: pd.DataFrame, terms: list[str], random_structure: str, model_name: str, seed: int = SEED) -> tuple[float, float]:
    cols = list(dict.fromkeys(["y_concentration", "mother_id", "week_c"] + terms))
    model_df = df[cols].dropna().reset_index(drop=True).copy()
    groups = model_df["mother_id"].to_numpy()
    y_true_all = []
    pred_all = []
    splitter = GroupKFold(n_splits=5)
    fold_rows = []
    for train_idx, test_idx in splitter.split(model_df, groups=groups):
        train = model_df.iloc[train_idx].copy()
        test = model_df.iloc[test_idx].copy()
        if random_structure == "cluster_robust_ols":
            fold_fit = cluster_robust_ols("cv_fold", train, terms)
        else:
            fold_fit = fit_lmm("cv_fold", train, terms, random_structure, maxiter=350)
        # Validation mothers are unseen groups, so only this fold model's fixed
        # effects are used for out-of-fold prediction.
        beta = fold_fit.beta
        pred = design_matrix(test, terms) @ beta
        y_fold = test["y_concentration"].to_numpy(float)
        y_true_all.extend(y_fold)
        pred_all.extend(pred)
        fold_rows.append(
            {
                "random_structure": random_structure,
                "model": model_name,
                "terms": "+".join(terms),
                "train_events": int(len(train)),
                "train_mothers": int(train["mother_id"].nunique()),
                "test_events": int(len(test)),
                "test_mothers": int(test["mother_id"].nunique()),
                "fold_rmse": float(np.sqrt(np.mean((y_fold - pred) ** 2))),
                "fold_mae": float(np.mean(np.abs(y_fold - pred))),
                "fold_converged": fold_fit.converged,
                "fold_message": fold_fit.message,
            }
        )
    y_true = np.asarray(y_true_all)
    pred = np.asarray(pred_all)
    rmse = float(np.sqrt(np.mean((y_true - pred) ** 2)))
    mae = float(np.mean(np.abs(y_true - pred)))
    pd.DataFrame(fold_rows).to_csv(
        RESULT_DIR / f"c1_cv_folds_{model_name}.csv",
        index=False,
        encoding="utf-8-sig",
    )
    return rmse, mae


def refit_lmm_cluster_bootstrap(df: pd.DataFrame, rng: np.random.Generator, model_name: str, terms: list[str], n_boot: int = BOOTSTRAP_N) -> pd.DataFrame:
    base_df = df[list(dict.fromkeys(["mother_id", "y_concentration", "week_c"] + terms))].dropna().reset_index(drop=True)
    mothers = base_df["mother_id"].drop_duplicates().to_numpy()
    mother_to_pos = {m: idx.to_numpy() for m, idx in base_df.groupby("mother_id").groups.items()}
    rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 50 == 0:
            print(f"{model_name} cluster bootstrap refit {b}/{n_boot}", flush=True)
        pieces = []
        chosen = rng.choice(mothers, size=len(mothers), replace=True)
        for draw_no, mother in enumerate(chosen, 1):
            part = base_df.iloc[mother_to_pos[mother]].copy()
            part["mother_id"] = f"{mother}__boot{draw_no}"
            pieces.append(part)
        sample = pd.concat(pieces, ignore_index=True)
        try:
            fit = fit_lmm(f"{model_name}_bootstrap", sample, terms, "random_intercept", maxiter=220)
            row = {
                "bootstrap_id": b,
                "model": model_name,
                "status": "ok",
                "converged": fit.converged,
                "loglike": fit.loglike,
                "icc": fit.icc,
            }
            for term in ["Intercept"] + terms:
                row[f"coef_{term}"] = fit.beta[fit.fixed_terms.index(term)]
            rows.append(row)
        except Exception as exc:
            rows.append({"bootstrap_id": b, "status": f"failed: {exc}", "converged": False})
    out = pd.DataFrame(rows)
    out.to_csv(RESULT_DIR / f"c1_{model_name}_cluster_bootstrap_refit.csv", index=False, encoding="utf-8-sig")
    return out


def choose_main_model(metrics: pd.DataFrame, coeffs: pd.DataFrame, comparison_df: pd.DataFrame) -> tuple[str, str]:
    row = comparison_df[
        comparison_df["base_model"].eq("M1_additive_LMM")
        & comparison_df["candidate_model"].eq("M1_linear_interaction_LMM")
    ].iloc[0]
    interaction_p = pd.to_numeric(
        coeffs[
            coeffs["model"].eq("M1_linear_interaction_LMM")
            & coeffs["term"].eq("week_bmi")
        ]["p_value"],
        errors="coerce",
    ).iloc[0]
    cv_gain = float(row["cv_rmse_improvement_rate"])
    if interaction_p < 0.05 and cv_gain >= 0.02:
        return "M1_linear_interaction_LMM", "interaction retained: p<0.05 and grouped-CV RMSE improves at least 2%"
    return "M1_additive_LMM", "additive selected: interaction not significant or grouped-CV RMSE gain below 2%"


def collect_results(df: pd.DataFrame) -> tuple[dict[str, FitResult], pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    fits: dict[str, FitResult] = {}
    metrics_rows = []
    coeff_rows = []
    pred_frames = []
    for name, (terms, random_structure) in MODEL_SPECS.items():
        cols = list(dict.fromkeys(["event_id", "mother_id", "y_concentration", "week_c"] + terms))
        model_df = df[cols].dropna().reset_index(drop=True).copy()
        if random_structure == "cluster_robust_ols":
            fit = cluster_robust_ols(name, model_df, terms)
        else:
            fit = fit_lmm(name, model_df, terms, random_structure)
        rmse, mae = grouped_cv(model_df, terms, random_structure, name)
        fits[name] = fit
        metrics_rows.append(
            {
                "model": name,
                "n_events": int(len(model_df)),
                "n_mothers": int(model_df["mother_id"].nunique()),
                "random_structure": fit.random_structure,
                "loglike": fit.loglike,
                "aic": fit.aic,
                "bic": fit.bic,
                "marginal_r2": fit.marginal_r2,
                "conditional_r2": fit.conditional_r2,
                "icc": fit.icc,
                "sigma_e2": fit.sigma_e2,
                "random_var_intercept": float(fit.G[0, 0]) if fit.G.size else 0.0,
                "random_var_week_slope": float(fit.G[1, 1]) if fit.G.shape == (2, 2) else "",
                "random_cov_intercept_week": float(fit.G[0, 1]) if fit.G.shape == (2, 2) else "",
                "cv_rmse": rmse,
                "cv_mae": mae,
                "converged": fit.converged,
                "message": fit.message,
            }
        )
        sd_y = float(model_df["y_concentration"].std(ddof=1))
        for term, beta, se, lo, hi, p in zip(fit.fixed_terms, fit.beta, fit.se, fit.ci_low, fit.ci_high, fit.p_values):
            if term == "Intercept":
                sd_x = np.nan
            else:
                sd_x = float(model_df[term].std(ddof=1)) if term in model_df else np.nan
            coeff_rows.append(
                {
                    "model": name,
                    "term": term,
                    "coef": beta,
                    "std_error": se,
                    "ci_low": lo,
                    "ci_high": hi,
                    "p_value": p,
                    "standardized_effect": "" if term == "Intercept" or not np.isfinite(sd_x) else beta * sd_x / sd_y,
                }
            )
        pred_frames.append(
            pd.DataFrame(
                {
                    "model": name,
                    "event_id": model_df["event_id"].to_numpy(),
                    "mother_id": model_df["mother_id"].to_numpy(),
                    "observed_y": model_df["y_concentration"].to_numpy(float),
                    "fixed_effect_prediction": fit.fixed_pred,
                    "conditional_prediction": fit.conditional_pred,
                    "residual": fit.residual,
                }
            )
        )
    metrics = pd.DataFrame(metrics_rows)
    coeffs = pd.DataFrame(coeff_rows)
    predictions = pd.concat(pred_frames, ignore_index=True)
    comparisons = []
    for a, b in [
        ("M1_additive_LMM", "M1_linear_interaction_LMM"),
        ("M1_linear_interaction_LMM", "M2_quadratic_LMM"),
        ("M2_quadratic_LMM", "M3_adjusted_LMM"),
        ("M1_linear_interaction_LMM", "M4_random_slope_sensitivity"),
    ]:
        lrt = 2 * (fits[b].loglike - fits[a].loglike)
        df_diff = len(fits[b].beta) + (4 if fits[b].random_structure == "random_slope_week" else 2) - len(fits[a].beta) - (4 if fits[a].random_structure == "random_slope_week" else 2)
        p_value = float(stats.chi2.sf(max(lrt, 0), max(df_diff, 1)))
        base_rmse = metrics.loc[metrics["model"].eq(a), "cv_rmse"].iloc[0]
        new_rmse = metrics.loc[metrics["model"].eq(b), "cv_rmse"].iloc[0]
        comparisons.append(
            {
                "base_model": a,
                "candidate_model": b,
                "lrt_stat": lrt,
                "df_diff": df_diff,
                "lrt_p_value": p_value,
                "delta_aic_candidate_minus_base": fits[b].aic - fits[a].aic,
                "delta_bic_candidate_minus_base": fits[b].bic - fits[a].bic,
                "cv_rmse_improvement_rate": (base_rmse - new_rmse) / base_rmse,
                "retain_rule": "retain candidate as main only if diagnostics acceptable and CV-RMSE improves at least 2% or main inference changes",
            }
        )
    comparison_df = pd.DataFrame(comparisons)
    metrics.to_csv(RESULT_DIR / "c1_model_metrics.csv", index=False, encoding="utf-8-sig")
    coeffs.to_csv(RESULT_DIR / "c1_coefficients.csv", index=False, encoding="utf-8-sig")
    comparison_df.to_csv(RESULT_DIR / "c1_model_comparison.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(RESULT_DIR / "c1_predictions.csv", index=False, encoding="utf-8-sig")
    return fits, metrics, coeffs, comparison_df, predictions


def diagnostics(df: pd.DataFrame, fits: dict[str, FitResult], coeffs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    diag_vars = ["week_c", "bmi_c", "age_c", "log_reads", "mapping_ratio", "duplicate_ratio", "gc_content", "filtered_ratio"]
    vdf = df[diag_vars].dropna()
    vif_rows = []
    for col in diag_vars:
        others = [c for c in diag_vars if c != col]
        X = np.column_stack([np.ones(len(vdf))] + [vdf[o].to_numpy(float) for o in others])
        y = vdf[col].to_numpy(float)
        pred = X @ np.linalg.lstsq(X, y, rcond=None)[0]
        r2 = 1 - np.sum((y - pred) ** 2) / np.sum((y - y.mean()) ** 2)
        vif_rows.append({"variable": col, "vif": 1 / max(1 - r2, 1e-12)})
    for fit in fits.values():
        shapiro_sample = fit.residual if len(fit.residual) <= 5000 else fit.residual[:5000]
        rows.append(
            {
                "model": fit.name,
                "diagnostic": "residual_summary",
                "value": "",
                "mean_residual": float(np.mean(fit.residual)),
                "std_residual": float(np.std(fit.residual, ddof=1)),
                "shapiro_p_value": float(stats.shapiro(shapiro_sample).pvalue),
                "max_abs_residual": float(np.max(np.abs(fit.residual))),
            }
        )
    for row in vif_rows:
        rows.append(
            {
                "model": "M3_adjusted_LMM",
                "diagnostic": "vif",
                "variable": row["variable"],
                "value": row["vif"],
                "flag": "VIF>10" if row["vif"] > 10 else ("VIF>5" if row["vif"] > 5 else ""),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(RESULT_DIR / "c1_diagnostics.csv", index=False, encoding="utf-8-sig")
    return out


def sensitivity(df: pd.DataFrame, rng: np.random.Generator, main_model_name: str, main_terms: list[str]) -> pd.DataFrame:
    rows = []
    variants = {
        "main_10_25_original": df.copy(),
        "all_valid_week_11_29": load_all_valid_events(),
        "winsor_1_99_y": df.copy(),
        "logit_y": df.copy(),
    }
    lo, hi = df["y_concentration"].quantile([0.01, 0.99])
    variants["winsor_1_99_y"]["y_concentration"] = variants["winsor_1_99_y"]["y_concentration"].clip(lo, hi)
    eps = 1e-6
    variants["logit_y"]["y_concentration"] = np.log(np.clip(variants["logit_y"]["y_concentration"], eps, 1 - eps) / (1 - np.clip(variants["logit_y"]["y_concentration"], eps, 1 - eps)))

    for name, vdf in variants.items():
        try:
            fit = fit_lmm("sensitivity", vdf.dropna(subset=["y_concentration", "mother_id"] + main_terms), main_terms, "random_intercept")
            for term in main_terms:
                idx = fit.fixed_terms.index(term)
                rows.append({"sensitivity": name, "term": term, "coef": fit.beta[idx], "ci_low": fit.ci_low[idx], "ci_high": fit.ci_high[idx], "p_value": fit.p_values[idx], "status": "ok"})
        except Exception as exc:
            rows.append({"sensitivity": name, "term": "", "coef": "", "ci_low": "", "ci_high": "", "p_value": "", "status": f"failed: {exc}"})

    try:
        m2_terms = ["week_c", "bmi_c", "week_bmi", "week_c2", "bmi_c2"]
        fit_m2 = fit_lmm("M2_nonlinear_sensitivity", df.dropna(subset=["y_concentration", "mother_id"] + m2_terms), m2_terms, "random_intercept")
        for term in m2_terms:
            idx = fit_m2.fixed_terms.index(term)
            rows.append(
                {
                    "sensitivity": "M2_nonlinear_sensitivity",
                    "term": term,
                    "coef": fit_m2.beta[idx],
                    "ci_low": fit_m2.ci_low[idx],
                    "ci_high": fit_m2.ci_high[idx],
                    "p_value": fit_m2.p_values[idx],
                    "status": "ok",
                }
            )
    except Exception as exc:
        rows.append({"sensitivity": "M2_nonlinear_sensitivity", "term": "", "coef": "", "ci_low": "", "ci_high": "", "p_value": "", "status": f"failed: {exc}"})

    base_fit = fit_lmm("bootstrap_reference", df, main_terms, "random_intercept")
    main_boot = refit_lmm_cluster_bootstrap(df, rng, main_model_name, main_terms, BOOTSTRAP_N)
    ok_boot = main_boot[main_boot["status"].eq("ok") & main_boot["converged"].astype(str).str.lower().eq("true")].copy()
    for t in main_terms:
        vals = pd.to_numeric(ok_boot[f"coef_{t}"], errors="coerce").dropna().to_numpy(float)
        base = base_fit.beta[base_fit.fixed_terms.index(t)]
        rows.append(
            {
                "sensitivity": f"cluster_bootstrap_{main_model_name}_refit_{len(vals)}_converged",
                "term": t,
                "coef": base,
                "ci_low": np.percentile(vals, 2.5),
                "ci_high": np.percentile(vals, 97.5),
                "p_value": "",
                "same_direction_rate": float(np.mean(np.sign(vals) == np.sign(base))),
                "status": "ok",
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(RESULT_DIR / "c1_sensitivity_summary.csv", index=False, encoding="utf-8-sig")
    return out


def make_figures(df: pd.DataFrame, fits: dict[str, FitResult], coeffs: pd.DataFrame, main_model_name: str) -> None:
    FIG_DATA_DIR.mkdir(parents=True, exist_ok=True)
    main = df.copy()
    main[["event_id", "week_num", "bmi", "y_concentration"]].to_csv(FIG_DATA_DIR / "c1_fig01_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(6.4, 4.0), constrained_layout=True)
    sc = ax.scatter(main["week_num"], main["y_concentration"], c=main["bmi"], s=16, cmap="viridis", alpha=0.68, linewidths=0)
    ax.axhline(0.04, color="#A33A46", linestyle="--", linewidth=1.0, label="4%参考线")
    ax.set_xlabel("检测孕周 / 周")
    ax.set_ylabel("Y染色体浓度")
    ax.set_title("Y染色体浓度与孕周的关系")
    fig.colorbar(sc, ax=ax, label="BMI")
    ax.legend(loc="upper left")
    savefig(fig, "c1_fig01_y_week_bmi")

    main[["event_id", "bmi", "week_num", "y_concentration"]].to_csv(FIG_DATA_DIR / "c1_fig02_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(6.4, 4.0), constrained_layout=True)
    sc = ax.scatter(main["bmi"], main["y_concentration"], c=main["week_num"], s=16, cmap="magma", alpha=0.68, linewidths=0)
    ax.axhline(0.04, color="#2F7F75", linestyle="--", linewidth=1.0, label="4%参考线")
    ax.set_xlabel("孕妇BMI")
    ax.set_ylabel("Y染色体浓度")
    ax.set_title("Y染色体浓度与BMI的关系")
    fig.colorbar(sc, ax=ax, label="检测孕周 / 周")
    ax.legend(loc="upper right")
    savefig(fig, "c1_fig02_y_bmi_week")

    selected = fits[main_model_name]
    selected_terms = selected.fixed_terms[1:]
    weeks = np.linspace(main["week_num"].min(), main["week_num"].max(), 120)
    week_c = weeks - main["week_num"].mean()
    bmi_quantiles = main["bmi"].quantile([0.25, 0.5, 0.75]).to_dict()
    effect_rows = []
    for q, bmi in bmi_quantiles.items():
        bmi_c = bmi - main["bmi"].mean()
        tmp = pd.DataFrame({"week_c": week_c, "bmi_c": bmi_c, "week_bmi": week_c * bmi_c})
        X_eff = design_matrix(tmp, selected_terms)
        pred = X_eff @ selected.beta
        se_pred = np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", X_eff, selected.cov_beta, X_eff), 0))
        for w, yhat, se_yhat in zip(weeks, pred, se_pred):
            effect_rows.append(
                {
                    "week_num": w,
                    "bmi_quantile": q,
                    "bmi": bmi,
                    "predicted_y": yhat,
                    "ci_low": yhat - 1.96 * se_yhat,
                    "ci_high": yhat + 1.96 * se_yhat,
                }
            )
    eff = pd.DataFrame(effect_rows)
    eff.to_csv(FIG_DATA_DIR / "c1_fig03_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(6.4, 4.0), constrained_layout=True)
    colors = {0.25: "#2F7F75", 0.5: "#C7923E", 0.75: "#A33A46"}
    for q, sub in eff.groupby("bmi_quantile"):
        ax.plot(sub["week_num"], sub["predicted_y"], color=colors[q], label=f"BMI P{int(q*100)}={sub['bmi'].iloc[0]:.1f}")
        ax.fill_between(sub["week_num"], sub["ci_low"], sub["ci_high"], color=colors[q], alpha=0.14, linewidth=0)
    ax.axhline(0.04, color="#555555", linestyle="--", linewidth=1.0)
    ax.set_xlabel("检测孕周 / 周")
    ax.set_ylabel("模型预测Y染色体浓度")
    ax.set_title("主模型下不同BMI水平的局部效应曲线")
    ax.legend()
    savefig(fig, "c1_fig03_partial_effects")

    forest = coeffs[coeffs["model"].isin([main_model_name, "M1_linear_interaction_LMM", "M2_quadratic_LMM", "M3_adjusted_LMM"]) & coeffs["term"].isin(["week_c", "bmi_c", "week_bmi", "week_c2", "bmi_c2", "age_c"])].copy()
    forest.to_csv(FIG_DATA_DIR / "c1_fig04_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(6.6, 4.1), constrained_layout=True)
    terms = list(dict.fromkeys(forest["term"]))
    y_base = np.arange(len(terms))
    models_for_forest = list(dict.fromkeys([main_model_name, "M1_linear_interaction_LMM", "M2_quadratic_LMM", "M3_adjusted_LMM"]))
    offsets = {model: offset for model, offset in zip(models_for_forest, np.linspace(-0.27, 0.27, len(models_for_forest)))}
    palette = ["#2F7F75", "#7666A8", "#C7923E", "#A33A46"]
    colors = {model: color for model, color in zip(models_for_forest, palette)}
    for model, sub in forest.groupby("model"):
        ys = [terms.index(t) + offsets[model] for t in sub["term"]]
        xs = pd.to_numeric(sub["standardized_effect"], errors="coerce")
        lo = pd.to_numeric(sub["ci_low"], errors="coerce")
        hi = pd.to_numeric(sub["ci_high"], errors="coerce")
        coef = pd.to_numeric(sub["coef"], errors="coerce")
        sd_y = main["y_concentration"].std(ddof=1)
        sd_x = [main[t].std(ddof=1) if t in main else np.nan for t in sub["term"]]
        lo_std = lo.to_numpy() * np.asarray(sd_x) / sd_y
        hi_std = hi.to_numpy() * np.asarray(sd_x) / sd_y
        ax.errorbar(xs, ys, xerr=[xs - lo_std, hi_std - xs], fmt="o", color=colors[model], label=model.replace("_LMM", "").replace("_", " "))
    ax.axvline(0, color="#555555", linewidth=0.8)
    ax.set_yticks(y_base, terms)
    ax.set_xlabel("标准化效应及95%置信区间")
    ax.set_title("核心系数森林图")
    ax.legend(loc="lower right")
    savefig(fig, "c1_fig04_coefficients")

    pred = pd.read_csv(RESULT_DIR / "c1_predictions.csv", encoding="utf-8-sig")
    diag = pred[pred["model"].eq(main_model_name)].copy()
    diag.to_csv(FIG_DATA_DIR / "c1_fig05_source.csv", index=False, encoding="utf-8-sig")
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.2), constrained_layout=True)
    axes[0, 0].scatter(diag["conditional_prediction"], diag["observed_y"], s=13, alpha=0.55, color="#2F7F75")
    lim = [min(diag["conditional_prediction"].min(), diag["observed_y"].min()), max(diag["conditional_prediction"].max(), diag["observed_y"].max())]
    axes[0, 0].plot(lim, lim, color="#555555", linestyle="--")
    axes[0, 0].set_title("观测-预测")
    axes[0, 0].set_xlabel("条件拟合预测")
    axes[0, 0].set_ylabel("观测值")
    axes[0, 1].scatter(diag["conditional_prediction"], diag["residual"], s=13, alpha=0.55, color="#C7923E")
    axes[0, 1].axhline(0, color="#555555", linestyle="--")
    axes[0, 1].set_title("残差-拟合")
    axes[0, 1].set_xlabel("条件拟合预测")
    axes[0, 1].set_ylabel("条件残差")
    osm, osr = stats.probplot(diag["residual"], dist="norm", fit=False)
    axes[1, 0].scatter(osm, osr, s=13, alpha=0.55, color="#A33A46")
    axes[1, 0].set_title("Q-Q图")
    axes[1, 0].set_xlabel("理论分位数")
    axes[1, 0].set_ylabel("条件残差分位数")
    mother_resid = diag.groupby("mother_id")["residual"].mean().sort_values().reset_index(drop=True)
    axes[1, 1].plot(np.arange(1, len(mother_resid) + 1), mother_resid, color="#7666A8")
    axes[1, 1].axhline(0, color="#555555", linestyle="--")
    axes[1, 1].set_title("按孕妇聚合残差")
    axes[1, 1].set_xlabel("孕妇排序")
    axes[1, 1].set_ylabel("平均残差")
    savefig(fig, "c1_fig05_diagnostics")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(INPUT))
    args = parser.parse_args()
    started = time.time()
    rng = np.random.default_rng(SEED)
    setup_style()
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    input_path = Path(args.input)
    df = load_data(input_path)
    describe(df)
    corr = cluster_bootstrap_correlations(df, rng)
    fits, metrics, coeffs, comparisons, preds = collect_results(df)
    main_model_name, main_model_reason = choose_main_model(metrics, coeffs, comparisons)
    main_terms, _ = MODEL_SPECS[main_model_name]
    pd.DataFrame(
        [
            {
                "selected_main_model": main_model_name,
                "decision_reason": main_model_reason,
            }
        ]
    ).to_csv(RESULT_DIR / "c1_main_model_decision.csv", index=False, encoding="utf-8-sig")
    diag = diagnostics(df, fits, coeffs)
    sens = sensitivity(df, rng, main_model_name, main_terms)
    make_figures(df, fits, coeffs, main_model_name)
    manifest = {
        "task": "C1-v1.0 stage2 descriptive correlation and models",
        "scope": "C1 only; no C2 BMI grouping or NIPT timing decision generated",
        "input": str(input_path),
        "n_events": int(len(df)),
        "n_mothers": int(df["mother_id"].nunique()),
        "seed": SEED,
        "cluster_bootstrap_n": BOOTSTRAP_N,
        "models": list(fits),
        "selected_main_model": main_model_name,
        "main_model_decision_reason": main_model_reason,
        "outputs": [
            "c1_descriptive_stats.csv",
            "c1_correlations.csv",
            "c1_model_metrics.csv",
            "c1_coefficients.csv",
            "c1_model_comparison.csv",
            "c1_predictions.csv",
            "c1_diagnostics.csv",
            "c1_sensitivity_summary.csv",
            "c1_main_model_decision.csv",
            "figures/*.png",
            "figures/*.svg",
            "figure_data/*.csv",
        ],
        "python": platform.python_version(),
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "scipy": stats.__version__ if hasattr(stats, "__version__") else "available",
        "runtime_seconds": round(time.time() - started, 3),
    }
    (RESULT_DIR / "c1_stage2_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
