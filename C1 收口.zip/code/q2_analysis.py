from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import GroupKFold

from c1_model_analysis import fit_lmm, setup_style, savefig


ROOT = Path(__file__).resolve().parents[1]
C1_DIR = ROOT / "results" / "C1-v1.0"
OUT_DIR = ROOT / "results" / "C2-v1.0"
FIG_DIR = OUT_DIR / "figures"
FIG_DATA_DIR = OUT_DIR / "figure_data"
INPUT = C1_DIR / "c1_clean_events.csv"
TECH_REP = C1_DIR / "c1_technical_replicates.csv"
SEED = 2025
WEEK_GRID = np.arange(11.0, 25.0 + 1e-9, 0.5)
Q_MAIN = 0.90
Q_SENS = [0.85, 0.90, 0.95]
K_CANDIDATES = [3, 4, 5]
MIN_MOTHERS = 35
MIN_EVENTS = 100
MIN_REACHED_MOTHERS = 10
THRESHOLD = 0.04
LAMBDA_GRID = [1, 2, 5, 10]
KAPPA_GRID = [0, 0.5, 1.0, 1.5, 2.0]


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def week_to_cn(week: float | str) -> str:
    if week == "" or pd.isna(week):
        return "未决"
    full = int(math.floor(float(week)))
    days = int(round((float(week) - full) * 7))
    if days == 7:
        full += 1
        days = 0
    return f"{full}周" if days == 0 else f"{full}周+{days}天"


def load_q2_data() -> tuple[pd.DataFrame, pd.DataFrame]:
    df = pd.read_csv(INPUT, encoding="utf-8-sig")
    df = df[df["keep_for_main_model"].astype(str).str.lower().eq("true")].copy()
    for col in ["week_num", "bmi", "y_concentration", "age", "height", "weight"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["mother_id", "week_num", "bmi", "y_concentration"]).copy()
    df["y_ge_4pct"] = df["y_concentration"] >= THRESHOLD

    first = (
        df.sort_values(["mother_id", "week_num", "test_date_key", "event_id"])
        .groupby("mother_id", as_index=False)
        .first()[["mother_id", "week_num", "bmi"]]
        .rename(columns={"week_num": "baseline_week", "bmi": "baseline_bmi"})
    )
    med = df.groupby("mother_id", as_index=False)["bmi"].median().rename(columns={"bmi": "median_bmi"})
    mothers = first.merge(med, on="mother_id", how="left")
    reached = df.groupby("mother_id")["y_ge_4pct"].max().reset_index().rename(columns={"y_ge_4pct": "ever_reached_4pct"})
    mothers = mothers.merge(reached, on="mother_id", how="left")
    return df.merge(mothers, on="mother_id", how="left"), mothers


def add_q2_centering(df: pd.DataFrame, week_mean: float | None = None, bmi_mean: float | None = None) -> tuple[pd.DataFrame, float, float]:
    out = df.copy()
    if week_mean is None:
        week_mean = float(out["week_num"].mean())
    if bmi_mean is None:
        bmi_mean = float(out["baseline_bmi"].mean())
    out["week_c"] = out["week_num"] - week_mean
    out["bmi_c"] = out["baseline_bmi"] - bmi_mean
    out["week_bmi"] = out["week_c"] * out["bmi_c"]
    return out, week_mean, bmi_mean


def fit_q2_lmm(df: pd.DataFrame):
    model_df, week_mean, bmi_mean = add_q2_centering(df)
    fit = fit_lmm("Q2_additive_LMM", model_df, ["week_c", "bmi_c"], "random_intercept", maxiter=500)
    return fit, week_mean, bmi_mean


def predict_obs_prob(fit, week_mean: float, bmi_mean: float, weeks: np.ndarray, bmis: np.ndarray, kappa: float = 1.0, sigma_m: float = 0.0) -> np.ndarray:
    beta0, beta_w, beta_b = fit.beta[:3]
    mu = beta0 + beta_w * (weeks - week_mean) + beta_b * (bmis - bmi_mean)
    sigma_u2 = float(fit.G[0, 0])
    sigma_e2 = float(fit.sigma_e2)
    sigma_within2 = max(sigma_e2 - sigma_m**2, 0.0)
    sigma = math.sqrt(max(sigma_u2 + sigma_within2 + (kappa * sigma_m) ** 2, 1e-12))
    return stats.norm.cdf((mu - THRESHOLD) / sigma)


def group_lcb(p_values: np.ndarray) -> tuple[float, float, float]:
    p = float(np.mean(p_values))
    se = float(np.std(p_values, ddof=1) / math.sqrt(len(p_values))) if len(p_values) > 1 else 0.0
    return p, max(0.0, p - 1.96 * se), min(1.0, p + 1.96 * se)


def estimate_technical_error(n_boot: int, rng: np.random.Generator) -> pd.DataFrame:
    rep = pd.read_csv(TECH_REP, encoding="utf-8-sig")
    rep = rep[pd.to_numeric(rep["tech_rep_n"], errors="coerce").fillna(0).astype(int) == 2].copy()
    rows = []
    diffs = []
    for _, row in rep.iterrows():
        source = str(row["source_raw_rows"]).split(";")
        # Only the event-level range is retained from cleaning, so for two repeats
        # the absolute difference equals the range.
        d = float(row["y_concentration_range"])
        diffs.append(d)
        rows.append({"event_id": row["event_id"], "mother_id": row["mother_id"], "abs_diff": d})
    diffs = np.asarray(diffs, dtype=float)
    sigma_m = math.sqrt(float(np.sum(diffs**2) / (2 * len(diffs)))) if len(diffs) else np.nan
    boots = []
    for _ in range(n_boot):
        sample = rng.choice(diffs, size=len(diffs), replace=True)
        boots.append(math.sqrt(float(np.sum(sample**2) / (2 * len(sample)))))
    out = pd.DataFrame(rows)
    out["sigma_m_estimate"] = sigma_m
    out["sigma_m_ci_low"] = np.percentile(boots, 2.5) if boots else np.nan
    out["sigma_m_ci_high"] = np.percentile(boots, 97.5) if boots else np.nan
    out["bootstrap_n"] = len(boots)
    out["note"] = "技术重复事件仅18个，纯检测误差估计不确定性较大"
    out.to_csv(OUT_DIR / "q2_technical_error.csv", index=False, encoding="utf-8-sig")
    return out


def censor_intervals(events: pd.DataFrame, mothers: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for mid, g in events.sort_values(["mother_id", "week_num"]).groupby("mother_id"):
        g = g.sort_values("week_num")
        above = g[g["y_ge_4pct"]]
        below = g[~g["y_ge_4pct"]]
        reversal = int((g["y_ge_4pct"].astype(int).diff().fillna(0) < 0).any())
        if above.empty:
            kind = "right_censored"
            lo, hi = float(g["week_num"].max()), np.inf
        else:
            first_above_idx = above.index[0]
            first_above_week = float(g.loc[first_above_idx, "week_num"])
            before = g[g["week_num"] < first_above_week]
            if before.empty or bool(g.iloc[0]["y_ge_4pct"]):
                kind = "left_censored"
                lo, hi = 11.0, first_above_week
            else:
                kind = "interval_censored"
                lo, hi = float(before[~before["y_ge_4pct"]]["week_num"].max()), first_above_week
        rows.append(
            {
                "mother_id": mid,
                "baseline_bmi": float(g["baseline_bmi"].iloc[0]),
                "median_bmi": float(g["median_bmi"].iloc[0]),
                "n_events": int(len(g)),
                "weeks": ";".join(f"{x:.3f}" for x in g["week_num"]),
                "y_values": ";".join(f"{x:.6f}" for x in g["y_concentration"]),
                "censor_type": kind,
                "interval_low": lo,
                "interval_high": hi if np.isfinite(hi) else "",
                "threshold_reversal": reversal,
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(OUT_DIR / "q2_mother_baseline.csv", index=False, encoding="utf-8-sig")
    return out


def cut_grid(values: pd.Series) -> list[float]:
    lo = math.ceil(float(values.min()) * 2) / 2
    hi = math.floor(float(values.max()) * 2) / 2
    return [x / 2 for x in range(int(lo * 2) + 1, int(hi * 2))]


def assign_groups(bmi: pd.Series | np.ndarray, cuts: list[float]) -> np.ndarray:
    return np.searchsorted(np.asarray(cuts, dtype=float), np.asarray(bmi, dtype=float), side="right")


def group_label(bounds: tuple[float, float], last: bool) -> str:
    lo, hi = bounds
    return f"[{lo:.1f}, {hi:.1f}{']' if last else ')'}"


def evaluate_group_timing(fit, week_mean, bmi_mean, bmis: np.ndarray, sigma_m: float, q: float = Q_MAIN, kappa: float = 1.0) -> dict:
    if len(bmis) == 0:
        return {"status": "empty_group", "best_week": np.nan, "best_p": np.nan, "best_lcb": np.nan, "grid": []}
    rows = []
    for t in WEEK_GRID:
        probs = predict_obs_prob(fit, week_mean, bmi_mean, np.full(len(bmis), t), bmis, kappa, sigma_m)
        p, lo, hi = group_lcb(probs)
        rows.append({"week": t, "p": p, "lcb": lo, "ucb": hi})
    ok = [r for r in rows if r["lcb"] >= q]
    best = ok[0] if ok else None
    if best is None:
        best_week = np.nan
        status = "undecided"
        best_p = rows[-1]["p"]
        best_lcb = rows[-1]["lcb"]
    else:
        best_week = best["week"]
        status = "ok"
        best_p = best["p"]
        best_lcb = best["lcb"]
    return {"status": status, "best_week": best_week, "best_p": best_p, "best_lcb": best_lcb, "grid": rows}


def individual_reliable_weeks(fit, week_mean, bmi_mean, bmis: np.ndarray, sigma_m: float, q: float = Q_MAIN) -> np.ndarray:
    out = []
    for b in bmis:
        probs = predict_obs_prob(fit, week_mean, bmi_mean, WEEK_GRID, np.full(len(WEEK_GRID), b), 1.0, sigma_m)
        ok = WEEK_GRID[probs >= q]
        out.append(ok[0] if len(ok) else np.nan)
    return np.asarray(out)


def evaluate_partition(name: str, cuts: list[float], mother_df: pd.DataFrame, event_df: pd.DataFrame, fit, week_mean, bmi_mean, sigma_m: float, q: float = Q_MAIN) -> tuple[list[dict], list[dict], dict]:
    mother_df = mother_df.copy()
    mother_df["group"] = assign_groups(mother_df["baseline_bmi"], cuts)
    event_df = event_df.copy()
    event_df["group"] = assign_groups(event_df["baseline_bmi"], cuts)
    bounds = [float(mother_df["baseline_bmi"].min())] + cuts + [float(mother_df["baseline_bmi"].max())]
    group_rows = []
    prob_rows = []
    group_weeks = {}
    feasible = True
    for g in range(len(cuts) + 1):
        gm = mother_df[mother_df["group"].eq(g)]
        ge = event_df[event_df["group"].eq(g)]
        reached = int(gm["ever_reached_4pct"].sum())
        count_ok = len(gm) >= MIN_MOTHERS and len(ge) >= MIN_EVENTS and reached >= MIN_REACHED_MOTHERS
        timing = evaluate_group_timing(fit, week_mean, bmi_mean, gm["baseline_bmi"].to_numpy(float), sigma_m, q)
        if not count_ok:
            feasible = False
        if timing["status"] != "ok":
            feasible = False
        group_weeks[g] = timing["best_week"]
        for pr in timing["grid"]:
            prob_rows.append({"strategy": name, "group_id": g + 1, "week": pr["week"], "p_obs": pr["p"], "lcb95": pr["lcb"], "ucb95": pr["ucb"]})
        group_rows.append(
            {
                "strategy": name,
                "group_id": g + 1,
                "bmi_interval": group_label((bounds[g], bounds[g + 1]), g == len(cuts)),
                "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                "mother_count": int(len(gm)),
                "event_count": int(len(ge)),
                "reached_mother_count": reached,
                "count_constraint_passed": count_ok,
                "status": timing["status"] if count_ok else "count_constraint_failed",
                "recommended_week": timing["best_week"] if timing["status"] == "ok" and count_ok else "",
                "recommended_week_cn": week_to_cn(timing["best_week"]) if timing["status"] == "ok" and count_ok else "未决",
                "p_obs_at_recommend": timing["best_p"],
                "lcb95_at_recommend": timing["best_lcb"],
            }
        )
    indiv_t = individual_reliable_weeks(fit, week_mean, bmi_mean, mother_df["baseline_bmi"].to_numpy(float), sigma_m, q)
    assigned_t = np.asarray([group_weeks[g] for g in mother_df["group"]])
    valid = np.isfinite(indiv_t) & np.isfinite(assigned_t)
    regret = np.maximum(assigned_t[valid] - indiv_t[valid], 0)
    summary = {
        "strategy": name,
        "K": len(cuts) + 1,
        "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
        "feasible": feasible,
        "mean_regret": float(np.mean(regret)) if len(regret) else np.nan,
        "p90_regret": float(np.percentile(regret, 90)) if len(regret) else np.nan,
        "worst_lcb95": min(float(r["lcb95_at_recommend"]) for r in group_rows),
        "undecided_mother_share": float(np.mean(~np.isfinite(assigned_t))),
        "low_risk_group_share": float(np.mean([float(r["recommended_week"]) <= 12 if r["recommended_week"] != "" else False for r in group_rows])),
    }
    return group_rows, prob_rows, summary


def quick_partition_constraints(cuts: list[float], mother_df: pd.DataFrame, event_df: pd.DataFrame) -> tuple[bool, str]:
    mother_group = assign_groups(mother_df["baseline_bmi"], cuts)
    event_group = assign_groups(event_df["baseline_bmi"], cuts)
    reasons = []
    for g in range(len(cuts) + 1):
        gm = mother_df.iloc[np.where(mother_group == g)[0]]
        ge = event_df.iloc[np.where(event_group == g)[0]]
        if len(gm) < MIN_MOTHERS:
            reasons.append(f"group{g+1}_mother<{MIN_MOTHERS}")
        if len(ge) < MIN_EVENTS:
            reasons.append(f"group{g+1}_event<{MIN_EVENTS}")
        if int(gm["ever_reached_4pct"].sum()) < MIN_REACHED_MOTHERS:
            reasons.append(f"group{g+1}_reached<{MIN_REACHED_MOTHERS}")
    return len(reasons) == 0, ";".join(reasons)


def search_partitions(mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, q=Q_MAIN) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    group_rows, prob_rows, cand = optimize_partition_dp(mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, q)
    group_rows.to_csv(OUT_DIR / "q2_optimal_groups.csv", index=False, encoding="utf-8-sig")
    prob_rows.to_csv(OUT_DIR / "q2_reach_probability_by_group_week.csv", index=False, encoding="utf-8-sig")
    cand.to_csv(OUT_DIR / "q2_group_candidates.csv", index=False, encoding="utf-8-sig")
    return group_rows, prob_rows, cand


def interval_record(i: int, j: int, edges: list[float], mother_df: pd.DataFrame, event_df: pd.DataFrame, fit, week_mean, bmi_mean, sigma_m: float, q: float, indiv_t_map: dict[str, float]) -> dict | None:
    lo, hi = edges[i], edges[j]
    gm = mother_df[(mother_df["baseline_bmi"] >= lo) & (mother_df["baseline_bmi"] < hi)].copy()
    ge = event_df[(event_df["baseline_bmi"] >= lo) & (event_df["baseline_bmi"] < hi)].copy()
    if len(gm) < MIN_MOTHERS or len(ge) < MIN_EVENTS or int(gm["ever_reached_4pct"].sum()) < MIN_REACHED_MOTHERS:
        return None
    timing = evaluate_group_timing(fit, week_mean, bmi_mean, gm["baseline_bmi"].to_numpy(float), sigma_m, q)
    if timing["status"] != "ok":
        return None
    indiv = np.asarray([indiv_t_map[m] for m in gm["mother_id"]], dtype=float)
    valid = np.isfinite(indiv)
    regret = np.maximum(float(timing["best_week"]) - indiv[valid], 0)
    return {
        "i": i,
        "j": j,
        "lo": lo,
        "hi": hi,
        "mother_count": int(len(gm)),
        "event_count": int(len(ge)),
        "reached_mother_count": int(gm["ever_reached_4pct"].sum()),
        "best_week": float(timing["best_week"]),
        "best_p": float(timing["best_p"]),
        "best_lcb": float(timing["best_lcb"]),
        "regret_sum": float(np.sum(regret)) if len(regret) else 0.0,
        "regret_values": regret,
        "timing_grid": timing["grid"],
    }


def optimize_partition_dp(mother_df: pd.DataFrame, event_df: pd.DataFrame, fit, week_mean: float, bmi_mean: float, sigma_m: float, q: float) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    grid = cut_grid(mother_df["baseline_bmi"])
    edges = [math.floor(float(mother_df["baseline_bmi"].min()) * 2) / 2] + grid + [math.ceil(float(mother_df["baseline_bmi"].max()) * 2) / 2 + 0.5]
    edges = sorted(dict.fromkeys(edges))
    indiv = individual_reliable_weeks(fit, week_mean, bmi_mean, mother_df["baseline_bmi"].to_numpy(float), sigma_m, q)
    indiv_t_map = dict(zip(mother_df["mother_id"], indiv))

    intervals: dict[tuple[int, int], dict] = {}
    for i in range(len(edges) - 1):
        for j in range(i + 1, len(edges)):
            rec = interval_record(i, j, edges, mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, q, indiv_t_map)
            if rec is not None:
                intervals[(i, j)] = rec

    candidate_rows = []
    best_by_k: dict[int, tuple[float, list[dict]]] = {}
    end = len(edges) - 1
    for K in K_CANDIDATES:
        dp: list[dict[int, tuple[float, list[dict]]]] = [dict() for _ in range(K + 1)]
        dp[0][0] = (0.0, [])
        for k in range(1, K + 1):
            for j in range(1, end + 1):
                best = None
                for i in range(0, j):
                    if i not in dp[k - 1] or (i, j) not in intervals:
                        continue
                    prev_score, prev_path = dp[k - 1][i]
                    rec = intervals[(i, j)]
                    score = prev_score + rec["regret_sum"]
                    if best is None or score < best[0]:
                        best = (score, prev_path + [rec])
                if best is not None:
                    dp[k][j] = best
        if end in dp[K]:
            score, path = dp[K][end]
            regrets = np.concatenate([p["regret_values"] for p in path if len(p["regret_values"])])
            cutpoints = [p["hi"] for p in path[:-1]]
            row = {
                "strategy": f"optimized_K{K}",
                "K": K,
                "cutpoints": ";".join(f"{c:.1f}" for c in cutpoints),
                "feasible": True,
                "mean_regret": float(np.mean(regrets)) if len(regrets) else np.nan,
                "p90_regret": float(np.percentile(regrets, 90)) if len(regrets) else np.nan,
                "worst_lcb95": min(p["best_lcb"] for p in path),
                "undecided_mother_share": 0.0,
                "low_risk_group_share": float(np.mean([p["best_week"] <= 12 for p in path])),
                "search_method": "dynamic_programming_best_partition_by_K",
                "feasible_interval_count": len(intervals),
            }
            candidate_rows.append(row)
            best_by_k[K] = (float(row["mean_regret"]), path)
        else:
            candidate_rows.append(
                {
                    "strategy": f"optimized_K{K}",
                    "K": K,
                    "cutpoints": "",
                    "feasible": False,
                    "mean_regret": np.nan,
                    "p90_regret": np.nan,
                    "worst_lcb95": np.nan,
                    "undecided_mother_share": np.nan,
                    "low_risk_group_share": np.nan,
                    "search_method": "dynamic_programming_best_partition_by_K",
                    "feasible_interval_count": len(intervals),
                    "failed_reason": "no feasible DP path under group constraints and reliability threshold",
                }
            )

    feasible_rows = [r for r in candidate_rows if r["feasible"]]
    group_out = []
    prob_out = []
    if feasible_rows:
        best_row = sorted(feasible_rows, key=lambda r: (r["mean_regret"], r["p90_regret"], r["K"]))[0]
        path = best_by_k[int(best_row["K"])][1]
        for group_id, rec in enumerate(path, 1):
            last = group_id == len(path)
            group_out.append(
                {
                    "strategy": "optimized_main",
                    "group_id": group_id,
                    "bmi_interval": group_label((rec["lo"], rec["hi"]), last),
                    "cutpoints": best_row["cutpoints"],
                    "mother_count": rec["mother_count"],
                    "event_count": rec["event_count"],
                    "reached_mother_count": rec["reached_mother_count"],
                    "count_constraint_passed": True,
                    "status": "ok",
                    "recommended_week": rec["best_week"],
                    "recommended_week_cn": week_to_cn(rec["best_week"]),
                    "p_obs_at_recommend": rec["best_p"],
                    "lcb95_at_recommend": rec["best_lcb"],
                }
            )
            for pr in rec["timing_grid"]:
                prob_out.append({"strategy": "optimized_main", "group_id": group_id, "week": pr["week"], "p_obs": pr["p"], "lcb95": pr["lcb"], "ucb95": pr["ucb"]})
    return pd.DataFrame(group_out), pd.DataFrame(prob_out), pd.DataFrame(candidate_rows)


def baseline_strategies(mother_df, event_df, fit, week_mean, bmi_mean, sigma_m) -> pd.DataFrame:
    examples = {
        "unified": [],
        "problem_example_5groups": [28, 32, 36, 40],
    }
    # Equal-frequency cuts are rounded to the permitted 0.5 grid.
    for K in K_CANDIDATES:
        qs = [i / K for i in range(1, K)]
        cuts = sorted(set(round(float(mother_df["baseline_bmi"].quantile(q)) * 2) / 2 for q in qs))
        if len(cuts) == K - 1:
            examples[f"equal_freq_K{K}"] = cuts
    rows = []
    for name, cuts in examples.items():
        _, _, summary = evaluate_partition(name, cuts, mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, Q_MAIN)
        rows.append(summary)
    opt = pd.read_csv(OUT_DIR / "q2_group_candidates.csv", encoding="utf-8-sig")
    feasible = opt[opt["feasible"].astype(str).str.lower().eq("true")].copy()
    if not feasible.empty:
        rows.append(feasible.sort_values(["mean_regret", "p90_regret", "K"]).iloc[0].to_dict())
    out = pd.DataFrame(rows)
    out.to_csv(OUT_DIR / "q2_strategy_comparison.csv", index=False, encoding="utf-8-sig")
    return out


def outer_cv(events: pd.DataFrame, rng: np.random.Generator, sigma_m: float) -> pd.DataFrame:
    splitter = GroupKFold(n_splits=5)
    rows = []
    groups = events["mother_id"].to_numpy()
    for fold, (tr, va) in enumerate(splitter.split(events, groups=groups), 1):
        train = events.iloc[tr].copy()
        valid = events.iloc[va].copy()
        fit, wm, bm = fit_q2_lmm(train)
        mother_train = build_mother_table(train)
        _, _, cand = search_partitions_tmp(mother_train, train, fit, wm, bm, sigma_m)
        feasible = cand[cand["feasible"]].copy()
        if feasible.empty:
            rows.append({"fold": fold, "status": "no_feasible_partition"})
            continue
        best = feasible.sort_values(["mean_regret", "p90_regret", "K"]).iloc[0]
        cuts = [float(x) for x in str(best["cutpoints"]).split(";") if x]
        train_group_rows, _, _ = evaluate_partition(f"cv_train_{fold}", cuts, mother_train, train, fit, wm, bm, sigma_m)
        rec_map = {int(r["group_id"]) - 1: float(r["recommended_week"]) for r in train_group_rows if r["recommended_week"] != ""}
        mother_valid = build_mother_table(valid)
        mother_valid["group"] = assign_groups(mother_valid["baseline_bmi"], cuts)
        indiv_t = individual_reliable_weeks(fit, wm, bm, mother_valid["baseline_bmi"].to_numpy(float), sigma_m)
        assigned_t = np.asarray([rec_map.get(int(g), np.nan) for g in mother_valid["group"]])
        valid_time = np.isfinite(indiv_t) & np.isfinite(assigned_t)
        regret = np.maximum(assigned_t[valid_time] - indiv_t[valid_time], 0)
        preds = []
        obs = []
        for _, row in mother_valid.iterrows():
            rec = rec_map.get(int(row["group"]), np.nan)
            if not np.isfinite(rec):
                continue
            p = predict_obs_prob(fit, wm, bm, np.array([rec]), np.array([row["baseline_bmi"]]), 1.0, sigma_m)[0]
            mg = valid[valid["mother_id"].eq(row["mother_id"])].copy()
            nearest = mg.iloc[(mg["week_num"] - rec).abs().argsort().iloc[0]]
            preds.append(float(p))
            obs.append(float(nearest["y_ge_4pct"]))
        preds = np.asarray(preds)
        obs = np.asarray(obs)
        rows.append(
            {
                "fold": fold,
                "status": "ok",
                "train_mothers": int(train["mother_id"].nunique()),
                "valid_mothers": int(valid["mother_id"].nunique()),
                "selected_K": int(best["K"]),
                "cutpoints": best["cutpoints"],
                "valid_brier_score": float(np.mean((preds - obs) ** 2)) if len(preds) else np.nan,
                "nearest_event_hit_rate": float(np.mean(obs)) if len(obs) else np.nan,
                "mean_regret": float(np.mean(regret)) if len(regret) else np.nan,
                "p90_regret": float(np.percentile(regret, 90)) if len(regret) else np.nan,
                "undecided_mother_share": float(np.mean(~np.isfinite(assigned_t))),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(OUT_DIR / "q2_outer_cv_results.csv", index=False, encoding="utf-8-sig")
    return out


def build_mother_table(events: pd.DataFrame) -> pd.DataFrame:
    first = (
        events.sort_values(["mother_id", "week_num", "test_date_key", "event_id"])
        .groupby("mother_id", as_index=False)
        .first()[["mother_id", "week_num", "bmi", "baseline_bmi", "median_bmi"]]
        .rename(columns={"week_num": "baseline_week", "bmi": "event_bmi_at_first"})
    )
    reached = events.groupby("mother_id")["y_ge_4pct"].max().reset_index().rename(columns={"y_ge_4pct": "ever_reached_4pct"})
    return first.merge(reached, on="mother_id", how="left")


def search_partitions_tmp(mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, q=Q_MAIN):
    return optimize_partition_dp(mother_df, event_df, fit, week_mean, bmi_mean, sigma_m, q)


def bootstrap_groups(events: pd.DataFrame, n_boot: int, rng: np.random.Generator, sigma_m: float) -> pd.DataFrame:
    base = events.reset_index(drop=True)
    mothers = base["mother_id"].drop_duplicates().to_numpy()
    mother_to_idx = {m: idx.to_numpy() for m, idx in base.groupby("mother_id").groups.items()}
    rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 50 == 0:
            print(f"Q2 bootstrap {b}/{n_boot}", flush=True)
        pieces = []
        chosen = rng.choice(mothers, size=len(mothers), replace=True)
        for draw_no, mid in enumerate(chosen, 1):
            part = base.iloc[mother_to_idx[mid]].copy()
            part["mother_id"] = f"{mid}__boot{draw_no}"
            pieces.append(part)
        sample = pd.concat(pieces, ignore_index=True)
        try:
            fit, wm, bm = fit_q2_lmm(sample)
            md = build_mother_table(sample)
            _, _, cand = search_partitions_tmp(md, sample, fit, wm, bm, sigma_m)
            feasible = cand[cand["feasible"]].copy()
            if feasible.empty:
                rows.append({"bootstrap_id": b, "status": "no_feasible_partition", "converged": fit.converged})
                continue
            best = feasible.sort_values(["mean_regret", "p90_regret", "K"]).iloc[0]
            cuts = [float(x) for x in str(best["cutpoints"]).split(";") if x]
            group_rows, _, _ = evaluate_partition("boot", cuts, md, sample, fit, wm, bm, sigma_m)
            row = {"bootstrap_id": b, "status": "ok", "converged": fit.converged, "K": int(best["K"]), "cutpoints": best["cutpoints"]}
            for g in group_rows:
                row[f"group{g['group_id']}_week"] = g["recommended_week"]
            rows.append(row)
        except Exception as exc:
            rows.append({"bootstrap_id": b, "status": f"failed: {exc}", "converged": False})
    out = pd.DataFrame(rows)
    out.to_csv(OUT_DIR / "q2_bootstrap_groups.csv", index=False, encoding="utf-8-sig")
    return out


def error_sensitivity(mother_df, event_df, fit, wm, bm, sigma_m) -> pd.DataFrame:
    rows = []
    for q in Q_SENS:
        for kappa in KAPPA_GRID:
            _, _, cand = search_partitions_tmp(mother_df, event_df, fit, wm, bm, sigma_m * kappa, q)
            feasible = cand[cand["feasible"]].copy()
            if feasible.empty:
                rows.append({"q": q, "kappa": kappa, "status": "no_feasible_partition"})
                continue
            best = feasible.sort_values(["mean_regret", "p90_regret", "K"]).iloc[0]
            rows.append({"q": q, "kappa": kappa, "status": "ok", "K": int(best["K"]), "cutpoints": best["cutpoints"], "mean_regret": best["mean_regret"], "p90_regret": best["p90_regret"]})
    out = pd.DataFrame(rows)
    out.to_csv(OUT_DIR / "q2_error_sensitivity.csv", index=False, encoding="utf-8-sig")
    return out


def interval_validation(censor_df: pd.DataFrame) -> pd.DataFrame:
    tmp = censor_df.copy()
    tmp["upper_for_trend"] = pd.to_numeric(tmp["interval_high"], errors="coerce")
    finite = tmp[tmp["upper_for_trend"].notna()].copy()
    pear = stats.pearsonr(finite["baseline_bmi"], finite["upper_for_trend"]) if len(finite) > 2 else None
    spear = stats.spearmanr(finite["baseline_bmi"], finite["upper_for_trend"]) if len(finite) > 2 else None
    out = pd.DataFrame(
        [
            {
                "method": "interval_censor_empirical_upper_trend_not_formal_AFT",
                "n_finite_upper": int(len(finite)),
                "bmi_pearson_with_upper": pear.statistic if pear else np.nan,
                "bmi_pearson_p": pear.pvalue if pear else np.nan,
                "bmi_spearman_with_upper": spear.statistic if spear else np.nan,
                "bmi_spearman_p": spear.pvalue if spear else np.nan,
                "direction_consistent_with_main": bool(spear.statistic > 0) if spear else False,
                "note": "该文件仅为区间删失经验验证，不是正式AFT生存模型",
            }
        ]
    )
    out.to_csv(OUT_DIR / "q2_interval_censor_validation.csv", index=False, encoding="utf-8-sig")
    return out


def make_q2_figures(groups: pd.DataFrame, probs: pd.DataFrame, censor: pd.DataFrame, comp: pd.DataFrame, err: pd.DataFrame, boot: pd.DataFrame) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    FIG_DATA_DIR.mkdir(parents=True, exist_ok=True)
    plt.rcParams["savefig.dpi"] = 300

    censor.to_csv(FIG_DATA_DIR / "q2_fig01_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4.2), constrained_layout=True)
    sample = censor.sort_values("baseline_bmi").reset_index(drop=True)
    colors = {"left_censored": "#2F7F75", "interval_censored": "#C7923E", "right_censored": "#A33A46"}
    for kind, sub in sample.groupby("censor_type"):
        y = sub.index
        lo = pd.to_numeric(sub["interval_low"], errors="coerce")
        hi = pd.to_numeric(sub["interval_high"], errors="coerce").fillna(25)
        ax.hlines(y, lo, hi, color=colors.get(kind, "#555555"), alpha=0.75, linewidth=1.1, label=kind)
    ax.set_xlabel("孕周 / 周")
    ax.set_ylabel("按BMI排序的孕妇")
    ax.set_title("观测首达标区间与删失类型")
    ax.legend(loc="lower right")
    fig.savefig(FIG_DIR / "q2_fig01_bmi_first_pass_interval.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig01_bmi_first_pass_interval.svg", bbox_inches="tight")
    plt.close(fig)

    main_prob = probs[probs["strategy"].eq("optimized_main")].copy()
    main_prob.to_csv(FIG_DATA_DIR / "q2_fig03_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4.2), constrained_layout=True)
    for gid, sub in main_prob.groupby("group_id"):
        ax.plot(sub["week"], sub["p_obs"], label=f"第{gid}组")
        ax.fill_between(sub["week"], sub["lcb95"], sub["ucb95"], alpha=0.12)
    ax.axhline(Q_MAIN, color="#555555", linestyle="--", linewidth=1)
    ax.set_xlabel("孕周 / 周")
    ax.set_ylabel("一次检测达标概率")
    ax.set_title("优化BMI分组下的达标概率曲线")
    ax.legend()
    fig.savefig(FIG_DIR / "q2_fig02_probability_surface.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig02_probability_surface.svg", bbox_inches="tight")
    plt.close(fig)

    opt = groups[groups["strategy"].eq("optimized_main")].copy()
    opt.to_csv(FIG_DATA_DIR / "q2_fig03_groups_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 3.8), constrained_layout=True)
    y = pd.to_numeric(opt["recommended_week"], errors="coerce")
    ax.bar(opt["bmi_interval"], y, color=["#2F7F75", "#C7923E", "#A33A46", "#7666A8", "#6E7F3F"][: len(opt)])
    ax.set_xlabel("BMI区间")
    ax.set_ylabel("推荐孕周")
    ax.set_title("BMI分组与推荐时点草案")
    fig.savefig(FIG_DIR / "q2_fig03_optimal_groups.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig03_optimal_groups.svg", bbox_inches="tight")
    plt.close(fig)

    comp.to_csv(FIG_DATA_DIR / "q2_fig04_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 3.8), constrained_layout=True)
    ax.bar(comp["strategy"], pd.to_numeric(comp["mean_regret"], errors="coerce"), color="#C7923E")
    ax.set_ylabel("平均延迟遗憾 / 周")
    ax.set_title("策略平均Regret对比")
    ax.tick_params(axis="x", rotation=25)
    fig.savefig(FIG_DIR / "q2_fig04_strategy_comparison.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig04_strategy_comparison.svg", bbox_inches="tight")
    plt.close(fig)

    err.to_csv(FIG_DATA_DIR / "q2_fig05_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 3.8), constrained_layout=True)
    ok = err[err["status"].eq("ok")].copy()
    for q, sub in ok.groupby("q"):
        ax.plot(sub["kappa"], sub["mean_regret"], marker="o", label=f"q={q:.2f}")
    ax.set_xlabel("检测误差倍数 kappa")
    ax.set_ylabel("平均延迟遗憾 / 周")
    ax.set_title("检测误差敏感性")
    ax.legend()
    fig.savefig(FIG_DIR / "q2_fig05_error_sensitivity.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig05_error_sensitivity.svg", bbox_inches="tight")
    plt.close(fig)

    boot.to_csv(FIG_DATA_DIR / "q2_fig06_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 3.8), constrained_layout=True)
    okb = boot[boot["status"].eq("ok")].copy()
    if not okb.empty:
        okb["cutpoints"].value_counts().head(12).sort_values().plot(kind="barh", ax=ax, color="#2F7F75")
    ax.set_xlabel("bootstrap选择次数")
    ax.set_title("BMI分界点bootstrap稳定性")
    fig.savefig(FIG_DIR / "q2_fig06_bootstrap_stability.png", dpi=300, bbox_inches="tight")
    fig.savefig(FIG_DIR / "q2_fig06_bootstrap_stability.svg", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=200)
    args = parser.parse_args()
    started = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    setup_style()
    rng = np.random.default_rng(SEED)

    events, mothers = load_q2_data()
    censor = censor_intervals(events, mothers)
    fit, week_mean, bmi_mean = fit_q2_lmm(events)
    coef_rows = []
    for term, beta, se, lo, hi, p in zip(fit.fixed_terms, fit.beta, fit.se, fit.ci_low, fit.ci_high, fit.p_values):
        coef_rows.append({"term": term, "coef": beta, "std_error": se, "ci_low": lo, "ci_high": hi, "p_value": p})
    coef = pd.DataFrame(coef_rows)
    coef["sigma_u"] = math.sqrt(float(fit.G[0, 0]))
    coef["sigma_e"] = math.sqrt(float(fit.sigma_e2))
    coef["converged"] = fit.converged
    coef["message"] = fit.message
    coef.to_csv(OUT_DIR / "q2_lmm_coefficients.csv", index=False, encoding="utf-8-sig")

    tech = estimate_technical_error(1000, rng)
    sigma_m = float(tech["sigma_m_estimate"].iloc[0])
    group_rows, prob_rows, candidates = search_partitions(mothers, events, fit, week_mean, bmi_mean, sigma_m, Q_MAIN)
    comp = baseline_strategies(mothers, events, fit, week_mean, bmi_mean, sigma_m)
    cv = outer_cv(events, rng, sigma_m)
    boot = bootstrap_groups(events, args.bootstrap, rng, sigma_m)
    err = error_sensitivity(mothers, events, fit, week_mean, bmi_mean, sigma_m)
    interval = interval_validation(censor)

    opt = group_rows[group_rows["strategy"].eq("optimized_main")].copy()
    opt.to_csv(OUT_DIR / "q2_decision_summary.csv", index=False, encoding="utf-8-sig")
    make_q2_figures(group_rows, prob_rows, censor, comp, err, boot)

    manifest = {
        "task": "C2-v1.0 first-run BMI grouping and NIPT timing draft",
        "status": "draft_not_frozen",
        "scope": "Q2 only; no age/height/weight/IVF/sequencing-quality multivariate decision",
        "input": str(INPUT),
        "input_sha256": file_sha256(INPUT),
        "n_events": int(len(events)),
        "n_mothers": int(events["mother_id"].nunique()),
        "week_grid": [float(WEEK_GRID[0]), float(WEEK_GRID[-1]), 0.5],
        "q_main": Q_MAIN,
        "bootstrap_n": args.bootstrap,
        "seed": SEED,
        "runtime_seconds": round(time.time() - started, 3),
        "python": platform.python_version(),
    }
    (OUT_DIR / "q2_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
