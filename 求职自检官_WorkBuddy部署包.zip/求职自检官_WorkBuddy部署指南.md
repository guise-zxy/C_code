# 求职自检官 — WorkBuddy Skill 部署指南

> 将 AI 求职自检官安装到你的 WorkBuddy 中，即可在对话中随时调用 JD 解析与经历匹配功能。

---

## 一、这是什么

「求职自检官」是一个 WorkBuddy Skill，能帮你：

1. **JD 解析**：粘贴一篇岗位描述 → 输出结构化能力画像（核心能力拆解、真实含义、面试官判断方式、需要准备的证据、优先级）
2. **经历匹配**：同时提供 JD + 个人经历 → 额外输出能力匹配评分（1-5 分）、证据差距、简历/面试表达建议

底层调用 DeepSeek API，无需安装任何第三方 Python 包。

---

## 二、压缩包内容

```
求职自检官/
├── SKILL.md                  # Skill 定义文件（触发词、工作流程、参数说明）
├── scripts/
│   └── analyze_jd.py         # 核心分析脚本（Python，仅依赖标准库）
└── references/
    └── prompts.md            # Prompt 模板参考（调试用，正常使用无需关注）
```

---

## 三、前置条件

| 条件 | 说明 |
|------|------|
| WorkBuddy 桌面版 | 已安装并登录，版本 ≥ 1.0 |
| Python 3.8+ | 运行 `python --version` 确认可用 |
| 网络 | 需能访问 `https://api.deepseek.com` |

> **关于 API Key**：脚本已内置一个 DeepSeek API Key，开箱即用。如果内置 Key 额度耗尽，可在调用时通过 `--api-key` 参数传入你自己的 Key。

---

## 四、安装步骤

### 方法一：手动安装（推荐）

1. 解压压缩包，得到 `求职自检官/` 文件夹
2. 将整个文件夹复制到 WorkBuddy 的用户级 Skill 目录：

   **Windows**：
   ```
   C:\Users\<你的用户名>\.workbuddy\skills\求职自检官\
   ```

   **macOS / Linux**：
   ```
   ~/.workbuddy/skills/求职自检官/
   ```

3. 确认目录结构如下：
   ```
   ~/.workbuddy/skills/求职自检官/
   ├── SKILL.md
   ├── scripts/
   │   └── analyze_jd.py
   └── references/
       └── prompts.md
   ```
4. 重启 WorkBuddy（或新建一个对话），Skill 即可生效

### 方法二：在对话中安装

在 WorkBuddy 对话中直接说：

> "帮我安装一个 Skill，压缩包在 [路径]"

让 WorkBuddy 的 Agent 自动帮你完成复制。

---

## 五、验证安装

1. 打开 WorkBuddy，新建一个对话
2. 输入以下任一触发词测试：
   - "帮我解析一个 JD"
   - "岗位分析"
   - "求职自检"
3. 如果 Skill 被正确加载，Agent 会主动调用 `analyze_jd.py` 脚本执行分析

### 命令行直接验证

```bash
python ~/.workbuddy/skills/求职自检官/scripts/analyze_jd.py \
  --job-title "产品经理实习生" \
  --jd-text "负责需求分析，与开发团队协作推动产品落地" \
  --mode jd-parse
```

如果返回包含 `coreAbilities` 的 JSON，说明安装成功。

---

## 六、使用方式

安装完成后，在 WorkBuddy 对话中自然表达即可，不需要记命令。

### 场景一：只分析 JD

直接粘贴 JD 文本：

> "帮我分析这个岗位：[粘贴 JD 全文]"

Agent 会自动推断岗位名称、调用脚本、将结果以清晰的卡片格式展示。

### 场景二：JD + 经历匹配

同时提供 JD 和你的经历：

> "我投这个岗，帮我看看匹配度。岗位：[JD]。我的经历：[经历描述]"

Agent 会先展示 JD 能力画像，再展示匹配评分和简历/面试建议。

### 场景三：通过 URL 提供 JD

> "帮我解析这个岗位的 JD：https://xxx.com/job/123"

Agent 会先用 WebFetch 抓取页面内容，再调用脚本分析。

### 场景四：口语化描述岗位

> "我想看看鹅厂的 AI-HR 培训生，大概就是用 AI 做人力资源那些事"

Agent 会直接将你的描述作为 JD 文本传入，同样能产出分析结果。

---

## 七、API Key 管理

### 使用内置 Key（默认）

安装后直接可用，无需任何配置。内置 Key 有共享额度限制，多人使用时可能较快耗尽。

### 使用自己的 Key

1. 前往 [DeepSeek 开放平台](https://platform.deepseek.com/) 注册账号
2. 在「API Keys」页面创建新 Key
3. 在对话中告诉 Agent：`"用这个 API Key：sk-xxxx"`，Agent 会通过 `--api-key` 参数传入

### 替换内置 Key（永久修改）

编辑 `scripts/analyze_jd.py`，找到第 29 行：

```python
BUILTIN_API_KEY = "sk-0d725255b5804cc69975d4918c7d8762"
```

将值替换为你自己的 Key 即可。

---

## 八、常见问题

### Q: 运行脚本报 `python: command not found`

Python 未安装或未加入 PATH。安装 Python 3.8+ 并确保 `python --version` 可正常输出。

### Q: 返回 `API 调用失败 (401)`

API Key 无效或过期。请使用自己的 DeepSeek API Key。

### Q: 返回 `API 调用失败 (429)`

请求频率过高或额度耗尽。稍后重试，或更换自己的 API Key。

### Q: 返回 `网络错误`

无法连接 `api.deepseek.com`。检查网络连接和代理设置。

### Q: 返回 JSON 解析失败

DeepSeek 模型偶尔会返回非标准 JSON。脚本已做了基本的 Markdown 代码块清理，但如果模型输出了其他格式的额外文本，可能导致解析失败。重新运行一次通常可以解决。

### Q: Skill 没有被触发

- 确认 `SKILL.md` 放在了 `~/.workbuddy/skills/求职自检官/` 目录下
- 确认文件名是 `SKILL.md`（大写）
- 重启 WorkBuddy 或新建对话再试

### Q: 分析结果不够准确

- JD 文本越完整、越正式，分析结果越准确
- 经历描述尽量具体：做了什么、用了什么技术、取得了什么成果
- 可以用 `--mode jd-parse` 先单独解析 JD，再基于解析结果有针对性地准备经历描述

---

## 九、文件说明

| 文件 | 作用 | 是否必需 |
|------|------|----------|
| `SKILL.md` | Skill 定义：触发词、工作流程、参数说明 | ✅ 必需 |
| `scripts/analyze_jd.py` | 核心分析脚本 | ✅ 必需 |
| `references/prompts.md` | Prompt 模板参考 | ❌ 可选（调试用） |

---

## 十、卸载

删除 Skill 目录即可：

```bash
# Windows
rmdir /s "C:\Users\<用户名>\.workbuddy\skills\求职自检官"

# macOS / Linux
rm -rf ~/.workbuddy/skills/求职自检官
```

重启 WorkBuddy 后 Skill 不再生效。

---

> 📌 本 Skill 由张馨怡开发，基于其 AI 求职自检官 Web 应用改编。原始项目部署于 Vercel，技术栈 Next.js + DeepSeek。
