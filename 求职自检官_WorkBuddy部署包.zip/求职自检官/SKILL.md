---
name: 求职自检官
description: >
  「AI 求职自检官」技能，对岗位 JD 进行结构化能力拆解（JD 解析），
  并能将用户个人经历与岗位要求进行匹配度分析（经历匹配）。
  适用于求职准备、简历优化、面试前能力诊断等场景。
  当用户提及"JD解析""经历匹配""岗位分析""能力诊断""求职自检""🔍📊"等关键词时触发。
trigger_keywords:
  - JD解析
  - 经历匹配
  - 岗位分析
  - 能力诊断
  - 求职自检
  - JD分析
  - 岗位画像
  - matching
agent_created: true
---

# 求职自检官 — AI 岗位能力诊断技能

## 概述

基于 DeepSeek API 的 JD 解析与能力匹配分析工具。调用该技能可完成：

1. **JD 解析**：输入岗位 JD 文本 → 输出结构化能力画像（核心能力拆解、每项能力的真实含义、面试官判断方式、需要准备的证据、优先级评估）
2. **经历匹配**：同时输入 JD 和个人经历 → 额外输出能力匹配评分（1-5 分）、证据差距分析、简历表达建议、面试表达建议

## 何时触发

- 用户粘贴了一篇岗位描述（JD）并要求"分析一下这个 JD"
- 用户问"这个岗位看重什么能力"、"这个 JD 到底在要求什么"
- 用户说"我的经历和这个岗位匹配吗"、"帮我看看能不能投这个岗"
- 用户正在准备面试，需要了解岗位能力画像

> **注意**：本文中的所有 `~/.workbuddy/skills/` 路径，在工作时需替换为实际的绝对路径（例如 `C:\Users\具体用户名\.workbuddy\skills\`），因为 WorkBuddy 运行环境的 home 目录可能与系统默认不同。

## 核心脚本

该技能的核心逻辑封装在 `scripts/analyze_jd.py` 中。

### 脚本路径

```
~/.workbuddy/skills/求职自检官/scripts/analyze_jd.py
```

### 依赖

- Python 3.8+（仅使用了标准库 `urllib` 和 `json`，无需安装第三方包）
- 可访问公网（需调用 `https://api.deepseek.com`）

### 脚本用法

```bash
python analyze_jd.py \
  --job-title "岗位名称" \
  --jd-text "岗位 JD 正文" \
  [--experience "个人经历描述"] \
  [--mode jd-parse|experience-match|full] \
  [--api-key "自定义Key"] \
  [--output "输出文件路径"]
```

#### 参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `--job-title` | 是 | 目标岗位名称（如"产品经理实习生"） |
| `--jd-text` | 是 | 岗位描述的完整文本 |
| `--experience` | 否 | 用户的个人经历/项目经验描述。提供后自动执行经历匹配 |
| `--mode` | 否 | 分析模式：`jd-parse`（仅解析）、`experience-match`（仅匹配）、`full`（自动判断，默认） |
| `--api-key` | 否 | 自定义 DeepSeek API Key。不传时使用内置 key |
| `--output` | 否 | 将 JSON 结果写入指定文件 |

#### 返回值

脚本将分析结果以 JSON 格式写入 stdout。若同时提供了 `--jd-text` 和 `--experience`，输出将同时包含 `jdAnalysis` 和 `experienceMatch` 两个字段。

**JD 解析返回结构**（`jdAnalysis` 字段）：
```json
{
  "jobTitle": "目标岗位名称",
  "coreAbilities": [
    {
      "name": "能力名称",
      "realMeaning": "真实含义（具体事例说明）",
      "interviewerJudge": "面试官判断方式",
      "evidenceNeeded": "需准备的经历/证据",
      "priority": "high | medium | low"
    }
  ],
  "priorityFocus": "建议优先补强项",
  "nextSteps": "下一步具体建议"
}
```

**经历匹配返回结构**（`experienceMatch` 字段）：
```json
{
  "jobTitle": "目标岗位名称",
  "experience": "用户经历概括",
  "matchedAbilities": [
    {
      "name": "能力名称",
      "score": 3.5,
      "evidence": "已有证据分析",
      "gap": "证据不足之处",
      "resumeAdvice": "简历表达建议",
      "interviewAdvice": "面试表达建议"
    }
  ],
  "overallMatch": "整体匹配度评估",
  "nextSteps": "下一步补强建议"
}
```

## 工作流程

### 场景一：用户只提供了 JD，需要解析

1. 确认用户是否指定了目标岗位名称。若用户未提供，从 JD 文本第一行或语境中推断。
2. 调用脚本：
   ```bash
   python ~/.workbuddy/skills/求职自检官/scripts/analyze_jd.py \
     --job-title "推断出的岗位名称" \
     --jd-text "用户提供的 JD 文本"
   ```
3. 将返回的 JSON 结果清晰呈现给用户：
   - 拆分 `coreAbilities` 列表，每个能力用卡片式结构显示（名称、真实含义、面试官判断方式、证据建议、优先级）
   - 高亮 `priorityFocus`（建议优先补强项）
   - 展示 `nextSteps`（下一步建议）
4. 若用户使用 URL 提供 JD，先通过 `WebFetch` 获取页面内容，提取 JD 文本后再调用脚本。

### 场景二：用户同时提供了 JD 和个人经历，需要匹配分析

1. 确认用户是否提供了目标岗位名称。若未提供，推断或询问。
2. 调用脚本时同时传入 `--jd-text` 和 `--experience`：
   ```bash
   python ~/.workbuddy/skills/求职自检官/scripts/analyze_jd.py \
     --job-title "岗位名称" \
     --jd-text "JD 文本" \
     --experience "用户描述的个人经历"
   ```
3. 展示结果时先展示 JD 解析部分（`jdAnalysis`），再展示经历匹配部分（`experienceMatch`）。
4. 对经历匹配部分：
   - 每项能力用评分条 + 分数展示
   - 显示已有证据和不足之处
   - 重点展示简历建议和面试建议

### 场景三：JD 文本过长或用户提供了 JD 链接

1. 用户提供 URL：使用 `WebFetch` 提取页面中的 JD 正文。
2. 或者，让用户粘贴 JD 全文。
3. 注意控制 JD 文本长度。DeepSeek 模型有 8K tokens 的上下文窗口，JD 文本若过长需要适当截断关键部分。

### 场景四：用户说"看看这个JD"但实际是中文口语化描述

1. 用户可能只是说了岗位名称 + 自己理解的描述，而非正式 JD 文本。
2. 直接将这些口头描述作为 `--jd-text` 传入即可。提示词设计为能处理非结构化输入。

## API Key 说明

- 脚本内置了默认的 DeepSeek API Key，一般无需用户提供。
- 若内置 Key 调用失败（如配额耗尽），脚本会返回 error 信息。此时可让用户提供自己的 DeepSeek API Key，通过 `--api-key` 传入。
- Key 的获取方式：用户访问 [DeepSeek 开发者平台](https://platform.deepseek.com/) 注册并创建 API Key。

## 输出格式参考

### JD 解析输出示例

```json
{
  "skill": "求职自检官",
  "version": "1.0.0",
  "jobTitle": "产品经理实习生",
  "jdAnalysis": {
    "jobTitle": "产品经理实习生",
    "coreAbilities": [
      {
        "name": "沟通与协作能力",
        "realMeaning": "能清晰表达自己的想法，也能理解别人的需求，在团队中推进事情而不是等别人推你",
        "interviewerJudge": "会通过你描述的项目协作方式来判断，比如你如何说服不同意见的人、如何处理冲突",
        "evidenceNeeded": "准备一个跨团队/跨角色协作的具体案例，要说明你的角色、遇到的矛盾、如何解决的",
        "priority": "high"
      }
    ],
    "priorityFocus": "沟通与协作能力是该岗位最核心的要求，建议优先准备相关案例。",
    "nextSteps": "整理1-2个在团队项目中推动进展的具体案例，按'背景-行动-结果'结构写好。"
  }
}
```

### 经历匹配输出示例

```json
{
  "skill": "求职自检官",
  "version": "1.0.0",
  "jobTitle": "产品经理实习生",
  "experienceMatch": {
    "jobTitle": "产品经理实习生",
    "experience": "在嵌入式项目中担任组长，负责任务拆解和进度推进",
    "matchedAbilities": [
      {
        "name": "沟通与协作能力",
        "score": 4,
        "evidence": "作为组长每周推进看板、同步项目进展，证明具备基础的沟通协调能力",
        "gap": "缺少数值化成果说明，比如团队效率提升了多少、提前多久完成",
        "resumeAdvice": "简历中应量化描述：'带领X人团队，按周推进Y个迭代，项目提前Z天完成'",
        "interviewAdvice": "面试中要说清楚你是如何同步信息、如何协调分歧的，给出具体例子而不仅仅是'我做组长'"
      }
    ],
    "overallMatch": "整体匹配度较高，有项目管理和沟通协调的实际经验，建议补充量化成果和更具体的协作细节。",
    "nextSteps": "针对每项能力补充 STAR 结构的具体案例，特别是沟通协作和推动落地的细节。"
  }
}
```

## 注意事项

1. **Python 环境**：调用脚本前确认 Python 3 可用（`python --version`），如不可用需安装。
2. **网络要求**：脚本需要访问 `https://api.deepseek.com`，确保运行环境能访问该域名。
3. **文本长度**：JD 文本过长时间（>3000 字）可先手动截取关键段落。脚本内部设定了 `max_tokens: 4096` 的输出限制。
4. **JSON 安全性**：API 返回的 JSON 可能包含 Markdown 代码块标记（` ```json `），脚本已自动处理。
5. **错误处理**：脚本返回的 JSON 结果若包含 `"error"` 字段，则代表分析失败，需将错误信息展示给用户并根据类型判断是否需要让用户提供自定义 API Key。

## Prompt 模板参考

详细的 Prompt 内容见 `references/prompts.md`。一般情况下无需手动调用 Prompt，脚本已将其内嵌。
