#!/usr/bin/env python3
"""
AI 求职自检官 — JD 解析与能力匹配分析脚本

用法：
  python analyze_jd.py [选项]

选项：
  --job-title TEXT     目标岗位名称（必填）
  --jd-text TEXT       岗位 JD 正文（必填）
  --experience TEXT    个人经历描述（可选，提供后额外做经历匹配分析）
  --mode MODE          分析模式（jd-parse | experience-match | full，默认 full）
  --api-key KEY        DeepSeek API Key（可选，未提供则使用内置 key）
  --output FILE        输出结果到文件（可选）

输出：
  写入 stdout 的 JSON 对象，包含分析结果。
  若同时提供 --jd-text 和 --experience，mode=full 将同时执行两项分析。
"""

import json
import sys
import urllib.request
import urllib.error

# ============================================================
# 内置 DeepSeek API Key（由用户提供，硬编码在 skill 中）
# ============================================================
BUILTIN_API_KEY = "sk-0d725255b5804cc69975d4918c7d8762"

DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"


# ============================================================
# Prompt 模板（来自项目 src/lib/prompts.js）
# ============================================================

JD_PARSE_SYSTEM_PROMPT = """你是一位专业的岗位能力分析专家。你需要帮助大学生理解岗位JD中的抽象要求。

分析规则：
1. 从JD中提取所有核心能力要求
2. 用具体、易懂的语言解释每项能力的真实含义
3. 说明面试官会如何判断应聘者是否具备这项能力
4. 建议用户需要准备什么样的经历或证据来证明这些能力
5. 识别出哪些能力项需要优先补强

输出格式必须是严格的JSON（不要包含markdown代码块标记），包含以下字段：
{
  "jobTitle": "目标岗位名称",
  "coreAbilities": [
    {
      "name": "能力名称",
      "realMeaning": "这项能力的真实含义（用具体事例说明）",
      "interviewerJudge": "面试官会如何判断应聘者是否具备这项能力",
      "evidenceNeeded": "用户需要准备什么样的经历或证据",
      "priority": "high/medium/low"
    }
  ],
  "priorityFocus": "建议优先补强项",
  "nextSteps": "下一步具体建议"
}"""

EXPERIENCE_MATCH_SYSTEM_PROMPT = """你是一位求职能力诊断专家。你需要帮助大学生分析他们的个人经历与目标岗位的匹配程度。

分析规则：
1. 从用户输入的个人经历中提取关键行为和项目成果
2. 判断这些行为能证明哪些岗位核心能力
3. 识别已有证据和证据不足之处
4. 对每项能力进行评分（1-5分）
5. 给出简历表达和面试表达的具体优化建议

评分标准：
5分：有充分的量化成果和具体案例
4分：有具体案例但缺少量化成果
3分：有相关经历但不够具体
2分：有零散关联但不够充分
1分：几乎没有相关经历或证据

输出格式必须是严格的JSON（不要包含markdown代码块标记），包含以下字段：
{
  "jobTitle": "目标岗位名称",
  "experience": "用户输入的个人经历概括",
  "matchedAbilities": [
    {
      "name": "能力名称",
      "score": 3.5,
      "evidence": "已有证据分析",
      "gap": "证据不足之处",
      "resumeAdvice": "简历表达建议",
      "interviewAdvice": "面试表达建议"
    }
  ],
  "overallMatch": "整体匹配度评估",
  "nextSteps": "下一步补强建议"
}"""


# ============================================================
# DeepSeek API 调用
# ============================================================

def call_deepseek(system_prompt, user_message, api_key):
    """调用 DeepSeek API 并返回结构化 JSON 响应"""
    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        "temperature": 0.7,
        "max_tokens": 4096,
    }

    req = urllib.request.Request(
        DEEPSEEK_API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"API 调用失败 ({e.code}): {error_body}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"网络错误: {e.reason}")

    content = data.get("choices", [{}])[0].get("message", {}).get("content")
    if not content:
        raise RuntimeError("API 返回结果为空，请重试")

    return content


def parse_json_response(raw_text):
    """从 API 返回文本中提取并解析 JSON"""
    cleaned = raw_text.replace("```json", "").replace("```", "").strip()
    return json.loads(cleaned)


# ============================================================
# 分析函数
# ============================================================

def analyze_jd(job_title, jd_text, api_key):
    """执行 JD 解析，返回结构化能力画像"""
    user_message = f"目标岗位：{job_title}\n\n岗位 JD：\n{jd_text}"
    raw = call_deepseek(JD_PARSE_SYSTEM_PROMPT, user_message, api_key)
    return parse_json_response(raw)


def analyze_experience_match(job_title, experience, api_key):
    """执行经历匹配分析，返回匹配度评分与建议"""
    user_message = f"目标岗位：{job_title}\n\n个人经历：\n{experience}"
    raw = call_deepseek(EXPERIENCE_MATCH_SYSTEM_PROMPT, user_message, api_key)
    return parse_json_response(raw)


# ============================================================
# CLI 入口
# ============================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(description="AI 求职自检官 — JD 解析与能力匹配分析")
    parser.add_argument("--job-title", required=True, help="目标岗位名称")
    parser.add_argument("--jd-text", help="岗位 JD 正文")
    parser.add_argument("--experience", help="个人经历描述")
    parser.add_argument(
        "--mode",
        choices=["jd-parse", "experience-match", "full"],
        default="full",
        help="分析模式（默认 full：根据输入自动判断）",
    )
    parser.add_argument("--api-key", help="DeepSeek API Key（可选，默认使用内置 key）")
    parser.add_argument("--output", help="输出结果到文件路径")
    args = parser.parse_args()

    api_key = args.api_key or BUILTIN_API_KEY

    result = {
        "skill": "求职自检官",
        "version": "1.0.0",
        "jobTitle": args.job_title,
    }

    try:
        # —— JD 解析 ——
        if args.jd_text and args.mode in ("jd-parse", "full"):
            jd_result = analyze_jd(args.job_title, args.jd_text, api_key)
            result["jdAnalysis"] = jd_result

        # —— 经历匹配 ——
        if args.experience and args.mode in ("experience-match", "full"):
            match_result = analyze_experience_match(
                args.job_title, args.experience, api_key
            )
            result["experienceMatch"] = match_result

        output = json.dumps(result, ensure_ascii=False, indent=2)

        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"结果已写入: {args.output}")
        else:
            print(output)

    except Exception as e:
        error_result = {
            "skill": "求职自检官",
            "error": str(e),
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2))
        sys.exit(1)


if __name__ == "__main__":
    main()
