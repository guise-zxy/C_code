import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { app } from "../../utils/cloudbase";
import { normalizeDocId } from "../../utils/documents";
import {
  formatAbsoluteDateTime,
  formatRelativeUpdatedTime,
  getCommunicationReminder,
  getLatestIssueActivityTime,
  getReminderProgressClass,
  getReminderToneClass,
  getStatusLabel,
  getThresholdDecisionSummary,
} from "../../utils/issueDetail";
import { getThresholdProgress } from "../../utils/threshold";
import type { IssueCard, IssueEvent, IssueStatus, KnowledgeItem, UserInfo } from "../../types";

const STATUS_STYLES: Record<IssueStatus, string> = {
  self_checking: "bg-sky-50 text-sky-700 ring-sky-200",
  near_threshold: "bg-amber-50 text-amber-700 ring-amber-200",
  need_communicate: "bg-orange-50 text-orange-700 ring-orange-200",
  waiting_mentor: "bg-rose-50 text-rose-700 ring-rose-200",
  resolved: "bg-emerald-50 text-emerald-700 ring-emerald-200",
};

const ISSUE_TYPE_LABELS: Record<string, string> = {
  technical: "技术实现",
  environment: "环境配置",
  permission: "权限资源",
  business: "业务理解",
  other: "其他",
  技术实现: "技术实现",
  环境配置: "环境配置",
  权限资源: "权限资源",
  业务理解: "业务理解",
  其他: "其他",
};

const ISSUE_TYPE_STYLES: Record<string, string> = {
  technical: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  environment: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  permission: "bg-violet-50 text-violet-700 ring-violet-200",
  business: "bg-teal-50 text-teal-700 ring-teal-200",
  other: "bg-slate-100 text-slate-600 ring-slate-200",
  技术实现: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  环境配置: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  权限资源: "bg-violet-50 text-violet-700 ring-violet-200",
  业务理解: "bg-teal-50 text-teal-700 ring-teal-200",
  其他: "bg-slate-100 text-slate-600 ring-slate-200",
};

function getIssueTypeLabel(value: string) {
  return ISSUE_TYPE_LABELS[value] || value;
}

function getIssueTypeStyle(value: string) {
  return ISSUE_TYPE_STYLES[value] || "bg-slate-100 text-slate-600 ring-slate-200";
}

function getRiskSummary(issue: IssueCard) {
  if (issue.blocksMainTask) return "已影响主线任务推进，建议优先处理。";
  if (issue.status === "waiting_mentor" || issue.status === "need_communicate") {
    return "问题已进入需要 Mentor 关注的区间。";
  }
  if (issue.status === "near_threshold") {
    return "问题接近沟通阈值，建议提前判断是否需要介入。";
  }
  return "当前仍处于实习生自主排查阶段，可先观察排查质量。";
}

function getEventTone(type: IssueEvent["type"]) {
  if (type === "status_change") return "bg-amber-400";
  if (type === "mentor_action") return "bg-emerald-500";
  if (type === "created") return "bg-sky-500";
  if (type === "comment") return "bg-slate-400";
  return "bg-slate-300";
}

export default function MentorIssueDetail() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [issue, setIssue] = useState<IssueCard | null>(null);
  const [issueDocId, setIssueDocId] = useState("");
  const [intern, setIntern] = useState<UserInfo | null>(null);
  const [events, setEvents] = useState<IssueEvent[]>([]);
  const [knowledge, setKnowledge] = useState<KnowledgeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [mentorNote, setMentorNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; message: string } | null>(null);

  const loadData = useCallback(async () => {
    if (!id || !user) return;
    const db = app.database();

    try {
      let rawIssue: (IssueCard & { _id?: string }) | undefined;

      const byBusinessId = await db.collection("issue_cards").where({ id }).limit(1).get();
      rawIssue = (byBusinessId.data as Array<IssueCard & { _id?: string }>)[0];

      if (!rawIssue) {
        const byDocId = await db.collection("issue_cards").doc(id).get();
        rawIssue = (byDocId.data as Array<IssueCard & { _id?: string }>)[0];
      }

      if (!rawIssue) {
        setIssue(null);
        setIssueDocId("");
        return;
      }

      const issueData = normalizeDocId(rawIssue);
      setIssue(issueData);
      setIssueDocId(rawIssue._id ?? issueData.id);

      const internRes = await db.collection("users").where({ id: issueData.internId }).limit(1).get();
      const internData = (internRes.data as UserInfo[])[0];
      setIntern(internData ?? null);

      const eventRes = await db.collection("issue_events")
        .where({ issueId: issueData.id })
        .orderBy("createdAt", "asc")
        .limit(50)
        .get();
      setEvents((eventRes.data as IssueEvent[]) || []);

      if (issueData.recommendedKnowledgeIds?.length) {
        const knowledgeRes = await db.collection("knowledge_items")
          .where({ id: db.command.in(issueData.recommendedKnowledgeIds) })
          .limit(20)
          .get();
        setKnowledge((knowledgeRes.data as KnowledgeItem[]) || []);
      } else {
        setKnowledge([]);
      }
    } catch (error) {
      console.error("加载问题详情失败:", error);
      setFeedback({ type: "error", message: "问题详情加载失败，请稍后刷新重试。" });
    } finally {
      setLoading(false);
    }
  }, [id, user]);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const addEvent = useCallback(
    async (type: IssueEvent["type"], content: string, fromStatus?: IssueStatus, toStatus?: IssueStatus) => {
      if (!issue || !user) return;
      const db = app.database();

      await db.collection("issue_events").add({
        issueId: issue.id,
        type,
        content,
        fromStatus,
        toStatus,
        actorId: user.id,
        actorRole: "mentor",
        createdAt: new Date().toISOString(),
      });
    },
    [issue, user]
  );

  const updateIssueStatus = async (newStatus: IssueStatus, eventContent: string, successMessage: string) => {
    if (!issue || !issueDocId) return;
    setSubmitting(true);
    setFeedback(null);

    try {
      const db = app.database();
      const now = new Date().toISOString();

      await db.collection("issue_cards").doc(issueDocId).update({
        status: newStatus,
        updatedAt: now,
      });

      await addEvent("status_change", eventContent, issue.status, newStatus);
      setFeedback({ type: "success", message: successMessage });
      await loadData();
    } catch (error) {
      console.error("更新问题状态失败:", error);
      setFeedback({ type: "error", message: "状态更新失败，请稍后重试。" });
    } finally {
      setSubmitting(false);
    }
  };

  const handleObserve = () =>
    updateIssueStatus("self_checking", "Mentor 选择继续观察，保持自主排查。", "已更新为继续观察。");

  const handleIntervene = () =>
    updateIssueStatus("waiting_mentor", "Mentor 确认介入处理该问题。", "已更新为 Mentor 介入。");

  const handleExtendThreshold = async () => {
    if (!issue || !issueDocId) return;
    setSubmitting(true);
    setFeedback(null);

    try {
      const db = app.database();
      const newThreshold = issue.thresholdMinutes + 30;
      const now = new Date().toISOString();

      await db.collection("issue_cards").doc(issueDocId).update({
        thresholdMinutes: newThreshold,
        status: "self_checking" as IssueStatus,
        updatedAt: now,
      });

      await addEvent(
        "mentor_action",
        `Mentor 将自主排查时间延长至 ${newThreshold} 分钟。`,
        issue.status,
        "self_checking"
      );

      setFeedback({ type: "success", message: "已延长排查时间。" });
      await loadData();
    } catch (error) {
      console.error("延长排查时间失败:", error);
      setFeedback({ type: "error", message: "延长排查时间失败，请稍后重试。" });
    } finally {
      setSubmitting(false);
    }
  };

  const handleResolve = () =>
    updateIssueStatus("resolved", "Mentor 已将该问题标记为解决。", "问题已标记为已解决。");

  const handleAddNote = async () => {
    if (!issue || !issueDocId || !mentorNote.trim()) return;
    setSubmitting(true);
    setFeedback(null);

    try {
      const db = app.database();
      const now = new Date().toISOString();
      const note = mentorNote.trim();

      await db.collection("issue_cards").doc(issueDocId).update({
        mentorNote: note,
        updatedAt: now,
      });

      await addEvent("comment", `Mentor 补充备注：${note}`);
      setMentorNote("");
      setFeedback({ type: "success", message: "备注已保存。" });
      await loadData();
    } catch (error) {
      console.error("添加备注失败:", error);
      setFeedback({ type: "error", message: "备注保存失败，请稍后重试。" });
    } finally {
      setSubmitting(false);
    }
  };

  const latestEventAt = events.length > 0 ? events[events.length - 1]?.createdAt : undefined;
  const latestActivityAt = issue ? getLatestIssueActivityTime(issue.updatedAt, latestEventAt) : undefined;
  const relativeUpdate = formatRelativeUpdatedTime(latestActivityAt);
  const communicationReminder = issue ? getCommunicationReminder(issue) : null;
  const thresholdDecision = issue ? getThresholdDecisionSummary(issue) : null;
  const progress = issue ? getThresholdProgress(issue.elapsedMinutes, Math.max(issue.thresholdMinutes, 1)) : 0;
  const progressColor = thresholdDecision ? getReminderProgressClass(thresholdDecision.tone) : "bg-sky-500";
  const isResolved = issue?.status === "resolved";

  const topSummary = useMemo(() => {
    if (!issue || !communicationReminder) return [];

    return [
      { label: "当前状态", value: getStatusLabel(issue.status), title: getStatusLabel(issue.status) },
      { label: "沟通提醒", value: communicationReminder.text, title: communicationReminder.text },
      { label: "最近更新", value: relativeUpdate.label, title: relativeUpdate.fullText },
    ];
  }, [communicationReminder, issue, relativeUpdate.fullText, relativeUpdate.label]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  if (!issue) {
    return (
      <div className="rounded-3xl border border-slate-200 bg-white p-8 shadow-sm">
        <p className="text-base font-medium text-slate-700">问题不存在</p>
        <p className="mt-2 text-sm text-slate-500">可能是卡片 id 与数据库文档 id 不一致，或该问题已被移除。</p>
        <button
          type="button"
          onClick={() => navigate("/mentor/issues")}
          className="mt-6 rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-emerald-700"
        >
          返回问题协助
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="overflow-hidden rounded-3xl border border-slate-200 bg-gradient-to-br from-white via-slate-50 to-emerald-50/80">
        <div className="flex flex-col gap-5 px-6 py-6 lg:flex-row lg:items-start lg:justify-between lg:px-8">
          <div className="max-w-3xl">
            <button
              type="button"
              onClick={() => navigate("/mentor/issues")}
              className="inline-flex items-center gap-2 rounded-full bg-white/90 px-4 py-2 text-sm font-medium text-slate-600 ring-1 ring-slate-200 transition-colors hover:bg-white hover:text-slate-900"
            >
              <span aria-hidden="true">←</span>
              返回问题协助
            </button>
            <div className="mt-5 flex flex-wrap items-center gap-2">
              <span className={`rounded-full px-3 py-1 text-xs font-medium ring-1 ${STATUS_STYLES[issue.status]}`}>
                {getStatusLabel(issue.status)}
              </span>
              <span className={`rounded-full px-3 py-1 text-xs font-medium ring-1 ${getIssueTypeStyle(issue.issueType)}`}>
                {getIssueTypeLabel(issue.issueType)}
              </span>
              {issue.blocksMainTask && (
                <span className="rounded-full bg-red-50 px-3 py-1 text-xs font-medium text-red-700 ring-1 ring-red-200">
                  阻塞主线任务
                </span>
              )}
            </div>
            <h1 className="mt-4 text-3xl font-semibold tracking-tight text-slate-900">{issue.title}</h1>
            <p className="mt-3 text-sm leading-7 text-slate-600">{issue.description}</p>
            <p className="mt-4 text-sm text-slate-500">
              实习生：{intern?.name || issue.internName || issue.internId}
              {" · "}
              问题创建时间：{formatAbsoluteDateTime(issue.createdAt)}
            </p>
          </div>

          <div className="grid w-full grid-cols-1 gap-3 sm:grid-cols-3 lg:w-[30rem]">
            {topSummary.map((item) => (
              <div key={item.label} className="rounded-2xl border border-white/80 bg-white/90 px-4 py-4 shadow-sm">
                <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">{item.label}</p>
                <p
                  className={`mt-3 text-sm font-semibold ${
                    item.label === "沟通提醒" && communicationReminder
                      ? getReminderToneClass(communicationReminder.tone)
                      : "text-slate-900"
                  }`}
                  title={item.title}
                >
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {feedback && (
        <div
          className={`rounded-2xl px-4 py-3 text-sm font-medium ${
            feedback.type === "success"
              ? "border border-emerald-200 bg-emerald-50 text-emerald-700"
              : "border border-rose-200 bg-rose-50 text-rose-700"
          }`}
        >
          {feedback.message}
        </div>
      )}

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1.7fr)_22rem]">
        <div className="space-y-6">
          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">当前判断</h2>
                <p className="mt-2 text-sm leading-7 text-slate-600">{getRiskSummary(issue)}</p>
              </div>
              <div className="rounded-2xl bg-slate-50 px-4 py-3 text-sm text-slate-600">
                {issue.taskTitle ? `关联任务：${issue.taskTitle}` : `关联任务 ID：${issue.taskId}`}
              </div>
            </div>

            {thresholdDecision && (
              <div className="mt-6">
                <p className="text-sm font-medium text-slate-500">阈值进度</p>
                <div className="mt-3 h-2.5 rounded-full bg-slate-100">
                  <div className={`h-2.5 rounded-full transition-all ${progressColor}`} style={{ width: `${progress}%` }} />
                </div>
                <div className="mt-4 space-y-2">
                  <p className={`text-base font-semibold ${getReminderToneClass(thresholdDecision.tone)}`}>
                    {thresholdDecision.headline}
                  </p>
                  <p className="text-sm text-slate-600">{thresholdDecision.detail}</p>
                </div>
              </div>
            )}
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">实习生排查信息</h2>
            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl bg-slate-50 px-4 py-4">
                <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">已尝试的方法</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {issue.attemptedMethods?.length ? (
                    issue.attemptedMethods.map((item, index) => (
                      <span
                        key={`${issue.id}-attempt-${index}`}
                        className="rounded-full bg-white px-3 py-1 text-xs text-slate-600 ring-1 ring-slate-200"
                      >
                        {item}
                      </span>
                    ))
                  ) : (
                    <span className="text-sm text-slate-400">暂无记录</span>
                  )}
                </div>
              </div>

              <div className="rounded-2xl bg-slate-50 px-4 py-4">
                <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">初步判断</p>
                <p className="mt-3 text-sm leading-7 text-slate-700">{issue.initialJudgement || "暂无记录"}</p>
              </div>

              <div className="rounded-2xl bg-slate-50 px-4 py-4 md:col-span-2">
                <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">希望获得的帮助</p>
                <p className="mt-3 text-sm leading-7 text-slate-700">{issue.expectedHelp || "暂无记录"}</p>
              </div>
            </div>
          </section>

          {knowledge.length > 0 && (
            <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">AI 推荐资料</h2>
                  <p className="mt-1 text-sm text-slate-500">供 Mentor 快速判断是否已有可复用经验。</p>
                </div>
              </div>

              <div className="mt-5 grid gap-3">
                {knowledge.map((item) => (
                  <article key={item.id} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                    <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
                    <p className="mt-2 text-sm leading-7 text-slate-600">{item.content}</p>
                    {item.tags?.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {item.tags.map((tag) => (
                          <span key={`${item.id}-${tag}`} className="rounded-full bg-white px-3 py-1 text-xs text-slate-500 ring-1 ring-slate-200">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </article>
                ))}
              </div>
            </section>
          )}

          <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-slate-900">处理时间线</h2>
            {events.length === 0 ? (
              <div className="mt-5 rounded-2xl border border-dashed border-slate-200 px-5 py-10 text-center text-sm text-slate-400">
                暂无处理记录
              </div>
            ) : (
              <div className="mt-5 space-y-4">
                {events.map((event, index) => (
                  <div key={event.id || `${event.createdAt}-${index}`} className="flex gap-4">
                    <div className="flex w-5 flex-col items-center">
                      <div className={`mt-1 h-2.5 w-2.5 rounded-full ${getEventTone(event.type)}`} />
                      {index < events.length - 1 && <div className="mt-2 w-px flex-1 bg-slate-200" />}
                    </div>
                    <div className="min-w-0 flex-1 pb-4">
                      <p className="text-sm leading-7 text-slate-700">{event.content}</p>
                      <p className="mt-1 text-xs text-slate-400">
                        {formatAbsoluteDateTime(event.createdAt)}
                        {event.actorRole ? ` · ${event.actorRole}` : ""}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <aside className="space-y-6">
          {issue.helpSummary && (
            <section className="rounded-3xl border border-cyan-200 bg-cyan-50 p-5 shadow-sm">
              <p className="text-xs font-medium uppercase tracking-[0.16em] text-cyan-600">AI 摘要</p>
              <p className="mt-3 text-sm leading-7 text-cyan-900">{issue.helpSummary}</p>
            </section>
          )}

          <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900">Mentor 操作</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              先判断是否继续观察，再决定是否提前介入或延长排查窗口。
            </p>

            <div className="mt-5 grid gap-3">
              <button
                type="button"
                onClick={handleObserve}
                disabled={submitting || isResolved}
                className="rounded-2xl bg-sky-50 px-4 py-3 text-sm font-medium text-sky-700 transition-colors hover:bg-sky-100 disabled:cursor-not-allowed disabled:opacity-50"
              >
                继续观察
              </button>
              <button
                type="button"
                onClick={handleIntervene}
                disabled={submitting || isResolved}
                className="rounded-2xl bg-orange-500 px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-50"
              >
                标记为 Mentor 介入
              </button>
              <button
                type="button"
                onClick={handleExtendThreshold}
                disabled={submitting || isResolved}
                className="rounded-2xl bg-amber-50 px-4 py-3 text-sm font-medium text-amber-700 transition-colors hover:bg-amber-100 disabled:cursor-not-allowed disabled:opacity-50"
              >
                延长 30 分钟排查时间
              </button>
              <button
                type="button"
                onClick={handleResolve}
                disabled={submitting || isResolved}
                className="rounded-2xl bg-emerald-600 px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                标记为已解决
              </button>
            </div>
          </section>

          <section className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-base font-semibold text-slate-900">Mentor 备注</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">用于补充处理建议、后续跟进点或沟通结论。</p>

            {issue.mentorNote && (
              <div className="mt-4 rounded-2xl bg-emerald-50 px-4 py-4 text-sm leading-7 text-emerald-900">
                {issue.mentorNote}
              </div>
            )}

            <textarea
              value={mentorNote}
              onChange={(event) => setMentorNote(event.target.value)}
              placeholder="补充你的判断、建议或下一步动作"
              rows={5}
              className="mt-4 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-emerald-400 focus:ring-2 focus:ring-emerald-100"
            />

            <button
              type="button"
              onClick={handleAddNote}
              disabled={submitting || !mentorNote.trim()}
              className="mt-4 w-full rounded-2xl bg-slate-900 px-4 py-3 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50"
            >
              保存备注
            </button>
          </section>
        </aside>
      </div>
    </div>
  );
}
