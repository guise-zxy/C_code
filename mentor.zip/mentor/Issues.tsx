import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { app } from "../../utils/cloudbase";
import { normalizeDocList } from "../../utils/documents";
import {
  formatRelativeUpdatedTime,
  getCommunicationReminder,
  getReminderProgressClass,
  getReminderToneClass,
  getStatusLabel,
} from "../../utils/issueDetail";
import { getThresholdProgress } from "../../utils/threshold";
import type { IssueCard, IssueStatus, UserInfo } from "../../types";

const STATUS_STYLES: Record<IssueStatus, string> = {
  self_checking: "bg-sky-50 text-sky-700 ring-sky-200",
  near_threshold: "bg-amber-50 text-amber-700 ring-amber-200",
  need_communicate: "bg-orange-50 text-orange-700 ring-orange-200",
  waiting_mentor: "bg-rose-50 text-rose-700 ring-rose-200",
  resolved: "bg-emerald-50 text-emerald-700 ring-emerald-200",
};

const ISSUE_TYPE_LABELS: Record<string, string> = {
  technical: "技术实现",
  environment: "环境配置",
  permission: "权限资源",
  business: "业务理解",
  other: "其他",
  技术实现: "技术实现",
  环境配置: "环境配置",
  权限资源: "权限资源",
  业务理解: "业务理解",
  其他: "其他",
};

const ISSUE_TYPE_STYLES: Record<string, string> = {
  technical: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  environment: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  permission: "bg-violet-50 text-violet-700 ring-violet-200",
  business: "bg-teal-50 text-teal-700 ring-teal-200",
  other: "bg-slate-100 text-slate-600 ring-slate-200",
  技术实现: "bg-indigo-50 text-indigo-700 ring-indigo-200",
  环境配置: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  权限资源: "bg-violet-50 text-violet-700 ring-violet-200",
  业务理解: "bg-teal-50 text-teal-700 ring-teal-200",
  其他: "bg-slate-100 text-slate-600 ring-slate-200",
};

function getIssueTypeLabel(value: string) {
  return ISSUE_TYPE_LABELS[value] || value;
}

function getIssueTypeStyle(value: string) {
  return ISSUE_TYPE_STYLES[value] || "bg-slate-100 text-slate-600 ring-slate-200";
}

function getCardTone(issue: IssueCard) {
  if (issue.status === "waiting_mentor" || issue.blocksMainTask) {
    return "border-rose-200 bg-white shadow-[0_18px_40px_-28px_rgba(244,63,94,0.35)]";
  }
  if (issue.status === "need_communicate" || issue.status === "near_threshold") {
    return "border-amber-200 bg-white shadow-[0_18px_40px_-28px_rgba(245,158,11,0.28)]";
  }
  return "border-slate-200 bg-white shadow-[0_18px_40px_-30px_rgba(15,23,42,0.14)]";
}

function getPriorityLabel(issue: IssueCard) {
  if (issue.blocksMainTask) return "优先处理";
  if (issue.status === "waiting_mentor" || issue.status === "need_communicate") return "建议立即查看";
  if (issue.status === "near_threshold") return "建议提前关注";
  return "可继续观察";
}

function getPriorityStyle(issue: IssueCard) {
  if (issue.blocksMainTask) return "bg-rose-50 text-rose-700";
  if (issue.status === "waiting_mentor" || issue.status === "need_communicate") return "bg-orange-50 text-orange-700";
  if (issue.status === "near_threshold") return "bg-amber-50 text-amber-700";
  return "bg-slate-100 text-slate-600";
}

export default function MentorIssues() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [issues, setIssues] = useState<IssueCard[]>([]);
  const [interns, setInterns] = useState<UserInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | IssueStatus>("all");

  useEffect(() => {
    if (!user) return;
    const db = app.database();

    const load = async () => {
      setLoading(true);
      try {
        const internRes = await db.collection("users")
          .where({ mentorId: user.id, role: "intern" })
          .limit(50)
          .get();

        const internList = (internRes.data as UserInfo[]) || [];
        setInterns(internList);

        if (internList.length === 0) {
          setIssues([]);
          return;
        }

        const internIds = internList.map((intern) => intern.id);
        const issueRes = await db.collection("issue_cards")
          .where({ internId: db.command.in(internIds), status: db.command.neq("resolved") })
          .orderBy("updatedAt", "desc")
          .limit(50)
          .get();

        setIssues(normalizeDocList((issueRes.data as Array<IssueCard & { _id?: string }>) || []));
      } catch (error) {
        console.error("加载 Mentor 问题协助列表失败:", error);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [user]);

  const internMap = useMemo(() => new Map(interns.map((intern) => [intern.id, intern])), [interns]);

  const filteredIssues = useMemo(() => {
    return filter === "all" ? issues : issues.filter((issue) => issue.status === filter);
  }, [filter, issues]);

  const urgentCount = issues.filter(
    (issue) =>
      issue.status === "waiting_mentor" ||
      issue.status === "need_communicate" ||
      issue.blocksMainTask
  ).length;
  const thresholdCount = issues.filter((issue) => issue.status === "near_threshold").length;
  const selfCheckingCount = issues.filter((issue) => issue.status === "self_checking").length;

  const filterOptions: Array<{ key: "all" | IssueStatus; label: string; count: number }> = [
    { key: "all", label: "全部问题", count: issues.length },
    { key: "waiting_mentor", label: "待我介入", count: issues.filter((issue) => issue.status === "waiting_mentor").length },
    { key: "need_communicate", label: "需联系", count: issues.filter((issue) => issue.status === "need_communicate").length },
    { key: "near_threshold", label: "接近阈值", count: thresholdCount },
    { key: "self_checking", label: "自主排查", count: selfCheckingCount },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <section className="rounded-[28px] border border-slate-200 bg-[linear-gradient(135deg,rgba(255,255,255,1)_0%,rgba(246,252,249,1)_58%,rgba(237,249,246,1)_100%)] p-6 shadow-[0_24px_60px_-44px_rgba(15,23,42,0.25)] lg:p-8">
        <div className="grid gap-5 xl:grid-cols-[minmax(0,1.5fr)_minmax(420px,0.9fr)]">
          <div className="min-w-0">
            <p className="text-sm font-medium tracking-[0.14em] text-emerald-700">Mentor 协助台</p>
            <h1 className="mt-3 text-4xl font-semibold tracking-tight text-slate-950">问题协助</h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-600">
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-[24px] border border-rose-100 bg-white px-5 py-5">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">待我介入</p>
              <p className="mt-4 text-4xl font-semibold text-rose-600">{urgentCount}</p>
              <p className="mt-2 text-sm leading-6 text-slate-500">阻塞主线或已进入协助阶段</p>
            </div>
            <div className="rounded-[24px] border border-amber-100 bg-white px-5 py-5">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">接近阈值</p>
              <p className="mt-4 text-4xl font-semibold text-amber-600">{thresholdCount}</p>
              <p className="mt-2 text-sm leading-6 text-slate-500">建议提前判断是否需要介入</p>
            </div>
            <div className="rounded-[24px] border border-sky-100 bg-white px-5 py-5">
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-400">自主排查</p>
              <p className="mt-4 text-4xl font-semibold text-sky-600">{selfCheckingCount}</p>
              <p className="mt-2 text-sm leading-6 text-slate-500">当前仍可继续观察排查质量</p>
            </div>
          </div>
        </div>
      </section>

      <section className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-[0_24px_60px_-46px_rgba(15,23,42,0.24)] lg:p-7">
        <div className="flex flex-col gap-5 border-b border-slate-100 pb-5 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-slate-950">问题队列</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">按处理阶段筛选，优先看高风险或阻塞主线的问题。</p>
          </div>

          <div className="flex flex-wrap gap-2">
            {filterOptions.map((option) => {
              const active = filter === option.key;
              return (
                <button
                  key={option.key}
                  type="button"
                  onClick={() => setFilter(option.key)}
                  className={`inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium transition-all ${
                    active
                      ? "bg-slate-950 text-white shadow-sm"
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  }`}
                >
                  <span>{option.label}</span>
                  <span className={`rounded-full px-2 py-0.5 text-xs ${active ? "bg-white/15" : "bg-white text-slate-500"}`}>
                    {option.count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {filteredIssues.length === 0 ? (
          <div className="mt-6 rounded-[24px] border border-dashed border-slate-200 px-6 py-14 text-center">
            <p className="text-sm font-medium text-slate-500">当前筛选条件下暂无问题</p>
            <p className="mt-2 text-sm text-slate-400">可以切换筛选查看其他阶段的问题。</p>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {filteredIssues.map((issue) => {
              const intern = internMap.get(issue.internId);
              const reminder = getCommunicationReminder(issue);
              const progressColor = getReminderProgressClass(reminder.tone);
              const thresholdProgress = getThresholdProgress(issue.elapsedMinutes, Math.max(issue.thresholdMinutes, 1));
              const updatedTime = formatRelativeUpdatedTime(issue.updatedAt);

              return (
                <button
                  key={issue.id}
                  type="button"
                  onClick={() => navigate(`/mentor/issues/${issue.id}`)}
                  className={`block w-full rounded-[26px] border p-5 text-left transition-all hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-[0_26px_60px_-42px_rgba(15,23,42,0.24)] lg:p-6 ${getCardTone(issue)}`}
                >
                  <div className="grid gap-5 xl:grid-cols-[minmax(0,1.65fr)_330px]">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`rounded-full px-3 py-1.5 text-xs font-medium ring-1 ${STATUS_STYLES[issue.status]}`}>
                          {getStatusLabel(issue.status)}
                        </span>
                        <span className={`rounded-full px-3 py-1.5 text-xs font-medium ring-1 ${getIssueTypeStyle(issue.issueType)}`}>
                          {getIssueTypeLabel(issue.issueType)}
                        </span>
                        {issue.blocksMainTask && (
                          <span className="rounded-full bg-rose-50 px-3 py-1.5 text-xs font-medium text-rose-700 ring-1 ring-rose-200">
                            阻塞主线
                          </span>
                        )}
                        <span className={`rounded-full px-3 py-1.5 text-xs font-medium ${getPriorityStyle(issue)}`}>
                          {getPriorityLabel(issue)}
                        </span>
                      </div>

                      <div className="mt-4 flex flex-col gap-3">
                        <h3 className="text-[32px] font-semibold leading-tight tracking-tight text-slate-950">
                          {issue.title}
                        </h3>
                        <p className="max-w-4xl text-sm leading-7 text-slate-600">{issue.description}</p>
                      </div>

                      <div className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-500">
                        <span>实习生：{intern?.name || issue.internName || issue.internId}</span>
                        <span title={updatedTime.fullText}>最近更新：{updatedTime.label}</span>
                        <span>自主排查：{issue.elapsedMinutes} 分钟</span>
                      </div>

                      <div className="mt-5 grid gap-3 lg:grid-cols-[minmax(0,1.3fr)_minmax(220px,0.7fr)]">
                        {issue.expectedHelp ? (
                          <div className="rounded-[20px] bg-slate-50 px-4 py-4">
                            <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">希望获得的帮助</p>
                            <p className="mt-3 text-sm leading-7 text-slate-700">{issue.expectedHelp}</p>
                          </div>
                        ) : (
                          <div className="rounded-[20px] bg-slate-50 px-4 py-4">
                            <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">当前诉求</p>
                            <p className="mt-3 text-sm leading-7 text-slate-500">暂无额外说明</p>
                          </div>
                        )}

                        <div className="rounded-[20px] bg-slate-50 px-4 py-4">
                          <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">已尝试动作</p>
                          <div className="mt-3 flex flex-wrap gap-2">
                            {issue.attemptedMethods?.length ? (
                              issue.attemptedMethods.slice(0, 3).map((item, index) => (
                                <span
                                  key={`${issue.id}-${index}`}
                                  className="rounded-full bg-white px-3 py-1.5 text-xs text-slate-600 ring-1 ring-slate-200"
                                >
                                  {item}
                                </span>
                              ))
                            ) : (
                              <span className="text-sm text-slate-400">暂无记录</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-[24px] border border-slate-200 bg-[linear-gradient(180deg,rgba(255,255,255,1)_0%,rgba(248,250,252,1)_100%)] px-5 py-5">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-xs font-medium uppercase tracking-[0.16em] text-slate-400">介入判断</p>
                          <p className={`mt-3 text-2xl font-semibold tracking-tight ${getReminderToneClass(reminder.tone)}`}>
                            {reminder.text}
                          </p>
                        </div>
                        <div className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-500">
                          {thresholdProgress}%
                        </div>
                      </div>

                      <div className="mt-5 h-2.5 rounded-full bg-slate-100">
                        <div
                          className={`h-2.5 rounded-full transition-all ${progressColor}`}
                          style={{ width: `${thresholdProgress}%` }}
                        />
                      </div>

                      <div className="mt-5 space-y-2 text-sm text-slate-600">
                        <p>状态：{getStatusLabel(issue.status)}</p>
                        <p>问题类型：{getIssueTypeLabel(issue.issueType)}</p>
                        <p>{issue.blocksMainTask ? "当前已影响主线任务推进" : "当前未阻塞主线任务"}</p>
                      </div>

                      <div className="mt-6 rounded-[18px] bg-white px-4 py-4 ring-1 ring-slate-200">
                        <p className="text-xs font-medium uppercase tracking-[0.14em] text-slate-400">点开前你已经知道</p>
                        <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600">
                          <li>实习生已经自主排查 {issue.elapsedMinutes} 分钟</li>
                          <li>{issue.expectedHelp ? `核心诉求是：${issue.expectedHelp}` : "当前没有额外诉求说明"}</li>
                          <li>{issue.attemptedMethods?.length ? `已尝试 ${issue.attemptedMethods.length} 项动作` : "尚未记录已尝试动作"}</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
