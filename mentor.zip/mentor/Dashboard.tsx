import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { app } from "../../utils/cloudbase";
import type { UserInfo, IssueCard, IssueStatus, Task } from "../../types";
import { ISSUE_STATUS_LABELS, ISSUE_STATUS_COLORS } from "../../types";
import { normalizeDocList } from "../../utils/documents";


type ActivitySummary = {
  label: string;
  timeText: string;
};

type IssueSection = {
  key: string;
  title: string;
  description: string;
  count: number;
  issues: IssueCard[];
  emptyText: string;
  accentClass: string;
};

type InternSummary = {
  intern: UserInfo;
  issues: IssueCard[];
  totalTasks: number;
  doneTasks: number;
  inProgressTasks: number;
  progressPercent: number;
  urgentCount: number;
  recentActivity: ActivitySummary | null;
};

const internStatusColors: Record<string, string> = {
  normal: "border-l-emerald-400",
  attention: "border-l-amber-400",
  risk: "border-l-red-400",
  stale: "border-l-gray-400",
};

function toArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function getTimestamp(value?: string): number {
  if (!value) return 0;
  const timestamp = new Date(value).getTime();
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function formatDateTime(value?: string): string {
  if (!value) return "暂无更新";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "暂无更新";
  return date.toLocaleString("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function buildRecentActivity(intern: UserInfo, internIssues: IssueCard[], internTasks: Task[]): ActivitySummary | null {
  const candidates: Array<{ label: string; time: string }> = [];

  if (intern.lastProgressAt) {
    candidates.push({ label: "最近提交了进展记录", time: intern.lastProgressAt });
  }

  const latestIssue = [...internIssues].sort((left, right) => getTimestamp(right.updatedAt) - getTimestamp(left.updatedAt))[0];
  if (latestIssue) {
    candidates.push({
      label: `问题更新 · ${latestIssue.title}`,
      time: latestIssue.updatedAt,
    });
  }

  const latestTask = [...internTasks].sort((left, right) => getTimestamp(right.updatedAt) - getTimestamp(left.updatedAt))[0];
  if (latestTask) {
    const taskPrefix = latestTask.status === "done"
      ? "任务完成"
      : latestTask.status === "in_progress"
        ? "任务推进"
        : "任务安排";

    candidates.push({
      label: `${taskPrefix} · ${latestTask.title}`,
      time: latestTask.updatedAt,
    });
  }

  const latest = candidates.sort((left, right) => getTimestamp(right.time) - getTimestamp(left.time))[0];

  if (!latest) {
    return null;
  }

  return {
    label: latest.label,
    timeText: formatDateTime(latest.time),
  };
}

function getStatusBadgeClass(status: IssueStatus): string {
  return ISSUE_STATUS_COLORS[status];
}

export default function MentorDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [interns, setInterns] = useState<UserInfo[]>([]);
  const [issues, setIssues] = useState<IssueCard[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const db = app.database();

    const load = async () => {
      setLoading(true);
      try {
        const internRes = await db.collection("users").where({ mentorId: user.id, role: "intern" }).limit(50).get();
        const internList = toArray<UserInfo>(internRes.data);
        setInterns(internList);

        if (internList.length === 0) {
          setIssues([]);
          setTasks([]);
          return;
        }

        const internIds = internList.map((intern) => intern.id);
        const [issueRes, taskRes] = await Promise.all([
          db.collection("issue_cards")
            .where({ internId: db.command.in(internIds), status: db.command.neq("resolved") })
            .orderBy("updatedAt", "desc")
            .limit(50)
            .get(),
          db.collection("tasks")
            .where({ internId: db.command.in(internIds) })
            .orderBy("updatedAt", "desc")
            .limit(100)
            .get(),
        ]);

        setIssues(normalizeDocList(toArray<IssueCard & { _id?: string }>(issueRes.data)));

        setTasks(toArray<Task>(taskRes.data));
      } catch (err) {
        console.error("加载 Mentor 首页数据失败:", err);
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  const immediateInterventionIssues = issues.filter(
    (issue) => issue.status === "need_communicate" || issue.status === "waiting_mentor" || issue.blocksMainTask
  );
  const nearThresholdIssues = issues.filter((issue) => issue.status === "near_threshold");
  const selfCheckingIssues = issues.filter((issue) => issue.status === "self_checking");
  const attentionIssues = issues.filter(
    (issue) => issue.status === "near_threshold" || issue.status === "need_communicate" || issue.status === "waiting_mentor" || issue.blocksMainTask
  );

  const issueSections: IssueSection[] = [
    {
      key: "immediate",
      title: "立即介入",
      description: "阻塞主线或已经进入 Mentor 处理阶段的问题",
      count: immediateInterventionIssues.length,
      issues: immediateInterventionIssues,
      emptyText: "当前没有需要立即介入的问题",
      accentClass: "border-red-200 bg-red-50/60",
    },
    {
      key: "near-threshold",
      title: "接近阈值",
      description: "距离升级到 Mentor 介入只差一步，建议提前关注",
      count: nearThresholdIssues.length,
      issues: nearThresholdIssues,
      emptyText: "当前没有接近阈值的问题",
      accentClass: "border-amber-200 bg-amber-50/60",
    },
    {
      key: "self-checking",
      title: "自主排查中",
      description: "实习生仍在自主排查，可用于判断是否需要提前跟进",
      count: selfCheckingIssues.length,
      issues: selfCheckingIssues,
      emptyText: "当前没有自主排查中的问题",
      accentClass: "border-blue-200 bg-blue-50/60",
    },
  ];

  const internSummaries: InternSummary[] = interns
    .map((intern) => {
      const internIssues = issues.filter((issue) => issue.internId === intern.id);
      const internTasks = tasks.filter((task) => task.internId === intern.id);
      const totalTasks = internTasks.length;
      const doneTasks = internTasks.filter((task) => task.status === "done").length;
      const inProgressTasks = internTasks.filter((task) => task.status === "in_progress").length;
      const urgentCount = internIssues.filter(
        (issue) => issue.status === "need_communicate" || issue.status === "waiting_mentor" || issue.blocksMainTask
      ).length;
      const progressPercent = totalTasks === 0 ? 0 : Math.round((doneTasks / totalTasks) * 100);

      return {
        intern,
        issues: internIssues,
        totalTasks,
        doneTasks,
        inProgressTasks,
        progressPercent,
        urgentCount,
        recentActivity: buildRecentActivity(intern, internIssues, internTasks),
      };
    })
    .sort((left, right) => {
      if (right.urgentCount !== left.urgentCount) {
        return right.urgentCount - left.urgentCount;
      }
      if (right.issues.length !== left.issues.length) {
        return right.issues.length - left.issues.length;
      }
      return left.intern.name.localeCompare(right.intern.name, "zh-CN");
    });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-gray-900">你好，{user?.name}</h1>
        <p className="mt-1 text-sm text-gray-500">{user?.department} · Mentor 首页</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
          <p className="text-sm text-gray-500">带教实习生</p>
          <p className="mt-2 text-3xl font-bold text-gray-900">{interns.length}</p>
          <p className="mt-2 text-xs text-gray-400">当前由你负责跟进的实习生数量</p>
        </div>
        <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
          <p className="text-sm text-gray-500">待关注问题</p>
          <p className="mt-2 text-3xl font-bold text-amber-600">{attentionIssues.length}</p>
          <p className="mt-2 text-xs text-gray-400">接近阈值或已经进入关注区的问题</p>
        </div>
        <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
          <p className="text-sm text-gray-500">等待我处理</p>
          <p className="mt-2 text-3xl font-bold text-red-600">{immediateInterventionIssues.length}</p>
          <p className="mt-2 text-xs text-gray-400">需要你尽快回复、介入或推进的问题</p>
        </div>
      </div>

      <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-base font-semibold text-gray-900">需要关注的问题</h2>
            <p className="mt-1 text-sm text-gray-500">按介入优先级重新聚合，先看该不该介入，再看具体问题</p>
          </div>
          <button
            type="button"
            onClick={() => navigate("/mentor/issues")}
            className="rounded-full bg-emerald-50 px-3 py-1.5 text-sm font-medium text-emerald-700 transition-colors hover:bg-emerald-100"
          >
            查看问题详情
          </button>
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          {issueSections.map((section) => (
            <div key={section.key} className={`rounded-xl border p-4 ${section.accentClass}`}>
              <div className="mb-3 flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-gray-900">{section.title}</h3>
                  <p className="mt-1 text-xs leading-5 text-gray-500">{section.description}</p>
                </div>
                <span className="rounded-full bg-white px-2.5 py-1 text-xs font-semibold text-gray-700 shadow-sm ring-1 ring-gray-200">
                  {section.count}
                </span>
              </div>

              {section.issues.length === 0 ? (
                <div className="rounded-lg bg-white/80 px-3 py-4 text-sm text-gray-400 ring-1 ring-white/70">
                  {section.emptyText}
                </div>
              ) : (
                <div className="space-y-2">
                  {section.issues.slice(0, 3).map((issue) => {
                    const intern = interns.find((item) => item.id === issue.internId);
                    return (
                      <button
                        key={issue.id}
                        type="button"
                        onClick={() => navigate(`/mentor/issues/${issue.id}`)}
                        className="block w-full rounded-lg bg-white px-3 py-3 text-left shadow-sm ring-1 ring-white/70 transition-colors hover:bg-gray-50"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-medium text-gray-900">{issue.title}</p>
                            <p className="mt-1 text-xs text-gray-500">
                              {intern?.name || issue.internId} · {issue.issueType} · {issue.elapsedMinutes}/{issue.thresholdMinutes}min
                            </p>
                          </div>
                          <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium ${getStatusBadgeClass(issue.status as IssueStatus)}`}>
                            {ISSUE_STATUS_LABELS[issue.status as IssueStatus]}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
        <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-base font-semibold text-gray-900">实习生状态</h2>
            <p className="mt-1 text-sm text-gray-500">把当前阶段、任务进度和最近动态合并在同一张状态卡里</p>
          </div>
          <button
            type="button"
            onClick={() => navigate("/mentor/interns")}
            className="rounded-full bg-gray-100 px-3 py-1.5 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-200"
          >
            查看全部实习生
          </button>
        </div>

        {internSummaries.length === 0 ? (
          <div className="rounded-lg border border-dashed border-gray-200 px-4 py-8 text-center text-sm text-gray-400">
            当前还没有分配给你的实习生
          </div>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {internSummaries.map((summary) => {
              const { intern, totalTasks, doneTasks, inProgressTasks, progressPercent, issues: internIssues, recentActivity, urgentCount } = summary;
              const statusAccent = urgentCount > 0
                ? "border-l-red-400"
                : internStatusColors[intern.progressStatus || "normal"] || internStatusColors.normal;

              return (
                <div
                  key={intern.id}
                  className={`rounded-xl border-l-4 bg-white p-4 shadow-sm ring-1 ring-gray-200 ${statusAccent}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-gray-900">{intern.name}</p>
                      <p className="mt-1 text-xs text-gray-500">{intern.position || intern.department}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {internIssues.length > 0 && (
                        <span className="rounded-full bg-orange-50 px-2 py-0.5 text-xs font-medium text-orange-700">
                          {internIssues.length} 个问题
                        </span>
                      )}
                      {urgentCount > 0 && (
                        <span className="rounded-full bg-red-50 px-2 py-0.5 text-xs font-medium text-red-700">
                          {urgentCount} 个待处理
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 grid gap-3 md:grid-cols-3">
                    <div className="rounded-lg bg-gray-50 p-3">
                      <p className="text-xs font-medium text-gray-500">当前阶段</p>
                      <p className="mt-2 text-sm font-semibold text-gray-900">
                        {intern.stage || "待分配阶段"}
                      </p>
                      <p className="mt-1 text-xs text-gray-500">
                        {intern.currentWeek ? `第 ${intern.currentWeek} 周` : "周次待同步"}
                      </p>
                    </div>

                    <div className="rounded-lg bg-gray-50 p-3">
                      <p className="text-xs font-medium text-gray-500">任务进度</p>
                      <div className="mt-2 flex items-end justify-between gap-3">
                        <p className="text-sm font-semibold text-gray-900">{doneTasks}/{totalTasks || 0} 已完成</p>
                        <span className="text-xs text-gray-500">
                          {inProgressTasks > 0 ? `${inProgressTasks} 项进行中` : totalTasks > 0 ? "待继续推进" : "暂无任务"}
                        </span>
                      </div>
                      <div className="mt-2 h-2 rounded-full bg-gray-200">
                        <div
                          className="h-2 rounded-full bg-emerald-500 transition-all"
                          style={{ width: `${progressPercent}%` }}
                        />
                      </div>
                    </div>

                    <div className="rounded-lg bg-gray-50 p-3">
                      <p className="text-xs font-medium text-gray-500">最近动态</p>
                      {recentActivity ? (
                        <>
                          <p className="mt-2 text-sm font-semibold leading-5 text-gray-900">{recentActivity.label}</p>
                          <p className="mt-1 text-xs text-gray-500">{recentActivity.timeText}</p>
                        </>
                      ) : (
                        <p className="mt-2 text-sm text-gray-400">暂时还没有同步动态</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
