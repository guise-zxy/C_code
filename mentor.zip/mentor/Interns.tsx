import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { app } from "../../utils/cloudbase";
import type { UserInfo, IssueCard } from "../../types";
import { normalizeDocList } from "../../utils/documents";


export default function MentorInterns() {
  const { user } = useAuth();
  const [interns, setInterns] = useState<UserInfo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const db = app.database();
    db.collection("users")
      .where({ mentorId: user.id, role: "intern" })
      .limit(50)
      .get()
      .then((res) => setInterns((res.data as unknown as UserInfo[]) || []))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [user]);

  if (loading) return <div className="text-sm text-gray-500">加载中...</div>;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold text-gray-900">实习生总览</h1>
      {interns.length === 0 ? (
        <p className="text-sm text-gray-400">暂无带教实习生</p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {interns.map((intern) => (
            <InternCard key={intern.id} intern={intern} />
          ))}
        </div>
      )}
    </div>
  );
}

function InternCard({ intern }: { intern: UserInfo }) {
  const [issues, setIssues] = useState<IssueCard[]>([]);

  useEffect(() => {
    const db = app.database();
    db.collection("issue_cards")
      .where({ internId: intern.id, status: db.command.neq("resolved") })
      .limit(5)
      .get()
      .then((res) => setIssues(normalizeDocList((res.data as Array<IssueCard & { _id?: string }>) || [])))

      .catch(console.error);
  }, [intern.id]);

  const statusColors: Record<string, string> = {
    normal: "border-l-emerald-400",
    attention: "border-l-amber-400",
    risk: "border-l-red-400",
    stale: "border-l-gray-400",
  };

  return (
    <div className={`rounded-lg bg-white p-4 shadow-sm ring-1 ring-gray-200 border-l-4 ${statusColors[intern.progressStatus || "normal"]}`}>
      <h3 className="text-sm font-semibold text-gray-900">{intern.name}</h3>
      <p className="text-xs text-gray-500">{intern.position} · {intern.stage}</p>
      {issues.length > 0 && (
        <div className="mt-2">
          <p className="text-xs font-medium text-gray-500">未解决问题 ({issues.length})</p>
          {issues.map((issue) => (
            <p key={issue.id} className="mt-1 text-xs text-gray-600 truncate">{issue.title}</p>
          ))}
        </div>
      )}
    </div>
  );
}
