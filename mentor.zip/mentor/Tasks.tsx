import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useAuth } from "../../contexts/AuthContext";
import {
  createMentorTask,
  listInternTasks,
  listMentorAssignedTasks,
  listMentorInterns,
} from "../../services/taskService";
import type { Task, TaskPriority, UserInfo } from "../../types";
import {
  TASK_PRIORITY_COLORS,
  TASK_PRIORITY_LABELS,
  TASK_STATUS_COLORS,
  TASK_STATUS_LABELS,
} from "../../types";

type FormState = {
  internId: string;
  title: string;
  description: string;
  completionCriteria: string;
  dueDate: string;
  priority: TaskPriority;
};

const INITIAL_FORM: FormState = {
  internId: "",
  title: "",
  description: "",
  completionCriteria: "",
  dueDate: "",
  priority: "medium",
};

function formatDateTime(value?: string) {
  if (!value) return "未设置";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "未设置";
  return date.toLocaleString("zh-CN", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export default function MentorTasks() {
  const { user } = useAuth();
  const [interns, setInterns] = useState<UserInfo[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (!user) return;

    const load = async () => {
      setLoading(true);
      setError("");
      try {
        const mentorInterns = await listMentorInterns(user.id);
        setInterns(mentorInterns);
        const mentorTasks = await listMentorAssignedTasks(
          user.id,
          mentorInterns.map((intern) => intern.id)
        );
        setTasks(mentorTasks);
      } catch (err) {
        console.error("Failed to load mentor tasks:", err);
        setError(err instanceof Error ? err.message : "加载 Mentor 任务失败。");
      } finally {
        setLoading(false);
      }
    };

    void load();
  }, [user]);

  const selectedIntern = useMemo(
    () => interns.find((intern) => intern.id === form.internId) || null,
    [form.internId, interns]
  );

  const handleChange = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((current) => ({ ...current, [key]: value }));
  };

  const refreshTasks = async (mentorId: string, internList: UserInfo[]) => {
    const mentorTasks = await listMentorAssignedTasks(
      mentorId,
      internList.map((intern) => intern.id)
    );
    setTasks(mentorTasks);
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!user || !selectedIntern || submitting) return;

    setSubmitting(true);
    setError("");
    setSuccess("");

    try {
      await createMentorTask({
        internId: selectedIntern.id,
        internName: selectedIntern.name,
        mentorId: user.id,
        mentorName: user.name,
        title: form.title,
        description: form.description,
        completionCriteria: form.completionCriteria,
        dueDate: new Date(form.dueDate).toISOString(),
        priority: form.priority,
        stage: selectedIntern.stage || "",
      });

      await refreshTasks(user.id, interns);
      await listInternTasks(selectedIntern.id);

      setSuccess(`已成功为 ${selectedIntern.name} 布置任务。`);
      setForm(INITIAL_FORM);
    } catch (err) {
      console.error("Failed to create task:", err);
      setError(err instanceof Error ? err.message : "创建任务失败。");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-emerald-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-xl font-bold text-gray-900">布置任务</h1>
          <p className="mt-1 text-sm text-gray-500">
            为单个实习生创建任务，并查看当前已布置的任务。
          </p>
        </div>
        <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">
          新任务默认状态为待开始
        </span>
      </div>

      <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">实习生</label>
              <select
                value={form.internId}
                onChange={(event) => handleChange("internId", event.target.value)}
                className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                required
              >
                <option value="">请选择实习生</option>
                {interns.map((intern) => (
                  <option key={intern.id} value={intern.id}>
                    {intern.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">截止时间</label>
              <input
                type="datetime-local"
                value={form.dueDate}
                onChange={(event) => handleChange("dueDate", event.target.value)}
                className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
                required
              />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">任务标题</label>
            <input
              type="text"
              value={form.title}
              onChange={(event) => handleChange("title", event.target.value)}
              className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
              placeholder="请输入任务标题"
              required
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">任务描述</label>
            <textarea
              value={form.description}
              onChange={(event) => handleChange("description", event.target.value)}
              rows={3}
              className="w-full resize-none rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
              placeholder="请说明任务背景、预期工作内容和输出"
              required
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-medium text-gray-700">完成标准</label>
            <textarea
              value={form.completionCriteria}
              onChange={(event) => handleChange("completionCriteria", event.target.value)}
              rows={3}
              className="w-full resize-none rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
              placeholder="请明确什么情况算完成"
              required
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">优先级</label>
              <select
                value={form.priority}
                onChange={(event) => handleChange("priority", event.target.value as TaskPriority)}
                className="w-full rounded-md border border-gray-200 px-3 py-2 text-sm focus:border-emerald-400 focus:outline-none focus:ring-1 focus:ring-emerald-400"
              >
                <option value="low">低</option>
                <option value="medium">中</option>
                <option value="high">高</option>
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-gray-700">初始状态</label>
              <div className="rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-600">
                待开始
              </div>
            </div>
          </div>

          {selectedIntern && (
            <div className="rounded-lg bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
              当前选择：{selectedIntern.name}
              {selectedIntern.stage ? ` / ${selectedIntern.stage}` : ""}
            </div>
          )}

          {error && (
            <div className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</div>
          )}
          {success && (
            <div className="rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{success}</div>
          )}

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={
                submitting ||
                !form.internId ||
                !form.title.trim() ||
                !form.description.trim() ||
                !form.completionCriteria.trim() ||
                !form.dueDate
              }
              className="rounded-lg bg-emerald-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition-colors hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {submitting ? "提交中..." : "创建任务"}
            </button>
          </div>
        </form>
      </div>

      <div className="rounded-xl bg-white p-5 shadow-sm ring-1 ring-gray-200">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-gray-900">已布置任务</h2>
            <p className="mt-1 text-sm text-gray-500">
              查看当前 Mentor 已经布置给实习生的任务列表。
            </p>
          </div>
          <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium text-gray-600">
            共 {tasks.length} 项
          </span>
        </div>

        {tasks.length === 0 ? (
          <div className="rounded-lg border border-dashed border-gray-200 px-4 py-8 text-center text-sm text-gray-400">
            暂无已布置任务。
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map((task) => {
              const priority = task.priority || "medium";
              return (
                <div key={task.id} className="rounded-lg border border-gray-100 px-4 py-4">
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-semibold text-gray-900">{task.title}</p>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${TASK_PRIORITY_COLORS[priority]}`}>
                          {TASK_PRIORITY_LABELS[priority]}
                        </span>
                        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${TASK_STATUS_COLORS[task.status]}`}>
                          {TASK_STATUS_LABELS[task.status]}
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">
                        {task.internName || interns.find((intern) => intern.id === task.internId)?.name || task.internId}
                      </p>
                      <p className="mt-2 text-xs text-gray-500">完成标准：{task.completionCriteria}</p>
                    </div>
                    <div className="shrink-0 text-sm text-gray-500">
                      截止：{formatDateTime(task.dueDate)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
