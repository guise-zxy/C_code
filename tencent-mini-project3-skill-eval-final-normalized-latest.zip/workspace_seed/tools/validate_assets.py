from __future__ import annotations

import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
WORKSPACE = ROOT / "workspace_seed"
SKILLS = ["db_report", "tracingclaw_finance"]
REQUIRED_FILES = ["ideal_state.md", "rubrics.yaml", "testcases.yaml", "meta_testcases.md"]
OPTIONAL_FILES = ["meta_testcases.yaml"]
FORBIDDEN_PHRASES = ["回答合理即可", "视情况而定", "大致正确即可", "基本合理即可"]
DBR_OLD_TERMS = ["min_delivery_check.py", "TPC-DS", "benchmarksql", "旧门控"]
FINANCE_INVESTMENT_TERMS = ["买入", "卖出", "目标价", "收益预测", "涨跌预测"]


def safe_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def try_load_yaml(path: Path) -> tuple[str, Any | None]:
    try:
        import yaml  # type: ignore
    except Exception:
        return "skipped_due_to_missing_pyyaml", None
    try:
        with path.open("r", encoding="utf-8") as fh:
            return "parsed", yaml.safe_load(fh)
    except Exception as exc:
        return f"parse_error: {exc}", None


def extract_ids_from_rubrics_text(text: str, prefix: str) -> list[str]:
    return re.findall(rf"^\s+- id:\s+({prefix}-\d+)\s*$", text, flags=re.M)


def extract_testcase_blocks(text: str) -> list[str]:
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if re.match(r"^  - id:\s+\S+", line)]
    blocks: list[str] = []
    for idx, start in enumerate(starts):
        end = starts[idx + 1] if idx + 1 < len(starts) else len(lines)
        blocks.append("\n".join(lines[start:end]))
    return blocks


def extract_testcase_ids(text: str) -> list[str]:
    return re.findall(r"^  - id:\s+(\S+)\s*$", text, flags=re.M)


def extract_related_dims(block: str) -> list[str]:
    match = re.search(r"related_rubric_dimensions:\n((?:\s+- .+\n?)*)", block)
    if not match:
        return []
    return re.findall(r"^\s+-\s+([A-Z]+-\d+)\s*$", match.group(1), flags=re.M)


def has_nonempty_pass_fail(block: str) -> bool:
    if "pass_fail_rules:" not in block:
        return False
    return bool(re.search(r"pass_fail_rules:\n(?:.+\n)*?\s+pass:\n(?:\s+- .+\n)+(?:.+\n)*?\s+fail:\n(?:\s+- .+\n)+", block))


def block_contains_forbidden_phrase(block: str) -> list[str]:
    found = []
    for phrase in FORBIDDEN_PHRASES:
        if phrase in block:
            found.append(phrase)
    return found


def rubric_weight_sum(data: Any, text: str) -> int | None:
    if isinstance(data, dict) and isinstance(data.get("dimensions"), list):
        weights = [item.get("weight") for item in data["dimensions"] if isinstance(item, dict)]
        if all(isinstance(x, int) for x in weights):
            return int(sum(weights))
    weights = [int(x) for x in re.findall(r"^\s+weight:\s+(\d+)\s*$", text, flags=re.M)]
    return sum(weights) if weights else None


def line_context_allows(lines: list[str], index: int, context_markers: list[str], window: int = 5) -> bool:
    start = max(0, index - window)
    end = min(len(lines), index + window + 1)
    nearby = "\n".join(lines[start:end])
    return any(marker in nearby for marker in context_markers)


def check_old_term_violation(text: str) -> list[str]:
    violations = []
    lower = text.lower()
    lines = text.splitlines()
    safe_context = [
        "不得作为当前硬要求",
        "已排除旧版依赖",
        "不应判失败",
        "不作为当前硬性",
        "不要把旧版",
        "must_not_include",
        "fail:",
        "旧版",
    ]
    for term in DBR_OLD_TERMS:
        if term.lower() in lower:
            bad = False
            for idx, line in enumerate(lines):
                if term.lower() in line.lower():
                    if not line_context_allows(lines, idx, safe_context):
                        bad = True
                        break
            if bad:
                violations.append(term)
    return violations


def check_finance_investment_violation(text: str) -> list[str]:
    violations = []
    lines = text.splitlines()
    safe_context = ["must_not_include", "硬失败", "红线", "禁止", "非投顾边界", "不得输出", "fail:", "投资建议"]
    for term in FINANCE_INVESTMENT_TERMS:
        if term in text:
            bad = False
            for idx, line in enumerate(lines):
                if term in line and not line_context_allows(lines, idx, safe_context):
                    bad = True
                    break
            if bad:
                violations.append(term)
    return sorted(set(violations))


def find_suspected_keys(scan_root: Path) -> list[dict[str, str]]:
    patterns = [
        re.compile(r"\bsk-[A-Za-z0-9]{20,}\b"),
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        re.compile(r"EM_API_KEY\s*=\s*(?!your_em_api_key_here)([A-Za-z0-9_\-]{12,})"),
    ]
    results: list[dict[str, str]] = []
    for path in scan_root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in {".git", "__pycache__", "node_modules"} for part in path.parts):
            continue
        if path.suffix in {".pyc", ".png", ".jpg", ".jpeg", ".zip", ".pdf", ".docx", ".html"}:
            continue
        text = safe_text(path)
        for pattern in patterns:
            m = pattern.search(text)
            if m:
                results.append({"file": str(path.relative_to(ROOT)), "match": m.group(0)[:80]})
                break
    return results


def find_unwanted_paths(scan_root: Path) -> dict[str, list[str]]:
    env_files = [str(p.relative_to(ROOT)) for p in scan_root.rglob(".env")]
    pycache_dirs = [str(p.relative_to(ROOT)) for p in scan_root.rglob("__pycache__") if p.is_dir()]
    pyc_files = [str(p.relative_to(ROOT)) for p in scan_root.rglob("*.pyc")]
    git_dirs = [str(p.relative_to(ROOT)) for p in scan_root.rglob(".git") if p.is_dir()]
    return {
        "env_files": env_files,
        "pycache_dirs": pycache_dirs,
        "pyc_files": pyc_files,
        "git_dirs": git_dirs,
    }


def skill_prefix(skill: str) -> str:
    return "DBR" if skill == "db_report" else "TCF"


def validate_skill(skill: str) -> dict[str, Any]:
    skill_dir = WORKSPACE / skill
    prefix = skill_prefix(skill)
    result: dict[str, Any] = {
        "exists": skill_dir.exists(),
        "required_files": {},
        "optional_files": {},
        "yaml_parse_status": {},
        "testcase_count": 0,
        "rubric_weight_sum": None,
        "related_rubric_dimension_issues": [],
        "pass_fail_issues": [],
        "forbidden_phrase_hits": [],
        "special_issues": [],
    }
    if not skill_dir.exists():
        return result

    for name in REQUIRED_FILES:
        result["required_files"][name] = (skill_dir / name).exists()
    for name in OPTIONAL_FILES:
        result["optional_files"][name] = (skill_dir / name).exists()

    rubrics_path = skill_dir / "rubrics.yaml"
    testcases_path = skill_dir / "testcases.yaml"
    meta_yaml_path = skill_dir / "meta_testcases.yaml"

    rubrics_status, rubrics_data = try_load_yaml(rubrics_path)
    testcases_status, testcases_data = try_load_yaml(testcases_path)
    result["yaml_parse_status"]["rubrics.yaml"] = rubrics_status
    result["yaml_parse_status"]["testcases.yaml"] = testcases_status
    if meta_yaml_path.exists():
        meta_status, _ = try_load_yaml(meta_yaml_path)
        result["yaml_parse_status"]["meta_testcases.yaml"] = meta_status

    rubrics_text = safe_text(rubrics_path)
    testcases_text = safe_text(testcases_path)
    result["rubric_weight_sum"] = rubric_weight_sum(rubrics_data, rubrics_text)

    rubric_ids = set()
    if isinstance(rubrics_data, dict) and isinstance(rubrics_data.get("dimensions"), list):
        rubric_ids = {item.get("id") for item in rubrics_data["dimensions"] if isinstance(item, dict) and item.get("id")}
    if not rubric_ids:
        rubric_ids = set(extract_ids_from_rubrics_text(rubrics_text, prefix))

    if isinstance(testcases_data, dict) and isinstance(testcases_data.get("testcases"), list):
        result["testcase_count"] = len(testcases_data["testcases"])
    else:
        result["testcase_count"] = len(extract_testcase_ids(testcases_text))

    for block in extract_testcase_blocks(testcases_text):
        tc_id_match = re.search(r"^  - id:\s+(\S+)", block, flags=re.M)
        tc_id = tc_id_match.group(1) if tc_id_match else "UNKNOWN"
        dims = extract_related_dims(block)
        missing = [dim for dim in dims if dim not in rubric_ids]
        if missing:
            result["related_rubric_dimension_issues"].append({"testcase_id": tc_id, "missing_dimensions": missing})
        if len(dims) < 2:
            result["related_rubric_dimension_issues"].append({"testcase_id": tc_id, "missing_dimensions": ["LESS_THAN_TWO_DIMENSIONS"]})
        if not has_nonempty_pass_fail(block):
            result["pass_fail_issues"].append(tc_id)
        hits = block_contains_forbidden_phrase(block)
        if hits:
            result["forbidden_phrase_hits"].append({"testcase_id": tc_id, "phrases": hits})

    if skill == "db_report":
        issues = check_old_term_violation(testcases_text)
        if issues:
            result["special_issues"].append({"type": "old_requirement_violation", "terms": issues})
    if skill == "tracingclaw_finance":
        issues = check_finance_investment_violation(testcases_text)
        if issues:
            result["special_issues"].append({"type": "investment_boundary_violation", "terms": issues})

    return result


def overall_status(skill_reports: dict[str, Any], safety: dict[str, Any]) -> str:
    if any(not report["exists"] for report in skill_reports.values()):
        return "fail"
    if safety["suspected_api_keys"]:
        return "fail"
    for report in skill_reports.values():
        if not all(report["required_files"].values()):
            return "fail"
        if report["testcase_count"] < 5:
            return "fail"
        if report["rubric_weight_sum"] != 100:
            return "fail"
        if report["related_rubric_dimension_issues"] or report["pass_fail_issues"] or report["forbidden_phrase_hits"] or report["special_issues"]:
            return "fail"
    return "pass"


def build_markdown(report: dict[str, Any]) -> str:
    lines = ["# Validation Report", "", f"- Generated: {report['generated_at']}", f"- Overall status: `{report['overall_status']}`", ""]
    for skill, data in report["skills"].items():
        lines.extend([f"## {skill}", ""])
        lines.append(f"- Skill directory exists: `{data['exists']}`")
        lines.append(f"- Testcase count: `{data['testcase_count']}`")
        lines.append(f"- Rubric weight sum: `{data['rubric_weight_sum']}`")
        lines.append("- Required files:")
        for name, exists in data["required_files"].items():
            lines.append(f"  - `{name}`: `{exists}`")
        if data["optional_files"]:
            lines.append("- Optional files:")
            for name, exists in data["optional_files"].items():
                lines.append(f"  - `{name}`: `{exists}`")
        lines.append("- YAML parse status:")
        for name, status in data["yaml_parse_status"].items():
            lines.append(f"  - `{name}`: `{status}`")
        lines.append(f"- related_rubric_dimensions issues: `{len(data['related_rubric_dimension_issues'])}`")
        lines.append(f"- pass_fail_rules issues: `{len(data['pass_fail_issues'])}`")
        lines.append(f"- forbidden phrase hits: `{len(data['forbidden_phrase_hits'])}`")
        lines.append(f"- special issues: `{len(data['special_issues'])}`")
        if data["related_rubric_dimension_issues"]:
            lines.append("- related_rubric_dimensions details:")
            for item in data["related_rubric_dimension_issues"]:
                lines.append(f"  - `{item['testcase_id']}`: {', '.join(item['missing_dimensions'])}")
        if data["pass_fail_issues"]:
            lines.append("- pass_fail_rules missing/empty:")
            for tc_id in data["pass_fail_issues"]:
                lines.append(f"  - `{tc_id}`")
        if data["forbidden_phrase_hits"]:
            lines.append("- Forbidden phrase hits:")
            for item in data["forbidden_phrase_hits"]:
                lines.append(f"  - `{item['testcase_id']}`: {', '.join(item['phrases'])}")
        if data["special_issues"]:
            lines.append("- Special issues:")
            for item in data["special_issues"]:
                lines.append(f"  - `{item['type']}`: {', '.join(item['terms'])}")
        lines.append("")

    safety = report["safety"]
    lines.extend(["## Safety", ""])
    lines.append(f"- Suspected API keys found: `{len(safety['suspected_api_keys'])}`")
    for item in safety["suspected_api_keys"]:
        lines.append(f"  - `{item['file']}`: `{item['match']}`")
    lines.append(f"- `.env` files found: `{len(safety['unwanted_paths']['env_files'])}`")
    for path in safety["unwanted_paths"]["env_files"]:
        lines.append(f"  - `{path}`")
    lines.append(f"- `__pycache__` dirs found: `{len(safety['unwanted_paths']['pycache_dirs'])}`")
    for path in safety["unwanted_paths"]["pycache_dirs"]:
        lines.append(f"  - `{path}`")
    lines.append(f"- `*.pyc` files found: `{len(safety['unwanted_paths']['pyc_files'])}`")
    for path in safety["unwanted_paths"]["pyc_files"]:
        lines.append(f"  - `{path}`")
    lines.append(f"- `.git` dirs found: `{len(safety['unwanted_paths']['git_dirs'])}`")
    for path in safety["unwanted_paths"]["git_dirs"]:
        lines.append(f"  - `{path}`")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    skills_report = {skill: validate_skill(skill) for skill in SKILLS}
    safety = {
        "suspected_api_keys": find_suspected_keys(ROOT),
        "unwanted_paths": find_unwanted_paths(ROOT),
    }
    report = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "overall_status": overall_status(skills_report, safety),
        "skills": skills_report,
        "safety": safety,
    }
    (WORKSPACE / "validation_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    (WORKSPACE / "validation_report.md").write_text(build_markdown(report), encoding="utf-8")
    print(json.dumps({"overall_status": report["overall_status"], "report_json": str(WORKSPACE / "validation_report.json")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
