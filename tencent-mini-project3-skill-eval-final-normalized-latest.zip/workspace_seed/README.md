# Skill Evaluation Package

## 项目目标

本提交包面向项目三最终提交，提供两个被测 Skill 的最小可交付评估资产：

- `db_report`
- `tracingclaw_finance`

当前版本聚焦于：

- 理想态定义
- Rubric 评分标准
- 可验收 testcase
- Meta-Testcase 自检
- 工程化校验与提交前检查

不包含：

- LLM Judge 自动执行
- 真实大模型 API 接入
- 真实金融工具 API 调用结果回放

## 最终交付物结构

```text
workspace_seed/
├── README.md
├── evaluation_report.md
├── ai_usage_note.md
├── final_checklist.md
├── validation_report.md
├── validation_report.json
├── report.html
├── run_matrix.yaml
├── .env.example
├── .gitignore
├── tools/
│   └── validate_assets.py
├── run_results/
├── scores/
├── db_report/
│   ├── skill_understanding.md
│   ├── ideal_state.md
│   ├── rubrics.yaml
│   ├── rubrics.md
│   ├── testcases.yaml
│   ├── testcases.md
│   ├── meta_testcases.yaml
│   └── meta_testcases.md
└── tracingclaw_finance/
    ├── skill_understanding.md
    ├── ideal_state.md
    ├── rubrics.yaml
    ├── rubrics.md
    ├── testcases.yaml
    ├── testcases.md
    ├── meta_testcases.yaml
    └── meta_testcases.md
```

## 如何查看 `report.html`

直接在浏览器中打开：

- [report.html](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/report.html)

它用于快速查看：

- 两个 Skill 的 rubric 权重
- testcase 覆盖矩阵
- meta-testcase 自检分
- validation 结果
- 4 条 smoke test 状态

## 如何运行校验脚本

在项目根目录执行：

```powershell
python workspace_seed/tools/validate_assets.py
```

脚本会生成：

- [validation_report.md](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/validation_report.md)
- [validation_report.json](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/validation_report.json)

如果环境缺少 `PyYAML`，脚本不会中断，而是：

- 将 YAML 解析状态标记为 `skipped_due_to_missing_pyyaml`
- 继续执行结构性文本检查

## Finance 环境说明

`tracingclaw_finance` 的真实工具调用环境依赖：

- `EM_API_KEY`

提交包中：

- 只保留 `.env.example`
- 不包含真实 `.env`
- 不包含真实 API Key

本地配置方式：

```env
EM_API_KEY=your_em_api_key_here
```

## 当前版本定位

当前版本面向“最后 25 分钟收口提交”，重点保证：

- 结构完整
- 可人工验收
- 可工程化校验
- 无明显泄漏风险
- 可直接打包提交

## 官方 test-resource 说明

`db_report` 部分 testcase 可以引用课程官方提供的 `test-resource/` 目录作为输入数据。

提交包中：

- 不重复打包 `test-resource/`
- 只在 testcase 和评估报告中说明使用了哪个官方路径

失败路径也允许使用：

- `test-resource/not_exist.log`
