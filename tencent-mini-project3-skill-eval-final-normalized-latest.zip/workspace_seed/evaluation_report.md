# Evaluation Report

## 1. 项目目标

本项目面向项目三最终提交，目标是在不接真实大模型 API、不做 LLM Judge 的前提下，交付一套可人工验收、可结构化校验、可直接打包提交的双 Skill 评估资产包。

## 2. 两个被测 Skill

- `db_report`
  - 聚焦本地数据输入、报告类型识别、指标可信性、分析方法论、三格式输出与最小交付边界。
- `tracingclaw_finance`
  - 聚焦金融事实核查、辅助工具使用、口径一致性、`0/1/2` 真实性评分、修正答案质量与非投顾边界。

## 3. 理想态设计

- 两个 Skill 均已补齐 `ideal_state.md`。
- `db_report` 强调结构化流程、边界清晰、输入真实性、分析路径、风险显性化与合规输出。
- `tracingclaw_finance` 强调核查而非投顾、证据优先级、任务边界、口径一致性、真实性评分与修正答案。

## 4. Rubric 设计

- 两个 Skill 的 `rubrics.yaml` 均采用 100 分制。
- `db_report` Rubric 覆盖：
  - 数据源与任务边界
  - 报告类型识别
  - 指标可信与可追溯
  - 方法论符合度
  - 报告结构与输出格式
  - 最小交付标准
- `tracingclaw_finance` Rubric 覆盖：
  - 输入识别与边界控制
  - 工具使用与流程表达
  - 金融事实核查准确性
  - 市场/币种/财年/交易日/复权等口径一致性
  - `0/1/2` 真实性评分
  - 修正答案与非投顾边界
  - 输出结构与复盘性
  - 缺数处理与禁止编造

## 5. Testcase 覆盖情况

- `db_report`
  - 共 6 条 testcase
  - 覆盖 `single / comparison / iteration / custom`
  - 覆盖无数据拒绝编造、公平性风险、回归前提、专项边界、三格式输出、最小交付检查
  - 部分用例引用官方 `test-resource/`；根据导师说明，官方 `test-resource/` 无需随提交包重复打包，只需在方案中说明引用路径
  - `DBR-TC002` 明确使用 `test-resource/not_exist.log` 作为失败路径测试
- `tracingclaw_finance`
  - 共 6 条 testcase
  - 覆盖 `0 / 1 / 2` 三档评分
  - 覆盖内部链接不可读、结构化事实优先于新闻观点、口径混用、非投顾边界、禁止编造金融事实和内部能力

## 6. Meta-Testcase 自检结果

- `db_report`
  - 自检得分：`95 / 100`
  - 优点：关键场景覆盖完整，旧版依赖已被排除为当前硬要求
- `tracingclaw_finance`
  - 自检得分：`97 / 100`
  - 优点：评分档位、口径一致性、非投顾边界和红线覆盖较完整

## 7. Validation 校验结果

- 使用 `workspace_seed/tools/validate_assets.py` 对交付包做结构校验
- 覆盖项包括：
  - Skill 文件完整性
  - YAML 可解析性
  - testcase 数量
  - rubric 权重总和
  - rubric 维度映射
  - `pass_fail_rules` 非空
  - 模糊表述检测
  - `db_report` 旧版依赖误用检测
  - `tracingclaw_finance` 非投顾边界与禁止项检测
  - `.env`、疑似 API Key、`.git`、`__pycache__`、`*.pyc` 风险检测

## 8. Finance 环境与执行器说明

- 本项目没有使用 `official_claw_agent`
- 当前 finance Agent-level 测试由 `codex_local_agent` 执行
- `agent_host` 记为 `Codex`
- `tracingclaw_finance` Skill 本体不直接读取 `EM_API_KEY`
- 实际读取 `EM_API_KEY` 的是辅助工具 `mx-finance-search/scripts/get_data.py`
- 真实 key 只允许通过本地 PowerShell 环境变量注入
- 提交包仅保留 `.env.example`，不包含真实 `.env` 或真实 key

## 9. Agent-level 与工具链验证说明

本项目区分 Agent-level smoke test 与 dependency tool connectivity test。当前 `TCF-TC004`、`TCF-TC006` 的 Agent-level 测试由 `codex_local_agent` 执行，不冒充官方课程 Host。

其中：

- `TCF-TC004` 已完成 `agent_level success via codex_local_agent`
- `TCF-TC006` 已完成 `agent_level success via codex_local_agent`
- `TCF-TC006` 同时验证了 `mx-finance-search` 工具链；观察到的脱敏结果为：
  - `mx-finance-search returned code=0/status=0/message=OK for query "贵州茅台 最新公告", with notice/research/news-like entries.`

## 10. Finance Smoke Test 真实状态

- `TCF-TC004`
  - Codex 按 SKILL.md 将输入识别为“仅提供内部分享链接”
  - 不假装读取内部内容
  - 不调用金融工具
  - 明确要求用户粘贴 `question/answer`
  - 结果：`agent_level success`
- `TCF-TC006`
  - Codex 按 SKILL.md 将输入识别为“问题 + 候选回答”核查任务
  - 拆解市场、币种、财年、公告、复权口径与评分问题
  - 结合已观察到的 `mx-finance-search` 成功结果，指出候选回答存在市场、币种、财年、港股/复权口径混用问题
  - 给出 `0/1/2` 评分、风险说明与修正参考答案
  - 不输出买入、卖出、目标价、收益预测等投资建议
  - 结果：`agent_level success`

## 11. 当前不足与后续优化

- 当前未做 LLM Judge 自动判分
- 当前未保留真实金融查询结果全文回放，仅保留脱敏摘要
- db_report 侧 smoke test 仍缺少可直接执行的本地 harness
- 后续若接入课程官方 Host，可补做 `official_claw_agent` 版本对照验证

