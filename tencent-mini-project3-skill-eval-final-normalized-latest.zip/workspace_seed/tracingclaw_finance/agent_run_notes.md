# tracingclaw_finance Agent Run Notes

## 1. 执行器说明

- 当前未使用官方 Claw Host。
- 本项目使用 Codex 作为本地 Agent 执行器。
- `base_agent_id` 记为 `codex_local_agent`。
- `agent_host` 记为 `Codex`。
- 该结果标记为 `agent_level via codex_local_agent`，不标记为 `official_claw_agent`。

## 2. 执行依据

- Codex 读取并遵循：
  - `.tmp_tracing_skill/tracingclaw_fince_skill/SKILL.md`
  - `workspace_seed/tracingclaw_finance/testcases.yaml`
  - `workspace_seed/tracingclaw_finance/rubrics.yaml`
- Codex 按 Skill 工作流执行 testcase：
  - 先识别输入类型
  - 再拆解金融核查点
  - 按边界决定是否停机、是否要求补充上下文
  - 对需要资讯搜索的场景，再结合 `mx-finance-search`

## 3. 工具使用说明

- 对需要金融资讯搜索的场景，调用或引用 `mx-finance-search` 结果。
- `westock-data` 与 `mx-finance-search` 是辅助工具，不是被测 Skill 本体。
- 本次 `TCF-TC006` 的工具链验证基于真实查询“贵州茅台 最新公告”的成功结果摘要。

## 4. 密钥与安全

- 真实 key 只通过当前 PowerShell 环境变量 `EM_API_KEY` 注入。
- 提交包不包含真实 key。
- 不在仓库文件中记录真实 `EM_API_KEY` 值。
- `api_key_included` 字段统一记录为 `false`。

## 5. 本次 Agent-level 记录

- `TCF-TC004`
  - `run_level: agent_level`
  - `base_agent_id: codex_local_agent`
  - `agent_host: Codex`
  - Codex 识别内部分享链接边界，不调用工具，不假装读取内部内容，并要求用户粘贴 `question/answer`
- `TCF-TC006`
  - `run_level: agent_level`
  - `base_agent_id: codex_local_agent`
  - `agent_host: Codex`
  - Codex 识别为“问题 + 候选回答”核查任务，按 Skill 输出结构生成结论、核查明细、口径与风险、真实性评分和修正参考答案
  - 同时记录已观察到的 `mx-finance-search` 成功工具调用摘要

