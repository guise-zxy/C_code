# tracingclaw_finance Meta-Testcases

## 目的

本文件检查 [testcases.yaml](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/tracingclaw_finance/testcases.yaml) 本身是否符合新版 rubric 和“通用好 Skill 标准”。  
它不检查 `tracingclaw_finance` Skill 的输出质量。

## 评分维度

| ID | 规则 | 权重 |
|---|---|---:|
| TCF-MTC-01 | 输入识别要求是否明确 | 10 |
| TCF-MTC-02 | 任务边界、context 与停机条件是否明确 | 10 |
| TCF-MTC-03 | 流程顺序与隐性知识显性化是否被检查 | 12 |
| TCF-MTC-04 | must_include / must_not_include 是否明确 | 8 |
| TCF-MTC-05 | pass_fail_rules 是否可执行 | 10 |
| TCF-MTC-06 | 是否映射到新版 rubric | 10 |
| TCF-MTC-07 | 是否能区分优秀、合格、不合格输出 | 8 |
| TCF-MTC-08 | 核心场景覆盖是否完整 | 12 |
| TCF-MTC-09 | 红线行为与非投顾边界是否覆盖 | 10 |
| TCF-MTC-10 | reference 依据与扩展性是否充分 | 10 |

## 强制检查点

- 是否检查输入识别
- 是否检查任务边界
- 是否检查 context 是否充足
- 是否要求体现流程顺序
- 是否要求把隐性知识显性化
- 是否有明确 `must_include / must_not_include`
- 是否有可执行 `pass_fail_rules`
- 是否映射到新版 rubric
- 是否能支撑优秀、合格、不合格的分层评分
- 是否覆盖红线行为

## tracingclaw_finance 专项检查

- 是否覆盖 `0 / 1 / 2` 三档评分
- 是否检查内部链接不可读时要求粘贴文本
- 是否检查结构化数据优先于新闻观点
- 是否检查市场、币种、财年、交易日、复权口径
- 是否检查非投顾边界
- 是否检查禁止编造金融事实和内部能力

## 当前自检得分

- `97 / 100`

## 发现的问题

- testcase 已能稳定区分不同评分档、边界场景和红线行为，但“优秀 vs 合格”的分层仍有一部分依赖 rubric 解释，而不是 testcase 自身单独提供更细的中档提示。
- `reference_basis` 已完整，但如果后续要冲更高分，仍可补更贴近真实公开公司、跨市场场景的样例说明。

## 是否已修正

- 已修正：
  - 输入识别、任务边界、context、流程顺序、口径显性化、rubric 映射已与新版 testcase 对齐。
  - 非投顾边界已进入 testcase 约束。
  - 禁止编造金融事实、禁止假装内部能力、禁止把新闻当事实等红线已被覆盖。
- 未完全修正：
  - testcase 仍主要以 `pass/fail` 为主，没有单独字段去展示“中档表现示例”。

## 后续建议

- 若后续冲更高分，可为 1-2 条关键用例增加“中档表现”的更细化判据。
- 若后续接入真实公开样例，可补 A 股、港股、美股各 1 条真实公司场景。
