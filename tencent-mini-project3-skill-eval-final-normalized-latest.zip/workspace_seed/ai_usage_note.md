# AI Usage Note

## 1. 使用了 AI 辅助的部分

本资产包在以下环节使用了 AI 辅助整理与生成：

- 梳理两个 Skill 的规范边界
- 生成理解层文档结构
- 生成初版 Rubric 维度与描述
- 生成 testcase 骨架与映射关系
- 生成 meta-testcase 自检框架
- 汇总生成 README、evaluation_report 和 final_checklist

## 2. 由人工确认的关键判断

以下判断应视为需要人工复核或已按人工要求约束的部分：

- `db_report` 的 reference 规范边界
- `tracingclaw_finance` 只以 `tracingclaw_fince_skill.zip` 的 `SKILL.md` 为准
- `westock-data` 与 `mx-finance-search` 仅是辅助工具，不是被测对象
- 不得编造内部 API、内部 Token、内部日志、内部链接读取能力
- 60 分版本优先保证结构完整与可验收，而非平台化实现

## 3. 如何避免直接照搬

为避免 AI 生成内容变成空泛模板，本次处理采用了以下约束：

- Rubric 必须绑定 Skill 具体规范，不写成通用大模型评分表
- testcase 必须能映射到 rubric 维度
- testcase 必须包含明确的 pass/fail 规则
- Meta-Testcase 检查 testcase 质量，而不是再次测试 Skill
- 对不确定的信息写成 assumption 或模拟数据，而不是编造真实资源

## 4. 如何避免编造

本版本明确避免：

- 编造内部调用链路
- 编造内部接口权限
- 编造内部 Token
- 编造内部分享链接读取能力
- 在没有真实测试资源时伪造真实数据来源

因此，凡是当前工作区中没有可直接引用的真实资源，均明确写为“模拟数据”或在文档中保留后续替换空间。
