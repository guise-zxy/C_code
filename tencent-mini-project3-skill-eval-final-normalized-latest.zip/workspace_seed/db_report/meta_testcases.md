# db_report Meta-Testcases

## 目的

本文件检查 [testcases.yaml](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/db_report/testcases.yaml) 本身的质量，重点判断 testcase 是否符合新版 rubric 和“通用好 Skill 标准”。  
它不检查 `db_report` Skill 的输出质量。

## 评分维度

| ID | 规则 | 权重 |
|---|---|---:|
| DBR-MTC-01 | 输入识别要求是否明确 | 10 |
| DBR-MTC-02 | 任务边界与 context 充足性是否可验收 | 10 |
| DBR-MTC-03 | 流程顺序与隐性知识显性化是否被检查 | 12 |
| DBR-MTC-04 | must_include / must_not_include 是否明确 | 8 |
| DBR-MTC-05 | pass_fail_rules 是否可执行 | 10 |
| DBR-MTC-06 | 是否映射到新版 rubric | 10 |
| DBR-MTC-07 | 是否能区分优秀、合格、不合格输出 | 8 |
| DBR-MTC-08 | 核心场景覆盖是否完整 | 12 |
| DBR-MTC-09 | 红线行为与最小交付边界是否覆盖 | 10 |
| DBR-MTC-10 | 是否避免引入旧版硬性要求 | 10 |

## 强制检查点

- 是否检查输入识别
- 是否检查任务边界
- 是否检查 context 是否充足
- 是否要求体现流程顺序
- 是否要求把隐性知识显性化
- 是否有明确 `must_include / must_not_include`
- 是否有可执行 `pass_fail_rules`
- 是否映射到新版 rubric
- 是否能支撑优秀、合格、不合格的分层评分
- 是否覆盖红线行为

## db_report 专项检查

- 是否覆盖 `single / comparison / iteration / custom`
- 是否检查无数据时拒绝编造
- 是否检查 comparison 公平性
- 是否检查 iteration 回归前提
- 是否检查 custom 专项边界
- 是否避免把旧版 `min_delivery_check.py`、`TPC-DS`、`benchmarksql`、旧门控写成当前硬性要求

## 当前自检得分

- `95 / 100`

## 发现的问题

- testcase 目前已经能稳定区分“通过/失败”，并能部分支撑“优秀/合格/不合格”分层；但“优秀 vs 合格”的差异，仍有一部分依赖 rubric 解释，而不是 testcase 自身提供更细的中档提示。
- 旧版硬性依赖已经在 `DBR-TC006` 中显式排除，但其余用例没有重复声明这一点。这个问题不影响当前执行，只影响冗余稳健性。

## 是否已修正

- 已修正：
  - 输入识别、流程顺序、任务边界、context、隐性知识显性化、rubric 映射、红线覆盖已与新版 testcase 对齐。
  - 旧版脚本/benchmark 不再作为当前硬性要求。
- 未完全修正：
  - testcase 本体仍以 `pass/fail` 为主，没有单独字段去写“中档表现示例”。

## 后续建议

- 若后续冲击更高分，可为 1-2 条核心 testcase 增加“部分满足时如何给中档分”的更细粒度提示。
- 若后续接入真实课程数据，可把四类 report_type 各补一条真实路径样例版 testcase。
