# db_report Testcases

## 数量

- 共 6 条

## 用例清单

| ID | 名称 | 优先级 | 核心场景 | 主要映射维度 |
|---|---|---|---|---|
| DBR-TC001 | 正常单次性能报告生成 | P0 | single 正常流 | DBR-01, DBR-02, DBR-03, DBR-04, DBR-05, DBR-06 |
| DBR-TC002 | 无数据输入时拒绝编造报告 | P0 | keyword_only | DBR-01, DBR-06 |
| DBR-TC003 | comparison 公平对比与风险提示 | P0 | 不公平 comparison | DBR-02, DBR-04, DBR-06 |
| DBR-TC004 | iteration 三版本回归识别 | P1 | 版本趋势与回归 | DBR-02, DBR-03, DBR-04, DBR-05 |
| DBR-TC005 | custom 高并发专项分析 | P1 | custom 专项分析 | DBR-02, DBR-04, DBR-05 |
| DBR-TC006 | 三格式与最小交付标准校验 | P1 | 输出门槛检查 | DBR-05, DBR-06 |

## 设计说明

- 用例覆盖四类报告类型：`single`、`comparison`、`iteration`、`custom`。
- 用例不只检查“有没有报告”，还检查：
  - 是否先识别输入与报告类型
  - 是否把数据前提、专项边界、公平性和回归条件显性化
  - 是否体现“先核前提、后分析、再交付”的过程顺序
  - 是否明确区分已核事实、分析解释和优化建议
  - 是否明确什么情况下必须拒绝编造
- 使用模拟数据的场景均已在 `preconditions` 中明确标注“模拟数据”。
- 根据导师说明，`db_report` 的 testcase 可以引用官方提供的 `test-resource/` 作为输入数据。
- 当前仓库未内置官方 `test-resource/` 目录，因此 `DBR-TC001`、`DBR-TC003`、`DBR-TC004`、`DBR-TC005` 采用“优先引用官方 `test-resource/`，若当前无法确认文件名则保留可替换占位路径”的写法，避免编造文件名。
- `DBR-TC002` 明确使用 `test-resource/not_exist.log` 作为故意不存在路径，用于测试缺失文件时是否拒绝编造报告。
- 官方 `test-resource/` 为课程提供的数据资源，提交包不重复打包该目录，只在方案中说明引用路径。
- `db_report` 用例只要求当前 Skill 与 reference 的交付和门控，不把旧版 `min_delivery_check.py`、`TPC-DS`、`benchmarksql` 或旧脚本调用写成硬性通过项。

## 验收原则

- 每条用例都必须有明确 `pass_fail_rules`。
- 每条用例都映射到两个或以上 rubric 维度。
- P0 用例优先覆盖无数据编造、类型误判、公平性风险等关键失败模式。
- 每条用例既验结果正确性，也验结构清晰度、流程指引、边界说明和 context 完整性。
