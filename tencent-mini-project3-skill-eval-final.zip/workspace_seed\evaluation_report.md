# Evaluation Report

## 1. 项目目标

本项目用于构建两个 Skill 的课程提交版评估资产包，目标是在不接真实 API、不做 LLM Judge 的前提下，交付一套可人工验收、可工程化校验、可打包提交的最小完整方案。

## 2. 两个被测 Skill

- `db_report`
  - 目标：评估数据库性能报告 Skill 的输入识别、报告分流、方法论、三格式输出与最小交付边界。
- `tracingclaw_finance`
  - 目标：评估金融验真 Skill 的输入边界、事实核查、证据优先级、口径一致性、`0/1/2` 评分与非投顾边界。

## 3. 理想态设计

两个 Skill 都已具备独立的 `ideal_state.md`：

- `db_report` 强调结构化工作流、输入边界、分析路径、风险显性化、三格式输出与最小交付控制。
- `tracingclaw_finance` 强调核查而非问答、任务边界、证据顺序、口径显性化、真实性评分与非投顾边界。

本阶段不再重写理想态，只以现有版本作为后续 rubric、testcase、meta-testcase 的上游依据。

## 4. Rubric 设计

两个 Skill 的 `rubrics.yaml` 均已按 100 分制配置，并与最新版理想态对齐：

- `db_report`
  - 输入识别、数据前提与任务边界
  - 报告类型判定与分析路径清晰度
  - 指标可信度、证据对应与结论分层
  - 方法论符合度与风险显性化
  - 报告结构、三格式输出与过程可读性
  - 最小交付校验与边界控制
- `tracingclaw_finance`
  - 输入识别与任务边界控制
  - 核查流程与工具角色表达
  - 金融事实核查准确性与证据优先级
  - 口径显性化与一致性控制
  - `0/1/2` 真实性评分合理性
  - 修正参考答案与非投顾边界
  - 输出结构、风险说明与可复盘性
  - 缺数处理、禁止编造与红线合规

## 5. Testcase 覆盖情况

- `db_report`
  - 6 条 testcase
  - 覆盖 `single / comparison / iteration / custom`
  - 覆盖无数据拒绝编造、公平性风险、回归前提、专项边界、三格式输出、最小交付检查
  - 部分用例按导师说明引用官方提供的 `test-resource/` 作为测试输入；官方 `test-resource/` 无需随提交包重复打包，只需在评估方案中说明引用路径
  - `DBR-TC002` 使用 `test-resource/not_exist.log` 作为失败路径测试，用于验证缺失文件时是否拒绝编造报告
- `tracingclaw_finance`
  - 6 条 testcase
  - 覆盖 `0 / 1 / 2` 三档评分
  - 覆盖内部链接不可读、结构化事实优先于新闻观点、市场/币种/财年/交易日/复权口径、非投顾边界、禁止编造金融事实和内部能力

## 6. Meta-Testcase 自检结果

- `db_report`
  - 自检分：`95 / 100`
  - 当前强项：流程顺序、边界、红线、类型覆盖、旧版依赖排除
  - 当前不足：优秀/合格的细粒度分层仍部分依赖 rubric
- `tracingclaw_finance`
  - 自检分：`97 / 100`
  - 当前强项：评分档位覆盖、内部链接边界、事实优先级、非投顾边界、红线覆盖
  - 当前不足：优秀/合格的细粒度分层仍部分依赖 rubric

## 7. Validation 校验结果

最终交付前新增了：

- [validate_assets.py](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/tools/validate_assets.py)
- [validation_report.md](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/validation_report.md)
- [validation_report.json](/abs/path/D:/Projects/tencent-mini-project3/workspace_seed/validation_report.json)

校验范围包括：

- 双 Skill 文件完整性
- YAML 可解析性或缺库降级策略
- testcase 数量
- rubric 权重总和
- testcase 与 rubric 映射
- `pass_fail_rules` 非空
- 模糊表达检查
- `db_report` 旧版依赖误用检查
- `tracingclaw_finance` 非投顾边界与允许输出误写检查
- `.env`、API Key、`.git`、`__pycache__`、`*.pyc` 风险检查

## 8. Finance 环境说明

`tracingclaw_finance` 真实工具调用依赖：

- `EM_API_KEY`

本提交包中：

- 不包含真实 key
- 不包含真实 `.env`
- 只保留 `.env.example`

因此：

- 资产包可以提交
- 但依赖真实金融工具调用的 smoke test 若未配置 `EM_API_KEY`，应诚实标记为 `blocked`

## 9. 当前不足与后续优化

当前不足：

- 未做 LLM Judge
- 未接真实课程 API 或真实大模型
- smoke test 仅保留 4 条收口版记录，且部分因环境原因 `blocked`
- testcase 仍以 `pass/fail` 为主，优秀/合格中档示例不够细

后续优化方向：

1. 接入真实课程样例和公开金融样例，替换部分模拟数据。
2. 为 testcase 增加更细粒度的中档判据。
3. 为 `db_report` 增加更多结构化格式检查脚本。
4. 在本地配置 `EM_API_KEY` 后补跑 finance 相关真实工具链 smoke test。
