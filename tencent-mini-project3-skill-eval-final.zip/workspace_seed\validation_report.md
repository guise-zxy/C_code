# Validation Report

- Generated: 2026-06-21T20:30:05
- Overall status: `pass`

## db_report

- Skill directory exists: `True`
- Testcase count: `6`
- Rubric weight sum: `100`
- Required files:
  - `ideal_state.md`: `True`
  - `rubrics.yaml`: `True`
  - `testcases.yaml`: `True`
  - `meta_testcases.md`: `True`
- Optional files:
  - `meta_testcases.yaml`: `True`
- YAML parse status:
  - `rubrics.yaml`: `skipped_due_to_missing_pyyaml`
  - `testcases.yaml`: `skipped_due_to_missing_pyyaml`
  - `meta_testcases.yaml`: `skipped_due_to_missing_pyyaml`
- related_rubric_dimensions issues: `0`
- pass_fail_rules issues: `0`
- forbidden phrase hits: `0`
- special issues: `0`

## tracingclaw_finance

- Skill directory exists: `True`
- Testcase count: `6`
- Rubric weight sum: `100`
- Required files:
  - `ideal_state.md`: `True`
  - `rubrics.yaml`: `True`
  - `testcases.yaml`: `True`
  - `meta_testcases.md`: `True`
- Optional files:
  - `meta_testcases.yaml`: `True`
- YAML parse status:
  - `rubrics.yaml`: `skipped_due_to_missing_pyyaml`
  - `testcases.yaml`: `skipped_due_to_missing_pyyaml`
  - `meta_testcases.yaml`: `skipped_due_to_missing_pyyaml`
- related_rubric_dimensions issues: `0`
- pass_fail_rules issues: `0`
- forbidden phrase hits: `0`
- special issues: `0`

## Safety

- Suspected API keys found: `0`
- `.env` files found: `0`
- `__pycache__` dirs found: `0`
- `*.pyc` files found: `0`
- `.git` dirs found: `1`
  - `.git`
