USE music_collection_db;

INSERT INTO users (user_id, username, password_hash, nickname, email, phone, avatar, role) VALUES
(1, 'admin', '$2y$10$RhLCEzTaNc4tHXezhU6JzOhLJU/sWEkqzwb4i9ohna.7NyIqoASh2', '系统管理员', 'admin@example.com', '13800000000', NULL, 'admin'),
(2, 'student', '$2y$10$RhLCEzTaNc4tHXezhU6JzOhLJU/sWEkqzwb4i9ohna.7NyIqoASh2', '课程演示用户', 'student@example.com', '13900000000', NULL, 'user');

INSERT INTO music_categories (category_id, category_name, category_description, sort_order) VALUES
(1, '华语流行', '适合日常播放的中文流行歌曲', 1),
(2, '摇滚', '节奏鲜明、现场感强的摇滚音乐', 2),
(3, '民谣', '旋律温和、叙事感较强的民谣作品', 3),
(4, '电子', '合成器与节拍驱动的电子音乐', 4),
(5, '古典', '经典器乐与交响作品', 5);

INSERT INTO songs (song_id, category_id, title, artist, album, duration, release_date, language, lyrics, file_path, cover_path, status) VALUES
(1, 1, '晴天', '周杰伦', '叶惠美', 269, '2003-07-31', '国语', '故事的小黄花，从出生那年就飘着。', 'assets/uploads/songs/qingtian.mp3', 'assets/uploads/covers/qingtian.jpg', 'active'),
(2, 1, '后来', '刘若英', '我等你', 341, '2000-01-07', '国语', '后来，我总算学会了如何去爱。', 'assets/uploads/songs/houlai.mp3', 'assets/uploads/covers/houlai.jpg', 'active'),
(3, 2, '蓝莲花', '许巍', '时光·漫步', 270, '2002-12-01', '国语', '没有什么能够阻挡，你对自由的向往。', 'assets/uploads/songs/lanlianhua.mp3', 'assets/uploads/covers/lanlianhua.jpg', 'active'),
(4, 3, '成都', '赵雷', '无法长大', 328, '2016-12-21', '国语', '和我在成都的街头走一走。', 'assets/uploads/songs/chengdu.mp3', 'assets/uploads/covers/chengdu.jpg', 'active'),
(5, 4, '夜空中最亮的星', '逃跑计划', '世界', 252, '2011-04-12', '国语', '夜空中最亮的星，能否听清。', 'assets/uploads/songs/star.mp3', 'assets/uploads/covers/star.jpg', 'active'),
(6, 5, 'Canon in D', 'Johann Pachelbel', 'Classical Collection', 300, '1680-01-01', '器乐', '经典卡农旋律。', 'assets/uploads/songs/canon.mp3', 'assets/uploads/covers/canon.jpg', 'active');

INSERT INTO playlists (playlist_id, creator_user_id, playlist_name, description, cover_path, is_recommended, created_at) VALUES
(1, 1, '午后学习歌单', '适合写作业和复习数据库课程时播放。', 'assets/uploads/playlists/study.jpg', 1, '2026-07-01 09:00:00'),
(2, 2, '中文流行精选', '课堂演示用的热门华语歌曲集合。', 'assets/uploads/playlists/pop.jpg', 1, '2026-07-01 10:00:00'),
(3, 1, '轻松民谣夜', '安静、舒缓的晚间歌单。', 'assets/uploads/playlists/folk.jpg', 0, '2026-07-01 11:00:00');

INSERT INTO playlist_songs (playlist_id, song_id, added_at, sort_order) VALUES
(1, 1, '2026-07-01 09:05:00', 1),
(1, 4, '2026-07-01 09:06:00', 2),
(1, 6, '2026-07-01 09:07:00', 3),
(2, 1, '2026-07-01 10:05:00', 1),
(2, 2, '2026-07-01 10:06:00', 2),
(2, 5, '2026-07-01 10:07:00', 3),
(3, 3, '2026-07-01 11:05:00', 1),
(3, 4, '2026-07-01 11:06:00', 2);

INSERT INTO song_favorites (user_id, song_id, favorited_at, note) VALUES
(2, 1, '2026-07-01 12:00:00', '喜欢的课堂演示歌曲'),
(2, 4, '2026-07-01 12:01:00', '民谣收藏'),
(1, 3, '2026-07-01 12:02:00', '摇滚代表曲目');

INSERT INTO playlist_favorites (user_id, playlist_id, favorited_at, note) VALUES
(2, 1, '2026-07-01 12:10:00', '学习时播放'),
(1, 2, '2026-07-01 12:11:00', '首页推荐');

INSERT INTO play_records (user_id, song_id, played_at, play_duration, play_source) VALUES
(2, 1, '2026-07-01 13:00:00', 120, '首页'),
(2, 4, '2026-07-01 13:05:00', 180, '歌单'),
(1, 3, '2026-07-01 13:10:00', 200, '搜索');

INSERT INTO playlist_browse_records (user_id, playlist_id, browsed_at, stay_duration) VALUES
(2, 1, '2026-07-01 13:20:00', 90),
(2, 2, '2026-07-01 13:25:00', 60),
(1, 2, '2026-07-01 13:30:00', 120);
