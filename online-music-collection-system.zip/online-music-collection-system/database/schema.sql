CREATE DATABASE IF NOT EXISTS music_collection_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE music_collection_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS playlist_browse_records;
DROP TABLE IF EXISTS playlist_favorites;
DROP TABLE IF EXISTS playlist_songs;
DROP TABLE IF EXISTS play_records;
DROP TABLE IF EXISTS song_favorites;
DROP TABLE IF EXISTS playlists;
DROP TABLE IF EXISTS songs;
DROP TABLE IF EXISTS music_categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  user_id INT UNSIGNED AUTO_INCREMENT COMMENT '用户编号',
  username VARCHAR(50) NOT NULL COMMENT '用户名',
  password_hash VARCHAR(255) NOT NULL COMMENT '密码摘要',
  nickname VARCHAR(50) NOT NULL COMMENT '昵称',
  email VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
  phone VARCHAR(30) DEFAULT NULL COMMENT '电话',
  avatar VARCHAR(255) DEFAULT NULL COMMENT '头像',
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user' COMMENT '角色',
  registered_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  PRIMARY KEY (user_id),
  UNIQUE KEY uk_users_username (username),
  UNIQUE KEY uk_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户';

CREATE TABLE music_categories (
  category_id INT UNSIGNED AUTO_INCREMENT COMMENT '分类编号',
  category_name VARCHAR(80) NOT NULL COMMENT '分类名称',
  category_description VARCHAR(255) DEFAULT NULL COMMENT '分类描述',
  sort_order INT NOT NULL DEFAULT 0 COMMENT '排序号',
  PRIMARY KEY (category_id),
  UNIQUE KEY uk_music_categories_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='音乐分类';

CREATE TABLE songs (
  song_id INT UNSIGNED AUTO_INCREMENT COMMENT '歌曲编号',
  category_id INT UNSIGNED DEFAULT NULL COMMENT '分类编号',
  title VARCHAR(120) NOT NULL COMMENT '歌曲名',
  artist VARCHAR(100) NOT NULL COMMENT '歌手',
  album VARCHAR(120) DEFAULT NULL COMMENT '专辑',
  duration INT UNSIGNED DEFAULT 0 COMMENT '时长（秒）',
  release_date DATE DEFAULT NULL COMMENT '发行日期',
  language VARCHAR(30) DEFAULT NULL COMMENT '语言',
  lyrics TEXT COMMENT '歌词',
  file_path VARCHAR(255) DEFAULT NULL COMMENT '文件路径',
  cover_path VARCHAR(255) DEFAULT NULL COMMENT '封面路径',
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active' COMMENT '状态',
  PRIMARY KEY (song_id),
  KEY idx_songs_category_id (category_id),
  KEY idx_songs_title_artist (title, artist),
  CONSTRAINT fk_songs_category
    FOREIGN KEY (category_id) REFERENCES music_categories(category_id)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌曲';

CREATE TABLE playlists (
  playlist_id INT UNSIGNED AUTO_INCREMENT COMMENT '歌单编号',
  creator_user_id INT UNSIGNED NOT NULL COMMENT '制作用户编号',
  playlist_name VARCHAR(120) NOT NULL COMMENT '歌单名称',
  description VARCHAR(500) DEFAULT NULL COMMENT '简介',
  cover_path VARCHAR(255) DEFAULT NULL COMMENT '封面路径',
  is_recommended TINYINT(1) NOT NULL DEFAULT 0 COMMENT '是否推荐',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (playlist_id),
  KEY idx_playlists_creator (creator_user_id),
  KEY idx_playlists_recommended (is_recommended, created_at),
  CONSTRAINT fk_playlists_creator
    FOREIGN KEY (creator_user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单';

CREATE TABLE song_favorites (
  user_id INT UNSIGNED NOT NULL COMMENT '用户编号',
  song_id INT UNSIGNED NOT NULL COMMENT '歌曲编号',
  favorited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
  note VARCHAR(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (user_id, song_id),
  KEY idx_song_favorites_song (song_id),
  CONSTRAINT fk_song_favorites_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_song_favorites_song
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌曲收藏';

CREATE TABLE play_records (
  play_record_id BIGINT UNSIGNED AUTO_INCREMENT COMMENT '播放记录号',
  user_id INT UNSIGNED NOT NULL COMMENT '用户编号',
  song_id INT UNSIGNED NOT NULL COMMENT '歌曲编号',
  played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '播放时间',
  play_duration INT UNSIGNED DEFAULT 0 COMMENT '播放时长（秒）',
  play_source VARCHAR(50) DEFAULT NULL COMMENT '播放来源',
  PRIMARY KEY (play_record_id),
  KEY idx_play_records_user_time (user_id, played_at),
  KEY idx_play_records_song (song_id),
  CONSTRAINT fk_play_records_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_play_records_song
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌曲播放记录';

CREATE TABLE playlist_songs (
  playlist_id INT UNSIGNED NOT NULL COMMENT '歌单编号',
  song_id INT UNSIGNED NOT NULL COMMENT '歌曲编号',
  added_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  sort_order INT NOT NULL DEFAULT 1 COMMENT '排列序号',
  PRIMARY KEY (playlist_id, song_id),
  UNIQUE KEY uk_playlist_sort_order (playlist_id, sort_order),
  KEY idx_playlist_songs_song (song_id),
  CONSTRAINT fk_playlist_songs_playlist
    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_playlist_songs_song
    FOREIGN KEY (song_id) REFERENCES songs(song_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单收录';

CREATE TABLE playlist_favorites (
  user_id INT UNSIGNED NOT NULL COMMENT '用户编号',
  playlist_id INT UNSIGNED NOT NULL COMMENT '歌单编号',
  favorited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '收藏时间',
  note VARCHAR(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (user_id, playlist_id),
  KEY idx_playlist_favorites_playlist (playlist_id),
  CONSTRAINT fk_playlist_favorites_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_playlist_favorites_playlist
    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单收藏';

CREATE TABLE playlist_browse_records (
  browse_record_id BIGINT UNSIGNED AUTO_INCREMENT COMMENT '浏览记录号',
  user_id INT UNSIGNED NOT NULL COMMENT '用户编号',
  playlist_id INT UNSIGNED NOT NULL COMMENT '歌单编号',
  browsed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '浏览时间',
  stay_duration INT UNSIGNED DEFAULT 0 COMMENT '停留时长（秒）',
  PRIMARY KEY (browse_record_id),
  KEY idx_browse_records_user_time (user_id, browsed_at),
  KEY idx_browse_records_playlist (playlist_id),
  CONSTRAINT fk_browse_records_user
    FOREIGN KEY (user_id) REFERENCES users(user_id)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_browse_records_playlist
    FOREIGN KEY (playlist_id) REFERENCES playlists(playlist_id)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='歌单浏览记录';
