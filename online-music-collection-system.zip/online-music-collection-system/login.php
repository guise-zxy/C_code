<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = '用户登录';
$errors = [];
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $errors[] = '请输入用户名和密码。';
    } else {
        try {
            $stmt = $pdo->prepare('SELECT user_id, username, password_hash, nickname, role FROM users WHERE username = ? LIMIT 1');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['user'] = [
                    'user_id' => $user['user_id'],
                    'username' => $user['username'],
                    'nickname' => $user['nickname'],
                    'role' => $user['role'],
                ];

                set_flash('success', '登录成功。');
                redirect('index.php');
            }

            $errors[] = '用户名或密码错误。';
        } catch (PDOException $e) {
            $errors[] = '登录失败，请检查数据库连接。错误信息：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6 col-lg-4">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">用户登录</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/login.php" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="username">用户名</label>
                        <input class="form-control" id="username" name="username" value="<?= e($username) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="password">密码</label>
                        <input class="form-control" id="password" type="password" name="password" required>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">登录</button>
                </form>

                <div class="mt-3 small text-muted">
                    测试账号：admin / password，student / password
                </div>
                <p class="mt-3 mb-0 text-center text-muted">
                    没有账号？<a href="<?= e($baseUrl) ?>/register.php">立即注册</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
