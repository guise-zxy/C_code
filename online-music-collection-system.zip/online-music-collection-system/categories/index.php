<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '音乐分类管理';
$categories = [];
$error = '';

try {
    $stmt = $pdo->query(
        'SELECT c.category_id, c.category_name, c.category_description, c.sort_order,
                COUNT(s.song_id) AS song_count
         FROM music_categories c
         LEFT JOIN songs s ON c.category_id = s.category_id
         GROUP BY c.category_id, c.category_name, c.category_description, c.sort_order
         ORDER BY c.sort_order ASC, c.category_id ASC'
    );
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '分类列表读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">音乐分类管理</h1>
    <a class="btn btn-primary" href="<?= e($baseUrl) ?>/categories/create.php">新增分类</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>分类编号</th>
                <th>分类名称</th>
                <th>分类描述</th>
                <th>排序号</th>
                <th>歌曲数量</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($categories): ?>
                <?php foreach ($categories as $category): ?>
                    <tr>
                        <td><?= e($category['category_id']) ?></td>
                        <td class="fw-semibold"><?= e($category['category_name']) ?></td>
                        <td><?= e($category['category_description'] ?? '-') ?></td>
                        <td><?= e($category['sort_order']) ?></td>
                        <td><?= e($category['song_count']) ?></td>
                        <td class="text-end">
                            <a class="btn btn-outline-primary btn-sm" href="<?= e($baseUrl) ?>/categories/edit.php?id=<?= e($category['category_id']) ?>">编辑</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/categories/delete.php?id=<?= e($category['category_id']) ?>" onclick="return confirm('确定要删除该分类吗？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">暂无分类数据</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
