<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '编辑音乐分类';
$errors = [];
$categoryId = (int)($_GET['id'] ?? $_POST['category_id'] ?? 0);

if ($categoryId <= 0) {
    set_flash('danger', '分类编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare('SELECT * FROM music_categories WHERE category_id = ?');
    $stmt->execute([$categoryId]);
    $form = $stmt->fetch();

    if (!$form) {
        set_flash('danger', '分类不存在。');
        redirect('index.php');
    }
} catch (PDOException $e) {
    set_flash('danger', '分类读取失败：' . $e->getMessage());
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['category_name'] = trim($_POST['category_name'] ?? '');
    $form['category_description'] = trim($_POST['category_description'] ?? '');
    $form['sort_order'] = trim($_POST['sort_order'] ?? '0');

    if ($form['category_name'] === '') {
        $errors[] = '分类名称不能为空。';
    }

    if ($form['sort_order'] === '' || !is_numeric($form['sort_order'])) {
        $errors[] = '排序号必须是数字。';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare('UPDATE music_categories SET category_name = ?, category_description = ?, sort_order = ? WHERE category_id = ?');
            $stmt->execute([
                $form['category_name'],
                $form['category_description'] ?: null,
                (int)$form['sort_order'],
                $categoryId,
            ]);
            set_flash('success', '分类修改成功。');
            redirect('index.php');
        } catch (PDOException $e) {
            $errors[] = '分类修改失败：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">编辑音乐分类</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/categories/edit.php">
                    <input type="hidden" name="category_id" value="<?= e($categoryId) ?>">
                    <div class="mb-3">
                        <label class="form-label" for="category_name">分类名称</label>
                        <input class="form-control" id="category_name" name="category_name" value="<?= e($form['category_name']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="category_description">分类描述</label>
                        <textarea class="form-control" id="category_description" name="category_description" rows="3"><?= e($form['category_description']) ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="sort_order">排序号</label>
                        <input class="form-control" id="sort_order" name="sort_order" type="number" value="<?= e($form['sort_order']) ?>" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">保存</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/categories/index.php">返回</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
