<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$categoryId = (int)($_GET['id'] ?? 0);

if ($categoryId <= 0) {
    set_flash('danger', '分类编号无效。');
    redirect('index.php');
}

try {
    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM songs WHERE category_id = ?');
    $countStmt->execute([$categoryId]);

    if ((int)$countStmt->fetchColumn() > 0) {
        set_flash('warning', '该分类下已有歌曲，不能直接删除。');
        redirect('index.php');
    }

    $stmt = $pdo->prepare('DELETE FROM music_categories WHERE category_id = ?');
    $stmt->execute([$categoryId]);

    if ($stmt->rowCount() > 0) {
        set_flash('success', '分类删除成功。');
    } else {
        set_flash('warning', '分类不存在或已被删除。');
    }
} catch (PDOException $e) {
    set_flash('danger', '分类删除失败：' . $e->getMessage());
}

redirect('index.php');
