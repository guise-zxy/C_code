<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '歌曲播放记录';
$query = trim($_GET['q'] ?? '');
$records = [];
$error = '';

try {
    $params = [current_user()['user_id']];
    $where = ['pr.user_id = ?'];

    if ($query !== '') {
        $where[] = '(s.title LIKE ? OR s.artist LIKE ?)';
        $keyword = '%' . $query . '%';
        $params[] = $keyword;
        $params[] = $keyword;
    }

    $stmt = $pdo->prepare(
        'SELECT pr.played_at, pr.play_duration, pr.play_source,
                s.title, s.artist, s.album, c.category_name
         FROM play_records pr
         JOIN songs s ON pr.song_id = s.song_id
         LEFT JOIN music_categories c ON s.category_id = c.category_id
         WHERE ' . implode(' AND ', $where) . '
         ORDER BY pr.played_at DESC, pr.play_record_id DESC'
    );
    $stmt->execute($params);
    $records = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '播放记录读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">播放记录</h1>
    <div class="btn-group">
        <a class="btn btn-primary" href="<?= e($baseUrl) ?>/records/play_records.php">歌曲播放记录</a>
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/records/browse_records.php">歌单浏览记录</a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<form class="card card-body shadow-sm mb-4" method="get" action="<?= e($baseUrl) ?>/records/play_records.php">
    <div class="row g-3">
        <div class="col-md-10">
            <label class="form-label" for="q">关键词</label>
            <input class="form-control" id="q" name="q" value="<?= e($query) ?>" placeholder="搜索歌曲名或歌手">
        </div>
        <div class="col-md-2 d-flex align-items-end gap-2">
            <button class="btn btn-primary w-100" type="submit">搜索</button>
            <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/records/play_records.php">重置</a>
        </div>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>歌曲名</th>
                <th>歌手</th>
                <th>专辑</th>
                <th>分类</th>
                <th>播放时间</th>
                <th>播放时长</th>
                <th>播放来源</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($records): ?>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($record['title']) ?></td>
                        <td><?= e($record['artist']) ?></td>
                        <td><?= e($record['album'] ?? '-') ?></td>
                        <td><?= e($record['category_name'] ?? '未分类') ?></td>
                        <td><?= e($record['played_at']) ?></td>
                        <td><?= e(format_duration($record['play_duration'])) ?></td>
                        <td><?= e($record['play_source'] ?? '-') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">暂无播放记录</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
