<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '歌单浏览记录';
$records = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT pbr.browsed_at, pbr.stay_duration,
                p.playlist_name, u.nickname AS creator_name
         FROM playlist_browse_records pbr
         JOIN playlists p ON pbr.playlist_id = p.playlist_id
         JOIN users u ON p.creator_user_id = u.user_id
         WHERE pbr.user_id = ?
         ORDER BY pbr.browsed_at DESC, pbr.browse_record_id DESC'
    );
    $stmt->execute([current_user()['user_id']]);
    $records = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '浏览记录读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">播放记录</h1>
    <div class="btn-group">
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/records/play_records.php">歌曲播放记录</a>
        <a class="btn btn-primary" href="<?= e($baseUrl) ?>/records/browse_records.php">歌单浏览记录</a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>歌单名称</th>
                <th>制作用户</th>
                <th>浏览时间</th>
                <th>停留时长</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($records): ?>
                <?php foreach ($records as $record): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($record['playlist_name']) ?></td>
                        <td>ssztu</td>
                        <td><?= e($record['browsed_at']) ?></td>
                        <td><?= e(format_duration($record['stay_duration'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center text-muted py-4">暂无歌单浏览记录</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
