<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$songId = (int)($_GET['id'] ?? 0);

if ($songId <= 0) {
    set_flash('danger', '歌曲编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare(
        'SELECT s.*, c.category_name
         FROM songs s
         LEFT JOIN music_categories c ON s.category_id = c.category_id
         WHERE s.song_id = ?'
    );
    $stmt->execute([$songId]);
    $song = $stmt->fetch();

    if (!$song) {
        set_flash('danger', '歌曲不存在。');
        redirect('index.php');
    }

    $favoriteStmt = $pdo->prepare('SELECT COUNT(*) FROM song_favorites WHERE user_id = ? AND song_id = ?');
    $favoriteStmt->execute([current_user()['user_id'], $songId]);
    $isFavorited = ((int)$favoriteStmt->fetchColumn()) > 0;
} catch (PDOException $e) {
    set_flash('danger', '歌曲读取失败：' . $e->getMessage());
    redirect('index.php');
}

$pageTitle = '歌曲详情 - ' . $song['title'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">歌曲详情</h1>
    <div class="d-flex gap-2">
        <?php if ($isFavorited): ?>
            <a class="btn btn-warning" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=detail">取消收藏</a>
        <?php else: ?>
            <a class="btn btn-outline-warning" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=detail">收藏</a>
        <?php endif; ?>
        <a class="btn btn-success" href="<?= e($baseUrl) ?>/songs/play.php?id=<?= e($song['song_id']) ?>&source=detail">播放</a>
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/songs/edit.php?id=<?= e($song['song_id']) ?>">编辑</a>
        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/songs/index.php">返回</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="h4"><?= e($song['title']) ?></h2>
                <dl class="row mb-0">
                    <dt class="col-sm-4">歌曲编号</dt>
                    <dd class="col-sm-8"><?= e($song['song_id']) ?></dd>
                    <dt class="col-sm-4">歌手</dt>
                    <dd class="col-sm-8"><?= e($song['artist']) ?></dd>
                    <dt class="col-sm-4">分类</dt>
                    <dd class="col-sm-8"><?= e($song['category_name'] ?? '未分类') ?></dd>
                    <dt class="col-sm-4">专辑</dt>
                    <dd class="col-sm-8"><?= e($song['album'] ?? '-') ?></dd>
                    <dt class="col-sm-4">时长</dt>
                    <dd class="col-sm-8"><?= e(format_duration($song['duration'])) ?></dd>
                    <dt class="col-sm-4">发行日期</dt>
                    <dd class="col-sm-8"><?= e($song['release_date'] ?? '-') ?></dd>
                    <dt class="col-sm-4">语言</dt>
                    <dd class="col-sm-8"><?= e($song['language'] ?? '-') ?></dd>
                    <dt class="col-sm-4">文件路径</dt>
                    <dd class="col-sm-8"><?= e($song['file_path'] ?? '-') ?></dd>
                    <dt class="col-sm-4">封面路径</dt>
                    <dd class="col-sm-8"><?= e($song['cover_path'] ?? '-') ?></dd>
                    <dt class="col-sm-4">状态</dt>
                    <dd class="col-sm-8"><?= $song['status'] === 'active' ? '启用' : '停用' ?></dd>
                </dl>
            </div>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-body">
                <h2 class="h4">歌词</h2>
                <pre class="lyrics-box mb-0"><?= e($song['lyrics'] ?: '暂无歌词') ?></pre>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
