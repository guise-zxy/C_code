<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '歌曲管理';
$query = trim($_GET['q'] ?? '');
$categoryId = (int)($_GET['category_id'] ?? 0);
$songs = [];
$categories = [];
$error = '';

try {
    $categories = $pdo->query('SELECT category_id, category_name FROM music_categories ORDER BY sort_order ASC, category_id ASC')->fetchAll();

    $where = ['1 = 1'];
    $params = [current_user()['user_id']];

    if ($query !== '') {
        $where[] = '(s.title LIKE ? OR s.artist LIKE ? OR s.album LIKE ?)';
        $keyword = '%' . $query . '%';
        $params[] = $keyword;
        $params[] = $keyword;
        $params[] = $keyword;
    }

    if ($categoryId > 0) {
        $where[] = 's.category_id = ?';
        $params[] = $categoryId;
    }

    $sql = 'SELECT s.song_id, s.title, s.artist, s.album, s.duration, s.language, s.status,
                   c.category_name, sf.user_id AS favorited_user_id
            FROM songs s
            LEFT JOIN music_categories c ON s.category_id = c.category_id
            LEFT JOIN song_favorites sf ON s.song_id = sf.song_id AND sf.user_id = ?
            WHERE ' . implode(' AND ', $where) . '
            ORDER BY s.song_id DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $songs = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '歌曲列表读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">歌曲管理</h1>
    <a class="btn btn-primary" href="<?= e($baseUrl) ?>/songs/create.php">新增歌曲</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<form class="card card-body shadow-sm mb-4" method="get" action="<?= e($baseUrl) ?>/songs/index.php">
    <div class="row g-3">
        <div class="col-md-6">
            <label class="form-label" for="q">关键词</label>
            <input class="form-control" id="q" name="q" value="<?= e($query) ?>" placeholder="歌曲名、歌手或专辑">
        </div>
        <div class="col-md-4">
            <label class="form-label" for="category_id">音乐分类</label>
            <select class="form-select" id="category_id" name="category_id">
                <option value="0">全部分类</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?= e($category['category_id']) ?>" <?= $categoryId === (int)$category['category_id'] ? 'selected' : '' ?>>
                        <?= e($category['category_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2 d-flex align-items-end gap-2">
            <button class="btn btn-primary w-100" type="submit">搜索</button>
            <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/songs/index.php">重置</a>
        </div>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>编号</th>
                <th>歌曲名</th>
                <th>歌手</th>
                <th>分类</th>
                <th>专辑</th>
                <th>时长</th>
                <th>语言</th>
                <th>状态</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($songs): ?>
                <?php foreach ($songs as $song): ?>
                    <tr>
                        <td><?= e($song['song_id']) ?></td>
                        <td class="fw-semibold"><?= e($song['title']) ?></td>
                        <td><?= e($song['artist']) ?></td>
                        <td><?= e($song['category_name'] ?? '未分类') ?></td>
                        <td><?= e($song['album'] ?? '-') ?></td>
                        <td><?= e(format_duration($song['duration'])) ?></td>
                        <td><?= e($song['language'] ?? '-') ?></td>
                        <td><?= $song['status'] === 'active' ? '启用' : '停用' ?></td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/songs/detail.php?id=<?= e($song['song_id']) ?>">详情</a>
                            <?php if ($song['favorited_user_id']): ?>
                                <a class="btn btn-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=list">取消收藏</a>
                            <?php else: ?>
                                <a class="btn btn-outline-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=list">收藏</a>
                            <?php endif; ?>
                            <a class="btn btn-outline-primary btn-sm" href="<?= e($baseUrl) ?>/songs/edit.php?id=<?= e($song['song_id']) ?>">编辑</a>
                            <a class="btn btn-outline-success btn-sm" href="<?= e($baseUrl) ?>/songs/play.php?id=<?= e($song['song_id']) ?>&source=list">播放</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/songs/delete.php?id=<?= e($song['song_id']) ?>" onclick="return confirm('确定要删除该歌曲吗？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9" class="text-center text-muted py-4">暂无歌曲数据</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
