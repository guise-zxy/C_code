<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '新增歌曲';
$errors = [];
$categories = [];
$form = [
    'category_id' => '',
    'title' => '',
    'artist' => '',
    'album' => '',
    'duration' => '0',
    'release_date' => '',
    'language' => '',
    'lyrics' => '',
    'file_path' => '',
    'cover_path' => '',
    'status' => 'active',
];

try {
    $categories = $pdo->query('SELECT category_id, category_name FROM music_categories ORDER BY sort_order ASC, category_id ASC')->fetchAll();
} catch (PDOException $e) {
    $errors[] = '分类读取失败：' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($form as $key => $value) {
        $form[$key] = trim($_POST[$key] ?? '');
    }

    if ((int)$form['category_id'] <= 0) {
        $errors[] = '请选择音乐分类。';
    }

    if ($form['title'] === '') {
        $errors[] = '歌曲名不能为空。';
    }

    if ($form['artist'] === '') {
        $errors[] = '歌手不能为空。';
    }

    if ($form['duration'] === '' || !is_numeric($form['duration']) || (int)$form['duration'] < 0) {
        $errors[] = '时长必须是大于等于 0 的数字。';
    }

    if (!in_array($form['status'], ['active', 'inactive'], true)) {
        $errors[] = '状态不正确。';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO songs (category_id, title, artist, album, duration, release_date, language, lyrics, file_path, cover_path, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                (int)$form['category_id'],
                $form['title'],
                $form['artist'],
                $form['album'] ?: null,
                (int)$form['duration'],
                $form['release_date'] ?: null,
                $form['language'] ?: null,
                $form['lyrics'] ?: null,
                $form['file_path'] ?: null,
                $form['cover_path'] ?: null,
                $form['status'],
            ]);
            set_flash('success', '歌曲新增成功。');
            redirect('index.php');
        } catch (PDOException $e) {
            $errors[] = '歌曲新增失败：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-9">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">新增歌曲</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/songs/create.php">
                    <?php require __DIR__ . '/form.php'; ?>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">保存</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/songs/index.php">返回</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
