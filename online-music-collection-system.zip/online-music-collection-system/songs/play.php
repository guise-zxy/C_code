<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$songId = (int)($_GET['id'] ?? 0);
$source = ($_GET['source'] ?? '') === 'detail' ? '歌曲详情页' : '歌曲列表页';
$redirectUrl = ($_GET['source'] ?? '') === 'detail' ? 'detail.php?id=' . $songId : 'index.php';

if ($songId <= 0) {
    set_flash('danger', '歌曲编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare('SELECT song_id, duration FROM songs WHERE song_id = ?');
    $stmt->execute([$songId]);
    $song = $stmt->fetch();

    if (!$song) {
        set_flash('danger', '歌曲不存在。');
        redirect('index.php');
    }

    $insertStmt = $pdo->prepare(
        'INSERT INTO play_records (user_id, song_id, played_at, play_duration, play_source)
         VALUES (?, ?, NOW(), ?, ?)'
    );
    $insertStmt->execute([
        current_user()['user_id'],
        $songId,
        (int)$song['duration'],
        $source,
    ]);

    set_flash('success', '播放成功，已生成播放记录。');
} catch (PDOException $e) {
    set_flash('danger', '播放失败：' . $e->getMessage());
}

redirect($redirectUrl);
