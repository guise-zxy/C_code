<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label" for="category_id">音乐分类</label>
        <select class="form-select" id="category_id" name="category_id" required>
            <option value="">请选择分类</option>
            <?php foreach ($categories as $category): ?>
                <option value="<?= e($category['category_id']) ?>" <?= (string)$form['category_id'] === (string)$category['category_id'] ? 'selected' : '' ?>>
                    <?= e($category['category_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="title">歌曲名</label>
        <input class="form-control" id="title" name="title" value="<?= e($form['title']) ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="artist">歌手</label>
        <input class="form-control" id="artist" name="artist" value="<?= e($form['artist']) ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label" for="album">专辑</label>
        <input class="form-control" id="album" name="album" value="<?= e($form['album'] ?? '') ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="duration">时长（秒）</label>
        <input class="form-control" id="duration" name="duration" type="number" min="0" value="<?= e($form['duration'] ?? 0) ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="release_date">发行日期</label>
        <input class="form-control" id="release_date" name="release_date" type="date" value="<?= e($form['release_date'] ?? '') ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="language">语言</label>
        <input class="form-control" id="language" name="language" value="<?= e($form['language'] ?? '') ?>">
    </div>
    <div class="col-md-6">
        <label class="form-label" for="file_path">文件路径</label>
        <input class="form-control" id="file_path" name="file_path" value="<?= e($form['file_path'] ?? '') ?>">
    </div>
    <div class="col-md-6">
        <label class="form-label" for="cover_path">封面路径</label>
        <input class="form-control" id="cover_path" name="cover_path" value="<?= e($form['cover_path'] ?? '') ?>">
    </div>
    <div class="col-md-4">
        <label class="form-label" for="status">状态</label>
        <select class="form-select" id="status" name="status">
            <option value="active" <?= ($form['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>启用</option>
            <option value="inactive" <?= ($form['status'] ?? '') === 'inactive' ? 'selected' : '' ?>>停用</option>
        </select>
    </div>
    <div class="col-12">
        <label class="form-label" for="lyrics">歌词</label>
        <textarea class="form-control" id="lyrics" name="lyrics" rows="6"><?= e($form['lyrics'] ?? '') ?></textarea>
    </div>
</div>
<hr>
