<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$songId = (int)($_GET['id'] ?? 0);

if ($songId <= 0) {
    set_flash('danger', '歌曲编号无效。');
    redirect('index.php');
}

try {
    $favoriteStmt = $pdo->prepare('SELECT COUNT(*) FROM song_favorites WHERE song_id = ?');
    $favoriteStmt->execute([$songId]);
    $favoriteCount = (int)$favoriteStmt->fetchColumn();

    $recordStmt = $pdo->prepare('SELECT COUNT(*) FROM play_records WHERE song_id = ?');
    $recordStmt->execute([$songId]);
    $recordCount = (int)$recordStmt->fetchColumn();

    $playlistStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_songs WHERE song_id = ?');
    $playlistStmt->execute([$songId]);
    $playlistCount = (int)$playlistStmt->fetchColumn();

    if ($favoriteCount > 0 || $recordCount > 0 || $playlistCount > 0) {
        set_flash('warning', '该歌曲已有收藏、播放记录或歌单收录，不能直接删除。');
        redirect('index.php');
    }

    $stmt = $pdo->prepare('DELETE FROM songs WHERE song_id = ?');
    $stmt->execute([$songId]);

    if ($stmt->rowCount() > 0) {
        set_flash('success', '歌曲删除成功。');
    } else {
        set_flash('warning', '歌曲不存在或已被删除。');
    }
} catch (PDOException $e) {
    set_flash('danger', '歌曲删除失败：' . $e->getMessage());
}

redirect('index.php');
