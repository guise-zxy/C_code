<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$songId = (int)($_GET['id'] ?? 0);
$return = $_GET['return'] ?? 'list';

if ($songId <= 0) {
    set_flash('danger', '歌曲编号无效。');
    redirect('../songs/index.php');
}

try {
    $songStmt = $pdo->prepare('SELECT song_id FROM songs WHERE song_id = ?');
    $songStmt->execute([$songId]);

    if (!$songStmt->fetch()) {
        set_flash('danger', '歌曲不存在。');
        redirect('../songs/index.php');
    }

    $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM song_favorites WHERE user_id = ? AND song_id = ?');
    $checkStmt->execute([current_user()['user_id'], $songId]);
    $exists = ((int)$checkStmt->fetchColumn()) > 0;

    if ($exists) {
        $stmt = $pdo->prepare('DELETE FROM song_favorites WHERE user_id = ? AND song_id = ?');
        $stmt->execute([current_user()['user_id'], $songId]);
        set_flash('success', '已取消收藏歌曲。');
    } else {
        $stmt = $pdo->prepare('INSERT INTO song_favorites (user_id, song_id, favorited_at, note) VALUES (?, ?, NOW(), NULL)');
        $stmt->execute([current_user()['user_id'], $songId]);
        set_flash('success', '歌曲收藏成功。');
    }
} catch (PDOException $e) {
    set_flash('danger', '收藏操作失败：' . $e->getMessage());
}

if ($return === 'detail') {
    redirect('../songs/detail.php?id=' . $songId);
}

if ($return === 'favorites') {
    redirect('songs.php');
}

if ($return === 'home') {
    redirect('../index.php');
}

redirect('../songs/index.php');
