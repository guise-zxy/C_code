<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '我的歌曲收藏';
$favorites = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT sf.favorited_at, sf.note,
                s.song_id, s.title, s.artist, s.album,
                c.category_name
         FROM song_favorites sf
         JOIN songs s ON sf.song_id = s.song_id
         LEFT JOIN music_categories c ON s.category_id = c.category_id
         WHERE sf.user_id = ?
         ORDER BY sf.favorited_at DESC'
    );
    $stmt->execute([current_user()['user_id']]);
    $favorites = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '歌曲收藏读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">我的收藏</h1>
    <div class="btn-group">
        <a class="btn btn-primary" href="<?= e($baseUrl) ?>/favorites/songs.php">我的歌曲收藏</a>
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/favorites/playlists.php">我的歌单收藏</a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>歌曲名</th>
                <th>歌手</th>
                <th>分类</th>
                <th>专辑</th>
                <th>收藏时间</th>
                <th>备注</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($favorites): ?>
                <?php foreach ($favorites as $favorite): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($favorite['title']) ?></td>
                        <td><?= e($favorite['artist']) ?></td>
                        <td><?= e($favorite['category_name'] ?? '未分类') ?></td>
                        <td><?= e($favorite['album'] ?? '-') ?></td>
                        <td><?= e($favorite['favorited_at']) ?></td>
                        <td><?= e($favorite['note'] ?? '-') ?></td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/songs/detail.php?id=<?= e($favorite['song_id']) ?>">详情</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($favorite['song_id']) ?>&return=favorites" onclick="return confirm('确定要取消收藏该歌曲吗？');">取消收藏</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">暂无歌曲收藏</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
