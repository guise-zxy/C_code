<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$playlistId = (int)($_GET['id'] ?? 0);
$return = $_GET['return'] ?? 'list';

if ($playlistId <= 0) {
    set_flash('danger', '歌单编号无效。');
    redirect('../playlists/index.php');
}

try {
    $playlistStmt = $pdo->prepare('SELECT playlist_id FROM playlists WHERE playlist_id = ?');
    $playlistStmt->execute([$playlistId]);

    if (!$playlistStmt->fetch()) {
        set_flash('danger', '歌单不存在。');
        redirect('../playlists/index.php');
    }

    $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_favorites WHERE user_id = ? AND playlist_id = ?');
    $checkStmt->execute([current_user()['user_id'], $playlistId]);
    $exists = ((int)$checkStmt->fetchColumn()) > 0;

    if ($exists) {
        $stmt = $pdo->prepare('DELETE FROM playlist_favorites WHERE user_id = ? AND playlist_id = ?');
        $stmt->execute([current_user()['user_id'], $playlistId]);
        set_flash('success', '已取消收藏歌单。');
    } else {
        $stmt = $pdo->prepare('INSERT INTO playlist_favorites (user_id, playlist_id, favorited_at, note) VALUES (?, ?, NOW(), NULL)');
        $stmt->execute([current_user()['user_id'], $playlistId]);
        set_flash('success', '歌单收藏成功。');
    }
} catch (PDOException $e) {
    set_flash('danger', '收藏操作失败：' . $e->getMessage());
}

if ($return === 'detail') {
    redirect('../playlists/detail.php?id=' . $playlistId);
}

if ($return === 'favorites') {
    redirect('playlists.php');
}

if ($return === 'home') {
    redirect('../index.php');
}

redirect('../playlists/index.php');
