<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '我的歌单收藏';
$favorites = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT pf.favorited_at, pf.note,
                p.playlist_id, p.playlist_name, p.description, p.is_recommended,
                u.nickname AS creator_name
         FROM playlist_favorites pf
         JOIN playlists p ON pf.playlist_id = p.playlist_id
         JOIN users u ON p.creator_user_id = u.user_id
         WHERE pf.user_id = ?
         ORDER BY pf.favorited_at DESC'
    );
    $stmt->execute([current_user()['user_id']]);
    $favorites = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '歌单收藏读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">我的收藏</h1>
    <div class="btn-group">
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/favorites/songs.php">我的歌曲收藏</a>
        <a class="btn btn-primary" href="<?= e($baseUrl) ?>/favorites/playlists.php">我的歌单收藏</a>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>歌单名称</th>
                <th>制作用户</th>
                <th>简介</th>
                <th>是否推荐</th>
                <th>收藏时间</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($favorites): ?>
                <?php foreach ($favorites as $favorite): ?>
                    <tr>
                        <td class="fw-semibold"><?= e($favorite['playlist_name']) ?></td>
                        <td>ssztu</td>
                        <td><?= e($favorite['description'] ?? '-') ?></td>
                        <td><?= (int)$favorite['is_recommended'] === 1 ? '是' : '否' ?></td>
                        <td><?= e($favorite['favorited_at']) ?></td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/playlists/detail.php?id=<?= e($favorite['playlist_id']) ?>">详情</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($favorite['playlist_id']) ?>&return=favorites" onclick="return confirm('确定要取消收藏该歌单吗？');">取消收藏</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center text-muted py-4">暂无歌单收藏</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
