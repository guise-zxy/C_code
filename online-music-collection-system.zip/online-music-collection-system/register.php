<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';

$pageTitle = '用户注册';
$errors = [];
$form = [
    'username' => '',
    'nickname' => '',
    'email' => '',
    'phone' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['username'] = trim($_POST['username'] ?? '');
    $form['nickname'] = trim($_POST['nickname'] ?? '');
    $form['email'] = trim($_POST['email'] ?? '');
    $form['phone'] = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($form['username'] === '' || !preg_match('/^[A-Za-z0-9_]{3,50}$/', $form['username'])) {
        $errors[] = '用户名必须为 3-50 位字母、数字或下划线。';
    }

    if ($form['nickname'] === '') {
        $errors[] = '昵称不能为空。';
    }

    if ($form['email'] !== '' && !filter_var($form['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = '邮箱格式不正确。';
    }

    if (strlen($password) < 6) {
        $errors[] = '密码长度至少为 6 位。';
    }

    if ($password !== $confirmPassword) {
        $errors[] = '两次输入的密码不一致。';
    }

    if (!$errors) {
        try {
            $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ?');
            $checkStmt->execute([$form['username']]);

            if ((int)$checkStmt->fetchColumn() > 0) {
                $errors[] = '用户名已存在，请换一个用户名。';
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO users (username, password_hash, nickname, email, phone, role) VALUES (?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([
                    $form['username'],
                    password_hash($password, PASSWORD_DEFAULT),
                    $form['nickname'],
                    $form['email'] ?: null,
                    $form['phone'] ?: null,
                    'user',
                ]);

                set_flash('success', '注册成功，请登录。');
                redirect('login.php');
            }
        } catch (PDOException $e) {
            $errors[] = '注册失败，请稍后再试。错误信息：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-7 col-lg-5">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">用户注册</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/register.php" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="username">用户名</label>
                        <input class="form-control" id="username" name="username" value="<?= e($form['username']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="nickname">昵称</label>
                        <input class="form-control" id="nickname" name="nickname" value="<?= e($form['nickname']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="email">邮箱</label>
                        <input class="form-control" id="email" type="email" name="email" value="<?= e($form['email']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="phone">电话</label>
                        <input class="form-control" id="phone" name="phone" value="<?= e($form['phone']) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="password">密码</label>
                        <input class="form-control" id="password" type="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="confirm_password">确认密码</label>
                        <input class="form-control" id="confirm_password" type="password" name="confirm_password" required>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">注册</button>
                </form>

                <p class="mt-3 mb-0 text-center text-muted">
                    已有账号？<a href="<?= e($baseUrl) ?>/login.php">去登录</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
