<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$pageTitle = $pageTitle ?? '在线音乐收藏管理系统';
$currentPage = basename($_SERVER['PHP_SELF']);
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$projectFolder = 'online-music-collection-system';
$projectPos = strpos($scriptName, '/' . $projectFolder . '/');

if ($projectPos !== false) {
    $baseUrl = substr($scriptName, 0, $projectPos + strlen('/' . $projectFolder));
} else {
    $baseUrl = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
}

$flash = get_flash();
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= e($baseUrl) ?>/assets/css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark navbar-klein" style="background-color: #002fa7;">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?= e($baseUrl) ?>/index.php">音乐收藏系统</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="切换导航">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link <?= $currentPage === 'index.php' ? 'active' : '' ?>" href="<?= e($baseUrl) ?>/index.php">首页</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/songs/index.php">歌曲</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/categories/index.php">分类</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/playlists/index.php">歌单</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/favorites/songs.php">我的收藏</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/records/play_records.php">播放记录</a></li>
                <?php if (is_logged_in()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?= e($baseUrl) ?>/users/profile.php">个人资料</a></li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto">
                <?php if (is_logged_in()): ?>
                    <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="<?= e($baseUrl) ?>/logout.php">退出</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link <?= $currentPage === 'login.php' ? 'active' : '' ?>" href="<?= e($baseUrl) ?>/login.php">登录</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm" href="<?= e($baseUrl) ?>/register.php">注册</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="container py-4">
    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
            <?= e($flash['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="关闭"></button>
        </div>
    <?php endif; ?>
