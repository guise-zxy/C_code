<?php
function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($url)
{
    header('Location: ' . $url);
    exit;
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message,
    ];
}

function get_flash()
{
    if (empty($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

function format_duration($seconds)
{
    $seconds = (int)$seconds;
    $minutes = floor($seconds / 60);
    $remainSeconds = $seconds % 60;
    return sprintf('%d:%02d', $minutes, $remainSeconds);
}
