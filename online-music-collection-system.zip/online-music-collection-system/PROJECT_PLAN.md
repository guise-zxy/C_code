# 在线音乐收藏管理系统开发计划书

## 1. 项目背景

本项目是数据库系统课程综合实验，目标是开发一个基于 Web 的在线音乐收藏管理系统。系统需要完成需求分析、数据库设计、前后端设计、数据库和前后端代码开发、测试和测试用例撰写，并支持现场演示数据的增、删、改、查和合理展示。

## 2. 技术栈

- 前端：HTML + CSS + JavaScript + Bootstrap
- 后端：PHP
- 数据库：MySQL
- 运行环境：phpstudy / Apache + PHP + MySQL
- 数据库管理：phpMyAdmin

不使用 Vue、React、Node.js、Composer、Laravel、Spring Boot 等复杂框架，优先保证本地运行稳定和演示可靠。

## 3. 系统核心功能

### 3.1 用户模块

- 用户注册
- 用户登录
- 用户退出
- 个人资料查看与修改
- 基于 Session 维护登录状态

### 3.2 首页模块

首页需要展示：

- 搜索框
- 当前用户收藏歌曲数量
- 推荐歌单
- 音乐分类
- 最新歌曲或热门歌曲

### 3.3 音乐分类模块

- 分类列表
- 新增分类
- 修改分类
- 删除分类
- 分类下歌曲列表

### 3.4 歌曲模块

- 歌曲列表
- 歌曲搜索
- 新增歌曲
- 修改歌曲
- 删除歌曲
- 歌曲详情
- 歌词查看
- 点击播放时生成播放记录

### 3.5 歌单模块

- 歌单列表
- 创建歌单
- 修改歌单
- 删除歌单
- 推荐歌单展示
- 歌单详情
- 歌单收录歌曲
- 从歌单移除歌曲
- 进入歌单详情时生成浏览记录

### 3.6 收藏模块

- 收藏歌曲
- 取消收藏歌曲
- 查看我的歌曲收藏
- 收藏歌单
- 取消收藏歌单
- 查看我的歌单收藏

### 3.7 记录模块

- 查看歌曲播放记录
- 查看歌单浏览记录

## 4. 最终关系模式

### 用户 users

用户（用户编号，用户名，密码摘要，昵称，邮箱，电话，头像，角色，注册时间）

### 音乐分类 music_categories

音乐分类（分类编号，分类名称，分类描述，排序号）

### 歌曲 songs

歌曲（歌曲编号，分类编号 FK，歌曲名，歌手，专辑，时长，发行日期，语言，歌词，文件路径，封面路径，状态）

### 歌单 playlists

歌单（歌单编号，制作用户编号 FK，歌单名称，简介，封面路径，是否推荐，创建时间）

### 歌曲收藏 song_favorites

歌曲收藏（用户编号 FK，歌曲编号 FK，收藏时间，备注）

### 歌曲播放记录 play_records

歌曲播放记录（播放记录号，用户编号 FK，歌曲编号 FK，播放时间，播放时长，播放来源）

### 歌单收录 playlist_songs

歌单收录（歌单编号 FK，歌曲编号 FK，加入时间，排列序号）

### 歌单收藏 playlist_favorites

歌单收藏（用户编号 FK，歌单编号 FK，收藏时间，备注）

### 歌单浏览记录 playlist_browse_records

歌单浏览记录（浏览记录号，用户编号 FK，歌单编号 FK，浏览时间，停留时长）

## 5. 数据库设计要求

- 数据库名建议：music_collection_db
- 字符集：utf8mb4
- 存储引擎：InnoDB
- 使用主键和外键保证实体完整性和参照完整性
- 多对多关系必须建立中间表
- 歌曲播放记录和歌单浏览记录属于记录型联系，必须使用独立记录编号作为主键
- 用户密码不能明文存储，应使用 PHP password_hash 和 password_verify
- SQL 操作必须使用 PDO 或 mysqli 预处理，避免 SQL 注入
- 表名和字段名使用英文，页面显示使用中文

## 6. 页面规划

建议目录结构：

```text
online-music-collection-system/
├── README.md
├── index.php
├── login.php
├── register.php
├── logout.php
├── database/
│   ├── schema.sql
│   └── seed.sql
├── config/
│   └── db.php
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── auth.php
│   └── functions.php
├── assets/
│   ├── css/
│   │   └── style.css
│   └── js/
│       └── main.js
├── users/
│   └── profile.php
├── categories/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   └── delete.php
├── songs/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   ├── delete.php
│   ├── detail.php
│   └── play.php
├── playlists/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   ├── delete.php
│   ├── detail.php
│   ├── add_song.php
│   └── remove_song.php
├── favorites/
│   ├── songs.php
│   ├── toggle_song.php
│   ├── playlists.php
│   └── toggle_playlist.php
└── records/
    ├── play_records.php
    └── browse_records.php