<?php
$configPath = __DIR__ . '/config/db.php';

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function add_check(&$checks, $name, $ok, $message)
{
    $checks[] = [
        'name' => $name,
        'ok' => (bool)$ok,
        'message' => $message,
    ];
}

function read_config_value($configText, $name, $default = null)
{
    $pattern = '/\$' . preg_quote($name, '/') . '\s*=\s*([\'"])(.*?)\1\s*;/';
    if (preg_match($pattern, $configText, $matches)) {
        return $matches[2];
    }
    return $default;
}

$checks = [];
$configText = is_file($configPath) ? file_get_contents($configPath) : '';

$dbHost = read_config_value($configText, 'dbHost', '127.0.0.1');
$dbName = read_config_value($configText, 'dbName', 'music_collection_db');
$dbUser = read_config_value($configText, 'dbUser', 'root');
$dbPass = read_config_value($configText, 'dbPass', '');
$dbCharset = read_config_value($configText, 'dbCharset', 'utf8mb4');

add_check($checks, 'PHP 是否正常运行', true, '当前 PHP 版本：' . PHP_VERSION);
add_check($checks, 'PDO 是否可用', class_exists('PDO'), class_exists('PDO') ? 'PDO 扩展已启用。' : 'PDO 扩展不可用，请在 phpstudy 中启用 PDO。');
add_check($checks, 'config/db.php 是否存在', is_file($configPath), is_file($configPath) ? '已读取配置文件。' : '未找到 config/db.php。');

$mysqlConnected = false;
$databaseConnected = false;
$usersTableExists = false;
$adminUserExists = false;

if (class_exists('PDO') && is_file($configPath)) {
    try {
        $mysqlDsn = "mysql:host={$dbHost};charset={$dbCharset}";
        $mysqlPdo = new PDO($mysqlDsn, $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $mysqlConnected = true;
        add_check($checks, '是否能连接 MySQL', true, 'MySQL 连接成功。');
    } catch (PDOException $e) {
        add_check($checks, '是否能连接 MySQL', false, 'MySQL 连接失败：' . $e->getMessage() . '。请检查 MySQL 是否启动，以及 config/db.php 中的用户名和密码。');
    }

    if ($mysqlConnected) {
        try {
            $dbDsn = "mysql:host={$dbHost};dbname={$dbName};charset={$dbCharset}";
            $pdo = new PDO($dbDsn, $dbUser, $dbPass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            $databaseConnected = true;
            add_check($checks, '是否能连接 music_collection_db', true, '数据库连接成功。');
        } catch (PDOException $e) {
            add_check($checks, '是否能连接 music_collection_db', false, '数据库连接失败：' . $e->getMessage() . '。请确认已经先导入 database/schema.sql。');
        }
    }

    if ($databaseConnected) {
        try {
            $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
            $usersTableExists = (bool)$stmt->fetchColumn();
            add_check($checks, 'users 表是否存在', $usersTableExists, $usersTableExists ? 'users 表存在。' : 'users 表不存在，请重新导入 database/schema.sql。');
        } catch (PDOException $e) {
            add_check($checks, 'users 表是否存在', false, '检查 users 表失败：' . $e->getMessage());
        }
    }

    if ($usersTableExists) {
        try {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ?');
            $stmt->execute(['admin']);
            $adminUserExists = ((int)$stmt->fetchColumn()) > 0;
            add_check($checks, 'admin 用户是否存在', $adminUserExists, $adminUserExists ? 'admin 用户存在。' : 'admin 用户不存在，请导入 database/seed.sql。');
        } catch (PDOException $e) {
            add_check($checks, 'admin 用户是否存在', false, '检查 admin 用户失败：' . $e->getMessage());
        }
    }
}

$allPassed = !in_array(false, array_column($checks, 'ok'), true);
?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>本地环境检查</title>
    <style>
        body {
            font-family: Arial, "Microsoft YaHei", sans-serif;
            background: #f5f7fb;
            color: #222;
            margin: 0;
            padding: 32px;
        }
        .wrap {
            max-width: 920px;
            margin: 0 auto;
            background: #fff;
            border: 1px solid #e4e7ef;
            border-radius: 8px;
            padding: 28px;
        }
        h1 {
            margin-top: 0;
        }
        .summary {
            padding: 12px 16px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .summary.ok {
            background: #e9f8ef;
            color: #176b35;
        }
        .summary.fail {
            background: #fff0f0;
            color: #9f1d1d;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border-bottom: 1px solid #edf0f5;
            padding: 12px;
            text-align: left;
            vertical-align: top;
        }
        th {
            background: #f8fafc;
        }
        .pass {
            color: #177245;
            font-weight: bold;
        }
        .fail {
            color: #b42318;
            font-weight: bold;
        }
        .config {
            margin-top: 24px;
            background: #f8fafc;
            border: 1px solid #edf0f5;
            border-radius: 6px;
            padding: 16px;
        }
        code {
            background: #eef2f7;
            padding: 2px 5px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<div class="wrap">
    <h1>本地环境检查</h1>
    <div class="summary <?= $allPassed ? 'ok' : 'fail' ?>">
        <?= $allPassed ? '基础环境检查通过。' : '部分检查未通过，请按提示处理。' ?>
    </div>

    <table>
        <thead>
        <tr>
            <th>检查项</th>
            <th>结果</th>
            <th>说明</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($checks as $check): ?>
            <tr>
                <td><?= h($check['name']) ?></td>
                <td class="<?= $check['ok'] ? 'pass' : 'fail' ?>"><?= $check['ok'] ? '通过' : '失败' ?></td>
                <td><?= h($check['message']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="config">
        <h2>当前读取到的数据库配置</h2>
        <p>主机：<code><?= h($dbHost) ?></code></p>
        <p>数据库名：<code><?= h($dbName) ?></code></p>
        <p>用户名：<code><?= h($dbUser) ?></code></p>
        <p>字符集：<code><?= h($dbCharset) ?></code></p>
        <p>密码：已配置，但不会在页面中显示。</p>
        <p>如果 MySQL 连接失败，请在 <code>config/db.php</code> 中尝试将 <code>$dbPass</code> 改为 <code>root</code> 或空字符串。</p>
    </div>
</div>
</body>
</html>
