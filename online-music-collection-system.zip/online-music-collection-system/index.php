<?php
session_start();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = '首页 - 在线音乐收藏管理系统';
$favoriteCount = 0;
$recommendedPlaylists = [];
$categories = [];
$songs = [];
$query = trim($_GET['q'] ?? '');
$dbError = '';
$currentUserId = is_logged_in() ? (int)current_user()['user_id'] : 0;

try {
    if (is_logged_in()) {
        $countStmt = $pdo->prepare('SELECT COUNT(*) FROM song_favorites WHERE user_id = ?');
        $countStmt->execute([current_user()['user_id']]);
        $favoriteCount = (int)$countStmt->fetchColumn();
    }

    $playlistStmt = $pdo->prepare(
        'SELECT p.playlist_id, p.playlist_name, p.description, p.cover_path, u.nickname AS creator_name,
                COUNT(ps.song_id) AS song_count, pf.user_id AS favorited_user_id
         FROM playlists p
         JOIN users u ON p.creator_user_id = u.user_id
         LEFT JOIN playlist_songs ps ON p.playlist_id = ps.playlist_id
         LEFT JOIN playlist_favorites pf ON p.playlist_id = pf.playlist_id AND pf.user_id = ?
         WHERE p.is_recommended = 1
         GROUP BY p.playlist_id, p.playlist_name, p.description, p.cover_path, u.nickname, pf.user_id
         ORDER BY p.created_at DESC
         LIMIT 4'
    );
    $playlistStmt->execute([$currentUserId]);
    $recommendedPlaylists = $playlistStmt->fetchAll();

    $categoryStmt = $pdo->query(
        'SELECT c.category_id, c.category_name, c.category_description, COUNT(s.song_id) AS song_count
         FROM music_categories c
         LEFT JOIN songs s ON c.category_id = s.category_id AND s.status = "active"
         GROUP BY c.category_id, c.category_name, c.category_description, c.sort_order
         ORDER BY c.sort_order ASC, c.category_id ASC'
    );
    $categories = $categoryStmt->fetchAll();

    if ($query !== '') {
        $songStmt = $pdo->prepare(
            'SELECT s.song_id, s.title, s.artist, s.album, s.duration, s.language, c.category_name,
                    sf.user_id AS favorited_user_id
             FROM songs s
             LEFT JOIN music_categories c ON s.category_id = c.category_id
             LEFT JOIN song_favorites sf ON s.song_id = sf.song_id AND sf.user_id = ?
             WHERE s.status = "active"
               AND (s.title LIKE ? OR s.artist LIKE ? OR s.album LIKE ?)
             ORDER BY s.song_id DESC
             LIMIT 10'
        );
        $keyword = '%' . $query . '%';
        $songStmt->execute([$currentUserId, $keyword, $keyword, $keyword]);
    } else {
        $songStmt = $pdo->prepare(
            'SELECT s.song_id, s.title, s.artist, s.album, s.duration, s.language, c.category_name,
                    sf.user_id AS favorited_user_id
             FROM songs s
             LEFT JOIN music_categories c ON s.category_id = c.category_id
             LEFT JOIN song_favorites sf ON s.song_id = sf.song_id AND sf.user_id = ?
             WHERE s.status = "active"
             ORDER BY s.song_id DESC
             LIMIT 8'
        );
        $songStmt->execute([$currentUserId]);
    }
    $songs = $songStmt->fetchAll();
} catch (PDOException $e) {
    $dbError = '首页数据读取失败，请检查数据库是否已导入。错误信息：' . $e->getMessage();
}

require_once __DIR__ . '/includes/header.php';
?>

<section class="hero-section mb-4">
    <div class="row align-items-center g-4">
        <div class="col-lg-8">
            <h1 class="display-6 fw-bold">在线音乐收藏管理系统</h1>
            <p class="lead mb-0">支持用户账号、音乐分类、歌曲、歌单、收藏和播放记录等核心数据关系。</p>
        </div>
        <div class="col-lg-4">
            <div class="stat-box">
                <div class="text-muted">我的收藏歌曲</div>
                <div class="stat-number"><?= is_logged_in() ? e($favoriteCount) : '-' ?></div>
                <div class="small text-muted"><?= is_logged_in() ? '当前登录用户统计' : '登录后查看个人收藏数量' ?></div>
            </div>
        </div>
    </div>
</section>

<?php if ($dbError): ?>
    <div class="alert alert-danger"><?= e($dbError) ?></div>
<?php endif; ?>

<?php if (!is_logged_in()): ?>
    <div class="alert alert-info">
        当前未登录。你可以先浏览首页展示数据，登录后可查看自己的收藏数量。
        <a class="alert-link" href="<?= e($baseUrl) ?>/login.php">去登录</a>
    </div>
<?php endif; ?>

<form class="row g-2 mb-4" method="get" action="<?= e($baseUrl) ?>/index.php">
    <div class="col-md-10">
        <input class="form-control form-control-lg" type="search" name="q" value="<?= e($query) ?>" placeholder="搜索歌曲名、歌手或专辑">
    </div>
    <div class="col-md-2 d-grid">
        <button class="btn btn-primary btn-lg" type="submit">搜索</button>
    </div>
</form>

<div class="row g-4">
    <section class="col-lg-8">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="h4 mb-0"><?= $query !== '' ? '搜索结果' : '歌曲列表' ?></h2>
            <?php if ($query !== ''): ?>
                <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/index.php">清除搜索</a>
            <?php endif; ?>
        </div>
        <div class="table-responsive card shadow-sm">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                <tr>
                    <th>歌曲</th>
                    <th>歌手</th>
                    <th>分类</th>
                    <th>专辑</th>
                    <th>时长</th>
                    <th>语言</th>
                    <th class="text-end">操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($songs): ?>
                    <?php foreach ($songs as $song): ?>
                        <tr>
                            <td class="fw-semibold"><?= e($song['title']) ?></td>
                            <td><?= e($song['artist']) ?></td>
                            <td><?= e($song['category_name'] ?? '未分类') ?></td>
                            <td><?= e($song['album'] ?? '-') ?></td>
                            <td><?= e(format_duration($song['duration'])) ?></td>
                            <td><?= e($song['language'] ?? '-') ?></td>
                            <td class="text-end text-nowrap">
                                <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/songs/detail.php?id=<?= e($song['song_id']) ?>">详情</a>
                                <?php if (is_logged_in()): ?>
                                    <a class="btn btn-outline-success btn-sm" href="<?= e($baseUrl) ?>/songs/play.php?id=<?= e($song['song_id']) ?>&source=list">播放</a>
                                    <?php if ($song['favorited_user_id']): ?>
                                        <a class="btn btn-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=home">取消收藏</a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_song.php?id=<?= e($song['song_id']) ?>&return=home">收藏</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">暂无歌曲数据</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <aside class="col-lg-4">
        <h2 class="h4 mb-3">音乐分类</h2>
        <div class="list-group shadow-sm mb-4">
            <?php if ($categories): ?>
                <?php foreach ($categories as $category): ?>
                    <div class="list-group-item">
                        <div class="d-flex justify-content-between">
                            <span class="fw-semibold"><?= e($category['category_name']) ?></span>
                            <span class="badge text-bg-primary"><?= e($category['song_count']) ?> 首</span>
                        </div>
                        <div class="small text-muted mt-1"><?= e($category['category_description']) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="list-group-item text-muted">暂无分类数据</div>
            <?php endif; ?>
        </div>
    </aside>
</div>

<section class="mt-5">
    <h2 class="h4 mb-3">推荐歌单</h2>
    <div class="row g-3">
        <?php if ($recommendedPlaylists): ?>
            <?php foreach ($recommendedPlaylists as $playlist): ?>
                <div class="col-md-6 col-lg-3">
                    <div class="card playlist-card h-100 shadow-sm">
                        <div class="card-body">
                            <span class="badge text-bg-success mb-2">推荐</span>
                            <h3 class="h5"><?= e($playlist['playlist_name']) ?></h3>
                            <p class="text-muted small"><?= e($playlist['description']) ?></p>
                            <div class="small text-muted">
                                制作人：ssztu · <?= e($playlist['song_count']) ?> 首歌
                            </div>
                            <div class="mt-3 d-flex gap-2">
                                <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/playlists/detail.php?id=<?= e($playlist['playlist_id']) ?>">详情</a>
                                <?php if (is_logged_in()): ?>
                                    <?php if ($playlist['favorited_user_id']): ?>
                                        <a class="btn btn-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlist['playlist_id']) ?>&return=home">取消收藏</a>
                                    <?php else: ?>
                                        <a class="btn btn-outline-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlist['playlist_id']) ?>&return=home">收藏</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-secondary mb-0">暂无推荐歌单数据</div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
