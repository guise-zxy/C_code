<?php
// 数据库连接配置：在 phpstudy 中按实际 MySQL 用户名和密码修改这里。
$dbHost = '127.0.0.1';
$dbName = 'music_collection_db';
$dbUser = 'root';
$dbPass = 'root';
$dbCharset = 'utf8mb4';

$dsn = "mysql:host={$dbHost};dbname={$dbName};charset={$dbCharset}";

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    die('数据库连接失败，请检查 config/db.php 中的数据库配置。错误信息：' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
}
