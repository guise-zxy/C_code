# 在线音乐收藏管理系统

这是数据库系统课程综合实验项目，使用传统 PHP 多页面方式实现在线音乐收藏管理。系统围绕用户、音乐分类、歌曲、歌单、收藏、播放记录和浏览记录等 9 张表展开，支持课程现场演示中的增、删、改、查和记录型联系展示。

## 技术栈

- 前端：HTML、CSS、JavaScript、Bootstrap
- 后端：PHP
- 数据库：MySQL
- 数据库访问：PDO 预处理
- 运行环境：phpstudy / Apache + PHP + MySQL
- 数据库管理：phpMyAdmin

## 运行环境

推荐环境：

- Windows
- phpstudy
- Apache
- PHP 7.x 或 8.x
- MySQL
- phpMyAdmin

当前本地运行目录示例：

```text
D:\phpstudy_pro\WWW\online-music-collection-system
```

访问地址：

```text
http://localhost/online-music-collection-system/
```

环境检查页：

```text
http://localhost/online-music-collection-system/setup_check.php
```

## 数据库导入步骤

1. 启动 phpstudy 中的 Apache 和 MySQL。
2. 打开 phpMyAdmin。
3. 先导入：

```text
database/schema.sql
```

4. 再导入：

```text
database/seed.sql
```

`schema.sql` 会创建数据库 `music_collection_db` 和 9 张表。  
`seed.sql` 会插入测试用户、分类、歌曲、歌单、收藏和记录数据。

## 数据库连接配置

配置文件：

```text
config/db.php
```

默认配置：

```php
$dbHost = '127.0.0.1';
$dbName = 'music_collection_db';
$dbUser = 'root';
$dbPass = 'root';
$dbCharset = 'utf8mb4';
```

如果 MySQL 密码为空，请改为：

```php
$dbPass = '';
```

## 测试账号

| 角色 | 用户名 | 密码 |
| --- | --- | --- |
| 管理员 | admin | password |
| 普通用户 | student | password |

## 主要功能

- 用户注册、登录、退出
- 个人资料查看与修改
- 首页搜索、分类展示、推荐歌单、歌曲入口
- 音乐分类管理：新增、修改、删除、查看
- 歌曲管理：新增、修改、删除、搜索、详情、歌词查看、播放
- 歌单管理：创建、修改、删除、详情
- 歌单收录歌曲：添加歌曲、移除歌曲
- 歌曲收藏：收藏、取消收藏、我的歌曲收藏
- 歌单收藏：收藏、取消收藏、我的歌单收藏
- 歌曲播放记录查看
- 歌单浏览记录查看

## 项目目录结构

```text
online-music-collection-system/
├── index.php
├── login.php
├── register.php
├── logout.php
├── setup_check.php
├── README.md
├── TEST_CASES.md
├── DEMO_SCRIPT.md
├── database/
│   ├── schema.sql
│   └── seed.sql
├── config/
│   └── db.php
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── auth.php
│   └── functions.php
├── assets/
│   ├── css/style.css
│   └── js/main.js
├── users/
│   └── profile.php
├── categories/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   └── delete.php
├── songs/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   ├── delete.php
│   ├── detail.php
│   └── play.php
├── playlists/
│   ├── index.php
│   ├── create.php
│   ├── edit.php
│   ├── delete.php
│   ├── detail.php
│   ├── add_song.php
│   └── remove_song.php
├── favorites/
│   ├── songs.php
│   ├── playlists.php
│   ├── toggle_song.php
│   └── toggle_playlist.php
└── records/
    ├── play_records.php
    └── browse_records.php
```

## 演示入口说明

- 首页：`index.php`
- 歌曲管理：`songs/index.php`
- 分类管理：`categories/index.php`
- 歌单管理：`playlists/index.php`
- 我的收藏：`favorites/songs.php`
- 播放记录：`records/play_records.php`
- 个人资料：`users/profile.php`

推荐按 `DEMO_SCRIPT.md` 的顺序进行现场演示，按 `TEST_CASES.md` 做功能测试。
