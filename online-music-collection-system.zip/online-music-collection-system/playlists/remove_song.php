<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$playlistId = (int)($_GET['playlist_id'] ?? 0);
$songId = (int)($_GET['song_id'] ?? 0);

if ($playlistId <= 0 || $songId <= 0) {
    set_flash('danger', '歌单编号或歌曲编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare('DELETE FROM playlist_songs WHERE playlist_id = ? AND song_id = ?');
    $stmt->execute([$playlistId, $songId]);

    if ($stmt->rowCount() > 0) {
        set_flash('success', '歌曲已从歌单中移除。');
    } else {
        set_flash('warning', '该歌曲不在歌单中或已被移除。');
    }
} catch (PDOException $e) {
    set_flash('danger', '移除歌曲失败：' . $e->getMessage());
}

redirect('detail.php?id=' . $playlistId);
