<div class="mb-3">
    <label class="form-label" for="playlist_name">歌单名称</label>
    <input class="form-control" id="playlist_name" name="playlist_name" value="<?= e($form['playlist_name']) ?>" required>
</div>
<div class="mb-3">
    <label class="form-label" for="description">简介</label>
    <textarea class="form-control" id="description" name="description" rows="4"><?= e($form['description'] ?? '') ?></textarea>
</div>
<div class="mb-3">
    <label class="form-label" for="cover_path">封面路径</label>
    <input class="form-control" id="cover_path" name="cover_path" value="<?= e($form['cover_path'] ?? '') ?>">
</div>
<div class="form-check mb-4">
    <input class="form-check-input" id="is_recommended" name="is_recommended" type="checkbox" value="1" <?= !empty($form['is_recommended']) ? 'checked' : '' ?>>
    <label class="form-check-label" for="is_recommended">推荐展示</label>
</div>
