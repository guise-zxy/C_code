<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$playlistId = (int)($_GET['id'] ?? 0);

if ($playlistId <= 0) {
    set_flash('danger', '歌单编号无效。');
    redirect('index.php');
}

try {
    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = ?');
    $countStmt->execute([$playlistId]);

    if ((int)$countStmt->fetchColumn() > 0) {
        set_flash('warning', '该歌单已收录歌曲，不能直接删除。');
        redirect('index.php');
    }

    $stmt = $pdo->prepare('DELETE FROM playlists WHERE playlist_id = ?');
    $stmt->execute([$playlistId]);

    if ($stmt->rowCount() > 0) {
        set_flash('success', '歌单删除成功。');
    } else {
        set_flash('warning', '歌单不存在或已被删除。');
    }
} catch (PDOException $e) {
    set_flash('danger', '歌单删除失败：' . $e->getMessage());
}

redirect('index.php');
