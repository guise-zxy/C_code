<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$playlistId = (int)($_GET['id'] ?? 0);

if ($playlistId <= 0) {
    set_flash('danger', '歌单编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare(
        'SELECT p.*, u.nickname AS creator_name
         FROM playlists p
         JOIN users u ON p.creator_user_id = u.user_id
         WHERE p.playlist_id = ?'
    );
    $stmt->execute([$playlistId]);
    $playlist = $stmt->fetch();

    if (!$playlist) {
        set_flash('danger', '歌单不存在。');
        redirect('index.php');
    }

    $browseStmt = $pdo->prepare(
        'INSERT INTO playlist_browse_records (user_id, playlist_id, browsed_at, stay_duration)
         VALUES (?, ?, NOW(), 0)'
    );
    $browseStmt->execute([current_user()['user_id'], $playlistId]);

    $favoriteStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_favorites WHERE user_id = ? AND playlist_id = ?');
    $favoriteStmt->execute([current_user()['user_id'], $playlistId]);
    $isFavorited = ((int)$favoriteStmt->fetchColumn()) > 0;

    $songStmt = $pdo->prepare(
        'SELECT ps.playlist_id, ps.song_id, ps.added_at, ps.sort_order,
                s.title, s.artist, s.album, s.duration, c.category_name
         FROM playlist_songs ps
         JOIN songs s ON ps.song_id = s.song_id
         LEFT JOIN music_categories c ON s.category_id = c.category_id
         WHERE ps.playlist_id = ?
         ORDER BY ps.sort_order ASC, ps.added_at ASC'
    );
    $songStmt->execute([$playlistId]);
    $songs = $songStmt->fetchAll();
} catch (PDOException $e) {
    set_flash('danger', '歌单详情读取失败：' . $e->getMessage());
    redirect('index.php');
}

$pageTitle = '歌单详情 - ' . $playlist['playlist_name'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">歌单详情</h1>
    <div class="d-flex gap-2">
        <?php if ($isFavorited): ?>
            <a class="btn btn-warning" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlistId) ?>&return=detail">取消收藏</a>
        <?php else: ?>
            <a class="btn btn-outline-warning" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlistId) ?>&return=detail">收藏</a>
        <?php endif; ?>
        <a class="btn btn-primary" href="<?= e($baseUrl) ?>/playlists/add_song.php?playlist_id=<?= e($playlistId) ?>">添加歌曲到歌单</a>
        <a class="btn btn-outline-primary" href="<?= e($baseUrl) ?>/playlists/edit.php?id=<?= e($playlistId) ?>">编辑</a>
        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/playlists/index.php">返回</a>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h2 class="h4"><?= e($playlist['playlist_name']) ?></h2>
        <dl class="row mb-0">
            <dt class="col-sm-2">制作用户</dt>
            <dd class="col-sm-10">ssztu</dd>
            <dt class="col-sm-2">简介</dt>
            <dd class="col-sm-10"><?= e($playlist['description'] ?? '-') ?></dd>
            <dt class="col-sm-2">封面路径</dt>
            <dd class="col-sm-10"><?= e($playlist['cover_path'] ?? '-') ?></dd>
            <dt class="col-sm-2">是否推荐</dt>
            <dd class="col-sm-10"><?= (int)$playlist['is_recommended'] === 1 ? '是' : '否' ?></dd>
            <dt class="col-sm-2">创建时间</dt>
            <dd class="col-sm-10"><?= e($playlist['created_at']) ?></dd>
        </dl>
    </div>
</div>

<h2 class="h4 mb-3">已收录歌曲</h2>
<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>排列序号</th>
                <th>歌曲名</th>
                <th>歌手</th>
                <th>专辑</th>
                <th>分类</th>
                <th>时长</th>
                <th>加入时间</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($songs): ?>
                <?php foreach ($songs as $song): ?>
                    <tr>
                        <td><?= e($song['sort_order']) ?></td>
                        <td class="fw-semibold"><?= e($song['title']) ?></td>
                        <td><?= e($song['artist']) ?></td>
                        <td><?= e($song['album'] ?? '-') ?></td>
                        <td><?= e($song['category_name'] ?? '未分类') ?></td>
                        <td><?= e(format_duration($song['duration'])) ?></td>
                        <td><?= e($song['added_at']) ?></td>
                        <td class="text-end">
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/playlists/remove_song.php?playlist_id=<?= e($playlistId) ?>&song_id=<?= e($song['song_id']) ?>" onclick="return confirm('确定要从歌单中移除该歌曲吗？');">移除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">该歌单暂未收录歌曲</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
