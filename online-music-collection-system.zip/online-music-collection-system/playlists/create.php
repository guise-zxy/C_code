<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '创建歌单';
$errors = [];
$form = [
    'playlist_name' => '',
    'description' => '',
    'cover_path' => '',
    'is_recommended' => 0,
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['playlist_name'] = trim($_POST['playlist_name'] ?? '');
    $form['description'] = trim($_POST['description'] ?? '');
    $form['cover_path'] = trim($_POST['cover_path'] ?? '');
    $form['is_recommended'] = isset($_POST['is_recommended']) ? 1 : 0;

    if ($form['playlist_name'] === '') {
        $errors[] = '歌单名称不能为空。';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO playlists (creator_user_id, playlist_name, description, cover_path, is_recommended)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $stmt->execute([
                current_user()['user_id'],
                $form['playlist_name'],
                $form['description'] ?: null,
                $form['cover_path'] ?: null,
                $form['is_recommended'],
            ]);
            set_flash('success', '歌单创建成功。');
            redirect('index.php');
        } catch (PDOException $e) {
            $errors[] = '歌单创建失败：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">创建歌单</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/playlists/create.php">
                    <?php require __DIR__ . '/form.php'; ?>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">保存</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/playlists/index.php">返回</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
