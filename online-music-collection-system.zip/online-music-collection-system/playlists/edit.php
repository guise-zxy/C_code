<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '编辑歌单';
$errors = [];
$playlistId = (int)($_GET['id'] ?? $_POST['playlist_id'] ?? 0);

if ($playlistId <= 0) {
    set_flash('danger', '歌单编号无效。');
    redirect('index.php');
}

try {
    $stmt = $pdo->prepare('SELECT * FROM playlists WHERE playlist_id = ?');
    $stmt->execute([$playlistId]);
    $form = $stmt->fetch();

    if (!$form) {
        set_flash('danger', '歌单不存在。');
        redirect('index.php');
    }
} catch (PDOException $e) {
    set_flash('danger', '歌单读取失败：' . $e->getMessage());
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['playlist_name'] = trim($_POST['playlist_name'] ?? '');
    $form['description'] = trim($_POST['description'] ?? '');
    $form['cover_path'] = trim($_POST['cover_path'] ?? '');
    $form['is_recommended'] = isset($_POST['is_recommended']) ? 1 : 0;

    if ($form['playlist_name'] === '') {
        $errors[] = '歌单名称不能为空。';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare(
                'UPDATE playlists
                 SET playlist_name = ?, description = ?, cover_path = ?, is_recommended = ?
                 WHERE playlist_id = ?'
            );
            $stmt->execute([
                $form['playlist_name'],
                $form['description'] ?: null,
                $form['cover_path'] ?: null,
                $form['is_recommended'],
                $playlistId,
            ]);
            set_flash('success', '歌单修改成功。');
            redirect('index.php');
        } catch (PDOException $e) {
            $errors[] = '歌单修改失败：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">编辑歌单</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/playlists/edit.php">
                    <input type="hidden" name="playlist_id" value="<?= e($playlistId) ?>">
                    <?php require __DIR__ . '/form.php'; ?>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">保存</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/playlists/index.php">返回</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
