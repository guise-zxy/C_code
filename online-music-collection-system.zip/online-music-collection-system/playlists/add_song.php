<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$playlistId = (int)($_GET['playlist_id'] ?? $_POST['playlist_id'] ?? 0);

if ($playlistId <= 0) {
    set_flash('danger', '歌单编号无效。');
    redirect('index.php');
}

$errors = [];
$songs = [];
$form = [
    'song_id' => '',
    'sort_order' => '1',
];

try {
    $playlistStmt = $pdo->prepare(
        'SELECT p.playlist_id, p.playlist_name, u.nickname AS creator_name
         FROM playlists p
         JOIN users u ON p.creator_user_id = u.user_id
         WHERE p.playlist_id = ?'
    );
    $playlistStmt->execute([$playlistId]);
    $playlist = $playlistStmt->fetch();

    if (!$playlist) {
        set_flash('danger', '歌单不存在。');
        redirect('index.php');
    }

    $songs = $pdo->query(
        'SELECT s.song_id, s.title, s.artist, c.category_name
         FROM songs s
         LEFT JOIN music_categories c ON s.category_id = c.category_id
         WHERE s.status = "active"
         ORDER BY s.song_id DESC'
    )->fetchAll();
} catch (PDOException $e) {
    set_flash('danger', '页面数据读取失败：' . $e->getMessage());
    redirect('index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['song_id'] = trim($_POST['song_id'] ?? '');
    $form['sort_order'] = trim($_POST['sort_order'] ?? '1');
    $songId = (int)$form['song_id'];

    if ($songId <= 0) {
        $errors[] = '请选择歌曲。';
    }

    if ($form['sort_order'] === '' || !is_numeric($form['sort_order']) || (int)$form['sort_order'] <= 0) {
        $errors[] = '排列序号必须是大于 0 的数字。';
    }

    if (!$errors) {
        try {
            $duplicateSongStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = ? AND song_id = ?');
            $duplicateSongStmt->execute([$playlistId, $songId]);

            if ((int)$duplicateSongStmt->fetchColumn() > 0) {
                $errors[] = '该歌曲已在歌单中。';
            }

            $duplicateOrderStmt = $pdo->prepare('SELECT COUNT(*) FROM playlist_songs WHERE playlist_id = ? AND sort_order = ?');
            $duplicateOrderStmt->execute([$playlistId, (int)$form['sort_order']]);

            if ((int)$duplicateOrderStmt->fetchColumn() > 0) {
                $errors[] = '该排列序号已被使用。';
            }

            if (!$errors) {
                $stmt = $pdo->prepare(
                    'INSERT INTO playlist_songs (playlist_id, song_id, added_at, sort_order)
                     VALUES (?, ?, NOW(), ?)'
                );
                $stmt->execute([$playlistId, $songId, (int)$form['sort_order']]);
                set_flash('success', '歌曲已添加到歌单。');
                redirect('detail.php?id=' . $playlistId);
            }
        } catch (PDOException $e) {
            $errors[] = '添加歌曲失败：' . $e->getMessage();
        }
    }
}

$pageTitle = '添加歌曲到歌单';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-2">添加歌曲到歌单</h1>
                <p class="text-muted">当前歌单：<?= e($playlist['playlist_name']) ?></p>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/playlists/add_song.php">
                    <input type="hidden" name="playlist_id" value="<?= e($playlistId) ?>">
                    <div class="mb-3">
                        <label class="form-label" for="song_id">选择歌曲</label>
                        <select class="form-select" id="song_id" name="song_id" required>
                            <option value="">请选择歌曲</option>
                            <?php foreach ($songs as $song): ?>
                                <option value="<?= e($song['song_id']) ?>" <?= (string)$form['song_id'] === (string)$song['song_id'] ? 'selected' : '' ?>>
                                    <?= e($song['title']) ?> - <?= e($song['artist']) ?><?= $song['category_name'] ? '（' . e($song['category_name']) . '）' : '' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="sort_order">排列序号</label>
                        <input class="form-control" id="sort_order" name="sort_order" type="number" min="1" value="<?= e($form['sort_order']) ?>" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">添加</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/playlists/detail.php?id=<?= e($playlistId) ?>">返回</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
