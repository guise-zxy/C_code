<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '歌单管理';
$playlists = [];
$error = '';

try {
    $stmt = $pdo->prepare(
        'SELECT p.playlist_id, p.playlist_name, p.description, p.cover_path, p.is_recommended, p.created_at,
                u.nickname AS creator_name, COUNT(ps.song_id) AS song_count, pf.user_id AS favorited_user_id
         FROM playlists p
         JOIN users u ON p.creator_user_id = u.user_id
         LEFT JOIN playlist_songs ps ON p.playlist_id = ps.playlist_id
         LEFT JOIN playlist_favorites pf ON p.playlist_id = pf.playlist_id AND pf.user_id = ?
         GROUP BY p.playlist_id, p.playlist_name, p.description, p.cover_path, p.is_recommended, p.created_at, u.nickname, pf.user_id
         ORDER BY p.created_at DESC, p.playlist_id DESC'
    );
    $stmt->execute([current_user()['user_id']]);
    $playlists = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = '歌单列表读取失败：' . $e->getMessage();
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h3 mb-0">歌单管理</h1>
    <a class="btn btn-primary" href="<?= e($baseUrl) ?>/playlists/create.php">创建歌单</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
            <tr>
                <th>歌单编号</th>
                <th>歌单名称</th>
                <th>制作用户</th>
                <th>简介</th>
                <th>是否推荐</th>
                <th>创建时间</th>
                <th>歌曲数量</th>
                <th class="text-end">操作</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($playlists): ?>
                <?php foreach ($playlists as $playlist): ?>
                    <tr>
                        <td><?= e($playlist['playlist_id']) ?></td>
                        <td class="fw-semibold"><?= e($playlist['playlist_name']) ?></td>
                        <td>ssztu</td>
                        <td><?= e($playlist['description'] ?? '-') ?></td>
                        <td><?= (int)$playlist['is_recommended'] === 1 ? '是' : '否' ?></td>
                        <td><?= e($playlist['created_at']) ?></td>
                        <td><?= e($playlist['song_count']) ?></td>
                        <td class="text-end text-nowrap">
                            <a class="btn btn-outline-secondary btn-sm" href="<?= e($baseUrl) ?>/playlists/detail.php?id=<?= e($playlist['playlist_id']) ?>">详情</a>
                            <?php if ($playlist['favorited_user_id']): ?>
                                <a class="btn btn-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlist['playlist_id']) ?>&return=list">取消收藏</a>
                            <?php else: ?>
                                <a class="btn btn-outline-warning btn-sm" href="<?= e($baseUrl) ?>/favorites/toggle_playlist.php?id=<?= e($playlist['playlist_id']) ?>&return=list">收藏</a>
                            <?php endif; ?>
                            <a class="btn btn-outline-primary btn-sm" href="<?= e($baseUrl) ?>/playlists/edit.php?id=<?= e($playlist['playlist_id']) ?>">编辑</a>
                            <a class="btn btn-outline-danger btn-sm" href="<?= e($baseUrl) ?>/playlists/delete.php?id=<?= e($playlist['playlist_id']) ?>" onclick="return confirm('确定要删除该歌单吗？');">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">暂无歌单数据</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
