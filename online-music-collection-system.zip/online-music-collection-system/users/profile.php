<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

if (!is_logged_in()) {
    set_flash('warning', '请先登录后再访问该页面。');
    redirect('../login.php');
}

$pageTitle = '个人资料';
$errors = [];
$userId = current_user()['user_id'];

try {
    $stmt = $pdo->prepare('SELECT user_id, username, nickname, email, phone, avatar, role, registered_at FROM users WHERE user_id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        set_flash('danger', '用户不存在，请重新登录。');
        redirect('../logout.php');
    }
} catch (PDOException $e) {
    set_flash('danger', '用户资料读取失败：' . $e->getMessage());
    redirect('../index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user['nickname'] = trim($_POST['nickname'] ?? '');
    $user['email'] = trim($_POST['email'] ?? '');
    $user['phone'] = trim($_POST['phone'] ?? '');
    $user['avatar'] = trim($_POST['avatar'] ?? '');

    if ($user['nickname'] === '') {
        $errors[] = '昵称不能为空。';
    }

    if ($user['email'] !== '' && !filter_var($user['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = '邮箱格式不正确。';
    }

    if (!$errors) {
        try {
            $stmt = $pdo->prepare('UPDATE users SET nickname = ?, email = ?, phone = ?, avatar = ? WHERE user_id = ?');
            $stmt->execute([
                $user['nickname'],
                $user['email'] ?: null,
                $user['phone'] ?: null,
                $user['avatar'] ?: null,
                $userId,
            ]);

            $_SESSION['user']['nickname'] = $user['nickname'];
            set_flash('success', '个人资料修改成功。');
            redirect('profile.php');
        } catch (PDOException $e) {
            $errors[] = '个人资料修改失败：' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h1 class="h3 mb-3">个人资料</h1>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($errors as $error): ?>
                            <div><?= e($error) ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form method="post" action="<?= e($baseUrl) ?>/users/profile.php">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">用户名</label>
                            <input class="form-control" value="<?= e($user['username']) ?>" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">角色</label>
                            <input class="form-control" value="<?= e($user['role']) ?>" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="nickname">昵称</label>
                            <input class="form-control" id="nickname" name="nickname" value="<?= e($user['nickname']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="email">邮箱</label>
                            <input class="form-control" id="email" name="email" type="email" value="<?= e($user['email'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="phone">电话</label>
                            <input class="form-control" id="phone" name="phone" value="<?= e($user['phone'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">注册时间</label>
                            <input class="form-control" value="<?= e($user['registered_at']) ?>" disabled>
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="avatar">头像路径</label>
                            <input class="form-control" id="avatar" name="avatar" value="<?= e($user['avatar'] ?? '') ?>">
                        </div>
                    </div>
                    <hr>
                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">保存修改</button>
                        <a class="btn btn-outline-secondary" href="<?= e($baseUrl) ?>/index.php">返回首页</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
