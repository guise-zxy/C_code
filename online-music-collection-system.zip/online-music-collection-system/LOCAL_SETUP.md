# Windows 本地运行环境准备

本文用于在 Windows 上使用 phpstudy 运行“在线音乐收藏管理系统”。本轮只准备运行环境，不涉及第二阶段 CRUD 功能。

## 1. 安装和启动 phpstudy

1. 安装 Windows 版 phpstudy。
2. 打开 phpstudy。
3. 在软件首页启动：
   - Apache
   - MySQL
4. 确认两个服务状态都显示为运行中。

如果 Apache 启动失败，常见原因是 80 端口被占用，可以在 phpstudy 中修改 Apache 端口，或关闭占用端口的软件。

## 2. 放置项目目录

phpstudy 安装完成后，把整个项目文件夹放到 phpstudy 的网站根目录。

常见目录示例：

```text
D:\phpstudy_pro\WWW\online-music-collection-system
```

或者：

```text
C:\phpstudy_pro\WWW\online-music-collection-system
```

最终目录应类似：

```text
WWW/
└── online-music-collection-system/
    ├── index.php
    ├── login.php
    ├── register.php
    ├── database/
    │   ├── schema.sql
    │   └── seed.sql
    ├── config/
    │   └── db.php
    └── setup_check.php
```

浏览器访问地址：

```text
http://localhost/online-music-collection-system/
```

如果你修改了 Apache 端口，例如 8080，则访问：

```text
http://localhost:8080/online-music-collection-system/
```

## 3. 进入 phpMyAdmin

在 phpstudy 中通常可以直接点击“数据库”或“phpMyAdmin”入口。

也可以尝试浏览器访问：

```text
http://localhost/phpMyAdmin/
```

或：

```text
http://localhost/phpmyadmin/
```

如果修改了 Apache 端口，例如 8080：

```text
http://localhost:8080/phpMyAdmin/
```

## 4. 导入数据库脚本

请按顺序导入，顺序不能反：

1. 先导入 `database/schema.sql`
2. 再导入 `database/seed.sql`

在 phpMyAdmin 中的操作方式：

1. 打开 phpMyAdmin。
2. 点击顶部或侧边栏的“导入”。
3. 选择项目中的 `database/schema.sql`。
4. 执行导入。
5. 再次进入“导入”。
6. 选择项目中的 `database/seed.sql`。
7. 执行导入。

`schema.sql` 会创建数据库 `music_collection_db` 和 9 张表。  
`seed.sql` 会插入测试账号、分类、歌曲、歌单、收藏和记录数据。

## 5. 检查数据库连接配置

当前项目配置文件是：

```text
config/db.php
```

当前配置为：

```php
$dbHost = '127.0.0.1';
$dbName = 'music_collection_db';
$dbUser = 'root';
$dbPass = 'root';
$dbCharset = 'utf8mb4';
```

其中通常需要检查的是：

- `$dbHost`：一般保持 `127.0.0.1`
- `$dbName`：必须是 `music_collection_db`
- `$dbUser`：phpstudy 默认通常是 `root`
- `$dbPass`：不同 phpstudy 版本可能不同
- `$dbCharset`：保持 `utf8mb4`

phpstudy 的 MySQL 默认密码常见有两种情况：

```php
$dbPass = 'root';
```

或者：

```php
$dbPass = '';
```

如果访问系统提示数据库连接失败，请先尝试把 `config/db.php` 中的 `$dbPass` 在 `root` 和空字符串之间切换。

## 6. 使用 setup_check.php 检查环境

项目根目录已经提供：

```text
setup_check.php
```

把项目放到 phpstudy 的 `WWW` 目录并启动 Apache、MySQL 后，访问：

```text
http://localhost/online-music-collection-system/setup_check.php
```

如果修改了 Apache 端口，例如 8080：

```text
http://localhost:8080/online-music-collection-system/setup_check.php
```

它会检查：

- PHP 是否正常运行
- PDO 是否可用
- 是否能连接 MySQL
- 是否能连接 `music_collection_db`
- `users` 表是否存在
- `admin` 用户是否存在

该页面不会输出数据库密码。

## 7. 测试账号

导入 `seed.sql` 后，测试账号为：

```text
admin / password
student / password
```

## 8. 推荐手动操作顺序

1. 安装 phpstudy。
2. 启动 Apache 和 MySQL。
3. 把项目文件夹放入 phpstudy 的 `WWW` 目录。
4. 打开 phpMyAdmin。
5. 导入 `database/schema.sql`。
6. 导入 `database/seed.sql`。
7. 检查 `config/db.php`，确认 MySQL 密码是 `root` 或空字符串。
8. 访问 `setup_check.php`。
9. 如果检查通过，访问 `index.php`。
10. 使用 `admin / password` 或 `student / password` 登录。
