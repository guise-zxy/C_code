# C2 当前目录说明

状态：C2-v1.0 已冻结。建模手确认正文采用 K=4 主分组，K=3/K=5 仅作稳健性对照。

当前顶层只保留四类内容：

- `12_k4_handoff/`：当前应交付给建模手和论文手的主目录。
- `06_code/`：当前 C2 复现代码副本。
- `obsolete/`：已撤回、早期草稿、返修过程文件，只作历史追溯，不进入正文。
- `README_C2看这里.md`：本说明。

优先查看：

- `12_k4_handoff/C2_K4正文主分组_论文手交付材料.md`
- `12_k4_handoff/C2_编程手正式结果接口_v1.0.md`
- `12_k4_handoff/C2_复现证据链收口说明.md`
- `12_k4_handoff/给建模手_C2_K4收口复核说明.md`
- `12_k4_handoff/给论文手_C2_K4写作交付说明.md`
- `12_k4_handoff/C2_K4交付文件索引.csv`
- `12_k4_handoff/figures/`
- `12_k4_handoff/figure_data/`
- `12_k4_handoff/input_snapshots/`
- `12_k4_handoff/round3_evidence/`
- `12_k4_handoff/C2完整06_code代码包.zip`
- `C2-v1.0正式冻结交付包.zip`

口径提醒：

- K=4 为正文主分组；
- K=3、K=5 为稳健性对照；
- 最高 BMI 组为 25 周内可靠性未决组；
- “高风险”仅指检测决策风险，不表示临床病理高风险；
- 26 周仅作扩展范围敏感性，不作为正式推荐；
- 风险函数只作辅助，主规则为组平均 bootstrap LCB95 >= 0.90。

说明：正式交付包不收入 `obsolete/`。`06_code/` 中保留返修阶段脚本用于追溯完整工程过程；旧脚本内部出现的“待返修”“未冻结”等文字仅对应历史阶段。当前状态以 `12_k4_handoff/C2-v1.0正式冻结说明.md`、`12_k4_handoff/C2_K4交付文件索引.csv` 和 `12_k4_handoff/c2_k4_handoff_run_manifest.json` 为准。
