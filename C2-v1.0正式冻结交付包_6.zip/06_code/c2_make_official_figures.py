from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "results" / "C2-v1.0"
MAIN_DIR = OUT_DIR / "01_main_results"
SENS_DIR = OUT_DIR / "02_sensitivity"
VALID_DIR = OUT_DIR / "03_validation"
INTERMEDIATE_DIR = OUT_DIR / "04_intermediate"
FIG_DIR = OUT_DIR / "figures"
FIG_DATA_DIR = OUT_DIR / "figure_data"

COLORS = {
    "ink": "#2B2B2B",
    "muted": "#737373",
    "grid": "#D8D3C8",
    "paper": "#FBFAF7",
    "sand": "#D8C7A3",
    "moss": "#7C8A4A",
    "jade": "#25736A",
    "copper": "#B76E3E",
    "rose": "#B44B5D",
    "plum": "#6E557F",
    "navy": "#34495E",
    "amber": "#D49A35",
    "soft_red": "#D9A2A9",
    "soft_green": "#B8C9B0",
}

GROUP_COLORS = ["#25736A", "#D49A35", "#B44B5D", "#6E557F"]
GROUP_LIGHT = ["#DCEDE8", "#F3E4C4", "#F2D8DC", "#E5DDEC"]


def setup_style() -> None:
    plt.rcParams.update(
        {
            "font.sans-serif": ["Noto Sans CJK SC", "Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"],
            "axes.unicode_minus": False,
            "figure.facecolor": COLORS["paper"],
            "axes.facecolor": COLORS["paper"],
            "axes.edgecolor": COLORS["ink"],
            "axes.labelcolor": COLORS["ink"],
            "xtick.color": COLORS["ink"],
            "ytick.color": COLORS["ink"],
            "grid.color": COLORS["grid"],
            "grid.linewidth": 0.65,
            "axes.titleweight": "regular",
            "axes.titlesize": 12,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.8,
            "ytick.labelsize": 8.8,
            "legend.fontsize": 8.5,
            "savefig.dpi": 300,
        }
    )


def save(fig: plt.Figure, stem: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor=COLORS["paper"])
    fig.savefig(FIG_DIR / f"{stem}.svg", bbox_inches="tight", facecolor=COLORS["paper"])
    plt.close(fig)


def clean_axes(ax: plt.Axes, grid_axis: str = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(axis=grid_axis, alpha=0.7)


def fig01_bmi_distribution() -> None:
    mothers = pd.read_csv(INTERMEDIATE_DIR / "q2_mother_baseline.csv", encoding="utf-8-sig")
    groups = pd.read_csv(MAIN_DIR / "c2_main_K4_groups.csv", encoding="utf-8-sig")
    cuts = [29.5, 31.5, 34.5]
    bounds = [mothers["baseline_bmi"].min(), *cuts, mothers["baseline_bmi"].max()]
    source = mothers[["mother_id", "baseline_bmi"]].copy()
    source["k4_group"] = np.searchsorted(cuts, source["baseline_bmi"], side="right") + 1
    source.to_csv(FIG_DATA_DIR / "c2_fig01_bmi_distribution_k4_boundaries_source.csv", index=False, encoding="utf-8-sig")

    fig, ax = plt.subplots(figsize=(7.2, 4.3), constrained_layout=True)
    bins = np.arange(np.floor(source["baseline_bmi"].min()), np.ceil(source["baseline_bmi"].max()) + 0.5, 0.5)
    for i in range(4):
        ax.axvspan(bounds[i], bounds[i + 1], color=GROUP_LIGHT[i], alpha=0.45, zorder=0)
    ax.hist(source["baseline_bmi"], bins=bins, color="#8A9A72", alpha=0.78, edgecolor=COLORS["paper"], linewidth=0.55, zorder=2)
    kde = stats.gaussian_kde(source["baseline_bmi"].to_numpy(float))
    xs = np.linspace(source["baseline_bmi"].min(), source["baseline_bmi"].max(), 400)
    scale = len(source) * (bins[1] - bins[0])
    ax.plot(xs, kde(xs) * scale, color=COLORS["plum"], linewidth=2.4, zorder=4)
    for j, cut in enumerate(cuts):
        ax.axvline(cut, color=COLORS["copper"], linestyle=(0, (4, 2)), linewidth=1.45, zorder=5)
        label_y = ax.get_ylim()[1] * (0.97 if j != 1 else 0.91)
        ax.text(
            cut,
            label_y,
            f"BMI={cut:.1f}",
            ha="center",
            va="top",
            fontsize=8.3,
            color=COLORS["copper"],
            bbox={"facecolor": COLORS["paper"], "edgecolor": "none", "alpha": 0.78, "pad": 1.0},
        )
    for _, row in groups.iterrows():
        gid = int(row["group_id"])
        interval_mid = (bounds[gid - 1] + bounds[gid]) / 2
        ax.text(
            interval_mid,
            ax.get_ylim()[1] * 0.83,
            f"第{gid}组\n{int(row['mother_count'])}人",
            ha="center",
            va="center",
            fontsize=8.2,
            color=COLORS["ink"],
        )
    ax.set_title("K4边界将BMI样本分成四个可解释区间")
    ax.set_xlabel("基线BMI")
    ax.set_ylabel("孕妇数")
    clean_axes(ax)
    save(fig, "c2_fig01_bmi_distribution_k4_boundaries")


def fig02_probability_curves() -> None:
    probs = pd.read_csv(MAIN_DIR / "c2_main_K4_reach_probability_by_group_week.csv", encoding="utf-8-sig")
    groups = pd.read_csv(MAIN_DIR / "c2_main_K4_groups.csv", encoding="utf-8-sig")
    rec = pd.read_csv(MAIN_DIR / "c2_main_K4_recommended_timing.csv", encoding="utf-8-sig")
    source = probs.merge(groups[["group_id", "bmi_interval"]], on="group_id", how="left")
    source.to_csv(FIG_DATA_DIR / "c2_fig02_k4_reach_probability_curves_source.csv", index=False, encoding="utf-8-sig")

    fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.4), sharex=True, sharey=True, constrained_layout=True)
    for ax, (gid, sub) in zip(axes.ravel(), source.groupby("group_id")):
        idx = int(gid) - 1
        color = GROUP_COLORS[idx]
        sub = sub.sort_values("week")
        r = rec[rec["group_id"].eq(gid)].iloc[0]
        x = sub["week"].to_numpy(float)
        ax.fill_between(x, sub["lcb95"].to_numpy(float), sub["ucb95"].to_numpy(float), color=color, alpha=0.16, linewidth=0)
        ax.plot(x, sub["p_obs"], color=color, linewidth=2.1, label="点估计")
        ax.plot(x, sub["lcb95"], color=color, linewidth=1.25, linestyle=(0, (2, 2)), alpha=0.88, label="95%下界")
        ax.axhline(0.90, color=COLORS["copper"], linewidth=1.1, linestyle="--")
        ax.axvline(r["recommended_week"], color=COLORS["ink"], linewidth=1.0, alpha=0.75)
        ax.scatter(r["recommended_week"], r["lcb95_at_recommend"], s=52, color=color, edgecolor=COLORS["paper"], linewidth=1.0, zorder=5)
        ax.text(
            r["recommended_week"] + 0.18,
            r["lcb95_at_recommend"] + 0.006,
            f"{r['recommended_week']:.1f}周",
            fontsize=8,
            color=COLORS["ink"],
        )
        ax.set_title(f"第{gid}组 {sub['bmi_interval'].iloc[0]}", fontsize=10)
        clean_axes(ax)
    axes[0, 0].set_ylabel("达标概率")
    axes[1, 0].set_ylabel("达标概率")
    axes[1, 0].set_xlabel("孕周/周")
    axes[1, 1].set_xlabel("孕周/周")
    axes[0, 0].set_ylim(0.78, 0.985)
    axes[0, 0].legend(frameon=False, loc="lower right")
    fig.suptitle("各组95%下界首次越过0.90的孕周依次推迟", fontsize=13)
    save(fig, "c2_fig02_k4_reach_probability_curves")


def fig03_risk_curves() -> None:
    risk = pd.read_csv(MAIN_DIR / "c2_main_K4_risk_by_group_week.csv", encoding="utf-8-sig")
    rec = pd.read_csv(MAIN_DIR / "c2_main_K4_recommended_timing.csv", encoding="utf-8-sig")
    risk.to_csv(FIG_DATA_DIR / "c2_fig03_k4_risk_curves_source.csv", index=False, encoding="utf-8-sig")

    fig, axes = plt.subplots(2, 2, figsize=(7.4, 5.4), sharex=True, constrained_layout=True)
    for ax, (gid, sub) in zip(axes.ravel(), risk.groupby("group_id")):
        idx = int(gid) - 1
        color = GROUP_COLORS[idx]
        sub = sub.sort_values("week")
        feasible = sub["reliability_constraint_passed"].astype(bool)
        ax.plot(sub["week"], sub["fail_risk"], color=COLORS["soft_red"], linewidth=1.15, label="未达标风险")
        ax.plot(sub["week"], sub["time_risk"], color=COLORS["sand"], linewidth=1.15, label="时间风险")
        ax.plot(sub.loc[~feasible, "week"], sub.loc[~feasible, "total_risk"], color=color, linestyle=":", linewidth=1.4, alpha=0.45)
        ax.plot(sub.loc[feasible, "week"], sub.loc[feasible, "total_risk"], color=color, linewidth=2.25, label="可行总风险")
        r = rec[rec["group_id"].eq(gid)].iloc[0]
        ax.scatter(r["recommended_week"], r["total_risk"], s=58, color=color, edgecolor=COLORS["paper"], linewidth=1.0, zorder=5)
        ax.text(r["recommended_week"] + 0.18, r["total_risk"] + 0.025, f"最小\n{r['recommended_week']:.1f}周", fontsize=7.8, color=COLORS["ink"])
        ax.set_title(f"第{gid}组 {sub['bmi_interval'].iloc[0]}", fontsize=10)
        clean_axes(ax)
    axes[0, 0].set_ylabel("风险值")
    axes[1, 0].set_ylabel("风险值")
    axes[1, 0].set_xlabel("孕周/周")
    axes[1, 1].set_xlabel("孕周/周")
    axes[0, 0].legend(frameon=False, loc="upper left", ncol=1)
    fig.suptitle("可靠性约束内的风险最小点就是推荐时点", fontsize=13)
    save(fig, "c2_fig03_k4_risk_curves")


def fig04_recommended_timing() -> None:
    rec = pd.read_csv(MAIN_DIR / "c2_main_K4_recommended_timing.csv", encoding="utf-8-sig")
    rec.to_csv(FIG_DATA_DIR / "c2_fig04_k4_recommended_timing_source.csv", index=False, encoding="utf-8-sig")

    fig, ax = plt.subplots(figsize=(7.0, 4.15), constrained_layout=True)
    y = np.arange(len(rec))
    vals = rec["recommended_week"].to_numpy(float)
    start = 15.5
    ax.hlines(y, start, vals, color="#B8B0A3", linewidth=3.6, alpha=0.55)
    ax.scatter(vals, y, s=120, color=GROUP_COLORS, edgecolor=COLORS["paper"], linewidth=1.2, zorder=4)
    for yi, row in zip(y, rec.itertuples(index=False)):
        ax.text(start - 0.25, yi, f"第{int(row.group_id)}组 {row.bmi_interval}", ha="right", va="center", fontsize=9)
        ax.text(float(row.recommended_week) + 0.16, yi, f"{float(row.recommended_week):.1f}周", va="center", fontsize=9.5, color=COLORS["ink"])
    ax.plot(vals, y, color=COLORS["ink"], linewidth=1.2, alpha=0.75, zorder=3)
    ax.set_yticks([])
    ax.set_xlim(15.0, 25.2)
    ax.set_xlabel("推荐孕周/周")
    ax.set_title("BMI越高，推荐NIPT检测时点整体越晚")
    clean_axes(ax, grid_axis="x")
    save(fig, "c2_fig04_k4_recommended_timing")


def fig05_k4_k5_comparison() -> None:
    comp = pd.read_csv(SENS_DIR / "c2_K4_vs_K5_comparison.csv", encoding="utf-8-sig")
    comp.to_csv(FIG_DATA_DIR / "c2_fig05_k4_vs_k5_comparison_source.csv", index=False, encoding="utf-8-sig")

    fig, axes = plt.subplots(1, 2, figsize=(8.3, 4.1), constrained_layout=True)
    ax = axes[0]
    labels = ["平均延迟遗憾", "90%分位延迟"]
    k4 = comp[comp["strategy"].eq("main_K4")].iloc[0]
    k5 = comp[comp["strategy"].eq("sensitivity_K5_data_driven")].iloc[0]
    k4_vals = [k4["mean_regret"], k4["p90_regret"]]
    k5_vals = [k5["mean_regret"], k5["p90_regret"]]
    y = np.arange(len(labels))
    ax.hlines(y, k5_vals, k4_vals, color="#B9B0A4", linewidth=2.4, zorder=1)
    ax.scatter(k4_vals, y, s=72, color=COLORS["jade"], label="K4正文", zorder=3)
    ax.scatter(k5_vals, y, s=72, color=COLORS["amber"], marker="s", label="K5敏感性", zorder=3)
    for yi, v4, v5 in zip(y, k4_vals, k5_vals):
        ax.text(max(v4, v5) + 0.045, yi, f"差{abs(v4-v5):.3f}周", va="center", fontsize=8.5, color=COLORS["muted"])
    ax.set_yticks(y)
    ax.set_yticklabels(labels)
    ax.set_xlabel("周")
    ax.set_title("K4的代价很小")
    ax.legend(frameon=False, loc="lower right")
    clean_axes(ax, grid_axis="x")

    ax = axes[1]
    k4_weeks = [float(v) for v in str(k4["recommended_week_by_group"]).split(";")]
    k5_weeks = [float(v) for v in str(k5["recommended_week_by_group"]).split(";")]
    xs4 = np.arange(1, len(k4_weeks) + 1)
    xs5 = np.arange(1, len(k5_weeks) + 1)
    ax.step(xs4, k4_weeks, where="mid", color=COLORS["jade"], linewidth=2.2, label="K4正文")
    ax.plot(xs4, k4_weeks, "o", color=COLORS["jade"], markersize=5.5)
    ax.step(xs5, k5_weeks, where="mid", color=COLORS["amber"], linewidth=1.8, linestyle="--", label="K5敏感性")
    ax.plot(xs5, k5_weeks, "s", color=COLORS["amber"], markersize=5)
    ax.annotate(
        "高BMI端K4更保守",
        xy=(4, k4_weeks[-1]),
        xytext=(2.75, 23.4),
        arrowprops={"arrowstyle": "->", "color": COLORS["ink"], "lw": 0.8},
        fontsize=8.5,
        color=COLORS["ink"],
    )
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel("组序号")
    ax.set_ylabel("推荐孕周/周")
    ax.set_title("推荐时点结构对比")
    ax.legend(frameon=False, loc="upper left")
    clean_axes(ax)
    fig.suptitle("K4用轻微延迟换取更稳定、可解释的正文分组", fontsize=13)
    save(fig, "c2_fig05_k4_vs_k5_comparison")


def fig06_bootstrap_stability() -> None:
    freq = pd.read_csv(VALID_DIR / "c2_bootstrap_boundary_frequency.csv", encoding="utf-8-sig")
    freq.to_csv(FIG_DATA_DIR / "c2_fig06_bootstrap_stability_source.csv", index=False, encoding="utf-8-sig")
    k_freq = freq[freq["type"].eq("K")].copy()
    cuts = freq[freq["type"].eq("cutpoints")].sort_values("share", ascending=False).head(8).copy()

    fig, axes = plt.subplots(1, 2, figsize=(8.5, 4.3), constrained_layout=True)
    ax = axes[0]
    k_freq["label"] = "K=" + k_freq["value"].astype(str)
    colors = [COLORS["plum"] if int(v) == 5 else COLORS["soft_green"] for v in k_freq["value"]]
    ax.barh(k_freq["label"], k_freq["share"] * 100, color=colors, height=0.52)
    for row in k_freq.itertuples(index=False):
        ax.text(row.share * 100 + 1.2, row.label, f"{row.share*100:.1f}%", va="center", fontsize=9)
    ax.set_xlim(0, 100)
    ax.set_xlabel("选择频率/%")
    ax.set_title("K5方向明显")
    clean_axes(ax, grid_axis="x")

    ax = axes[1]
    cuts = cuts.sort_values("share", ascending=True)
    y = np.arange(len(cuts))
    highlight = cuts["value"].astype(str).str.contains("29.5;31.5;33.0;34.5", regex=False)
    ax.hlines(y, 0, cuts["share"] * 100, color="#BDB6AB", linewidth=2.3)
    ax.scatter(cuts["share"] * 100, y, color=np.where(highlight, COLORS["copper"], COLORS["navy"]), s=np.where(highlight, 54, 34))
    for yi, row in zip(y, cuts.itertuples(index=False)):
        ax.text(row.share * 100 + 0.35, yi, f"{row.share*100:.1f}%", va="center", fontsize=7.8)
    ax.set_yticks(y)
    ax.set_yticklabels(cuts["value"], fontsize=7.2)
    ax.set_xlabel("选择频率/%")
    ax.set_title("精确切点分散")
    clean_axes(ax, grid_axis="x")
    fig.suptitle("bootstrap支持K5方向，但不支持唯一精确切点", fontsize=13)
    save(fig, "c2_fig06_bootstrap_stability")


def write_note() -> None:
    note = """# C2 正式图绘制说明

本组图按“先确定每张图的核心结论，再选择图形与强调元素”的流程绘制。所有图均输出 300dpi PNG、SVG 可编辑版本和对应源数据 CSV。

| 图号 | 核心结论句 | 数据类型 | 图形类型 | 重点强调元素 | 配色/样式 | 论文排版适配 |
|---|---|---|---|---|---|---|
| c2_fig01 | K4边界将BMI样本分成四个可解释区间 | 连续BMI分布、K4切点、组样本量 | 直方图+密度曲线+分区背景 | 三条切点线和各组人数 | 灰绿柱、紫色密度、赭色切点、浅色分区 | C2开头说明分组依据 |
| c2_fig02 | 各组95%下界首次越过0.90的孕周依次推迟 | 组别-孕周-点估计与置信区间 | 2x2小多图折线+置信带 | 0.90阈值、推荐孕周、LCB交点 | 每组单独主色，非重点置信带降透明度 | 正文核心图，避免四条线挤在一起 |
| c2_fig03 | 可靠性约束内的风险最小点就是推荐时点 | 风险函数、失败风险、时间风险、可行标记 | 2x2小多图风险曲线 | 可行总风险实线、不可行段虚线、最小点 | 总风险用组色，风险分量用浅红和沙色 | 解释风险函数主模型 |
| c2_fig04 | BMI越高，推荐NIPT检测时点整体越晚 | BMI组和推荐孕周 | 水平棒棒糖图 | 四个推荐孕周点和上升趋势线 | 组别渐变色，背景极简 | 正文结果图，比普通柱状更聚焦趋势 |
| c2_fig05 | K4用轻微延迟换取更稳定、可解释的正文分组 | K4/K5遗憾指标与推荐时点 | 哑铃图+阶梯折线 | K4-K5差值、高BMI端差异 | K4青绿，K5赭黄，差值用灰线 | 稳健性分析图 |
| c2_fig06 | bootstrap支持K5方向，但不支持唯一精确切点 | K选择频率、切点组合频率 | 水平条形图+棒棒糖图 | K5高频、切点组合分散 | K5紫色强调，切点用深灰/赭色 | 稳定性验证图，建议正文或附录 |
"""
    (OUT_DIR / "00_docs" / "C2正式图绘制说明.md").write_text(note, encoding="utf-8")


def main() -> None:
    FIG_DATA_DIR.mkdir(parents=True, exist_ok=True)
    setup_style()
    fig01_bmi_distribution()
    fig02_probability_curves()
    fig03_risk_curves()
    fig04_recommended_timing()
    fig05_k4_k5_comparison()
    fig06_bootstrap_stability()
    write_note()
    print("C2 official figures generated.")


if __name__ == "__main__":
    main()
