from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

import q2_analysis as q2
from c2_repair_round2 import (
    LogisticFit,
    bootstrap_lcb_grid,
    bootstrap_status_summary,
    fit_logistic,
    group_grid,
    recommend,
    resample_mothers,
    sha256,
    timing_summary,
)


ROOT = Path(__file__).resolve().parents[1]
C2_DIR = ROOT / "results" / "C2-v1.0"
ROUND3_DIR = C2_DIR / "11_repair_round3"
CODE_DIR = C2_DIR / "06_code"
Q_MAIN = 0.90
WEEK_GRID_25 = q2.WEEK_GRID
K_CANDIDATE_CUTS = {
    3: [31.5, 34.5],
    4: [29.5, 31.5, 34.5],
    5: [29.5, 31.5, 33.0, 34.5],
}


def load_sigma_m() -> float:
    tech_path = C2_DIR / "03_validation" / "q2_technical_error.csv"
    return float(pd.read_csv(tech_path, encoding="utf-8-sig")["sigma_m_estimate"].iloc[0])


def bootstrap_compare_k(
    events: pd.DataFrame,
    sigma_m: float,
    n_boot: int,
    rng: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    prob_rows = []
    timing_rows = []
    status_rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C2 round3 LMM K-compare bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            fit, wm, bm = q2.fit_q2_lmm(sample)
            if not bool(fit.converged):
                status_rows.append({"bootstrap_id": b, "status": "not_converged", "converged": False, "note": ""})
                continue
            sample_mothers = q2.build_mother_table(sample)
            for K, cuts in K_CANDIDATE_CUTS.items():
                grid = group_grid("lmm", fit, wm, bm, sample_mothers, cuts, sigma_m, WEEK_GRID_25)
                for _, row in grid.iterrows():
                    prob_rows.append(
                        {
                            "bootstrap_id": b,
                            "K": K,
                            "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                            "group_id": int(row["group_id"]),
                            "week": float(row["week"]),
                            "p_group_mean": float(row["p_group_mean"]),
                        }
                    )
                rec = recommend(grid, "p_group_mean")
                for _, row in rec.iterrows():
                    timing_rows.append(
                        {
                            "bootstrap_id": b,
                            "K": K,
                            "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                            "group_id": int(row["group_id"]),
                            "status": row["status"],
                            "recommended_week": row["recommended_week"],
                            "at_25_boundary": row["at_upper_week_boundary"],
                        }
                    )
            status_rows.append({"bootstrap_id": b, "status": "ok", "converged": True, "note": ""})
        except Exception as exc:
            status_rows.append({"bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})
    return pd.DataFrame(prob_rows), pd.DataFrame(timing_rows), pd.DataFrame(status_rows)


def point_grids(events: pd.DataFrame, mothers: pd.DataFrame, sigma_m: float) -> pd.DataFrame:
    fit, wm, bm = q2.fit_q2_lmm(events)
    frames = []
    for K, cuts in K_CANDIDATE_CUTS.items():
        g = group_grid("lmm", fit, wm, bm, mothers, cuts, sigma_m, WEEK_GRID_25)
        g["K"] = K
        frames.append(g)
    return pd.concat(frames, ignore_index=True)


def k_lcb_grid(point: pd.DataFrame, boot_prob: pd.DataFrame) -> pd.DataFrame:
    quant = (
        boot_prob.groupby(["K", "group_id", "week"])["p_group_mean"]
        .agg(
            bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)),
            bootstrap_median=lambda s: float(np.percentile(s, 50)),
            bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)),
            bootstrap_ok_count="count",
        )
        .reset_index()
    )
    return point.merge(quant, on=["K", "group_id", "week"], how="left")


def recommend_by_k(grid: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for K, sub in grid.groupby("K", sort=True):
        rec = recommend(sub, "bootstrap_lcb95")
        rec["K"] = int(K)
        frames.append(rec)
    return pd.concat(frames, ignore_index=True)


def k_compare_summary(rec: pd.DataFrame, status: pd.DataFrame, mothers: pd.DataFrame) -> pd.DataFrame:
    rows = []
    attempts = int(status["bootstrap_id"].nunique())
    converged = int(status["status"].eq("ok").sum())
    for K, sub in rec.groupby("K", sort=True):
        ok_groups = int(sub["status"].eq("ok").sum())
        high_risk_groups = int((sub["status"] != "ok").sum())
        rows.append(
            {
                "model_type": "lmm",
                "K": int(K),
                "cutpoints": sub["cutpoints"].iloc[0],
                "bootstrap_attempts": attempts,
                "strict_converged_iterations": converged,
                "ok_group_count": ok_groups,
                "high_risk_undecided_group_count": high_risk_groups,
                "all_groups_pass_lcb95_0p90": bool(high_risk_groups == 0),
                "latest_recommended_week_among_ok": float(pd.to_numeric(sub["recommended_week"], errors="coerce").max()),
                "min_bootstrap_lcb95_at_decision": float(pd.to_numeric(sub["bootstrap_lcb95"], errors="coerce").min()),
                "n_mothers": int(len(mothers)),
            }
        )
    return pd.DataFrame(rows)


def k_timing_summary(timing: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    attempts = int(status["bootstrap_id"].nunique())
    converged = int(status["status"].eq("ok").sum())
    rows = []
    for (K, gid), sub in timing.groupby(["K", "group_id"], sort=True):
        vals = pd.to_numeric(sub["recommended_week"], errors="coerce").dropna().to_numpy(float)
        rows.append(
            {
                "K": int(K),
                "group_id": int(gid),
                "bootstrap_attempts": attempts,
                "strict_converged_iterations": converged,
                "valid_recommend_count": int(len(vals)),
                "no_feasible_ratio_among_converged": float(1 - len(vals) / converged) if converged else np.nan,
                "recommended_week_median": float(np.percentile(vals, 50)) if len(vals) else np.nan,
                "recommended_week_ci_low_2p5": float(np.percentile(vals, 2.5)) if len(vals) else np.nan,
                "recommended_week_ci_high_97p5": float(np.percentile(vals, 97.5)) if len(vals) else np.nan,
                "boundary_25_ratio_among_valid": float(np.mean(sub["at_25_boundary"].astype(str).str.lower().eq("true"))) if len(vals) else np.nan,
            }
        )
    return pd.DataFrame(rows)


def detection_error_sensitivity(events: pd.DataFrame, mothers: pd.DataFrame, sigma_m: float) -> pd.DataFrame:
    fit, wm, bm = q2.fit_q2_lmm(events)
    rows = []
    for K, cuts in K_CANDIDATE_CUTS.items():
        for kappa in q2.KAPPA_GRID:
            grid = group_grid("lmm", fit, wm, bm, mothers, cuts, sigma_m, WEEK_GRID_25, kappa=kappa)
            rec = recommend(grid, "conditional_bmi_composition_lcb95")
            for _, row in rec.iterrows():
                rows.append(
                    {
                        "model_type": "lmm",
                        "K": K,
                        "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                        "kappa": float(kappa),
                        "group_id": int(row["group_id"]),
                        "bmi_interval": row["bmi_interval"],
                        "status": row["status"],
                        "recommended_week": row["recommended_week"],
                        "p_group_mean": row["p_group_mean"],
                        "conditional_bmi_composition_lcb95": row["conditional_bmi_composition_lcb95"],
                        "formula": "sigma_total^2=sigma_u^2+max(sigma_e^2-sigma_m^2,0)+kappa^2*sigma_m^2",
                    }
                )
    out = pd.DataFrame(rows)
    base = out[out["kappa"].eq(1.0)][["K", "group_id", "recommended_week", "p_group_mean"]].rename(columns={"recommended_week": "base_week", "p_group_mean": "base_p"})
    out = out.merge(base, on=["K", "group_id"], how="left")
    out["recommended_week_changed_vs_kappa1"] = out["recommended_week"].astype(str) != out["base_week"].astype(str)
    out["probability_changed_vs_kappa1"] = (pd.to_numeric(out["p_group_mean"], errors="coerce") - pd.to_numeric(out["base_p"], errors="coerce")).abs() > 1e-10
    return out


def boundary_stability(events: pd.DataFrame, sigma_m: float, n_boot: int, rng: np.random.Generator) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C2 round3 boundary stability bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            fit, wm, bm = q2.fit_q2_lmm(sample)
            if not bool(fit.converged):
                rows.append({"bootstrap_id": b, "status": "not_converged", "converged": False})
                continue
            sample_mothers = q2.build_mother_table(sample)
            _, _, cand = q2.optimize_partition_dp(sample_mothers, sample, fit, wm, bm, sigma_m, Q_MAIN)
            feasible = cand[cand["feasible"].astype(str).str.lower().eq("true")].copy()
            if feasible.empty:
                rows.append({"bootstrap_id": b, "status": "no_feasible_partition", "converged": True})
                continue
            best = feasible.sort_values(["mean_regret", "p90_regret", "K"]).iloc[0]
            rows.append(
                {
                    "bootstrap_id": b,
                    "status": "ok",
                    "converged": True,
                    "K": int(best["K"]),
                    "cutpoints": best["cutpoints"],
                    "mean_regret": best["mean_regret"],
                    "p90_regret": best["p90_regret"],
                    "worst_conditional_lcb95": best["worst_lcb95"],
                }
            )
        except Exception as exc:
            rows.append({"bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})
    raw = pd.DataFrame(rows)
    ok = raw[raw["status"].eq("ok")].copy()
    freq_rows = []
    if not ok.empty:
        for k, cnt in ok["K"].value_counts().sort_index().items():
            freq_rows.append({"type": "K", "value": str(k), "count": int(cnt), "share_among_ok": float(cnt / len(ok))})
        for cuts, cnt in ok["cutpoints"].value_counts().head(30).items():
            freq_rows.append({"type": "cutpoints_top30", "value": str(cuts), "count": int(cnt), "share_among_ok": float(cnt / len(ok))})
    freq = pd.DataFrame(freq_rows)
    return raw, freq


def copy_code_and_write_index(files: dict[str, pd.DataFrame], manifest: dict) -> None:
    ROUND3_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    for name, df in files.items():
        path = ROUND3_DIR / name
        df.to_csv(path, index=False, encoding="utf-8-sig")
        rows.append({"category": "result", "status": "round3_draft", "path": f"11_repair_round3/{name}", "note": f"rows={len(df)}"})
    CODE_DIR.mkdir(parents=True, exist_ok=True)
    code_files = ["q2_analysis.py", "c2_finalize_k4.py", "c2_make_official_figures.py", "c2_repair_draft.py", "c2_repair_round2.py", "c2_repair_round3.py"]
    code_rows = []
    for name in code_files:
        src = ROOT / "code" / name
        dst = CODE_DIR / name
        shutil.copy2(src, dst)
        digest = sha256(dst)
        code_rows.append({"file": f"06_code/{name}", "source_path": str(src), "sha256": digest})
        rows.append({"category": "code", "status": "round3_draft", "path": f"06_code/{name}", "note": f"sha256={digest}"})
    pd.DataFrame(code_rows).to_csv(ROUND3_DIR / "c2_round3_code_hashes.csv", index=False, encoding="utf-8-sig")
    rows.append({"category": "hash", "status": "round3_draft", "path": "11_repair_round3/c2_round3_code_hashes.csv", "note": "完整代码包哈希"})
    input_paths = [q2.INPUT, q2.TECH_REP, C2_DIR / "10_repair_round2" / "c2_round2_cv_model_comparison_summary.csv"]
    input_rows = [{"path": str(p), "exists": p.exists(), "sha256": sha256(p) if p.exists() else ""} for p in input_paths]
    pd.DataFrame(input_rows).to_csv(ROUND3_DIR / "c2_round3_input_hashes.csv", index=False, encoding="utf-8-sig")
    rows.append({"category": "hash", "status": "round3_draft", "path": "11_repair_round3/c2_round3_input_hashes.csv", "note": "输入哈希"})
    (ROUND3_DIR / "c2_round3_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    rows.append({"category": "manifest", "status": "round3_draft", "path": "11_repair_round3/c2_round3_run_manifest.json", "note": "运行命令和环境"})
    pd.DataFrame(rows).to_csv(ROUND3_DIR / "C2第三轮返修文件索引.csv", index=False, encoding="utf-8-sig")


def write_docs(summary: pd.DataFrame) -> None:
    text = """# C2第三轮返修草案交付说明

状态：C2未冻结草案，暂不交论文手写正文。C1保持不变，未进入C3。

本轮落实建模手暂定口径：

- LMM派生概率为主模型；
- Logistic为敏感性模型；
- 最高BMI组按25周内未满足可靠性约束的未决组处理；
- 26周只作为11-29周搜索上限敏感性，不作为正式推荐；
- 正式口径为总体BMI构成、严格收敛bootstrap、组平均LCB95>=0.90硬约束；
- 风险函数只作辅助。

建模手优先看：

- `c2_round3_k_compare_summary.csv`
- `c2_round3_k_recommended_timing.csv`
- `c2_round3_k_timing_bootstrap_summary.csv`
- `c2_round3_detection_error_sensitivity.csv`
- `c2_round3_boundary_stability_frequency.csv`

论文手当前不要使用旧图旧表写正文，等待C2最终冻结。
"""
    (ROUND3_DIR / "C2第三轮返修草案交付说明.md").write_text(text, encoding="utf-8")
    readme = C2_DIR / "README_C2看这里.md"
    readme.write_text(
        "# C2 当前状态\n\n"
        "状态：未冻结草案。当前最新返修为 `11_repair_round3`。\n\n"
        "优先查看：\n\n"
        "- `11_repair_round3/C2第三轮返修草案交付说明.md`\n"
        "- `11_repair_round3/C2第三轮返修文件索引.csv`\n"
        "- `11_repair_round3/c2_round3_k_compare_summary.csv`\n"
        "- `06_code/`\n\n"
        "说明：C1 保持不变；C2 暂不交论文手写正文；最高BMI组暂按25周内未决组处理。\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--boundary-bootstrap", type=int, default=300)
    parser.add_argument("--seed", type=int, default=q2.SEED + 300)
    args = parser.parse_args()
    start = time.time()
    ROUND3_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    events, mothers = q2.load_q2_data()
    sigma_m = load_sigma_m()
    point = point_grids(events, mothers, sigma_m)
    boot_prob, boot_timing, boot_status = bootstrap_compare_k(events, sigma_m, args.bootstrap, rng)
    lcb = k_lcb_grid(point, boot_prob)
    rec = recommend_by_k(lcb)
    k_summary = k_compare_summary(rec, boot_status, mothers)
    timing_sum = k_timing_summary(boot_timing, boot_status)
    status_sum = pd.DataFrame(
        [
            {
                "bootstrap_attempts": int(boot_status["bootstrap_id"].nunique()),
                "strict_converged_ok_count": int(boot_status["status"].eq("ok").sum()),
                "not_converged_count": int(boot_status["status"].eq("not_converged").sum()),
                "failed_count": int(boot_status["status"].eq("failed").sum()),
                "failure_reasons": "; ".join(sorted(set(str(x) for x in boot_status.loc[boot_status["status"].eq("failed"), "note"].dropna())))[:1000],
            }
        ]
    )
    err = detection_error_sensitivity(events, mothers, sigma_m)
    boundary_raw, boundary_freq = boundary_stability(events, sigma_m, args.boundary_bootstrap, rng)

    # Keep the accepted logistic sensitivity comparison from round2 available in the latest package.
    round2 = C2_DIR / "10_repair_round2"
    logistic_sens = pd.read_csv(round2 / "c2_round2_cv_model_comparison_summary.csv", encoding="utf-8-sig") if (round2 / "c2_round2_cv_model_comparison_summary.csv").exists() else pd.DataFrame()
    week29 = pd.read_csv(round2 / "c2_round2_week11_29_lmm_recommended_timing_bootstrap_lcb.csv", encoding="utf-8-sig") if (round2 / "c2_round2_week11_29_lmm_recommended_timing_bootstrap_lcb.csv").exists() else pd.DataFrame()

    files = {
        "c2_round3_k_probability_bootstrap_lcb.csv": lcb,
        "c2_round3_k_recommended_timing.csv": rec,
        "c2_round3_k_compare_summary.csv": k_summary,
        "c2_round3_k_bootstrap_status.csv": boot_status,
        "c2_round3_k_bootstrap_status_summary.csv": status_sum,
        "c2_round3_k_bootstrap_raw_probability.csv": boot_prob,
        "c2_round3_k_bootstrap_raw_timing.csv": boot_timing,
        "c2_round3_k_timing_bootstrap_summary.csv": timing_sum,
        "c2_round3_detection_error_sensitivity.csv": err,
        "c2_round3_boundary_stability_raw.csv": boundary_raw,
        "c2_round3_boundary_stability_frequency.csv": boundary_freq,
        "c2_round3_logistic_sensitivity_reference.csv": logistic_sens,
        "c2_round3_week11_29_sensitivity_reference.csv": week29,
    }
    manifest = {
        "status": "round3_draft_not_frozen",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "python": sys.version,
        "platform": platform.platform(),
        "run_command": f"python problem_c_nipt/code/c2_repair_round3.py --bootstrap {args.bootstrap} --boundary-bootstrap {args.boundary_bootstrap} --seed {args.seed}",
        "bootstrap_n": args.bootstrap,
        "boundary_bootstrap_n": args.boundary_bootstrap,
        "seed": args.seed,
        "model_main": "LMM derived probability",
        "model_sensitivity": "logistic binary probability",
        "main_reliability_rule": "resampled BMI composition, strict converged bootstrap, group mean LCB95 >= 0.90",
        "high_bmi_policy": "undecided high-risk group if no feasible week by 25",
        "week26_policy": "sensitivity only, not formal recommendation",
        "elapsed_seconds": round(time.time() - start, 3),
    }
    copy_code_and_write_index(files, manifest)
    write_docs(k_summary)


if __name__ == "__main__":
    main()
