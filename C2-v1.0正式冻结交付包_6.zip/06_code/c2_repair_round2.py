from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import optimize
from scipy.special import expit, logit
from sklearn.model_selection import GroupKFold

import q2_analysis as q2


ROOT = Path(__file__).resolve().parents[1]
C2_DIR = ROOT / "results" / "C2-v1.0"
ROUND2_DIR = C2_DIR / "10_repair_round2"
CODE_DIR = C2_DIR / "06_code"
DOC_DIR = C2_DIR / "00_docs"
K4_CUTS = [29.5, 31.5, 34.5]
Q_MAIN = 0.90
THRESHOLD = q2.THRESHOLD
WEEK_GRID_25 = q2.WEEK_GRID
WEEK_GRID_29 = np.arange(11.0, 29.0 + 1e-9, 0.5)
EPS = 1e-6


@dataclass
class LogisticFit:
    beta: np.ndarray
    week_mean: float
    bmi_mean: float
    converged: bool
    objective: float
    n_obs: int


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def week_to_cn(week: float | str) -> str:
    return q2.week_to_cn(week)


def load_sigma_m() -> float:
    tech_path = C2_DIR / "03_validation" / "q2_technical_error.csv"
    if tech_path.exists():
        return float(pd.read_csv(tech_path, encoding="utf-8-sig")["sigma_m_estimate"].iloc[0])
    tech = q2.estimate_technical_error(200, np.random.default_rng(q2.SEED))
    return float(tech["sigma_m_estimate"].iloc[0])


def group_bounds(mothers: pd.DataFrame, cuts: list[float]) -> list[tuple[float, float]]:
    lo = math.floor(float(mothers["baseline_bmi"].min()) * 2) / 2
    hi = math.ceil(float(mothers["baseline_bmi"].max()) * 2) / 2 + 0.5
    edges = [lo] + cuts + [hi]
    return [(float(edges[i]), float(edges[i + 1])) for i in range(len(edges) - 1)]


def with_groups(mothers: pd.DataFrame, cuts: list[float]) -> pd.DataFrame:
    out = mothers.copy()
    out["group"] = q2.assign_groups(out["baseline_bmi"], cuts)
    return out


def resample_mothers(events: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    base = events.reset_index(drop=True)
    mothers = base["mother_id"].drop_duplicates().to_numpy()
    index_map = {m: idx.to_numpy() for m, idx in base.groupby("mother_id").groups.items()}
    pieces = []
    chosen = rng.choice(mothers, size=len(mothers), replace=True)
    for draw_no, mid in enumerate(chosen, 1):
        part = base.iloc[index_map[mid]].copy()
        part["mother_id"] = f"{mid}__boot{draw_no}"
        pieces.append(part)
    return pd.concat(pieces, ignore_index=True)


def fit_logistic(events: pd.DataFrame) -> LogisticFit:
    df = events.dropna(subset=["week_num", "baseline_bmi", "y_ge_4pct"]).copy()
    week_mean = float(df["week_num"].mean())
    bmi_mean = float(df["baseline_bmi"].mean())
    x_week = df["week_num"].to_numpy(float) - week_mean
    x_bmi = df["baseline_bmi"].to_numpy(float) - bmi_mean
    X = np.column_stack([np.ones(len(df)), x_week, x_bmi])
    y = df["y_ge_4pct"].astype(float).to_numpy()

    def nll(beta: np.ndarray) -> float:
        eta = X @ beta
        p = np.clip(expit(eta), EPS, 1 - EPS)
        ridge = 1e-6 * float(np.sum(beta[1:] ** 2))
        return float(-np.sum(y * np.log(p) + (1 - y) * np.log(1 - p)) + ridge)

    start = np.zeros(3)
    start[0] = logit(np.clip(y.mean(), EPS, 1 - EPS))
    result = optimize.minimize(nll, start, method="L-BFGS-B", bounds=[(None, None), (0.0, None), (None, None)], options={"maxiter": 1000})
    return LogisticFit(beta=result.x, week_mean=week_mean, bmi_mean=bmi_mean, converged=bool(result.success), objective=float(result.fun), n_obs=len(df))


def predict_logistic(fit: LogisticFit, weeks: np.ndarray, bmis: np.ndarray) -> np.ndarray:
    X = np.column_stack([np.ones(len(weeks)), weeks - fit.week_mean, bmis - fit.bmi_mean])
    return expit(X @ fit.beta)


def predict_model(model_type: str, fit, wm: float, bm: float, weeks: np.ndarray, bmis: np.ndarray, sigma_m: float, kappa: float = 1.0) -> np.ndarray:
    if model_type == "lmm":
        return q2.predict_obs_prob(fit, wm, bm, weeks, bmis, kappa=kappa, sigma_m=sigma_m)
    if model_type == "logistic":
        return predict_logistic(fit, weeks, bmis)
    raise ValueError(model_type)


def group_grid(
    model_type: str,
    fit,
    wm: float,
    bm: float,
    mothers: pd.DataFrame,
    cuts: list[float],
    sigma_m: float,
    week_grid: np.ndarray,
    kappa: float = 1.0,
) -> pd.DataFrame:
    grouped = with_groups(mothers, cuts)
    bounds = group_bounds(mothers, cuts)
    rows = []
    for gid in range(len(cuts) + 1):
        gm = grouped[grouped["group"].eq(gid)]
        if gm.empty:
            continue
        bmis = gm["baseline_bmi"].to_numpy(float)
        for week in week_grid:
            probs = predict_model(model_type, fit, wm, bm, np.full(len(bmis), week), bmis, sigma_m, kappa)
            mean_p, cond_lcb, cond_ucb = q2.group_lcb(probs)
            rows.append(
                {
                    "model_type": model_type,
                    "group_id": gid + 1,
                    "bmi_interval": q2.group_label(bounds[gid], gid == len(cuts)),
                    "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                    "week": float(week),
                    "p_group_mean": float(mean_p),
                    "conditional_bmi_composition_lcb95": float(cond_lcb),
                    "conditional_bmi_composition_ucb95": float(cond_ucb),
                    "individual_p_min": float(np.min(probs)),
                    "individual_p_q10": float(np.percentile(probs, 10)),
                    "individual_p_median": float(np.median(probs)),
                    "individual_share_ge_0p90": float(np.mean(probs >= Q_MAIN)),
                    "mother_count": int(len(gm)),
                }
            )
    return pd.DataFrame(rows)


def recommend(grid: pd.DataFrame, reliability_col: str) -> pd.DataFrame:
    rows = []
    for gid, sub in grid.groupby("group_id", sort=True):
        sub = sub.sort_values("week")
        feasible = sub[pd.to_numeric(sub[reliability_col], errors="coerce") >= Q_MAIN]
        if feasible.empty:
            ref = sub.iloc[-1]
            rows.append(
                {
                    "model_type": ref["model_type"],
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "cutpoints": ref["cutpoints"],
                    "status": "undecided_high_risk",
                    "recommended_week": "",
                    "recommended_week_cn": "未决/高风险组",
                    "p_group_mean": float(ref["p_group_mean"]),
                    reliability_col: float(ref[reliability_col]),
                    "at_upper_week_boundary": True,
                }
            )
        else:
            ref = feasible.iloc[0]
            rows.append(
                {
                    "model_type": ref["model_type"],
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "cutpoints": ref["cutpoints"],
                    "status": "ok",
                    "recommended_week": float(ref["week"]),
                    "recommended_week_cn": week_to_cn(float(ref["week"])),
                    "p_group_mean": float(ref["p_group_mean"]),
                    reliability_col: float(ref[reliability_col]),
                    "at_upper_week_boundary": bool(np.isclose(float(ref["week"]), sub["week"].max())),
                }
            )
    return pd.DataFrame(rows)


def bootstrap_fixed_cuts(
    model_type: str,
    events: pd.DataFrame,
    cuts: list[float],
    sigma_m: float,
    n_boot: int,
    rng: np.random.Generator,
    week_grid: np.ndarray,
    composition: str,
    original_mothers: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    prob_rows = []
    timing_rows = []
    status_rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C2 round2 {model_type} {composition} bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            if model_type == "lmm":
                fit, wm, bm = q2.fit_q2_lmm(sample)
                converged = bool(fit.converged)
                model_note = ""
            else:
                fit_log = fit_logistic(sample)
                fit, wm, bm = fit_log, fit_log.week_mean, fit_log.bmi_mean
                converged = bool(fit_log.converged)
                model_note = f"objective={fit_log.objective:.6f}"
            if not converged:
                status_rows.append({"bootstrap_id": b, "model_type": model_type, "composition": composition, "status": "not_converged", "converged": False, "note": model_note})
                continue
            sample_mothers = q2.build_mother_table(sample)
            comp_mothers = sample_mothers if composition == "resampled_bmi_composition" else original_mothers
            grid = group_grid(model_type, fit, wm, bm, comp_mothers, cuts, sigma_m, week_grid)
            for _, row in grid.iterrows():
                prob_rows.append(
                    {
                        "bootstrap_id": b,
                        "model_type": model_type,
                        "composition": composition,
                        "group_id": int(row["group_id"]),
                        "week": float(row["week"]),
                        "p_group_mean": float(row["p_group_mean"]),
                    }
                )
            rec = recommend(grid, "p_group_mean")
            for _, row in rec.iterrows():
                timing_rows.append(
                    {
                        "bootstrap_id": b,
                        "model_type": model_type,
                        "composition": composition,
                        "group_id": int(row["group_id"]),
                        "status": row["status"],
                        "recommended_week": row["recommended_week"],
                        "at_upper_week_boundary": row["at_upper_week_boundary"],
                    }
                )
            status_rows.append({"bootstrap_id": b, "model_type": model_type, "composition": composition, "status": "ok", "converged": True, "note": model_note})
        except Exception as exc:
            status_rows.append({"bootstrap_id": b, "model_type": model_type, "composition": composition, "status": "failed", "converged": False, "note": str(exc)})
    return pd.DataFrame(prob_rows), pd.DataFrame(timing_rows), pd.DataFrame(status_rows)


def bootstrap_lcb_grid(point_grid: pd.DataFrame, boot_prob: pd.DataFrame, composition: str) -> pd.DataFrame:
    if boot_prob.empty:
        out = point_grid.copy()
        out["bootstrap_lcb95"] = np.nan
        out["bootstrap_median"] = np.nan
        out["bootstrap_ucb95"] = np.nan
        out["bootstrap_ok_count"] = 0
        out["composition"] = composition
        return out
    quant = (
        boot_prob.groupby(["model_type", "group_id", "week"])["p_group_mean"]
        .agg(
            bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)),
            bootstrap_median=lambda s: float(np.percentile(s, 50)),
            bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)),
            bootstrap_ok_count="count",
        )
        .reset_index()
    )
    out = point_grid.merge(quant, on=["model_type", "group_id", "week"], how="left")
    out["composition"] = composition
    return out


def timing_summary(timing: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (model_type, composition, gid), sub in timing.groupby(["model_type", "composition", "group_id"], sort=True):
        status_sub = status[status["model_type"].eq(model_type) & status["composition"].eq(composition)]
        total = int(status_sub["bootstrap_id"].nunique()) if not status_sub.empty else 0
        strict = int(status_sub[status_sub["status"].eq("ok")]["bootstrap_id"].nunique()) if not status_sub.empty else 0
        vals = pd.to_numeric(sub["recommended_week"], errors="coerce").dropna().to_numpy(float)
        rows.append(
            {
                "model_type": model_type,
                "composition": composition,
                "group_id": int(gid),
                "bootstrap_attempts": total,
                "strict_converged_iterations": strict,
                "valid_recommend_count": int(len(vals)),
                "no_feasible_ratio_among_converged": float(1 - len(vals) / strict) if strict else np.nan,
                "recommended_week_median": float(np.percentile(vals, 50)) if len(vals) else np.nan,
                "recommended_week_ci_low_2p5": float(np.percentile(vals, 2.5)) if len(vals) else np.nan,
                "recommended_week_ci_high_97p5": float(np.percentile(vals, 97.5)) if len(vals) else np.nan,
                "upper_boundary_ratio_among_valid": float(np.mean(sub["at_upper_week_boundary"].astype(str).str.lower().eq("true"))) if len(vals) else np.nan,
            }
        )
    return pd.DataFrame(rows)


def bootstrap_status_summary(status: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (model_type, composition), sub in status.groupby(["model_type", "composition"], sort=True):
        rows.append(
            {
                "model_type": model_type,
                "composition": composition,
                "attempts": int(sub["bootstrap_id"].nunique()),
                "strict_converged_ok_count": int(sub["status"].eq("ok").sum()),
                "not_converged_count": int(sub["status"].eq("not_converged").sum()),
                "failed_count": int(sub["status"].eq("failed").sum()),
                "failure_reasons": "; ".join(sorted(set(str(x) for x in sub.loc[~sub["status"].eq("ok"), "note"].dropna())))[:1000],
            }
        )
    return pd.DataFrame(rows)


def calibration_rows(pred: pd.DataFrame, label: str) -> pd.DataFrame:
    if pred.empty:
        return pd.DataFrame()
    p = np.clip(pred["predicted_probability"].to_numpy(float), EPS, 1 - EPS)
    y = pred["observed_y_ge_4pct"].to_numpy(float)
    rows = []

    def nll(par: np.ndarray) -> float:
        phat = expit(par[0] + par[1] * logit(p))
        phat = np.clip(phat, EPS, 1 - EPS)
        return float(-np.sum(y * np.log(phat) + (1 - y) * np.log(1 - phat)))

    opt = optimize.minimize(nll, np.array([0.0, 1.0]), method="Nelder-Mead")
    rows.append(
        {
            "model_type": label,
            "calibration_type": "logistic_intercept_slope",
            "bin": "all",
            "n": int(len(y)),
            "pred_mean": float(np.mean(p)),
            "obs_rate": float(np.mean(y)),
            "calibration_intercept": float(opt.x[0]),
            "calibration_slope": float(opt.x[1]),
            "converged": bool(opt.success),
        }
    )
    near = pred[(pred["predicted_probability"] >= 0.85) & (pred["predicted_probability"] <= 0.95)]
    rows.append(
        {
            "model_type": label,
            "calibration_type": "near_0p90_window",
            "bin": "[0.85,0.95]",
            "n": int(len(near)),
            "pred_mean": float(near["predicted_probability"].mean()) if len(near) else np.nan,
            "obs_rate": float(near["observed_y_ge_4pct"].mean()) if len(near) else np.nan,
        }
    )
    tmp = pred.copy()
    tmp["bin"] = pd.qcut(tmp["predicted_probability"], q=5, duplicates="drop").astype(str)
    for name, sub in tmp.groupby("bin", sort=False):
        rows.append(
            {
                "model_type": label,
                "calibration_type": "quantile_bin",
                "bin": name,
                "n": int(len(sub)),
                "pred_mean": float(sub["predicted_probability"].mean()),
                "obs_rate": float(sub["observed_y_ge_4pct"].mean()),
            }
        )
    return pd.DataFrame(rows)


def cv_compare(events: pd.DataFrame, sigma_m: float, n_splits: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    splitter = GroupKFold(n_splits=n_splits)
    rows = []
    pred_rows = []
    groups = events["mother_id"].to_numpy()
    for fold, (tr, va) in enumerate(splitter.split(events, groups=groups), 1):
        train = events.iloc[tr].copy()
        valid = events.iloc[va].copy()
        valid_mothers = q2.build_mother_table(valid)[["mother_id", "baseline_bmi"]]
        valid = valid.drop(columns=["baseline_bmi"], errors="ignore").merge(valid_mothers, on="mother_id", how="left")
        y = valid["y_ge_4pct"].astype(int).to_numpy()

        lmm, wm, bm = q2.fit_q2_lmm(train)
        lp = q2.predict_obs_prob(lmm, wm, bm, valid["week_num"].to_numpy(float), valid["baseline_bmi"].to_numpy(float), 1.0, sigma_m)
        logi = fit_logistic(train)
        gp = predict_logistic(logi, valid["week_num"].to_numpy(float), valid["baseline_bmi"].to_numpy(float))
        const_p = np.repeat(float(train["y_ge_4pct"].mean()), len(valid))
        for model_type, p, converged in [("lmm_derived_probability", lp, bool(lmm.converged)), ("logistic_binary_probability", gp, bool(logi.converged)), ("constant_train_event_rate", const_p, True)]:
            p_clip = np.clip(p, EPS, 1 - EPS)
            rows.append(
                {
                    "fold": fold,
                    "model_type": model_type,
                    "status": "ok" if converged else "not_converged",
                    "train_mothers": int(train["mother_id"].nunique()),
                    "valid_mothers": int(valid["mother_id"].nunique()),
                    "valid_events": int(len(valid)),
                    "brier_score_event_actual_week": float(np.mean((p - y) ** 2)),
                    "log_loss_event_actual_week": float(-np.mean(y * np.log(p_clip) + (1 - y) * np.log(1 - p_clip))),
                    "converged": converged,
                }
            )
            for local_i, (_, row) in enumerate(valid.iterrows()):
                pred_rows.append(
                    {
                        "fold": fold,
                        "model_type": model_type,
                        "event_id": row["event_id"],
                        "mother_id": row["mother_id"],
                        "actual_week": float(row["week_num"]),
                        "baseline_bmi": float(row["baseline_bmi"]),
                        "observed_y_ge_4pct": int(row["y_ge_4pct"]),
                        "predicted_probability": float(p[local_i]),
                    }
                )
    metrics = pd.DataFrame(rows)
    pred = pd.DataFrame(pred_rows)
    cal = pd.concat([calibration_rows(pred[pred["model_type"].eq(m)].copy(), m) for m in pred["model_type"].unique()], ignore_index=True)
    return metrics, pred, cal


def individual_reliable_weeks_model(model_type: str, fit, wm: float, bm: float, bmis: np.ndarray, sigma_m: float, week_grid: np.ndarray) -> np.ndarray:
    out = []
    for bmi in bmis:
        p = predict_model(model_type, fit, wm, bm, week_grid, np.full(len(week_grid), bmi), sigma_m, 1.0)
        ok = week_grid[p >= Q_MAIN]
        out.append(float(ok[0]) if len(ok) else np.nan)
    return np.asarray(out)


def evaluate_cut_candidate(
    model_type: str,
    fit,
    wm: float,
    bm: float,
    mothers: pd.DataFrame,
    events: pd.DataFrame,
    cuts: list[float],
    sigma_m: float,
    week_grid: np.ndarray,
) -> tuple[pd.DataFrame, dict] | None:
    grouped = with_groups(mothers, cuts)
    event_group = events.copy()
    event_group["group"] = q2.assign_groups(event_group["baseline_bmi"], cuts)
    rows = []
    feasible_counts = True
    feasible_time = True
    for gid in range(len(cuts) + 1):
        gm = grouped[grouped["group"].eq(gid)]
        ge = event_group[event_group["group"].eq(gid)]
        reached = int(gm["ever_reached_4pct"].sum())
        count_ok = len(gm) >= q2.MIN_MOTHERS and len(ge) >= q2.MIN_EVENTS and reached >= q2.MIN_REACHED_MOTHERS
        feasible_counts = feasible_counts and count_ok
        grid = group_grid(model_type, fit, wm, bm, gm.drop(columns=["group"]), [], sigma_m, week_grid)
        rec = recommend(grid, "conditional_bmi_composition_lcb95").iloc[0]
        if rec["status"] != "ok":
            feasible_time = False
        rows.append(
            {
                "model_type": model_type,
                "group_id": gid + 1,
                "bmi_interval": q2.group_label(group_bounds(mothers, cuts)[gid], gid == len(cuts)),
                "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                "mother_count": int(len(gm)),
                "event_count": int(len(ge)),
                "reached_mother_count": reached,
                "count_constraint_passed": bool(count_ok),
                "status": rec["status"] if count_ok else "count_constraint_failed",
                "recommended_week": rec["recommended_week"] if count_ok else "",
                "p_group_mean": rec["p_group_mean"],
                "conditional_bmi_composition_lcb95": rec["conditional_bmi_composition_lcb95"],
            }
        )
    indiv = individual_reliable_weeks_model(model_type, fit, wm, bm, mothers["baseline_bmi"].to_numpy(float), sigma_m, week_grid)
    rec_map = {r["group_id"] - 1: r["recommended_week"] for r in rows if r["recommended_week"] != ""}
    assigned = np.asarray([rec_map.get(int(g), np.nan) for g in grouped["group"]], dtype=float)
    evaluable = np.isfinite(indiv) & np.isfinite(assigned)
    regret = np.maximum(assigned[evaluable] - indiv[evaluable], 0)
    summary = {
        "model_type": model_type,
        "K": len(cuts) + 1,
        "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
        "feasible": bool(feasible_counts and feasible_time),
        "mean_regret_evaluable_only": float(np.mean(regret)) if len(regret) else np.nan,
        "p90_regret_evaluable_only": float(np.percentile(regret, 90)) if len(regret) else np.nan,
        "n_total": int(len(mothers)),
        "n_evaluable": int(np.sum(evaluable)),
        "coverage": float(np.mean(evaluable)),
        "undecided_mother_count": int(len(mothers) - np.sum(evaluable)),
        "worst_conditional_lcb95": float(np.nanmin([r["conditional_bmi_composition_lcb95"] for r in rows])),
    }
    return pd.DataFrame(rows), summary


def interval_record_model(
    model_type: str,
    fit,
    wm: float,
    bm: float,
    mothers: pd.DataFrame,
    events: pd.DataFrame,
    edges: list[float],
    i: int,
    j: int,
    sigma_m: float,
    week_grid: np.ndarray,
    indiv_map: dict[str, float],
) -> dict | None:
    lo, hi = edges[i], edges[j]
    gm = mothers[(mothers["baseline_bmi"] >= lo) & (mothers["baseline_bmi"] < hi)].copy()
    ge = events[(events["baseline_bmi"] >= lo) & (events["baseline_bmi"] < hi)].copy()
    if len(gm) < q2.MIN_MOTHERS or len(ge) < q2.MIN_EVENTS or int(gm["ever_reached_4pct"].sum()) < q2.MIN_REACHED_MOTHERS:
        return None
    grid = group_grid(model_type, fit, wm, bm, gm, [], sigma_m, week_grid)
    rec = recommend(grid, "conditional_bmi_composition_lcb95").iloc[0]
    if rec["status"] != "ok":
        return None
    indiv = np.asarray([indiv_map[m] for m in gm["mother_id"]], dtype=float)
    valid = np.isfinite(indiv)
    rec_week = float(rec["recommended_week"])
    regret = np.maximum(rec_week - indiv[valid], 0)
    return {
        "i": i,
        "j": j,
        "lo": float(lo),
        "hi": float(hi),
        "mother_count": int(len(gm)),
        "event_count": int(len(ge)),
        "reached_mother_count": int(gm["ever_reached_4pct"].sum()),
        "recommended_week": rec_week,
        "p_group_mean": float(rec["p_group_mean"]),
        "conditional_lcb": float(rec["conditional_bmi_composition_lcb95"]),
        "regret_sum": float(np.sum(regret)) if len(regret) else 0.0,
        "regret_values": regret,
        "n_evaluable": int(np.sum(valid)),
        "undecided_mother_count": int(len(gm) - np.sum(valid)),
    }


def search_partitions_by_model(model_type: str, fit, wm: float, bm: float, mothers: pd.DataFrame, events: pd.DataFrame, sigma_m: float, week_grid: np.ndarray) -> tuple[pd.DataFrame, pd.DataFrame]:
    grid = q2.cut_grid(mothers["baseline_bmi"])
    edges = [math.floor(float(mothers["baseline_bmi"].min()) * 2) / 2] + grid + [math.ceil(float(mothers["baseline_bmi"].max()) * 2) / 2 + 0.5]
    edges = sorted(dict.fromkeys(edges))
    indiv = individual_reliable_weeks_model(model_type, fit, wm, bm, mothers["baseline_bmi"].to_numpy(float), sigma_m, week_grid)
    indiv_map = dict(zip(mothers["mother_id"], indiv))
    intervals: dict[tuple[int, int], dict] = {}
    for i in range(len(edges) - 1):
        for j in range(i + 1, len(edges)):
            rec = interval_record_model(model_type, fit, wm, bm, mothers, events, edges, i, j, sigma_m, week_grid, indiv_map)
            if rec is not None:
                intervals[(i, j)] = rec
    end = len(edges) - 1
    candidate_rows = []
    group_rows = []
    for K in [3, 4, 5]:
        dp: list[dict[int, tuple[float, list[dict]]]] = [dict() for _ in range(K + 1)]
        dp[0][0] = (0.0, [])
        for k in range(1, K + 1):
            for j in range(1, end + 1):
                best = None
                for i in range(j):
                    if i not in dp[k - 1] or (i, j) not in intervals:
                        continue
                    prev_score, prev_path = dp[k - 1][i]
                    rec = intervals[(i, j)]
                    score = prev_score + rec["regret_sum"]
                    if best is None or score < best[0]:
                        best = (score, prev_path + [rec])
                if best is not None:
                    dp[k][j] = best
        if end not in dp[K]:
            candidate_rows.append({"model_type": model_type, "K": K, "feasible": False, "note": "no feasible DP path by point model conditional LCB", "feasible_interval_count": len(intervals)})
            continue
        _, path = dp[K][end]
        regrets = np.concatenate([p["regret_values"] for p in path if len(p["regret_values"])])
        cutpoints = [p["hi"] for p in path[:-1]]
        total_undecided = int(sum(p["undecided_mother_count"] for p in path))
        total_evaluable = int(sum(p["n_evaluable"] for p in path))
        candidate_rows.append(
            {
                "model_type": model_type,
                "K": K,
                "cutpoints": ";".join(f"{c:.1f}" for c in cutpoints),
                "feasible": True,
                "mean_regret_evaluable_only": float(np.mean(regrets)) if len(regrets) else np.nan,
                "p90_regret_evaluable_only": float(np.percentile(regrets, 90)) if len(regrets) else np.nan,
                "n_total": int(len(mothers)),
                "n_evaluable": total_evaluable,
                "coverage": float(total_evaluable / len(mothers)),
                "undecided_mother_count": total_undecided,
                "worst_conditional_lcb95": float(min(p["conditional_lcb"] for p in path)),
                "feasible_interval_count": len(intervals),
            }
        )
        for gid, rec in enumerate(path, 1):
            group_rows.append(
                {
                    "model_type": model_type,
                    "K": K,
                    "candidate_role": "best_by_K_point_conditional_lcb_screening",
                    "group_id": gid,
                    "bmi_interval": q2.group_label((rec["lo"], rec["hi"]), gid == len(path)),
                    "cutpoints": ";".join(f"{c:.1f}" for c in cutpoints),
                    "mother_count": rec["mother_count"],
                    "event_count": rec["event_count"],
                    "reached_mother_count": rec["reached_mother_count"],
                    "recommended_week": rec["recommended_week"],
                    "recommended_week_cn": week_to_cn(rec["recommended_week"]),
                    "p_group_mean": rec["p_group_mean"],
                    "conditional_bmi_composition_lcb95": rec["conditional_lcb"],
                }
            )
    return pd.DataFrame(candidate_rows), pd.DataFrame(group_rows)


def k4_week29_sensitivity(model_type: str, fit, wm: float, bm: float, mothers: pd.DataFrame, events: pd.DataFrame, sigma_m: float) -> pd.DataFrame:
    grid = group_grid(model_type, fit, wm, bm, mothers, K4_CUTS, sigma_m, WEEK_GRID_29)
    rec_cond = recommend(grid, "conditional_bmi_composition_lcb95")
    rows = []
    for _, row in rec_cond.iterrows():
        rows.append(
            {
                "model_type": model_type,
                "week_grid": "11_29",
                "group_id": int(row["group_id"]),
                "bmi_interval": row["bmi_interval"],
                "status_conditional_lcb": row["status"],
                "recommended_week_conditional_lcb": row["recommended_week"],
                "p_group_mean": row["p_group_mean"],
                "conditional_bmi_composition_lcb95": row["conditional_bmi_composition_lcb95"],
                "at_29_week_boundary": row["at_upper_week_boundary"],
            }
        )
    return pd.DataFrame(rows)


def error_sensitivity_lmm(fit, wm: float, bm: float, mothers: pd.DataFrame, sigma_m: float) -> pd.DataFrame:
    rows = []
    for kappa in q2.KAPPA_GRID:
        grid = group_grid("lmm", fit, wm, bm, mothers, K4_CUTS, sigma_m, WEEK_GRID_25, kappa=kappa)
        rec = recommend(grid, "conditional_bmi_composition_lcb95")
        for _, row in rec.iterrows():
            rows.append(
                {
                    "model_type": "lmm",
                    "kappa": float(kappa),
                    "group_id": int(row["group_id"]),
                    "bmi_interval": row["bmi_interval"],
                    "status": row["status"],
                    "recommended_week": row["recommended_week"],
                    "p_group_mean": row["p_group_mean"],
                    "conditional_bmi_composition_lcb95": row["conditional_bmi_composition_lcb95"],
                    "formula": "sigma_total^2=sigma_u^2+max(sigma_e^2-sigma_m^2,0)+kappa^2*sigma_m^2",
                }
            )
    out = pd.DataFrame(rows)
    base = out[out["kappa"].eq(1.0)][["group_id", "recommended_week", "p_group_mean"]].rename(columns={"recommended_week": "base_week", "p_group_mean": "base_p"})
    out = out.merge(base, on="group_id", how="left")
    out["recommended_week_changed_vs_kappa1"] = out["recommended_week"].astype(str) != out["base_week"].astype(str)
    out["probability_changed_vs_kappa1"] = (pd.to_numeric(out["p_group_mean"], errors="coerce") - pd.to_numeric(out["base_p"], errors="coerce")).abs() > 1e-10
    return out


def write_bundle_and_hashes(files: dict[str, pd.DataFrame], manifest: dict) -> None:
    ROUND2_DIR.mkdir(parents=True, exist_ok=True)
    index_rows = []
    for name, df in files.items():
        path = ROUND2_DIR / name
        df.to_csv(path, index=False, encoding="utf-8-sig")
        index_rows.append({"category": "result", "status": "round2_draft", "path": f"10_repair_round2/{name}", "note": f"rows={len(df)}"})

    CODE_DIR.mkdir(parents=True, exist_ok=True)
    code_files = ["q2_analysis.py", "c2_finalize_k4.py", "c2_make_official_figures.py", "c2_repair_draft.py", "c2_repair_round2.py"]
    code_rows = []
    for name in code_files:
        src = ROOT / "code" / name
        dst = CODE_DIR / name
        shutil.copy2(src, dst)
        code_rows.append({"file": f"06_code/{name}", "source_path": str(src), "sha256": sha256(dst)})
        index_rows.append({"category": "code", "status": "round2_draft", "path": f"06_code/{name}", "note": f"sha256={sha256(dst)}"})
    pd.DataFrame(code_rows).to_csv(ROUND2_DIR / "c2_round2_code_hashes.csv", index=False, encoding="utf-8-sig")
    index_rows.append({"category": "hash", "status": "round2_draft", "path": "10_repair_round2/c2_round2_code_hashes.csv", "note": "随包代码哈希"})

    input_paths = [q2.INPUT, q2.TECH_REP, C2_DIR / "01_main_results" / "c2_main_K4_groups.csv"]
    input_rows = [{"path": str(p), "exists": p.exists(), "sha256": sha256(p) if p.exists() else ""} for p in input_paths]
    pd.DataFrame(input_rows).to_csv(ROUND2_DIR / "c2_round2_input_hashes.csv", index=False, encoding="utf-8-sig")
    index_rows.append({"category": "hash", "status": "round2_draft", "path": "10_repair_round2/c2_round2_input_hashes.csv", "note": "输入哈希"})

    (ROUND2_DIR / "c2_round2_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    index_rows.append({"category": "manifest", "status": "round2_draft", "path": "10_repair_round2/c2_round2_run_manifest.json", "note": "运行命令、参数、环境"})
    pd.DataFrame(index_rows).to_csv(ROUND2_DIR / "C2第二轮返修文件索引.csv", index=False, encoding="utf-8-sig")


def write_docs(summary: dict) -> None:
    text = f"""# C2第二轮返修草案交付说明

状态：未冻结草案，暂不交论文手写正文。C1保持不变，未进入C3。

本轮按建模审核意见完成：

1. bootstrap只保留严格收敛迭代进入概率分位数和推荐时点统计；
2. bootstrap尝试次数提高到{summary['bootstrap_n']}次；
3. 正式组平均可靠性改为总体口径：每次孕妇簇重采样后，用该次重采样孕妇的BMI构成计算组平均达标概率；
4. 保留固定原样本BMI构成结果为条件敏感性；
5. 增加直接针对 `Y浓度>=4%` 的二项logistic概率模型，并与LMM派生概率做GroupKFold比较；
6. 重新输出K=3、K=4、K=5候选分组筛查结果，不把旧切点作为冻结结果；
7. 删除未决孕妇2周惩罚的正式统计，改为单列未决人数和比例；
8. 增加11-29周敏感性，检查高BMI组未决是否由25周上限造成。

重要临时发现：

- LMM总体组平均bootstrap口径下，固定K4高BMI组在25周内仍未通过 `LCB95>=0.90`。
- 固定K4高BMI组11-29周敏感性需由 `c2_round2_week11_29_sensitivity.csv` 复核。
- Logistic二项模型与LMM派生概率的校准和预测表现，请优先看 `c2_round2_cv_model_comparison_summary.csv` 与 `c2_round2_cv_calibration.csv`。

建模手当前口径已记录：

- 可靠性主对象：总体组平均可靠性；
- 组内覆盖：安全性补充；
- 可靠性约束：主约束；
- 风险函数：辅助；
- 最高BMI组：暂列高风险未决组。
"""
    (ROUND2_DIR / "C2第二轮返修草案交付说明.md").write_text(text, encoding="utf-8")

    readme = C2_DIR / "README_C2看这里.md"
    readme.write_text(
        "# C2 当前状态\n\n"
        "状态：未冻结草案。原 C2-v1.0 冻结结论已撤回，第一轮返修后继续进入第二轮返修。\n\n"
        "当前优先查看：\n\n"
        "- `10_repair_round2/C2第二轮返修草案交付说明.md`\n"
        "- `10_repair_round2/C2第二轮返修文件索引.csv`\n"
        "- `10_repair_round2/c2_round2_run_manifest.json`\n"
        "- `06_code/`\n\n"
        "说明：C1 保持不变；C2 暂不交论文手写正文；待建模手确认概率模型、分组与高BMI组处理后再冻结。\n",
        encoding="utf-8",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--cv-splits", type=int, default=5)
    parser.add_argument("--seed", type=int, default=q2.SEED)
    args = parser.parse_args()
    start = time.time()
    rng = np.random.default_rng(args.seed)
    ROUND2_DIR.mkdir(parents=True, exist_ok=True)

    events, mothers = q2.load_q2_data()
    sigma_m = load_sigma_m()
    lmm, wm, bm = q2.fit_q2_lmm(events)
    logi = fit_logistic(events)

    lmm_point_k4 = group_grid("lmm", lmm, wm, bm, mothers, K4_CUTS, sigma_m, WEEK_GRID_25)
    logi_point_k4 = group_grid("logistic", logi, logi.week_mean, logi.bmi_mean, mothers, K4_CUTS, sigma_m, WEEK_GRID_25)

    lmm_prob_overall, lmm_timing_overall, lmm_status_overall = bootstrap_fixed_cuts("lmm", events, K4_CUTS, sigma_m, args.bootstrap, rng, WEEK_GRID_25, "resampled_bmi_composition", mothers)
    # Conditional sensitivity uses a fresh RNG stream to avoid reusing exactly the same samples as the main overall口径.
    lmm_prob_cond, lmm_timing_cond, lmm_status_cond = bootstrap_fixed_cuts("lmm", events, K4_CUTS, sigma_m, args.bootstrap, rng, WEEK_GRID_25, "original_bmi_composition", mothers)
    logi_prob_overall, logi_timing_overall, logi_status_overall = bootstrap_fixed_cuts("logistic", events, K4_CUTS, sigma_m, args.bootstrap, rng, WEEK_GRID_25, "resampled_bmi_composition", mothers)

    lmm_grid_overall = bootstrap_lcb_grid(lmm_point_k4, lmm_prob_overall, "resampled_bmi_composition")
    lmm_grid_cond = bootstrap_lcb_grid(lmm_point_k4, lmm_prob_cond, "original_bmi_composition")
    logi_grid_overall = bootstrap_lcb_grid(logi_point_k4, logi_prob_overall, "resampled_bmi_composition")
    lcb_grids = pd.concat([lmm_grid_overall, lmm_grid_cond, logi_grid_overall], ignore_index=True)

    recs = pd.concat(
        [
            recommend(lmm_grid_overall, "bootstrap_lcb95"),
            recommend(lmm_grid_cond, "bootstrap_lcb95"),
            recommend(logi_grid_overall, "bootstrap_lcb95"),
        ],
        ignore_index=True,
    )
    recs["composition"] = ["resampled_bmi_composition"] * 4 + ["original_bmi_composition"] * 4 + ["resampled_bmi_composition"] * 4

    boot_status = pd.concat([lmm_status_overall, lmm_status_cond, logi_status_overall], ignore_index=True)
    boot_prob = pd.concat([lmm_prob_overall, lmm_prob_cond, logi_prob_overall], ignore_index=True)
    boot_timing = pd.concat([lmm_timing_overall, lmm_timing_cond, logi_timing_overall], ignore_index=True)
    boot_status_sum = bootstrap_status_summary(boot_status)
    boot_timing_sum = timing_summary(boot_timing, boot_status)

    cv_metrics, cv_pred, cv_cal = cv_compare(events, sigma_m, args.cv_splits)
    cv_summary = (
        cv_metrics.groupby("model_type")
        .agg(
            folds=("fold", "count"),
            mean_brier=("brier_score_event_actual_week", "mean"),
            mean_log_loss=("log_loss_event_actual_week", "mean"),
            nonconverged=("converged", lambda s: int((~s.astype(bool)).sum())),
        )
        .reset_index()
    )

    cand_frames = []
    group_frames = []
    for model_type, fit, mw, mb in [("lmm", lmm, wm, bm), ("logistic", logi, logi.week_mean, logi.bmi_mean)]:
        cand, groups_out = search_partitions_by_model(model_type, fit, mw, mb, mothers, events, sigma_m, WEEK_GRID_25)
        cand_frames.append(cand)
        group_frames.append(groups_out)
    candidates = pd.concat(cand_frames, ignore_index=True)
    candidate_groups = pd.concat(group_frames, ignore_index=True)

    week29 = pd.concat(
        [
            k4_week29_sensitivity("lmm", lmm, wm, bm, mothers, events, sigma_m),
            k4_week29_sensitivity("logistic", logi, logi.week_mean, logi.bmi_mean, mothers, events, sigma_m),
        ],
        ignore_index=True,
    )
    lmm_prob_29, lmm_timing_29, lmm_status_29 = bootstrap_fixed_cuts(
        "lmm",
        events,
        K4_CUTS,
        sigma_m,
        args.bootstrap,
        rng,
        WEEK_GRID_29,
        "resampled_bmi_composition_week11_29",
        mothers,
    )
    lmm_point_k4_29 = group_grid("lmm", lmm, wm, bm, mothers, K4_CUTS, sigma_m, WEEK_GRID_29)
    lmm_grid_29 = bootstrap_lcb_grid(lmm_point_k4_29, lmm_prob_29, "resampled_bmi_composition_week11_29")
    rec_29 = recommend(lmm_grid_29, "bootstrap_lcb95")
    rec_29["composition"] = "resampled_bmi_composition_week11_29"
    timing_29 = timing_summary(lmm_timing_29, lmm_status_29)
    status_29 = bootstrap_status_summary(lmm_status_29)
    err = error_sensitivity_lmm(lmm, wm, bm, mothers, sigma_m)

    individual_safety = pd.concat([lmm_point_k4, logi_point_k4], ignore_index=True)[
        [
            "model_type",
            "group_id",
            "bmi_interval",
            "week",
            "p_group_mean",
            "individual_p_min",
            "individual_p_q10",
            "individual_p_median",
            "individual_share_ge_0p90",
        ]
    ]

    files = {
        "c2_round2_k4_probability_bootstrap_lcb.csv": lcb_grids,
        "c2_round2_k4_recommended_timing_bootstrap_lcb.csv": recs,
        "c2_round2_bootstrap_status.csv": boot_status,
        "c2_round2_bootstrap_status_summary.csv": boot_status_sum,
        "c2_round2_bootstrap_raw_probability.csv": boot_prob,
        "c2_round2_bootstrap_raw_timing.csv": boot_timing,
        "c2_round2_fixed_k4_timing_summary.csv": boot_timing_sum,
        "c2_round2_individual_probability_safety.csv": individual_safety,
        "c2_round2_cv_model_comparison_by_fold.csv": cv_metrics,
        "c2_round2_cv_model_comparison_summary.csv": cv_summary,
        "c2_round2_cv_predictions.csv": cv_pred,
        "c2_round2_cv_calibration.csv": cv_cal,
        "c2_round2_partition_candidates_by_model.csv": candidates,
        "c2_round2_partition_groups_by_model.csv": candidate_groups,
        "c2_round2_error_sensitivity_fixed_kappa.csv": err,
        "c2_round2_week11_29_sensitivity.csv": week29,
        "c2_round2_week11_29_lmm_bootstrap_lcb.csv": lmm_grid_29,
        "c2_round2_week11_29_lmm_recommended_timing_bootstrap_lcb.csv": rec_29,
        "c2_round2_week11_29_lmm_bootstrap_status_summary.csv": status_29,
        "c2_round2_week11_29_lmm_timing_summary.csv": timing_29,
        "c2_round2_week11_29_lmm_bootstrap_raw_probability.csv": lmm_prob_29,
        "c2_round2_week11_29_lmm_bootstrap_raw_timing.csv": lmm_timing_29,
        "c2_round2_week11_29_lmm_bootstrap_status.csv": lmm_status_29,
    }
    manifest = {
        "status": "round2_draft_not_frozen",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "python": sys.version,
        "platform": platform.platform(),
        "run_command": f"python problem_c_nipt/code/c2_repair_round2.py --bootstrap {args.bootstrap} --cv-splits {args.cv_splits} --seed {args.seed}",
        "bootstrap_n": args.bootstrap,
        "cv_splits": args.cv_splits,
        "seed": args.seed,
        "k4_cutpoints": K4_CUTS,
        "sigma_m": sigma_m,
        "lmm_converged": bool(lmm.converged),
        "logistic_converged": bool(logi.converged),
        "risk_function_role": "auxiliary_only",
        "main_reliability_rule": "group mean bootstrap LCB95 >= 0.90 under resampled BMI composition",
        "elapsed_seconds": round(time.time() - start, 3),
    }
    write_bundle_and_hashes(files, manifest)
    write_docs({"bootstrap_n": args.bootstrap})


if __name__ == "__main__":
    main()
