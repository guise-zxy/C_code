from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CODE_DIR = ROOT / "code"
C2_DIR = ROOT / "results" / "C2-v1.0"
HANDOFF_DIR = C2_DIR / "12_k4_handoff"
TOP_CODE_DIR = C2_DIR / "06_code"
HANDOFF_CODE_DIR = HANDOFF_DIR / "06_code"
ROUND3_SOURCE_DIR = C2_DIR / "obsolete" / "history_20260907_cleanup" / "11_repair_round3"
ROUND3_EVIDENCE_DIR = HANDOFF_DIR / "round3_evidence"
C1_DIR = ROOT / "results" / "C1-v1.0"


CODE_FILES = [
    "q2_analysis.py",
    "c2_finalize_k4.py",
    "c2_make_official_figures.py",
    "c2_repair_draft.py",
    "c2_repair_round2.py",
    "c2_repair_round3.py",
    "c2_k4_final_handoff.py",
    "c2_freeze_package.py",
]


C1_DEPENDENCY_FILES = [
    C1_DIR / "c1_clean_events.csv",
    C1_DIR / "c1_technical_replicates.csv",
    CODE_DIR / "c1_model_analysis.py",
]


ROUND3_EVIDENCE_FILES = [
    "c2_round3_k_bootstrap_status.csv",
    "c2_round3_k_bootstrap_status_summary.csv",
    "c2_round3_run_manifest.json",
    "c2_round3_k_bootstrap_raw_probability.csv",
    "c2_round3_k_bootstrap_raw_timing.csv",
    "c2_round3_logistic_sensitivity_reference.csv",
]


DOC_FILES = [
    "C2-v1.0\u6b63\u5f0f\u51bb\u7ed3\u8bf4\u660e.md",
    "C2_\u7f16\u7a0b\u624b\u6b63\u5f0f\u7ed3\u679c\u63a5\u53e3_v1.0.md",
    "C2_\u590d\u73b0\u8bc1\u636e\u94fe\u6536\u53e3\u8bf4\u660e.md",
    "C2_K4\u6b63\u6587\u4e3b\u5206\u7ec4_\u8bba\u6587\u624b\u4ea4\u4ed8\u6750\u6599.md",
    "\u7ed9\u5efa\u6a21\u624b_C2_K4\u6536\u53e3\u590d\u6838\u8bf4\u660e.md",
    "\u7ed9\u8bba\u6587\u624b_C2_K4\u5199\u4f5c\u4ea4\u4ed8\u8bf4\u660e.md",
    "c2_k4_handoff_run_manifest.json",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_code() -> pd.DataFrame:
    for directory in [TOP_CODE_DIR, HANDOFF_CODE_DIR]:
        if directory.exists():
            shutil.rmtree(directory)
    TOP_CODE_DIR.mkdir(parents=True, exist_ok=True)
    HANDOFF_CODE_DIR.mkdir(parents=True, exist_ok=True)
    rows = []
    missing = []
    for name in CODE_FILES:
        src = CODE_DIR / name
        if not src.exists():
            missing.append(name)
            continue
        shutil.copy2(src, TOP_CODE_DIR / name)
        shutil.copy2(src, HANDOFF_CODE_DIR / name)
        rows.append({"file": f"06_code/{name}", "sha256": sha256(src)})
    if missing:
        raise FileNotFoundError("Missing C2 code files: " + ", ".join(missing))
    code_hashes = pd.DataFrame(rows)
    code_hashes.to_csv(HANDOFF_DIR / "c2_k4_code_hashes.csv", index=False, encoding="utf-8-sig")
    return code_hashes


def write_c1_dependency_hashes() -> Path:
    rows = []
    missing = []
    for path in C1_DEPENDENCY_FILES:
        if not path.exists():
            missing.append(str(path.relative_to(ROOT)))
            continue
        rows.append(
            {
                "dependency_problem": "C1-v1.0",
                "relative_path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "sha256": sha256(path),
                "note": "frozen C1 dependency used by C2",
            }
        )
    if missing:
        raise FileNotFoundError("Missing C1 dependency files: " + ", ".join(missing))
    out = HANDOFF_DIR / "c2_c1_dependency_hashes.csv"
    pd.DataFrame(rows).to_csv(out, index=False, encoding="utf-8-sig")
    return out


def copy_round3_evidence() -> list[Path]:
    ROUND3_EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
    copied = []
    missing = []
    for name in ROUND3_EVIDENCE_FILES:
        src = ROUND3_SOURCE_DIR / name
        if not src.exists():
            missing.append(name)
            continue
        dst = ROUND3_EVIDENCE_DIR / name
        shutil.copy2(src, dst)
        copied.append(dst)
    if missing:
        raise FileNotFoundError("Missing round3 evidence files: " + ", ".join(missing))
    return copied


def write_dependency_versions() -> Path:
    import matplotlib
    import numpy
    import scipy
    import sklearn

    rows = [
        {"package": "python", "version": ".".join(map(str, __import__("sys").version_info[:3]))},
        {"package": "numpy", "version": numpy.__version__},
        {"package": "pandas", "version": pd.__version__},
        {"package": "scipy", "version": scipy.__version__},
        {"package": "scikit-learn", "version": sklearn.__version__},
        {"package": "matplotlib", "version": matplotlib.__version__},
    ]
    out = HANDOFF_DIR / "c2_python_dependency_versions.csv"
    pd.DataFrame(rows).to_csv(out, index=False, encoding="utf-8-sig")
    return out


def write_code_zip() -> Path:
    archive = HANDOFF_DIR / "C2\u5b8c\u657406_code\u4ee3\u7801\u5305.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(HANDOFF_CODE_DIR.glob("*.py")):
            zf.write(path, arcname=f"06_code/{path.name}")
    return archive


def csv_rows(path: Path) -> str:
    try:
        return str(len(pd.read_csv(path)))
    except Exception:
        return ""


def write_index(code_hashes: pd.DataFrame, archive: Path) -> Path:
    rows = []
    index_name = "C2_K4\u4ea4\u4ed8\u6587\u4ef6\u7d22\u5f15.csv"
    validation_name = "c2_index_path_validation.csv"
    zip_validation_name = "c2_zip_member_validation.csv"
    for path in sorted(HANDOFF_DIR.glob("*.csv")):
        if path.name in {index_name, validation_name, zip_validation_name}:
            continue
        n = csv_rows(path)
        rows.append(
            {
                "category": "result",
                "status": "frozen",
                "path": f"12_k4_handoff/{path.name}",
                "note": f"rows={n}" if n else "csv",
            }
        )
    for folder, category, note in [
        ("figures", "figure", "PNG 300dpi or editable SVG"),
        ("figure_data", "figure_data", "figure source data"),
        ("input_snapshots", "input_snapshot", "reproducible input snapshot"),
        ("round3_evidence", "round3_evidence", "main K=3/4/5 bootstrap reproduction evidence"),
    ]:
        for path in sorted((HANDOFF_DIR / folder).glob("*")):
            if path.is_file():
                rows.append(
                    {
                        "category": category,
                        "status": "frozen",
                        "path": f"12_k4_handoff/{folder}/{path.name}",
                        "note": note,
                    }
                )
    for _, row in code_hashes.iterrows():
        rows.append(
            {
                "category": "code",
                "status": "frozen",
                "path": row["file"],
                "note": f"sha256={row['sha256']}",
            }
        )
    rows.append(
        {
            "category": "archive",
            "status": "frozen",
            "path": f"12_k4_handoff/{archive.name}",
            "note": "complete 06_code zip",
        }
    )
    rows.append(
        {
            "category": "validation",
            "status": "frozen",
            "path": "12_k4_handoff/c2_index_path_validation.csv",
            "note": "index path existence validation",
        }
    )
    for name in DOC_FILES:
        rows.append(
            {
                "category": "doc",
                "status": "frozen",
                "path": f"12_k4_handoff/{name}",
                "note": "handoff note or run manifest",
            }
        )
    index_path = HANDOFF_DIR / index_name
    pd.DataFrame(rows).to_csv(index_path, index=False, encoding="utf-8-sig")
    return index_path


def patch_manifest() -> None:
    manifest_path = HANDOFF_DIR / "c2_k4_handoff_run_manifest.json"
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    data["status"] = "c2_v1_0_frozen"
    data["high_risk_term"] = "detection-decision risk only, not clinical pathological risk"
    data["freeze_confirmation"] = (
        "modeler confirmed K4 main grouping; K3/K5 robustness only; "
        "highest BMI group undecided within 11-25 weeks; no unified recommendation"
    )
    manifest_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_delivery_zip() -> Path:
    package = C2_DIR / "C2-v1.0\u6b63\u5f0f\u51bb\u7ed3\u4ea4\u4ed8\u5305.zip"
    index_path = HANDOFF_DIR / "C2_K4\u4ea4\u4ed8\u6587\u4ef6\u7d22\u5f15.csv"
    index_df = pd.read_csv(index_path)
    members = [
        (C2_DIR / "README_C2\u770b\u8fd9\u91cc.md", "README_C2\u770b\u8fd9\u91cc.md"),
        (C2_DIR / "C2\u76ee\u5f55\u6e05\u7406\u4e0e\u4ea4\u4ed8\u8bf4\u660e.md", "C2\u76ee\u5f55\u6e05\u7406\u4e0e\u4ea4\u4ed8\u8bf4\u660e.md"),
        (index_path, "12_k4_handoff/C2_K4\u4ea4\u4ed8\u6587\u4ef6\u7d22\u5f15.csv"),
    ]
    for raw_path in index_df["path"].astype(str):
        rel = raw_path.replace("\\", "/")
        members.append((C2_DIR / rel, rel))
    with zipfile.ZipFile(package, "w", zipfile.ZIP_DEFLATED) as zf:
        for source, arcname in members:
            if not source.exists():
                raise FileNotFoundError(f"Cannot package missing member: {arcname}")
            zf.write(source, arcname=arcname)
    return package


def validate_index_paths(index_path: Path) -> Path:
    df = pd.read_csv(index_path)
    rows = []
    for _, row in df.iterrows():
        raw_path = str(row["path"])
        if raw_path.startswith("12_k4_handoff/"):
            target = C2_DIR / raw_path
        elif raw_path.startswith("06_code/"):
            target = C2_DIR / raw_path
        else:
            target = C2_DIR / raw_path
        exists = target.exists() or raw_path == "12_k4_handoff/c2_index_path_validation.csv"
        rows.append(
            {
                "path": raw_path,
                "exists": exists,
                "resolved_path": str(target),
                "category": row.get("category", ""),
                "status": row.get("status", ""),
            }
        )
    out = HANDOFF_DIR / "c2_index_path_validation.csv"
    result = pd.DataFrame(rows)
    result.to_csv(out, index=False, encoding="utf-8-sig")
    if not bool(result["exists"].all()):
        bad = result.loc[~result["exists"], "path"].tolist()
        raise FileNotFoundError("Index contains missing paths: " + ", ".join(bad[:10]))
    return out


def validate_zip_members(package: Path, index_path: Path) -> Path:
    df = pd.read_csv(index_path)
    with zipfile.ZipFile(package) as zf:
        members = set(zf.namelist())
    allowed = set(df["path"].astype(str).str.replace("\\", "/", regex=False))
    allowed.update(
        {
            "README_C2\u770b\u8fd9\u91cc.md",
            "C2\u76ee\u5f55\u6e05\u7406\u4e0e\u4ea4\u4ed8\u8bf4\u660e.md",
            "12_k4_handoff/C2_K4\u4ea4\u4ed8\u6587\u4ef6\u7d22\u5f15.csv",
        }
    )
    rows = []
    for _, row in df.iterrows():
        raw_path = str(row["path"]).replace("\\", "/")
        rows.append(
            {
                "path": raw_path,
                "exists_in_zip": raw_path in members,
                "unexpected_in_zip": False,
                "category": row.get("category", ""),
                "status": row.get("status", ""),
            }
        )
    for extra in sorted(members - allowed):
        rows.append(
            {
                "path": extra,
                "exists_in_zip": True,
                "unexpected_in_zip": True,
                "category": "unexpected",
                "status": "unexpected",
            }
        )
    out = HANDOFF_DIR / "c2_zip_member_validation.csv"
    result = pd.DataFrame(rows)
    result.to_csv(out, index=False, encoding="utf-8-sig")
    missing = sorted(allowed - members)
    unexpected = sorted(members - allowed)
    if missing:
        bad = missing[:10]
        raise FileNotFoundError("Zip package missing indexed members: " + ", ".join(bad[:10]))
    if unexpected:
        bad = unexpected[:10]
        raise RuntimeError("Zip package contains unexpected members: " + ", ".join(bad[:10]))
    return out


def main() -> None:
    patch_manifest()
    write_c1_dependency_hashes()
    copy_round3_evidence()
    write_dependency_versions()
    code_hashes = copy_code()
    archive = write_code_zip()
    index_path = write_index(code_hashes, archive)
    package = write_delivery_zip()
    validation = validate_index_paths(index_path)
    package = write_delivery_zip()
    zip_validation = validate_zip_members(package, index_path)
    print(f"code_files={len(code_hashes)}")
    print(f"index={index_path}")
    print(f"index_validation={validation}")
    print(f"zip_validation={zip_validation}")
    print(f"code_zip={archive}")
    print(f"delivery_zip={package}")


if __name__ == "__main__":
    main()
