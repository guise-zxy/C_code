from __future__ import annotations

import json
import math
import platform
import time
from pathlib import Path

import numpy as np
import pandas as pd

import q2_analysis as q2


K4_CUTS = [29.5, 31.5, 34.5]
K4_DISPLAY_BOUNDS = [20.5, 29.5, 31.5, 34.5, 47.5]
K5_SENSITIVITY_LABEL = "sensitivity_K5_data_driven"


def risk_for_groups(groups: pd.DataFrame, probs: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    info = groups[["group_id", "bmi_interval", "mother_count", "event_count", "reached_mother_count"]].copy()
    risk = probs.merge(info, on="group_id", how="left")
    risk["fail_risk"] = 1.0 - pd.to_numeric(risk["p_obs"], errors="coerce")
    risk["time_risk"] = pd.to_numeric(risk["week"], errors="coerce").map(q2.time_risk)
    risk["w_fail"] = q2.RISK_W_FAIL
    risk["w_time"] = q2.RISK_W_TIME_MAIN
    risk["total_risk"] = risk["w_fail"] * risk["fail_risk"] + risk["w_time"] * risk["time_risk"]
    risk["reliability_constraint_passed"] = pd.to_numeric(risk["lcb95"], errors="coerce") >= q2.Q_MAIN
    risk = risk[
        [
            "group_id",
            "bmi_interval",
            "mother_count",
            "event_count",
            "reached_mother_count",
            "week",
            "p_obs",
            "lcb95",
            "ucb95",
            "fail_risk",
            "time_risk",
            "w_fail",
            "w_time",
            "total_risk",
            "reliability_constraint_passed",
        ]
    ]

    rows = []
    for gid, sub in risk.groupby("group_id"):
        sub = sub.sort_values("week").copy()
        feasible = sub[sub["reliability_constraint_passed"]].copy()
        if feasible.empty:
            best = sub.loc[sub["week"].idxmax()]
            rows.append(
                {
                    "group_id": int(gid),
                    "bmi_interval": best["bmi_interval"],
                    "mother_count": int(best["mother_count"]),
                    "event_count": int(best["event_count"]),
                    "reached_mother_count": int(best["reached_mother_count"]),
                    "status": "undecided_high_risk",
                    "recommended_week": "",
                    "recommended_week_cn": "未决/高风险组",
                    "p_obs_at_recommend": float(best["p_obs"]),
                    "lcb95_at_recommend": float(best["lcb95"]),
                    "fail_risk": float(best["fail_risk"]),
                    "time_risk": float(best["time_risk"]),
                    "total_risk": float(best["total_risk"]),
                    "risk_min_at_search_boundary": bool(best["week"] in [q2.WEEK_GRID[0], q2.WEEK_GRID[-1]]),
                }
            )
            continue
        min_risk = float(feasible["total_risk"].min())
        best = feasible[feasible["total_risk"] <= min_risk + q2.RISK_TIE_TOL].sort_values("week").iloc[0]
        rows.append(
            {
                "group_id": int(gid),
                "bmi_interval": best["bmi_interval"],
                "mother_count": int(best["mother_count"]),
                "event_count": int(best["event_count"]),
                "reached_mother_count": int(best["reached_mother_count"]),
                "status": "ok",
                "recommended_week": float(best["week"]),
                "recommended_week_cn": q2.week_to_cn(float(best["week"])),
                "p_obs_at_recommend": float(best["p_obs"]),
                "lcb95_at_recommend": float(best["lcb95"]),
                "fail_risk": float(best["fail_risk"]),
                "time_risk": float(best["time_risk"]),
                "total_risk": float(best["total_risk"]),
                "risk_min_at_search_boundary": bool(best["week"] in [q2.WEEK_GRID[0], q2.WEEK_GRID[-1]]),
            }
        )
    return risk, pd.DataFrame(rows)


def diagnostics(groups: pd.DataFrame, rec: pd.DataFrame, k4_summary: dict, k5_summary: dict, k5_groups: pd.DataFrame) -> pd.DataFrame:
    rows = []
    weeks = pd.to_numeric(rec.loc[rec["status"].eq("ok"), "recommended_week"], errors="coerce").to_numpy(float)
    monotone = bool(np.all(np.diff(weeks) >= -1e-12)) if len(weeks) > 1 else True
    boundary = int(rec["risk_min_at_search_boundary"].astype(bool).sum())
    undecided = int((rec["status"] != "ok").sum())
    reliable_same = True
    merged = groups[["group_id", "recommended_week"]].merge(
        rec[["group_id", "recommended_week"]], on="group_id", suffixes=("_reliable", "_risk")
    )
    reliable_same = bool(
        np.allclose(
            pd.to_numeric(merged["recommended_week_reliable"], errors="coerce"),
            pd.to_numeric(merged["recommended_week_risk"], errors="coerce"),
        )
    )
    rows.extend(
        [
            {"check": "K4_group_count", "passed": len(groups) == 4, "value": len(groups), "note": "固定K=4"},
            {"check": "group_count_constraints", "passed": bool(groups["count_constraint_passed"].all()), "value": ";".join(str(int(x)) for x in groups["mother_count"]), "note": "每组孕妇数满足约束"},
            {"check": "recommended_week_monotone_non_decreasing_by_bmi", "passed": monotone, "value": ";".join(str(x) for x in weeks), "note": "推荐时点随BMI升高不提前"},
            {"check": "risk_min_at_25_week_boundary_count", "passed": boundary == 0, "value": boundary, "note": "风险最小点不应落在25周边界"},
            {"check": "undecided_or_high_risk_group_count", "passed": undecided == 0, "value": undecided, "note": "是否存在25周内无法满足LCB95>=0.90的组"},
            {"check": "risk_timing_same_as_reliable_timing", "passed": reliable_same, "value": reliable_same, "note": "风险函数结果是否与可靠时点一致"},
            {"check": "K4_vs_K5_mean_regret_delta", "passed": True, "value": float(k4_summary["mean_regret"] - k5_summary["mean_regret"]), "note": "K4相对K5平均延迟遗憾增加量"},
            {"check": "K4_vs_K5_p90_regret_delta", "passed": True, "value": float(k4_summary["p90_regret"] - k5_summary["p90_regret"]), "note": "K4相对K5的90%分位延迟遗憾变化"},
            {"check": "K4_vs_K5_worst_lcb_delta", "passed": True, "value": float(k4_summary["worst_lcb95"] - k5_summary["worst_lcb95"]), "note": "K4相对K5最差LCB变化"},
            {"check": "K4_sample_balance_min_mothers", "passed": int(groups["mother_count"].min()) >= q2.MIN_MOTHERS, "value": int(groups["mother_count"].min()), "note": "K4最小组孕妇数"},
            {"check": "K5_sensitivity_preserved", "passed": not k5_groups.empty, "value": K5_SENSITIVITY_LABEL, "note": "K5原结果保留为敏感性分析"},
        ]
    )
    return pd.DataFrame(rows)


def apply_k4_display_intervals(groups: pd.DataFrame, probs: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    labels = {
        gid: q2.group_label((K4_DISPLAY_BOUNDS[gid - 1], K4_DISPLAY_BOUNDS[gid]), gid == len(K4_DISPLAY_BOUNDS) - 1)
        for gid in range(1, len(K4_DISPLAY_BOUNDS))
    }
    groups = groups.copy()
    probs = probs.copy()
    groups["bmi_interval"] = groups["group_id"].map(labels)
    return groups, probs


def main() -> None:
    started = time.time()
    out = q2.OUT_DIR
    out.mkdir(parents=True, exist_ok=True)
    q2.setup_style()

    events, mothers = q2.load_q2_data()
    fit, week_mean, bmi_mean = q2.fit_q2_lmm(events)
    tech_path = out / "q2_technical_error.csv"
    if tech_path.exists():
        sigma_m = float(pd.read_csv(tech_path, encoding="utf-8-sig")["sigma_m_estimate"].iloc[0])
    else:
        sigma_m = 0.0

    group_rows, prob_rows, k4_summary = q2.evaluate_partition(
        "main_K4",
        K4_CUTS,
        mothers,
        events,
        fit,
        week_mean,
        bmi_mean,
        sigma_m,
        q2.Q_MAIN,
    )
    groups = pd.DataFrame(group_rows)
    probs = pd.DataFrame(prob_rows)
    groups, probs = apply_k4_display_intervals(groups, probs)
    risk, rec = risk_for_groups(groups, probs)

    candidates = pd.read_csv(out / "q2_group_candidates.csv", encoding="utf-8-sig")
    k5_summary = candidates[candidates["strategy"].eq("optimized_K5")].iloc[0].to_dict()
    k4_candidate_summary = candidates[candidates["strategy"].eq("optimized_K4")].iloc[0].to_dict()
    k5_groups = pd.read_csv(out / "q2_optimal_groups.csv", encoding="utf-8-sig").copy()
    k5_groups["strategy"] = K5_SENSITIVITY_LABEL
    k5_groups.to_csv(out / "c2_sensitivity_K5_data_driven_groups.csv", index=False, encoding="utf-8-sig")

    diag = diagnostics(groups, rec, k4_summary, k5_summary, k5_groups)

    compare_rows = [
        {
            "strategy": "main_K4",
            "role": "main_text",
            "K": 4,
            "cutpoints": ";".join(f"{x:.1f}" for x in K4_CUTS),
            "mean_regret": k4_summary["mean_regret"],
            "p90_regret": k4_summary["p90_regret"],
            "worst_lcb95": k4_summary["worst_lcb95"],
            "mother_count_by_group": ";".join(str(int(x)) for x in groups["mother_count"]),
            "recommended_week_by_group": ";".join(str(x) for x in rec["recommended_week"]),
        },
        {
            "strategy": K5_SENSITIVITY_LABEL,
            "role": "sensitivity",
            "K": 5,
            "cutpoints": k5_summary["cutpoints"],
            "mean_regret": k5_summary["mean_regret"],
            "p90_regret": k5_summary["p90_regret"],
            "worst_lcb95": k5_summary["worst_lcb95"],
            "mother_count_by_group": ";".join(str(int(x)) for x in k5_groups["mother_count"]),
            "recommended_week_by_group": ";".join(str(x) for x in k5_groups["recommended_week"]),
        },
    ]
    compare = pd.DataFrame(compare_rows)

    groups.to_csv(out / "c2_main_K4_groups.csv", index=False, encoding="utf-8-sig")
    probs.to_csv(out / "c2_main_K4_reach_probability_by_group_week.csv", index=False, encoding="utf-8-sig")
    risk.to_csv(out / "c2_main_K4_risk_by_group_week.csv", index=False, encoding="utf-8-sig")
    rec.to_csv(out / "c2_main_K4_recommended_timing.csv", index=False, encoding="utf-8-sig")
    diag.to_csv(out / "c2_main_K4_diagnostics.csv", index=False, encoding="utf-8-sig")
    compare.to_csv(out / "c2_K4_vs_K5_comparison.csv", index=False, encoding="utf-8-sig")

    manifest = {
        "task": "C2 K4 main-text finalization draft",
        "status": "draft_waiting_modeler_review",
        "input": str(q2.INPUT),
        "n_events": int(len(events)),
        "n_mothers": int(events["mother_id"].nunique()),
        "main_strategy": "main_K4",
        "main_cutpoints": K4_CUTS,
        "sensitivity_strategy": K5_SENSITIVITY_LABEL,
        "risk_function": "R(g,t)=1-p_g(t)+L(t), L(t)=0 if t<=12 else (t-12)/13",
        "q_main": q2.Q_MAIN,
        "outputs": [
            "c2_main_K4_groups.csv",
            "c2_main_K4_reach_probability_by_group_week.csv",
            "c2_main_K4_risk_by_group_week.csv",
            "c2_main_K4_recommended_timing.csv",
            "c2_main_K4_diagnostics.csv",
            "c2_K4_vs_K5_comparison.csv",
            "c2_sensitivity_K5_data_driven_groups.csv",
        ],
        "runtime_seconds": round(time.time() - started, 3),
        "python": platform.python_version(),
    }
    (out / "c2_K4_main_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
