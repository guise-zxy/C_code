from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import logit
from sklearn.model_selection import GroupKFold

import q2_analysis as q2


ROOT = Path(__file__).resolve().parents[1]
C2_DIR = ROOT / "results" / "C2-v1.0"
REPAIR_DIR = C2_DIR / "09_repair_draft"
CODE_DIR = C2_DIR / "06_code"
DOC_DIR = C2_DIR / "00_docs"
K4_CUTS = [29.5, 31.5, 34.5]
WEEK_GRID = q2.WEEK_GRID
Q_MAIN = q2.Q_MAIN
EPS = 1e-6


def file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def week_cn(week: float | str) -> str:
    return q2.week_to_cn(week)


def load_sigma_m() -> float:
    tech_path = C2_DIR / "03_validation" / "q2_technical_error.csv"
    if tech_path.exists():
        return float(pd.read_csv(tech_path, encoding="utf-8-sig")["sigma_m_estimate"].iloc[0])
    tech = q2.estimate_technical_error(200, np.random.default_rng(q2.SEED))
    return float(tech["sigma_m_estimate"].iloc[0])


def k4_labels(mothers: pd.DataFrame) -> tuple[pd.DataFrame, list[tuple[float, float]]]:
    out = mothers.copy()
    out["group"] = q2.assign_groups(out["baseline_bmi"], K4_CUTS)
    lo = math.floor(float(out["baseline_bmi"].min()) * 2) / 2
    hi = math.ceil(float(out["baseline_bmi"].max()) * 2) / 2 + 0.5
    edges = [lo] + K4_CUTS + [hi]
    bounds = [(edges[i], edges[i + 1]) for i in range(len(edges) - 1)]
    return out, bounds


def group_probability_grid(
    fit,
    week_mean: float,
    bmi_mean: float,
    grouped_mothers: pd.DataFrame,
    bounds: list[tuple[float, float]],
    sigma_m: float,
    kappa: float = 1.0,
) -> pd.DataFrame:
    rows = []
    for gid in sorted(grouped_mothers["group"].unique()):
        gm = grouped_mothers[grouped_mothers["group"].eq(gid)]
        bmis = gm["baseline_bmi"].to_numpy(float)
        last = int(gid) == len(bounds) - 1
        label = q2.group_label(bounds[int(gid)], last)
        for week in WEEK_GRID:
            probs = q2.predict_obs_prob(
                fit,
                week_mean,
                bmi_mean,
                np.full(len(bmis), week),
                bmis,
                kappa=kappa,
                sigma_m=sigma_m,
            )
            mean_p, cond_lcb, cond_ucb = q2.group_lcb(probs)
            rows.append(
                {
                    "group_id": int(gid) + 1,
                    "bmi_interval": label,
                    "week": float(week),
                    "p_group_mean": float(mean_p),
                    "conditional_bmi_composition_lcb95": float(cond_lcb),
                    "conditional_bmi_composition_ucb95": float(cond_ucb),
                    "individual_p_min": float(np.min(probs)),
                    "individual_p_q10": float(np.percentile(probs, 10)),
                    "individual_p_median": float(np.median(probs)),
                    "individual_share_ge_0p90": float(np.mean(probs >= Q_MAIN)),
                    "mother_count": int(len(gm)),
                }
            )
    return pd.DataFrame(rows)


def recommend_from_grid(prob_grid: pd.DataFrame, lcb_col: str) -> pd.DataFrame:
    rows = []
    for gid, sub in prob_grid.groupby("group_id", sort=True):
        sub = sub.sort_values("week")
        feasible = sub[pd.to_numeric(sub[lcb_col], errors="coerce") >= Q_MAIN]
        if feasible.empty:
            ref = sub.iloc[-1]
            rows.append(
                {
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "status": "undecided_high_risk",
                    "recommended_week": "",
                    "recommended_week_cn": "未决/高风险组",
                    "p_group_mean": float(ref["p_group_mean"]),
                    lcb_col: float(ref[lcb_col]),
                    "at_25_week_boundary": True,
                }
            )
        else:
            ref = feasible.iloc[0]
            rows.append(
                {
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "status": "ok",
                    "recommended_week": float(ref["week"]),
                    "recommended_week_cn": week_cn(float(ref["week"])),
                    "p_group_mean": float(ref["p_group_mean"]),
                    lcb_col: float(ref[lcb_col]),
                    "at_25_week_boundary": bool(np.isclose(float(ref["week"]), WEEK_GRID[-1])),
                }
            )
    return pd.DataFrame(rows)


def resample_mothers(events: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    base = events.reset_index(drop=True)
    mothers = base["mother_id"].drop_duplicates().to_numpy()
    index_map = {m: idx.to_numpy() for m, idx in base.groupby("mother_id").groups.items()}
    pieces = []
    chosen = rng.choice(mothers, size=len(mothers), replace=True)
    for draw_no, mid in enumerate(chosen, 1):
        part = base.iloc[index_map[mid]].copy()
        part["mother_id"] = f"{mid}__boot{draw_no}"
        pieces.append(part)
    return pd.concat(pieces, ignore_index=True)


def bootstrap_k4_probability_lcb(
    events: pd.DataFrame,
    grouped_mothers: pd.DataFrame,
    bounds: list[tuple[float, float]],
    sigma_m: float,
    n_boot: int,
    rng: np.random.Generator,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    boot_rows = []
    timing_rows = []
    status_rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 50 == 0:
            print(f"C2 K4 fixed bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            fit, wm, bm = q2.fit_q2_lmm(sample)
            grid = group_probability_grid(fit, wm, bm, grouped_mothers, bounds, sigma_m, kappa=1.0)
            for _, row in grid.iterrows():
                boot_rows.append(
                    {
                        "bootstrap_id": b,
                        "group_id": int(row["group_id"]),
                        "week": float(row["week"]),
                        "p_group_mean": float(row["p_group_mean"]),
                    }
                )
            rec = recommend_from_grid(grid, "p_group_mean")
            for _, row in rec.iterrows():
                timing_rows.append(
                    {
                        "bootstrap_id": b,
                        "group_id": int(row["group_id"]),
                        "status": row["status"],
                        "recommended_week": row["recommended_week"],
                        "at_25_week_boundary": row["at_25_week_boundary"],
                    }
                )
            status_rows.append({"bootstrap_id": b, "status": "ok", "converged": bool(fit.converged)})
        except Exception as exc:
            status_rows.append({"bootstrap_id": b, "status": f"failed: {exc}", "converged": False})
    return pd.DataFrame(boot_rows), pd.DataFrame(timing_rows), pd.DataFrame(status_rows)


def summarize_bootstrap_lcb(point_grid: pd.DataFrame, boot_prob: pd.DataFrame) -> pd.DataFrame:
    if boot_prob.empty:
        out = point_grid.copy()
        out["bootstrap_lcb95"] = np.nan
        out["bootstrap_ucb95"] = np.nan
        out["bootstrap_ok_count"] = 0
        return out
    quant = (
        boot_prob.groupby(["group_id", "week"])["p_group_mean"]
        .agg(
            bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)),
            bootstrap_median=lambda s: float(np.percentile(s, 50)),
            bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)),
            bootstrap_ok_count="count",
        )
        .reset_index()
    )
    return point_grid.merge(quant, on=["group_id", "week"], how="left")


def summarize_fixed_k4_timing(timing: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    rows = []
    total = int(status["bootstrap_id"].nunique()) if not status.empty else 0
    for gid in sorted(timing["group_id"].dropna().astype(int).unique()):
        sub = timing[timing["group_id"].astype(int).eq(gid)]
        vals = pd.to_numeric(sub["recommended_week"], errors="coerce").dropna().to_numpy(float)
        rows.append(
            {
                "group_id": int(gid),
                "bootstrap_total": total,
                "valid_recommend_count": int(len(vals)),
                "no_feasible_ratio": float(1 - len(vals) / total) if total else np.nan,
                "recommended_week_median": float(np.percentile(vals, 50)) if len(vals) else np.nan,
                "recommended_week_ci_low_2p5": float(np.percentile(vals, 2.5)) if len(vals) else np.nan,
                "recommended_week_ci_high_97p5": float(np.percentile(vals, 97.5)) if len(vals) else np.nan,
                "boundary_25_ratio": float(np.mean(np.isclose(vals, WEEK_GRID[-1]))) if len(vals) else np.nan,
            }
        )
    return pd.DataFrame(rows)


def event_level_groupkfold_cv(events: pd.DataFrame, sigma_m: float, n_splits: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    splitter = GroupKFold(n_splits=n_splits)
    groups = events["mother_id"].to_numpy()
    pred_rows = []
    metric_rows = []
    for fold, (tr, va) in enumerate(splitter.split(events, groups=groups), 1):
        train = events.iloc[tr].copy()
        valid = events.iloc[va].copy()
        try:
            fit, wm, bm = q2.fit_q2_lmm(train)
            train_mothers = q2.build_mother_table(train)
            valid_mothers = q2.build_mother_table(valid)[["mother_id", "baseline_bmi"]]
            valid = valid.drop(columns=["baseline_bmi"], errors="ignore").merge(valid_mothers, on="mother_id", how="left")
            p = q2.predict_obs_prob(
                fit,
                wm,
                bm,
                valid["week_num"].to_numpy(float),
                valid["baseline_bmi"].to_numpy(float),
                kappa=1.0,
                sigma_m=sigma_m,
            )
            y = valid["y_ge_4pct"].astype(int).to_numpy()
            p_clip = np.clip(p, EPS, 1 - EPS)
            brier = float(np.mean((p - y) ** 2))
            log_loss = float(-np.mean(y * np.log(p_clip) + (1 - y) * np.log(1 - p_clip)))
            metric_rows.append(
                {
                    "fold": fold,
                    "status": "ok",
                    "train_mothers": int(train["mother_id"].nunique()),
                    "valid_mothers": int(valid["mother_id"].nunique()),
                    "valid_events": int(len(valid)),
                    "brier_score_event_actual_week": brier,
                    "log_loss_event_actual_week": log_loss,
                    "train_mothers_for_model": int(len(train_mothers)),
                    "converged": bool(fit.converged),
                }
            )
            for local_i, (_, row) in enumerate(valid.iterrows()):
                pred_rows.append(
                    {
                        "fold": fold,
                        "event_id": row["event_id"],
                        "mother_id": row["mother_id"],
                        "actual_week": float(row["week_num"]),
                        "baseline_bmi": float(row["baseline_bmi"]),
                        "observed_y_ge_4pct": int(row["y_ge_4pct"]),
                        "predicted_probability": float(p[local_i]),
                    }
                )
        except Exception as exc:
            metric_rows.append({"fold": fold, "status": f"failed: {exc}"})
    pred = pd.DataFrame(pred_rows)
    metrics = pd.DataFrame(metric_rows)
    cal = calibration_summary(pred)
    return pred, metrics, cal


def calibration_summary(pred: pd.DataFrame) -> pd.DataFrame:
    if pred.empty:
        return pd.DataFrame()
    p = np.clip(pd.to_numeric(pred["predicted_probability"], errors="coerce").to_numpy(float), EPS, 1 - EPS)
    y = pd.to_numeric(pred["observed_y_ge_4pct"], errors="coerce").to_numpy(float)
    rows = []
    # Logistic calibration: observed label ~ intercept + slope * logit(pred)
    try:
        from scipy.optimize import minimize

        x = logit(p)

        def nll(par: np.ndarray) -> float:
            eta = par[0] + par[1] * x
            phat = 1 / (1 + np.exp(-eta))
            phat = np.clip(phat, EPS, 1 - EPS)
            return float(-np.sum(y * np.log(phat) + (1 - y) * np.log(1 - phat)))

        opt = minimize(nll, np.array([0.0, 1.0]), method="Nelder-Mead")
        rows.append({"type": "calibration_model", "bin": "all", "n": len(y), "pred_mean": float(np.mean(p)), "obs_rate": float(np.mean(y)), "calibration_intercept": float(opt.x[0]), "calibration_slope": float(opt.x[1]), "converged": bool(opt.success)})
    except Exception as exc:
        rows.append({"type": "calibration_model", "bin": "all", "n": len(y), "pred_mean": float(np.mean(p)), "obs_rate": float(np.mean(y)), "calibration_intercept": np.nan, "calibration_slope": np.nan, "note": str(exc)})
    bins = pd.qcut(p, q=5, duplicates="drop")
    tmp = pd.DataFrame({"p": p, "y": y, "bin": bins.astype(str)})
    for name, sub in tmp.groupby("bin", sort=False):
        rows.append({"type": "calibration_bin", "bin": name, "n": int(len(sub)), "pred_mean": float(sub["p"].mean()), "obs_rate": float(sub["y"].mean())})
    return pd.DataFrame(rows)


def evaluate_k4_error_sensitivity(grouped_mothers: pd.DataFrame, bounds: list[tuple[float, float]], fit, wm, bm, sigma_m: float) -> pd.DataFrame:
    rows = []
    for kappa in q2.KAPPA_GRID:
        grid = group_probability_grid(fit, wm, bm, grouped_mothers, bounds, sigma_m, kappa=kappa)
        rec = recommend_from_grid(grid, "conditional_bmi_composition_lcb95")
        for _, row in rec.iterrows():
            rows.append(
                {
                    "scenario": "fixed_K4_conditional_lcb",
                    "kappa": float(kappa),
                    "group_id": int(row["group_id"]),
                    "bmi_interval": row["bmi_interval"],
                    "status": row["status"],
                    "recommended_week": row["recommended_week"],
                    "p_group_mean": row["p_group_mean"],
                    "conditional_bmi_composition_lcb95": row["conditional_bmi_composition_lcb95"],
                    "formula": "sigma_total^2=sigma_u^2+max(sigma_e^2-sigma_m^2,0)+kappa^2*sigma_m^2",
                }
            )
    out = pd.DataFrame(rows)
    base = out[out["kappa"].eq(1.0)][["group_id", "recommended_week", "p_group_mean"]].rename(columns={"recommended_week": "base_week", "p_group_mean": "base_p"})
    out = out.merge(base, on="group_id", how="left")
    out["recommended_week_changed_vs_kappa1"] = out["recommended_week"].astype(str) != out["base_week"].astype(str)
    out["probability_changed_vs_kappa1"] = (pd.to_numeric(out["p_group_mean"], errors="coerce") - pd.to_numeric(out["base_p"], errors="coerce")).abs() > 1e-10
    return out


def regret_denominator(grouped_mothers: pd.DataFrame, fit, wm, bm, sigma_m: float, rec_boot: pd.DataFrame) -> pd.DataFrame:
    indiv = q2.individual_reliable_weeks(fit, wm, bm, grouped_mothers["baseline_bmi"].to_numpy(float), sigma_m, Q_MAIN)
    rec_map = {
        int(row["group_id"]) - 1: float(row["recommended_week"])
        for _, row in rec_boot.iterrows()
        if str(row["status"]) == "ok" and row["recommended_week"] != ""
    }
    assigned = np.asarray([rec_map.get(int(g), np.nan) for g in grouped_mothers["group"]])
    evaluable = np.isfinite(indiv) & np.isfinite(assigned)
    regret = np.maximum(assigned[evaluable] - indiv[evaluable], 0)
    n_total = len(grouped_mothers)
    n_eval = int(np.sum(evaluable))
    penalty_value = 2.0
    penalty_values = np.full(n_total, penalty_value, dtype=float)
    penalty_values[evaluable] = np.maximum(assigned[evaluable] - indiv[evaluable], 0)
    return pd.DataFrame(
        [
            {
                "strategy": "fixed_K4_bootstrap_group_mean_lcb",
                "n_total": n_total,
                "n_evaluable": n_eval,
                "coverage": float(n_eval / n_total),
                "undecided_mother_count": int(n_total - n_eval),
                "mean_regret_evaluable_only": float(np.mean(regret)) if len(regret) else np.nan,
                "p90_regret_evaluable_only": float(np.percentile(regret, 90)) if len(regret) else np.nan,
                "penalty_rule": "未纳入evaluable的孕妇统一记2周遗憾惩罚，仅供建模手决定是否采用",
                "mean_regret_with_penalty": float(np.mean(penalty_values)) if len(penalty_values) else np.nan,
                "p90_regret_with_penalty": float(np.percentile(penalty_values, 90)) if len(penalty_values) else np.nan,
            }
        ]
    )


def write_code_bundle() -> pd.DataFrame:
    CODE_DIR.mkdir(parents=True, exist_ok=True)
    code_files = ["q2_analysis.py", "c2_finalize_k4.py", "c2_make_official_figures.py", "c2_repair_draft.py"]
    rows = []
    for name in code_files:
        src = ROOT / "code" / name
        dst = CODE_DIR / name
        shutil.copy2(src, dst)
        rows.append({"file": str(dst.relative_to(C2_DIR)), "source_path": str(src), "sha256": file_sha256(dst), "role": "code"})
    return pd.DataFrame(rows)


def write_status_docs(index_rows: list[dict], manifest: dict) -> None:
    DOC_DIR.mkdir(parents=True, exist_ok=True)
    repair_note = REPAIR_DIR / "C2返修草案交付说明.md"
    repair_note.write_text(
        "\n".join(
            [
                "# C2返修草案交付说明",
                "",
                "状态：待返修草案。C2-v1.0原冻结结论已撤回，暂不交论文手写正文；C1结果保持不变。",
                "",
                "本轮只完成建模审核指出的工程与验证返修：代码随包交付、输入哈希记录、bootstrap概率下界、固定K4 bootstrap、事件实际孕周GroupKFold验证、检测误差敏感性修复、遗憾值分母核查。",
                "",
                "可靠性口径待建模手选择：",
                "- 组平均可靠：使用孕妇簇bootstrap下组平均达标概率的2.5%分位作为正式LCB。",
                "- 组内覆盖可靠：需使用组内个体预测概率的最小值、10%分位数、中位数和达标比例作为约束或解释指标。",
                "",
                "风险函数口径待建模手二选一：",
                "- A：保留LCB>=0.90硬约束，正文称为可靠性约束下的最早可行时点，风险函数只作辅助。",
                "- B：显式风险函数折中，需给出权重来源，并接受权重敏感性导致时点变化。",
                "",
                "模型命名：C2使用首次检测BMI作为固定个体BMI并重新拟合，应称为C2专用随机截距加性LMM，不与C1事件级BMI主模型混写。",
                "",
                "运行命令：",
                f"`{manifest['run_command']}`",
            ]
        ),
        encoding="utf-8",
    )
    index_rows.append({"category": "doc", "status": "draft_repair", "path": str(repair_note.relative_to(C2_DIR)), "note": "本轮返修交付说明"})

    pd.DataFrame(index_rows).to_csv(REPAIR_DIR / "C2返修文件索引.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=200)
    parser.add_argument("--cv-splits", type=int, default=5)
    parser.add_argument("--seed", type=int, default=q2.SEED)
    args = parser.parse_args()
    start = time.time()
    REPAIR_DIR.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(args.seed)
    events, mothers = q2.load_q2_data()
    sigma_m = load_sigma_m()
    fit, wm, bm = q2.fit_q2_lmm(events)
    grouped_mothers, bounds = k4_labels(mothers)

    point_grid = group_probability_grid(fit, wm, bm, grouped_mothers, bounds, sigma_m, kappa=1.0)
    boot_prob, boot_timing, boot_status = bootstrap_k4_probability_lcb(events, grouped_mothers, bounds, sigma_m, args.bootstrap, rng)
    prob_boot_lcb = summarize_bootstrap_lcb(point_grid, boot_prob)
    rec_boot_lcb = recommend_from_grid(prob_boot_lcb, "bootstrap_lcb95")
    timing_summary = summarize_fixed_k4_timing(boot_timing, boot_status)
    cv_pred, cv_metrics, cv_cal = event_level_groupkfold_cv(events, sigma_m, args.cv_splits)
    err = evaluate_k4_error_sensitivity(grouped_mothers, bounds, fit, wm, bm, sigma_m)
    regret = regret_denominator(grouped_mothers, fit, wm, bm, sigma_m, rec_boot_lcb)

    outputs = {
        "c2_k4_probability_bootstrap_lcb_by_group_week.csv": prob_boot_lcb,
        "c2_k4_recommended_timing_bootstrap_lcb.csv": rec_boot_lcb,
        "c2_k4_individual_probability_summary.csv": point_grid,
        "c2_k4_fixed_bootstrap_raw_probability.csv": boot_prob,
        "c2_k4_fixed_bootstrap_raw_timing.csv": boot_timing,
        "c2_k4_fixed_bootstrap_status.csv": boot_status,
        "c2_k4_fixed_bootstrap_timing_summary.csv": timing_summary,
        "c2_outer_groupkfold_event_predictions.csv": cv_pred,
        "c2_outer_groupkfold_event_metrics.csv": cv_metrics,
        "c2_outer_groupkfold_calibration.csv": cv_cal,
        "c2_error_sensitivity_fixed_kappa.csv": err,
        "c2_regret_denominator_check.csv": regret,
    }
    index_rows: list[dict] = []
    for name, df in outputs.items():
        path = REPAIR_DIR / name
        df.to_csv(path, index=False, encoding="utf-8-sig")
        index_rows.append({"category": "result", "status": "draft_repair", "path": str(path.relative_to(C2_DIR)), "note": f"rows={len(df)}"})

    code_index = write_code_bundle()
    code_index.to_csv(REPAIR_DIR / "c2_code_bundle_hashes.csv", index=False, encoding="utf-8-sig")
    for _, row in code_index.iterrows():
        index_rows.append({"category": "code", "status": "draft_repair", "path": row["file"], "note": f"sha256={row['sha256']}"})

    inputs = [
        q2.INPUT,
        q2.TECH_REP,
        C2_DIR / "01_main_results" / "c2_main_K4_groups.csv",
        C2_DIR / "01_main_results" / "c2_main_K4_recommended_timing.csv",
    ]
    input_rows = []
    for p in inputs:
        input_rows.append({"path": str(p), "exists": p.exists(), "sha256": file_sha256(p) if p.exists() else ""})
    input_hashes = pd.DataFrame(input_rows)
    input_hashes.to_csv(REPAIR_DIR / "c2_repair_input_hashes.csv", index=False, encoding="utf-8-sig")
    index_rows.append({"category": "hash", "status": "draft_repair", "path": "09_repair_draft/c2_repair_input_hashes.csv", "note": "输入文件哈希"})
    index_rows.append({"category": "hash", "status": "draft_repair", "path": "09_repair_draft/c2_code_bundle_hashes.csv", "note": "随包代码哈希"})

    manifest = {
        "status": "draft_repair_not_frozen",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "python": sys.version,
        "platform": platform.platform(),
        "run_command": f"python problem_c_nipt/code/c2_repair_draft.py --bootstrap {args.bootstrap} --cv-splits {args.cv_splits} --seed {args.seed}",
        "bootstrap_n": args.bootstrap,
        "cv_splits": args.cv_splits,
        "seed": args.seed,
        "k4_cutpoints": K4_CUTS,
        "sigma_m": sigma_m,
        "week_grid": [float(WEEK_GRID[0]), float(WEEK_GRID[-1]), 0.5],
        "elapsed_seconds": round(time.time() - start, 3),
        "model_name": "C2专用随机截距加性LMM",
        "reliability_lcb": "mother-cluster bootstrap 2.5% quantile of group mean probability",
    }
    (REPAIR_DIR / "c2_repair_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    index_rows.append({"category": "manifest", "status": "draft_repair", "path": "09_repair_draft/c2_repair_run_manifest.json", "note": "返修运行命令、版本与参数"})
    write_status_docs(index_rows, manifest)

    status_readme = C2_DIR / "README_C2看这里.md"
    status_readme.write_text(
        "# C2 当前状态\n\n"
        "状态：待返修草案，原 C2-v1.0 冻结结论已撤回。\n\n"
        "优先查看：`09_repair_draft/C2返修草案交付说明.md` 和 `09_repair_draft/C2返修文件索引.csv`。\n\n"
        "说明：C1 保持不变；C2 暂不交论文手写正文，待建模手确认可靠性对象和风险函数口径后再冻结。\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
