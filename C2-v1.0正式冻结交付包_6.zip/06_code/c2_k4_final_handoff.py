from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import q2_analysis as q2
from c2_repair_round2 import bootstrap_lcb_grid, group_grid, recommend, resample_mothers
from c2_repair_round3 import WEEK_GRID_25, K_CANDIDATE_CUTS


ROOT = Path(__file__).resolve().parents[1]
C2_DIR = ROOT / "results" / "C2-v1.0"
OUT_DIR = C2_DIR / "12_k4_handoff"
FIG_DIR = OUT_DIR / "figures"
FIG_DATA_DIR = OUT_DIR / "figure_data"
CODE_DIR = C2_DIR / "06_code"
INPUT_SNAPSHOT_DIR = OUT_DIR / "input_snapshots"
K4_CUTS = [29.5, 31.5, 34.5]
Q_MAIN = 0.90


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_input_csv(name: str, fallback: Path) -> pd.DataFrame:
    snapshot = INPUT_SNAPSHOT_DIR / name
    path = snapshot if snapshot.exists() else fallback
    return pd.read_csv(path, encoding="utf-8-sig")


def load_sigma_m() -> float:
    df = read_input_csv("q2_technical_error.csv", C2_DIR / "03_validation" / "q2_technical_error.csv")
    return float(df["sigma_m_estimate"].iloc[0])


def bootstrap_kappa_sensitivity(events: pd.DataFrame, sigma_m: float, n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    prob_rows = []
    timing_rows = []
    status_rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C2 K4 kappa bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            fit, wm, bm = q2.fit_q2_lmm(sample)
            if not bool(fit.converged):
                status_rows.append({"bootstrap_id": b, "status": "not_converged", "converged": False, "note": ""})
                continue
            sample_mothers = q2.build_mother_table(sample)
            for kappa in q2.KAPPA_GRID:
                grid = group_grid("lmm", fit, wm, bm, sample_mothers, K4_CUTS, sigma_m, WEEK_GRID_25, kappa=float(kappa))
                for _, row in grid.iterrows():
                    prob_rows.append(
                        {
                            "bootstrap_id": b,
                            "kappa": float(kappa),
                            "group_id": int(row["group_id"]),
                            "week": float(row["week"]),
                            "p_group_mean": float(row["p_group_mean"]),
                        }
                    )
                rec = recommend(grid, "p_group_mean")
                for _, row in rec.iterrows():
                    timing_rows.append(
                        {
                            "bootstrap_id": b,
                            "kappa": float(kappa),
                            "group_id": int(row["group_id"]),
                            "status": row["status"],
                            "recommended_week": row["recommended_week"],
                            "at_25_boundary": row["at_upper_week_boundary"],
                        }
                    )
            status_rows.append({"bootstrap_id": b, "status": "ok", "converged": True, "note": ""})
        except Exception as exc:
            status_rows.append({"bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})

    prob = pd.DataFrame(prob_rows)
    timing = pd.DataFrame(timing_rows)
    status = pd.DataFrame(status_rows)

    quant = (
        prob.groupby(["kappa", "group_id", "week"])["p_group_mean"]
        .agg(
            bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)),
            bootstrap_median=lambda s: float(np.percentile(s, 50)),
            bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)),
            bootstrap_ok_count="count",
        )
        .reset_index()
    )
    return prob, timing, status, quant


def recommend_kappa(quant: pd.DataFrame, events: pd.DataFrame, mothers: pd.DataFrame, sigma_m: float) -> pd.DataFrame:
    fit, wm, bm = q2.fit_q2_lmm(events)
    point_rows = []
    for kappa in q2.KAPPA_GRID:
        point = group_grid("lmm", fit, wm, bm, mothers, K4_CUTS, sigma_m, WEEK_GRID_25, kappa=float(kappa))
        point["kappa"] = float(kappa)
        point_rows.append(point)
    point_df = pd.concat(point_rows, ignore_index=True)
    merged = point_df.merge(quant, on=["kappa", "group_id", "week"], how="left")
    frames = []
    for kappa, sub in merged.groupby("kappa", sort=True):
        rec = recommend(sub, "bootstrap_lcb95")
        rec["kappa"] = float(kappa)
        frames.append(rec)
    out = pd.concat(frames, ignore_index=True)
    out["口径"] = "总体BMI构成+严格收敛bootstrap+组平均LCB95>=0.90"
    return out


def kappa_status_summary(status: pd.DataFrame, quant: pd.DataFrame) -> pd.DataFrame:
    attempts = int(status["bootstrap_id"].nunique())
    ok = int(status["status"].eq("ok").sum())
    rows = []
    for kappa in sorted(quant["kappa"].unique()):
        rows.append(
            {
                "kappa": float(kappa),
                "bootstrap_attempts": attempts,
                "strict_converged_iterations": ok,
                "not_converged_count": int(status["status"].eq("not_converged").sum()),
                "failed_count": int(status["status"].eq("failed").sum()),
                "bootstrap_ok_count_min": int(quant[quant["kappa"].eq(kappa)]["bootstrap_ok_count"].min()),
                "failure_reasons": "; ".join(sorted(set(str(x) for x in status.loc[status["status"].eq("failed"), "note"].dropna())))[:1000],
            }
        )
    return pd.DataFrame(rows)


def setup_style() -> None:
    plt.rcParams.update(
        {
            "font.sans-serif": ["Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Arial Unicode MS", "DejaVu Sans"],
            "axes.unicode_minus": False,
            "figure.dpi": 140,
            "savefig.dpi": 300,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def savefig(fig, name: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f"{name}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(FIG_DIR / f"{name}.svg", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def make_figures(events: pd.DataFrame, mothers: pd.DataFrame, k4_grid: pd.DataFrame, k4_rec: pd.DataFrame, kcompare: pd.DataFrame, kappa_rec: pd.DataFrame, boundary_freq: pd.DataFrame, week29: pd.DataFrame) -> None:
    setup_style()
    FIG_DATA_DIR.mkdir(parents=True, exist_ok=True)
    palette = ["#2f7f7a", "#d19a2e", "#b94755", "#66549a", "#6f843f"]
    pale = ["#dcece8", "#f3dfb2", "#eed1d5", "#ded7ee", "#e2e8cf"]
    accent = "#b94755"
    dark = "#24343b"
    gray = "#7d8587"
    soft_grid = "#e7ece8"
    rec = k4_rec[k4_rec["K"].eq(4)].copy()

    # Fig 1: BMI distribution and K4 boundaries.
    fig_data = mothers[["mother_id", "baseline_bmi"]].copy()
    fig_data.to_csv(FIG_DATA_DIR / "c2_k4_fig01_bmi_distribution_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    bins = np.arange(20, 48.5, 1.0)
    counts, _, patches = ax.hist(fig_data["baseline_bmi"], bins=bins, color="#8bb7ad", edgecolor="white", alpha=0.95)
    group_edges = [20.5] + K4_CUTS + [47.5]
    for i in range(4):
        ax.axvspan(group_edges[i], group_edges[i + 1], color=pale[i], alpha=0.34, zorder=0)
    for c in K4_CUTS:
        ax.axvline(c, color=accent, lw=2.2, ls="--", zorder=3)
        ax.text(c + 0.10, max(counts) * 0.93, f"BMI={c:.1f}", color=accent, fontsize=9, rotation=90, va="top")
    ax.scatter(fig_data["baseline_bmi"], np.full(len(fig_data), -0.7), marker="|", color="#5b696b", alpha=0.35, s=18, clip_on=False)
    ax.set_title("BMI分布与K=4分组边界")
    ax.set_xlabel("首次检测BMI")
    ax.set_ylabel("孕妇数")
    ax.grid(axis="y", color=soft_grid, lw=0.8)
    ax.text(0.02, 0.95, "分组边界将样本密集区拆开，最高BMI组样本少且后续被判为未决。", transform=ax.transAxes, fontsize=9, color=dark)
    savefig(fig, "c2_k4_fig01_bmi_distribution_boundaries")

    # Fig 2: K4 probability and bootstrap LCB curves. Facets make the BMI delay pattern clearer.
    prob = k4_grid[k4_grid["K"].eq(4)].copy()
    prob.to_csv(FIG_DATA_DIR / "c2_k4_fig02_probability_lcb_source.csv", index=False, encoding="utf-8-sig")
    fig, axes = plt.subplots(2, 2, figsize=(8.2, 6.0), sharex=True, sharey=True)
    rec_lookup = rec.set_index("group_id")
    for ax, (gid, sub) in zip(axes.ravel(), prob.groupby("group_id", sort=True)):
        i = int(gid) - 1
        color = palette[i]
        label = sub["bmi_interval"].iloc[0]
        ax.axhspan(0.90, 1.01, color="#eef5ef", alpha=0.85, zorder=0)
        ax.plot(sub["week"], sub["p_group_mean"], color=color, lw=2.3, label="点估计")
        ax.plot(sub["week"], sub["bootstrap_lcb95"], color=color, lw=1.8, ls=(0, (2.2, 2.2)), alpha=0.95, label="bootstrap下界")
        ax.fill_between(sub["week"], sub["bootstrap_lcb95"], sub["p_group_mean"], color=color, alpha=0.08, linewidth=0)
        cross = sub[pd.to_numeric(sub["bootstrap_lcb95"], errors="coerce") >= 0.90].head(1)
        if not cross.empty:
            x = float(cross["week"].iloc[0])
            yv = float(cross["bootstrap_lcb95"].iloc[0])
            ax.axvline(x, color="#555555", lw=1.0, alpha=0.75)
            ax.scatter([x], [yv], s=44, color=color, edgecolor="white", linewidth=1.0, zorder=4)
            ax.text(x + 0.18, yv + 0.006, f"{x:.1f}周\nLCB={yv:.3f}", fontsize=7.4, color=dark)
        else:
            high = sub.sort_values("week").iloc[-1]
            ax.scatter([high["week"]], [high["bootstrap_lcb95"]], s=44, color=accent, edgecolor="white", linewidth=1.0, zorder=4)
            ax.text(18.0, 0.585, f"25周内未决\n25周LCB={high['bootstrap_lcb95']:.3f}", fontsize=7.8, color=accent)
        ax.axhline(0.90, color="#b87945", lw=1.2, ls="--")
        ax.set_title(f"第{int(gid)}组 {label}", fontsize=11)
        ax.grid(axis="y", color=soft_grid, lw=0.8)
    axes[0, 0].set_ylabel("达标概率")
    axes[1, 0].set_ylabel("达标概率")
    axes[1, 0].set_xlabel("孕周 / 周")
    axes[1, 1].set_xlabel("孕周 / 周")
    axes[0, 0].legend(frameon=False, fontsize=8, loc="lower right")
    axes[0, 0].set_ylim(0.56, 1.0)
    fig.suptitle("K=4各组达标概率与bootstrap下界", y=0.99, fontsize=15)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    savefig(fig, "c2_k4_fig02_probability_bootstrap_lcb")

    # Fig 2b: risk components. This uses the same current probability table and keeps the risk function auxiliary.
    risk = prob.copy()
    risk["fail_risk"] = 1.0 - pd.to_numeric(risk["p_group_mean"], errors="coerce")
    risk["time_risk"] = pd.to_numeric(risk["week"], errors="coerce").map(q2.time_risk)
    risk["total_risk"] = risk["fail_risk"] + risk["time_risk"]
    risk["reliability_constraint_passed"] = pd.to_numeric(risk["bootstrap_lcb95"], errors="coerce") >= Q_MAIN
    risk.to_csv(FIG_DATA_DIR / "c2_k4_fig02b_risk_curves_source.csv", index=False, encoding="utf-8-sig")
    fig, axes = plt.subplots(2, 2, figsize=(8.2, 6.0), sharex=True, sharey=True)
    for ax, (gid, sub) in zip(axes.ravel(), risk.groupby("group_id", sort=True)):
        i = int(gid) - 1
        color = palette[i]
        feasible = sub["reliability_constraint_passed"].astype(bool)
        ax.plot(sub["week"], sub["fail_risk"], color="#d99ca6", lw=1.25, label="未达标风险")
        ax.plot(sub["week"], sub["time_risk"], color="#d6c49a", lw=1.25, label="时间风险")
        ax.plot(sub.loc[~feasible, "week"], sub.loc[~feasible, "total_risk"], color=color, lw=1.55, ls=(0, (2.0, 2.0)), alpha=0.55)
        ax.plot(sub.loc[feasible, "week"], sub.loc[feasible, "total_risk"], color=color, lw=2.4, label="约束内总风险")
        row = rec_lookup.loc[int(gid)]
        rw = pd.to_numeric(row["recommended_week"], errors="coerce")
        if np.isfinite(rw):
            rrow = sub[np.isclose(sub["week"], rw)].iloc[0]
            ax.scatter([rw], [rrow["total_risk"]], s=52, color=color, edgecolor="white", linewidth=1.0, zorder=4)
            ax.text(rw + 0.18, rrow["total_risk"] + 0.03, f"推荐{rw:.1f}周\nR={rrow['total_risk']:.3f}", fontsize=7.4, color=dark)
        else:
            best = sub.sort_values("total_risk").iloc[0]
            ax.text(17.8, 0.84, "无满足LCB约束时点\n风险曲线仅辅助说明", fontsize=7.8, color=accent)
            ax.scatter([best["week"]], [best["total_risk"]], s=42, color=accent, edgecolor="white", linewidth=1.0, zorder=4)
        ax.set_title(f"第{int(gid)}组 {sub['bmi_interval'].iloc[0]}", fontsize=11)
        ax.grid(axis="y", color=soft_grid, lw=0.8)
    axes[0, 0].legend(frameon=False, fontsize=8, loc="upper left")
    axes[0, 0].set_ylabel("风险值")
    axes[1, 0].set_ylabel("风险值")
    axes[1, 0].set_xlabel("孕周 / 周")
    axes[1, 1].set_xlabel("孕周 / 周")
    fig.suptitle("可靠性约束下的辅助风险函数", y=0.99, fontsize=15)
    fig.tight_layout(rect=(0, 0, 1, 0.96))
    savefig(fig, "c2_k4_fig02b_risk_curves")

    # Fig 3: recommended timing with high-risk group.
    rec.to_csv(FIG_DATA_DIR / "c2_k4_fig03_recommended_timing_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7.4, 4.35))
    y = np.arange(len(rec))
    weeks = pd.to_numeric(rec["recommended_week"], errors="coerce")
    colors = [palette[i] if np.isfinite(w) else "#dac8a5" for i, w in enumerate(weeks)]
    bars = ax.barh(y, weeks.fillna(25), color=colors, height=0.48)
    for i, (bar, w) in enumerate(zip(bars, weeks)):
        if not np.isfinite(w):
            bar.set_hatch("///")
            bar.set_alpha(0.62)
    ax.axvline(25, color=accent, lw=1.6, ls="--")
    ax.text(25.05, len(rec) - 0.45, "25周上限", color=accent, fontsize=9)
    for pos, (_, row) in enumerate(rec.iterrows()):
        w = pd.to_numeric(row["recommended_week"], errors="coerce")
        if np.isfinite(w):
            text = f"{w:.1f}周  p={row['p_group_mean']:.3f}, LCB={row['bootstrap_lcb95']:.3f}"
        else:
            text = f"25周内未决  p={row['p_group_mean']:.3f}, LCB={row['bootstrap_lcb95']:.3f}"
        ax.text((w if np.isfinite(w) else 25) + 0.15, pos, text, va="center", fontsize=8.2, color=accent if not np.isfinite(w) else dark)
    ax.set_yticks(y)
    ax.set_yticklabels(rec["bmi_interval"])
    ax.set_xlim(11, 27)
    ax.set_xlabel("推荐孕周")
    ax.set_title("K=4可靠性约束下推荐时点")
    ax.grid(axis="x", color=soft_grid, lw=0.8)
    savefig(fig, "c2_k4_fig03_recommended_timing")

    # Fig 4: K comparison, shown as group tiles rather than a plain stacked bar.
    kcompare.to_csv(FIG_DATA_DIR / "c2_k4_fig04_k_comparison_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7.4, 4.55))
    xs = np.arange(len(kcompare))
    for x, (_, row) in zip(xs, kcompare.iterrows()):
        k = int(row["K"])
        ok_n = int(row["ok_group_count"])
        for j in range(k):
            is_ok = j < ok_n
            color = "#4d8f89" if is_ok else "#c06a71"
            ax.scatter(x, j + 1, marker="s", s=820, color=color, edgecolor="white", linewidth=1.2, zorder=3)
            ax.text(x, j + 1, "可行" if is_ok else "未决", ha="center", va="center", fontsize=7.2, color="white", zorder=4)
        ax.text(x, k + 0.48, f"{ok_n}/{k}组可行", ha="center", va="bottom", fontsize=9, color=dark)
    ax.scatter([], [], marker="s", s=160, color="#4d8f89", label="满足可靠性约束")
    ax.scatter([], [], marker="s", s=160, color="#c06a71", label="最高BMI组未决")
    ax.set_xticks(xs)
    ax.set_xticklabels([f"K={int(k)}\n{c}" for k, c in zip(kcompare["K"], kcompare["cutpoints"])], fontsize=8)
    ax.set_yticks(range(1, int(max(kcompare["K"])) + 1))
    ax.set_ylabel("BMI组序号")
    ax.set_title("K=3/4/5分组稳健性对照")
    ax.legend(frameon=False, loc="upper left", ncol=2)
    ax.text(0.02, 0.88, "K=4为正文主分组；K=3、K=5仅作稳健性对照。", transform=ax.transAxes, fontsize=9, color=dark)
    ax.set_xlim(-0.6, len(kcompare) - 0.4)
    ax.set_ylim(0.4, max(kcompare["K"]) + 0.9)
    ax.grid(axis="y", color=soft_grid, lw=0.8)
    savefig(fig, "c2_k4_fig04_k_comparison")

    # Fig 5: kappa sensitivity.
    krec = kappa_rec.copy()
    krec.to_csv(FIG_DATA_DIR / "c2_k4_fig05_kappa_sensitivity_source.csv", index=False, encoding="utf-8-sig")
    pivot = krec.pivot(index="group_id", columns="kappa", values="recommended_week")
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    mat = pivot.to_numpy(dtype=float)
    masked = np.ma.masked_invalid(mat)
    cmap = plt.get_cmap("YlGnBu").copy()
    cmap.set_bad("#d8c6a1")
    im = ax.imshow(masked, aspect="auto", cmap=cmap, vmin=16, vmax=22)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            txt = "未决" if not np.isfinite(mat[i, j]) else f"{mat[i, j]:.1f}"
            ax.text(j, i, txt, ha="center", va="center", color=accent if txt == "未决" else dark, fontsize=9)
    ax.set_xticks(np.arange(len(pivot.columns)))
    ax.set_xticklabels([f"{x:g}" for x in pivot.columns])
    ax.set_yticks(np.arange(len(pivot.index)))
    ax.set_yticklabels([f"第{int(i)}组" for i in pivot.index])
    ax.set_xlabel("检测误差倍数 kappa")
    ax.set_title("检测误差敏感性：推荐时点热图", pad=18)
    cbar = fig.colorbar(im, ax=ax, fraction=0.045, pad=0.03)
    cbar.set_label("推荐孕周")
    ax.text(
        0.02,
        0.98,
        "米色 = 25周内未决",
        transform=ax.transAxes,
        fontsize=9,
        color=dark,
        va="top",
        bbox=dict(boxstyle="round,pad=0.25", facecolor="white", edgecolor="none", alpha=0.82),
    )
    savefig(fig, "c2_k4_fig05_detection_error_sensitivity")

    # Fig 6: boundary stability.
    bf = boundary_freq.copy()
    bf.to_csv(FIG_DATA_DIR / "c2_k4_fig06_boundary_stability_source.csv", index=False, encoding="utf-8-sig")
    top = bf[bf["type"].eq("cutpoints_top30")].head(10).copy()
    fig, ax = plt.subplots(figsize=(7.6, 4.8))
    colors = ["#b94755" if i == 0 else "#7f9160" for i in range(len(top))]
    ax.barh(np.arange(len(top)), top["share_among_ok"], color=colors, height=0.62)
    for i, (_, row) in enumerate(top.iterrows()):
        ax.text(row["share_among_ok"] + 0.002, i, f"{row['share_among_ok']:.1%}", va="center", fontsize=8, color=dark)
    ax.set_yticks(np.arange(len(top)))
    ax.set_yticklabels(top["value"], fontsize=8)
    ax.invert_yaxis()
    ax.set_xlim(0, max(top["share_among_ok"]) * 1.25 if len(top) else 1)
    ax.set_xlabel("bootstrap选择频率")
    ax.set_title("分组边界bootstrap稳定性（最高频仅4.7%）")
    ax.grid(axis="x", color=soft_grid, lw=0.8)
    savefig(fig, "c2_k4_fig06_boundary_stability")

    # Fig 7: 11-29 sensitivity.
    if not week29.empty:
        week29.to_csv(FIG_DATA_DIR / "c2_k4_fig07_week11_29_sensitivity_source.csv", index=False, encoding="utf-8-sig")
        fig, ax = plt.subplots(figsize=(7.4, 4.35))
        w = pd.to_numeric(week29["recommended_week"], errors="coerce")
        colors = [palette[i] for i in range(len(week29))]
        ax.axvspan(25, 29, color="#f5eadc", alpha=0.8, zorder=0)
        ax.barh(np.arange(len(week29)), w - 11, left=11, color=colors, height=0.34, alpha=0.88)
        ax.scatter(w, np.arange(len(week29)), s=54, color=colors, edgecolor="white", linewidth=1.0, zorder=3)
        ax.axvline(25, color=accent, ls="--", lw=1.5)
        ax.text(25.15, len(week29) - 0.24, "25周后仅作敏感性", color=accent, fontsize=9, va="top")
        for i, val in enumerate(w):
            ax.text(val + 0.12, i, f"{val:.1f}周", va="center", fontsize=9, color=dark)
        ax.set_yticks(np.arange(len(week29)))
        ax.set_yticklabels(week29["bmi_interval"])
        ax.set_xlabel("扩展搜索得到的通过约束孕周")
        ax.set_title("11-29周扩展范围敏感性")
        ax.set_xlim(11, 30)
        ax.grid(axis="x", color=soft_grid, lw=0.8)
        savefig(fig, "c2_k4_fig07_week11_29_sensitivity")


def write_code_bundle() -> pd.DataFrame:
    CODE_DIR.mkdir(parents=True, exist_ok=True)
    code_files = sorted([p for p in (ROOT / "code").glob("*.py")])
    rows = []
    for src in code_files:
        dst = CODE_DIR / src.name
        shutil.copy2(src, dst)
        rows.append({"file": f"06_code/{src.name}", "source_path": str(src), "sha256": sha256(dst)})
    return pd.DataFrame(rows)


def archive_code_dir() -> Path:
    archive = OUT_DIR / "C2完整06_code代码包.zip"
    if archive.exists():
        archive.unlink()
    shutil.make_archive(str(archive.with_suffix("")), "zip", CODE_DIR)
    return archive


def write_docs(k4_rec: pd.DataFrame, kcompare: pd.DataFrame, kappa_rec: pd.DataFrame, manifest: dict) -> None:
    def md_table(df: pd.DataFrame, max_rows: int = 30) -> str:
        if df.empty:
            return "（空表）"
        view = df.head(max_rows).copy()
        cols = list(view.columns)
        lines = ["| " + " | ".join(cols) + " |", "| " + " | ".join(["---"] * len(cols)) + " |"]
        for _, row in view.iterrows():
            vals = []
            for c in cols:
                v = row[c]
                if isinstance(v, float):
                    vals.append(f"{v:.6g}")
                elif pd.isna(v):
                    vals.append("")
                else:
                    vals.append(str(v))
            lines.append("| " + " | ".join(vals) + " |")
        if len(df) > max_rows:
            lines.append(f"\n仅展示前 {max_rows} 行，完整结果见对应 CSV。")
        return "\n".join(lines)

    text = f"""# C2 K4正文主分组交付材料

状态：C2-v1.0 已冻结。K4为正文主分组，K3/K5仅作稳健性对照。

## 1. 建模手确认口径

- 正文主分组：K=4；
- K=3、K=5：稳健性对照；
- 概率主模型：LMM派生概率；
- Logistic：敏感性模型；
- 可靠性约束：总体BMI构成、严格收敛bootstrap、组平均LCB95>=0.90；
- 风险函数：辅助；
- 最高BMI组：25周内可靠性未决组；
- “高风险”仅指检测决策风险，不表示临床病理高风险；
- 26周：只作为扩展范围敏感性，不作为正式推荐。

## 2. K4正文主结果

{md_table(k4_rec)}

## 3. K=3/4/5对照

{md_table(kcompare)}

## 4. 检测误差敏感性

检测误差敏感性已统一为总体BMI构成、严格收敛bootstrap、组平均LCB95>=0.90口径。

{md_table(kappa_rec)}

## 5. 运行命令

`{manifest["run_command"]}`
"""
    (OUT_DIR / "C2_K4正文主分组_论文手交付材料.md").write_text(text, encoding="utf-8")

    modeler = """# 给建模手_C2_K4冻结确认记录

C2-v1.0 已按建模手确认口径冻结：

1. 正文主分组采用 K=4；
2. K=3、K=5 仅作稳健性对照；
3. 最高 BMI 组在 11-25 周范围内未满足组平均 bootstrap LCB95 >= 0.90，不设置统一推荐时点；
4. 最高 BMI 组列为可靠性未决组；“高风险”仅指检测决策风险，不表示临床病理高风险；
5. 26 周仅作扩展范围敏感性，不作为正式推荐；
6. 检测误差敏感性已统一 bootstrap 口径复核通过。

重点文件：

- `c2_k4_main_recommended_timing.csv`
- `c2_k4_k3_k4_k5_comparison.csv`
- `c2_k4_detection_error_recommended_timing.csv`
- `figures/`
"""
    (OUT_DIR / "给建模手_C2_K4收口复核说明.md").write_text(modeler, encoding="utf-8")

    writer = """# 给论文手_C2_K4写作交付说明

当前 C2-v1.0 已冻结，可按 K4 正文主分组准备文字和图表。

写作口径：

- 不写“所有组均有可靠推荐时点”；
- 最高BMI组写为“25周内可靠性未决组，建议个体化复查”；若出现“高风险”字样，仅指检测决策风险，不表示临床病理高风险；
- 26周只写为扩展范围敏感性，不作为正式推荐；
- LMM派生概率为主模型，Logistic只作敏感性模型；
- 风险函数只作辅助，不写成直接决定推荐时点。

正式图表在 `figures/`，可编辑SVG同名保留，源数据在 `figure_data/`。
"""
    (OUT_DIR / "给论文手_C2_K4写作交付说明.md").write_text(writer, encoding="utf-8")


def write_index(files: dict[str, pd.DataFrame], code_hashes: pd.DataFrame, archive: Path) -> None:
    rows = []
    for name, df in files.items():
        rows.append({"category": "result", "status": "frozen", "path": f"12_k4_handoff/{name}", "note": f"rows={len(df)}"})
    for p in sorted(FIG_DIR.glob("*")):
        rows.append({"category": "figure", "status": "frozen", "path": f"12_k4_handoff/figures/{p.name}", "note": "PNG 300dpi或SVG可编辑图"})
    for p in sorted(FIG_DATA_DIR.glob("*.csv")):
        rows.append({"category": "figure_data", "status": "frozen", "path": f"12_k4_handoff/figure_data/{p.name}", "note": "图源数据"})
    for p in sorted(INPUT_SNAPSHOT_DIR.glob("*.csv")):
        rows.append({"category": "input_snapshot", "status": "frozen", "path": f"12_k4_handoff/input_snapshots/{p.name}", "note": "最终脚本复现所需输入快照"})
    for _, row in code_hashes.iterrows():
        rows.append({"category": "code", "status": "frozen", "path": row["file"], "note": f"sha256={row['sha256']}"})
    rows.append({"category": "archive", "status": "frozen", "path": f"12_k4_handoff/{archive.name}", "note": "完整06_code代码包zip"})
    for p in ["C2-v1.0正式冻结说明.md", "C2_K4正文主分组_论文手交付材料.md", "给建模手_C2_K4收口复核说明.md", "给论文手_C2_K4写作交付说明.md", "c2_k4_handoff_run_manifest.json"]:
        rows.append({"category": "doc", "status": "frozen", "path": f"12_k4_handoff/{p}", "note": "交付说明或运行记录"})
    pd.DataFrame(rows).to_csv(OUT_DIR / "C2_K4交付文件索引.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=2607)
    args = parser.parse_args()
    start = time.time()
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    events, mothers = q2.load_q2_data()
    sigma_m = load_sigma_m()
    round3 = C2_DIR / "11_repair_round3"
    k_grid = read_input_csv("c2_round3_k_probability_bootstrap_lcb.csv", round3 / "c2_round3_k_probability_bootstrap_lcb.csv")
    k_rec = read_input_csv("c2_round3_k_recommended_timing.csv", round3 / "c2_round3_k_recommended_timing.csv")
    kcompare = read_input_csv("c2_round3_k_compare_summary.csv", round3 / "c2_round3_k_compare_summary.csv")
    boundary_freq = read_input_csv("c2_round3_boundary_stability_frequency.csv", round3 / "c2_round3_boundary_stability_frequency.csv")
    week29 = read_input_csv("c2_round3_week11_29_sensitivity_reference.csv", round3 / "c2_round3_week11_29_sensitivity_reference.csv")

    prob, timing, status, quant = bootstrap_kappa_sensitivity(events, sigma_m, args.bootstrap, args.seed)
    kappa_rec = recommend_kappa(quant, events, mothers, sigma_m)
    kappa_sum = kappa_status_summary(status, quant)

    k4_grid = k_grid[k_grid["K"].eq(4)].copy()
    k4_rec = k_rec[k_rec["K"].eq(4)].copy()
    files = {
        "c2_k4_main_probability_bootstrap_lcb.csv": k4_grid,
        "c2_k4_main_recommended_timing.csv": k4_rec,
        "c2_k4_k3_k4_k5_comparison.csv": kcompare,
        "c2_k4_k3_k4_k5_recommended_timing.csv": k_rec,
        "c2_k4_detection_error_bootstrap_probability.csv": prob,
        "c2_k4_detection_error_bootstrap_timing.csv": timing,
        "c2_k4_detection_error_bootstrap_status.csv": status,
        "c2_k4_detection_error_probability_lcb.csv": quant,
        "c2_k4_detection_error_recommended_timing.csv": kappa_rec,
        "c2_k4_detection_error_status_summary.csv": kappa_sum,
        "c2_k4_boundary_stability_frequency.csv": boundary_freq,
        "c2_k4_week11_29_sensitivity.csv": week29,
    }
    for name, df in files.items():
        df.to_csv(OUT_DIR / name, index=False, encoding="utf-8-sig")

    make_figures(events, mothers, k_grid, k_rec, kcompare, kappa_rec, boundary_freq, week29)
    code_hashes = write_code_bundle()
    code_hashes.to_csv(OUT_DIR / "c2_k4_code_hashes.csv", index=False, encoding="utf-8-sig")
    archive = archive_code_dir()

    manifest = {
        "status": "c2_v1_0_frozen",
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "python": sys.version,
        "platform": platform.platform(),
        "run_command": f"python problem_c_nipt/code/c2_k4_final_handoff.py --bootstrap {args.bootstrap} --seed {args.seed}",
        "bootstrap_n_detection_error": args.bootstrap,
        "seed": args.seed,
        "main_grouping": "K=4",
        "robustness_grouping": ["K=3", "K=5"],
        "main_probability_model": "LMM derived probability",
        "sensitivity_probability_model": "Logistic binary probability from round2",
        "main_reliability_rule": "resampled BMI composition, strict converged bootstrap, group mean LCB95 >= 0.90",
        "high_bmi_group_policy": "undecided within 25 weeks",
        "week26_policy": "extension-range sensitivity only, not formal recommendation",
        "high_risk_term": "detection-decision risk only, not clinical pathological risk",
        "elapsed_seconds": round(time.time() - start, 3),
    }
    (OUT_DIR / "c2_k4_handoff_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    write_docs(k4_rec, kcompare, kappa_rec, manifest)
    write_index(files, code_hashes, archive)

    readme = C2_DIR / "README_C2看这里.md"
    readme.write_text(
        "# C2 当前状态\n\n"
        "状态：C2-v1.0 已冻结。建模手确认正文采用 K=4 主分组，K=3/K=5 仅作稳健性对照。\n\n"
        "当前优先查看：\n\n"
        "- `12_k4_handoff/C2_K4正文主分组_论文手交付材料.md`\n"
        "- `12_k4_handoff/给建模手_C2_K4收口复核说明.md`\n"
        "- `12_k4_handoff/C2_K4交付文件索引.csv`\n"
        "- `12_k4_handoff/figures/`\n"
        "- `12_k4_handoff/C2完整06_code代码包.zip`\n\n"
        "说明：K=4为正文主分组，K=3和K=5为稳健性对照；最高BMI组为25周内可靠性未决组；“高风险”仅指检测决策风险；26周仅作扩展范围敏感性。\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
