from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix


N_PERIODS = 144
DT_HOURS = 1.0 / 6.0
SOC_INITIAL = 6000.0
SOC_MIN = 1200.0
SOC_MAX = 10800.0
P_MAX = 5000.0
DEFAULT_ETA = 0.9


@dataclass
class SolveSummary:
    scenario: str
    success: bool
    status: int
    message: str
    objective_cost_yuan: float
    total_grid_purchase_kwh: float
    no_storage_cost_yuan: float
    saving_rate: float
    soc_min: float
    soc_max: float
    mip_gap: float | None
    max_power_balance_abs_kw: float
    max_soc_transition_abs_kwh: float
    simultaneous_charge_discharge_count: int
    max_soc_violation: float
    max_power_violation: float


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_attachment1(path: Path) -> pd.DataFrame:
    df = pd.read_excel(path)
    expected = ["时间", "电价", "小区负载", "光伏发电预测功率"]
    if list(df.columns) != expected:
        raise ValueError(f"附件1字段不匹配: actual={list(df.columns)!r}, expected={expected!r}")
    if len(df) != N_PERIODS:
        raise ValueError(f"附件1行数应为144，实际为{len(df)}")
    if str(df.iloc[-1, 0]) != "0:00+1":
        raise ValueError("附件1最后一个时间标签应为0:00+1")
    for col in expected[1:]:
        if df[col].isna().any():
            raise ValueError(f"附件1字段存在缺失值: {col}")
        if (df[col] < 0).any():
            raise ValueError(f"附件1字段存在负值: {col}")
    return df


def no_storage_cost(price: np.ndarray, load: np.ndarray, pv: np.ndarray) -> float:
    grid = np.maximum(load - pv, 0.0)
    return float(np.sum(price * grid * DT_HOURS))


def variable_slices(n: int = N_PERIODS) -> dict[str, slice]:
    start = 0
    out: dict[str, slice] = {}
    for name, length in [
        ("G", n),
        ("C", n),
        ("D", n),
        ("W", n),
        ("E", n + 1),
        ("z", n),
    ]:
        out[name] = slice(start, start + length)
        start += length
    out["all"] = slice(0, start)
    return out


def solve_dispatch(
    price: np.ndarray,
    load: np.ndarray,
    pv: np.ndarray,
    *,
    eta_c: float = DEFAULT_ETA,
    eta_d: float = DEFAULT_ETA,
    scenario: str = "main",
) -> tuple[pd.DataFrame, SolveSummary, dict]:
    n = len(price)
    s = variable_slices(n)
    n_vars = s["all"].stop

    c = np.zeros(n_vars)
    c[s["G"]] = price * DT_HOURS

    lb = np.zeros(n_vars)
    ub = np.full(n_vars, np.inf)
    ub[s["C"]] = P_MAX
    ub[s["D"]] = P_MAX
    ub[s["W"]] = pv
    lb[s["E"]] = SOC_MIN
    ub[s["E"]] = SOC_MAX
    lb[s["E"].start] = SOC_INITIAL
    ub[s["E"].start] = SOC_INITIAL
    lb[s["E"].stop - 1] = SOC_INITIAL
    ub[s["E"].stop - 1] = SOC_INITIAL
    ub[s["z"]] = 1.0

    integrality = np.zeros(n_vars)
    integrality[s["z"]] = 1

    rows = 2 * n + 2 * n
    a = lil_matrix((rows, n_vars), dtype=float)
    lower = np.zeros(rows)
    upper = np.zeros(rows)
    row = 0

    # Power balance: G_t + P_t + D_t = L_t + C_t + W_t
    for t in range(n):
        a[row, s["G"].start + t] = 1.0
        a[row, s["C"].start + t] = -1.0
        a[row, s["D"].start + t] = 1.0
        a[row, s["W"].start + t] = -1.0
        lower[row] = load[t] - pv[t]
        upper[row] = load[t] - pv[t]
        row += 1

    # SOC transition: E_{t+1}=E_t+eta_c*C_t*dt-D_t*dt/eta_d
    for t in range(n):
        a[row, s["E"].start + t + 1] = 1.0
        a[row, s["E"].start + t] = -1.0
        a[row, s["C"].start + t] = -eta_c * DT_HOURS
        a[row, s["D"].start + t] = DT_HOURS / eta_d
        lower[row] = 0.0
        upper[row] = 0.0
        row += 1

    # Charge/discharge mutual exclusion via binary z.
    for t in range(n):
        a[row, s["C"].start + t] = 1.0
        a[row, s["z"].start + t] = -P_MAX
        lower[row] = -np.inf
        upper[row] = 0.0
        row += 1
    for t in range(n):
        a[row, s["D"].start + t] = 1.0
        a[row, s["z"].start + t] = P_MAX
        lower[row] = -np.inf
        upper[row] = P_MAX
        row += 1

    constraints = LinearConstraint(a.tocsr(), lower, upper)
    result = milp(
        c=c,
        integrality=integrality,
        bounds=Bounds(lb, ub),
        constraints=constraints,
        options={"mip_rel_gap": 1e-10, "time_limit": 300, "disp": False},
    )
    mip_gap = None
    if hasattr(result, "mip_gap"):
        mip_gap = None if result.mip_gap is None else float(result.mip_gap)
    if result.x is None:
        raise RuntimeError(f"MILP求解失败，未返回解向量: status={result.status}, message={result.message}")
    if not result.success:
        raise RuntimeError(f"MILP求解失败，success=False: status={result.status}, message={result.message}")
    if int(result.status) != 0:
        raise RuntimeError(f"MILP求解失败，status不是0: status={result.status}, message={result.message}")
    if mip_gap is None:
        raise RuntimeError("MILP求解失败，mip_gap为空，不能写出正式结果")
    if mip_gap > 1e-8:
        raise RuntimeError(f"MILP求解失败，mip_gap={mip_gap} 超过 1e-8，不能写出正式结果")

    x = result.x
    G = x[s["G"]]
    C = x[s["C"]]
    D = x[s["D"]]
    W = x[s["W"]]
    E = x[s["E"]]
    z = x[s["z"]]

    detail = pd.DataFrame(
        {
            "period_index": np.arange(n),
            "price_yuan_per_kwh": price,
            "load_kw": load,
            "pv_forecast_kw": pv,
            "grid_purchase_kw": G,
            "charge_kw": C,
            "discharge_kw": D,
            "curtailment_kw": W,
            "soc_start_kwh": E[:-1],
            "soc_end_kwh": E[1:],
            "charge_state_z": z,
            "grid_purchase_kwh": G * DT_HOURS,
            "charge_kwh_microgrid_side": C * DT_HOURS,
            "discharge_kwh_microgrid_side": D * DT_HOURS,
            "curtailment_kwh": W * DT_HOURS,
            "period_cost_yuan": price * G * DT_HOURS,
        }
    )

    balance = G + pv + D - load - C - W
    soc_resid = E[1:] - E[:-1] - eta_c * C * DT_HOURS + D * DT_HOURS / eta_d
    objective = float(np.sum(price * G * DT_HOURS))
    base_cost = no_storage_cost(price, load, pv)
    max_soc_violation = max(
        float(np.max(np.maximum(SOC_MIN - E, 0.0))),
        float(np.max(np.maximum(E - SOC_MAX, 0.0))),
        abs(float(E[0] - SOC_INITIAL)),
        abs(float(E[-1] - SOC_INITIAL)),
    )
    max_power_violation = max(
        float(np.max(np.maximum(C - P_MAX, 0.0))),
        float(np.max(np.maximum(D - P_MAX, 0.0))),
        float(np.max(np.maximum(-G, 0.0))),
        float(np.max(np.maximum(-C, 0.0))),
        float(np.max(np.maximum(-D, 0.0))),
        float(np.max(np.maximum(-W, 0.0))),
        float(np.max(np.maximum(W - pv, 0.0))),
    )
    summary = SolveSummary(
        scenario=scenario,
        success=bool(result.success),
        status=int(result.status),
        message=str(result.message),
        objective_cost_yuan=objective,
        total_grid_purchase_kwh=float(np.sum(G * DT_HOURS)),
        no_storage_cost_yuan=base_cost,
        saving_rate=float((base_cost - objective) / base_cost),
        soc_min=float(np.min(E)),
        soc_max=float(np.max(E)),
        mip_gap=mip_gap,
        max_power_balance_abs_kw=float(np.max(np.abs(balance))),
        max_soc_transition_abs_kwh=float(np.max(np.abs(soc_resid))),
        simultaneous_charge_discharge_count=int(np.sum((C > 1e-6) & (D > 1e-6))),
        max_soc_violation=max_soc_violation,
        max_power_violation=max_power_violation,
    )

    raw_solver = {
        "fun": None if result.fun is None else float(result.fun),
        "mip_node_count": getattr(result, "mip_node_count", None),
        "mip_dual_bound": None
        if getattr(result, "mip_dual_bound", None) is None
        else float(result.mip_dual_bound),
        "mip_gap": mip_gap,
    }
    return detail, summary, raw_solver


def fill_result1_template(template: Path, output: Path, detail: pd.DataFrame) -> None:
    wb = load_workbook(template)
    ws_plan = wb["计划购电量"]
    ws_storage = wb["充放电量"]

    for i, value in enumerate(detail["grid_purchase_kwh"].to_numpy(), start=2):
        ws_plan.cell(row=i, column=2).value = round(float(value), 4)

    charge = detail["charge_kwh_microgrid_side"].to_numpy()
    discharge = detail["discharge_kwh_microgrid_side"].to_numpy()
    for block in range(6):
        start = block * 24
        end = start + 24
        ws_storage.cell(row=block + 2, column=2).value = round(float(np.sum(charge[start:end])), 4)
        ws_storage.cell(row=block + 2, column=3).value = round(float(np.sum(discharge[start:end])), 4)

    ws_storage.cell(row=2, column=5).value = round(float(detail["soc_start_kwh"].iloc[0]), 4)
    ws_storage.cell(row=3, column=5).value = round(float(detail["soc_end_kwh"].iloc[-1]), 4)
    wb.save(output)


def write_summary_doc(path: Path, summary: SolveSummary, sensitivity: pd.DataFrame) -> None:
    display_cols = [
        "scenario",
        "objective_cost_yuan",
        "total_grid_purchase_kwh",
        "no_storage_cost_yuan",
        "saving_rate",
        "soc_min",
        "soc_max",
        "simultaneous_charge_discharge_count",
    ]
    header = "| " + " | ".join(display_cols) + " |"
    sep = "| " + " | ".join(["---"] * len(display_cols)) + " |"
    body = []
    for _, row in sensitivity[display_cols].iterrows():
        values = []
        for col in display_cols:
            value = row[col]
            if isinstance(value, float):
                values.append(f"{value:.10f}")
            else:
                values.append(str(value))
        body.append("| " + " | ".join(values) + " |")
    sensitivity_markdown = "\n".join([header, sep] + body)
    lines = [
        "# C题问题1求解与验证说明",
        "",
        "## 冻结状态",
        "本问题的模型、参数口径、主结果和敏感性结论已由建模手复核通过并冻结。后续除复现环境、文件索引和封包说明外，不再修改问题1数值结果。",
        "",
        "## 主口径",
        "- 主口径采用官方模板逐行映射：附件1第i行电价、负载和光伏数据直接对应result1第i个购电量单元格。",
        "- 主结果不再赋予附件时间戳区间起点或终点含义，模板中的区间文字仅作为官方报表标签保留。",
        "- 六个4小时充放电汇总按144个决策时段依次每24行分组。",
        "- 决策时段为t=0,...,143，SOC节点为E0,...,E144。",
        "- 充电效率和放电效率均为0.9，最大充放电功率作用于微网侧功率。",
        "",
        "## 主结果",
        f"- 最优购电费用：{summary.objective_cost_yuan:.10f} 元。",
        f"- 全天购电量：{summary.total_grid_purchase_kwh:.10f} kWh。",
        f"- 无储能费用：{summary.no_storage_cost_yuan:.10f} 元。",
        f"- 费用节省率：{summary.saving_rate:.10%}。",
        f"- SOC范围：{summary.soc_min:.10f} 至 {summary.soc_max:.10f} kWh。",
        f"- 充放电同时为正时段数：{summary.simultaneous_charge_discharge_count}。",
        "",
        "## 敏感性摘要",
        sensitivity_markdown,
        "",
        "其中 `timestamp_as_interval_end_alignment` 为附件时间戳作为区间终点的对齐口径，仅作为时间敏感性分析保留，不进入result1主结果。",
        "",
        "## 交付边界",
        "本结果只对应问题1的确定性单日计划购电模型，不使用附件2至附件4，也不代表后续全年滚动调度结果。",
        "",
        "## 舍入说明",
        "论文中的全天购电量采用未取整调度结果汇总后再保留四位小数，即59482.6990 kWh。result1各行先保留四位小数后再求和为59482.6991 kWh，差异0.0001 kWh属于逐行舍入误差，不需要人为调整某一时段。",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    raw = root / "00_raw"
    out = root / "01_q1" / "outputs"
    val = root / "01_q1" / "validation"
    sens_dir = root / "01_q1" / "sensitivity"
    docs = root / "01_q1" / "docs"
    for p in [out, val, sens_dir, docs]:
        p.mkdir(parents=True, exist_ok=True)

    attachment = raw / "附件1.xlsx"
    template = raw / "result1.xlsx"
    df = load_attachment1(attachment)
    price = df["电价"].to_numpy(dtype=float)
    load = df["小区负载"].to_numpy(dtype=float)
    pv = df["光伏发电预测功率"].to_numpy(dtype=float)

    scenarios = []
    main_detail, main_summary, main_solver = solve_dispatch(
        price, load, pv, scenario="official_template_row_mapping"
    )
    scenarios.append((main_detail, main_summary, main_solver))

    shifted_detail, shifted_summary, shifted_solver = solve_dispatch(
        np.roll(price, -1),
        np.roll(load, -1),
        np.roll(pv, -1),
        scenario="timestamp_as_interval_end_alignment",
    )
    scenarios.append((shifted_detail, shifted_summary, shifted_solver))

    sqrt_eta = float(np.sqrt(0.9))
    eta_detail, eta_summary, eta_solver = solve_dispatch(
        price, load, pv, eta_c=sqrt_eta, eta_d=sqrt_eta, scenario="eta_sqrt_0p9"
    )
    scenarios.append((eta_detail, eta_summary, eta_solver))

    main_detail.insert(1, "template_time_label", df["时间"].astype(str).to_numpy())
    main_detail.to_csv(out / "q1_dispatch_detail.csv", index=False, encoding="utf-8-sig")
    fill_result1_template(template, out / "result1.xlsx", main_detail)

    sensitivity_df = pd.DataFrame([asdict(s) for _, s, _ in scenarios])
    sensitivity_df.to_csv(sens_dir / "q1_sensitivity_summary.csv", index=False, encoding="utf-8-sig")

    validation = {
        "input_files": {
            "附件1.xlsx": sha256_file(attachment),
            "result1.xlsx_template": sha256_file(template),
        },
        "model_constants": {
            "n_periods": N_PERIODS,
            "dt_hours": DT_HOURS,
            "soc_initial_kwh": SOC_INITIAL,
            "soc_min_kwh": SOC_MIN,
            "soc_max_kwh": SOC_MAX,
            "p_max_kw": P_MAX,
            "eta_c_main": DEFAULT_ETA,
            "eta_d_main": DEFAULT_ETA,
        },
        "main_summary": asdict(main_summary),
        "solver_raw": main_solver,
        "regression_reference": {
            "no_storage_cost_yuan_expected": 48052.0465908,
            "objective_cost_yuan_reference": 35126.9486,
            "total_grid_purchase_kwh_reference": 59482.6990,
            "no_storage_cost_abs_error": abs(main_summary.no_storage_cost_yuan - 48052.0465908),
            "objective_cost_abs_error": abs(main_summary.objective_cost_yuan - 35126.9486),
            "total_grid_purchase_abs_error": abs(main_summary.total_grid_purchase_kwh - 59482.6990),
        },
    }
    (val / "q1_validation_report.json").write_text(
        json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    pd.DataFrame(
        [
            {
                "check": "power_balance",
                "value": main_summary.max_power_balance_abs_kw,
                "threshold": 1e-6,
                "passed": main_summary.max_power_balance_abs_kw <= 1e-6,
            },
            {
                "check": "soc_transition",
                "value": main_summary.max_soc_transition_abs_kwh,
                "threshold": 1e-6,
                "passed": main_summary.max_soc_transition_abs_kwh <= 1e-6,
            },
            {
                "check": "charge_discharge_mutual_exclusion",
                "value": main_summary.simultaneous_charge_discharge_count,
                "threshold": 0,
                "passed": main_summary.simultaneous_charge_discharge_count == 0,
            },
            {
                "check": "soc_bounds",
                "value": main_summary.max_soc_violation,
                "threshold": 1e-6,
                "passed": main_summary.max_soc_violation <= 1e-6,
            },
            {
                "check": "power_bounds",
                "value": main_summary.max_power_violation,
                "threshold": 1e-6,
                "passed": main_summary.max_power_violation <= 1e-6,
            },
            {
                "check": "solver_success",
                "value": int(main_summary.success),
                "threshold": 1,
                "passed": main_summary.success,
            },
            {
                "check": "optimal_status",
                "value": main_summary.status,
                "threshold": 0,
                "passed": main_summary.status == 0,
            },
            {
                "check": "mip_gap",
                "value": main_summary.mip_gap,
                "threshold": 1e-8,
                "passed": main_summary.mip_gap is not None and main_summary.mip_gap <= 1e-8,
            },
        ]
    ).to_csv(val / "q1_validation_checks.csv", index=False, encoding="utf-8-sig")

    write_summary_doc(docs / "C题问题1_编程手交付说明.md", main_summary, sensitivity_df)


if __name__ == "__main__":
    main()
