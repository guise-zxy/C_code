from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from itertools import combinations
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import pandas as pd
import scipy
import sklearn
from scipy import optimize, stats
from scipy.special import expit, logit
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold

import c1_model_analysis as c1


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "results" / "C3-v0.1" / "01_first_round"
FIG_DIR = OUT_DIR / "figures"
FIG_DATA_DIR = OUT_DIR / "figure_data"
CODE_DIR = OUT_DIR / "06_code"

C1_CLEAN = ROOT / "results" / "C1-v1.0" / "c1_clean_events.csv"
C1_TECH = ROOT / "results" / "C1-v1.0" / "c1_technical_replicates.csv"
C1_CODE = ROOT / "code" / "c1_model_analysis.py"
EXPECTED_HASHES = {
    str(C1_CLEAN.relative_to(ROOT)): "09b146af6fba3adf620ca051cca32d3bf506d5b8a4e2dfa9481845213a805444",
    str(C1_TECH.relative_to(ROOT)): "21a8a1834f1876e5f34bab666a99d1cdde65a7e58746298bffa793d92ba70901",
    str(C1_CODE.relative_to(ROOT)): "e0d98f0f6393b80c5e8054179deaf850cadac90b1b70a3afe0457e318c4cec92",
}

THRESHOLD = 0.04
Q_MAIN = 0.90
SIGMA_M = 0.0047336048
SIGMA_M_LOW = 0.0033687715
SIGMA_M_HIGH = 0.0060003084
WEEK_GRID = np.arange(11.0, 25.0 + 1e-9, 0.5)
DISPLAY_LOW = 20.5
DISPLAY_HIGH = 47.5
K_VALUES = [3, 4, 5]
KAPPA_GRID = [0.0, 0.5, 1.0, 1.5, 2.0]
MIN_MOTHERS = 35
MIN_EVENTS = 100
MIN_REACHED = 10
EPS = 1e-8

MODEL_SPECS = {
    "M0": {"terms": ["week_c", "baseline_bmi_c"], "random": "random_intercept", "complexity": 5, "model_type": "lmm"},
    "M1": {
        "terms": ["week_c", "baseline_bmi_c", "baseline_age_c", "baseline_height_c", "pregnancy_count_c", "birth_count_c"],
        "random": "random_intercept",
        "complexity": 9,
        "model_type": "lmm",
    },
    "M2": {
        "terms": [
            "week_c",
            "baseline_bmi_c",
            "baseline_age_c",
            "baseline_height_c",
            "pregnancy_count_c",
            "birth_count_c",
            "week_c2",
            "baseline_bmi_c2",
            "week_bmi",
        ],
        "random": "random_intercept",
        "complexity": 12,
        "model_type": "lmm",
    },
    "M3": {
        "terms": ["week_c", "baseline_weight_c", "baseline_age_c", "baseline_height_c", "pregnancy_count_c", "birth_count_c"],
        "random": "random_intercept",
        "complexity": 9,
        "model_type": "lmm",
    },
    "M4_random_slope_M0": {"terms": ["week_c", "baseline_bmi_c"], "random": "random_slope_week", "complexity": 7, "model_type": "lmm"},
    "Binary_cluster_logit_M0": {"terms": ["week_c", "baseline_bmi_c"], "random": "cluster_logit", "complexity": 3, "model_type": "binary_cluster_logit"},
    "Constant_train_prevalence": {"terms": [], "random": "constant", "complexity": 1, "model_type": "constant"},
}


def setup_style() -> None:
    preferred = ["Noto Sans CJK SC", "Source Han Sans SC", "Microsoft YaHei", "SimHei", "SimSun"]
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for font in preferred:
        if font in installed:
            plt.rcParams["font.sans-serif"] = [font]
            break
    plt.rcParams.update({"axes.unicode_minus": False, "figure.dpi": 150, "savefig.dpi": 300, "font.size": 9})


def savefig(fig: plt.Figure, stem: str) -> None:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIG_DIR / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(FIG_DIR / f"{stem}.svg", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_inputs() -> pd.DataFrame:
    rows = []
    for rel, expected in EXPECTED_HASHES.items():
        path = ROOT / rel
        actual = sha256(path)
        rows.append({"relative_path": rel.replace("\\", "/"), "expected_sha256": expected, "actual_sha256": actual, "passed": actual.lower() == expected.lower()})
    out = pd.DataFrame(rows)
    if not bool(out["passed"].all()):
        raise RuntimeError("C1冻结输入哈希不一致，停止C3第一轮计算")
    return out


def c2_reference_inputs() -> pd.DataFrame:
    refs = [
        {
            "relative_path": "results/C2-v1.0/12_k4_handoff/c2_k4_main_recommended_timing.csv",
            "status": "frozen_reference",
            "source_version": "C2-v1.0",
            "role": "fixed K4 timing comparison only; not used to train C3",
        },
        {
            "relative_path": "results/C2-v1.0/12_k4_handoff/c2_k4_main_probability_bootstrap_lcb.csv",
            "status": "frozen_reference",
            "source_version": "C2-v1.0",
            "role": "fixed K4 probability reference",
        },
    ]
    rows = []
    for item in refs:
        path = ROOT / item["relative_path"]
        rows.append(item | {"exists": path.exists(), "sha256": sha256(path) if path.exists() else ""})
    return pd.DataFrame(rows)


def normalize_count(x) -> float:
    s = str(x).strip()
    if s in {"", "nan", "None"}:
        return np.nan
    if "≥" in s or ">=" in s:
        return 3.0
    try:
        return float(s)
    except ValueError:
        nums = "".join(ch for ch in s if ch.isdigit() or ch == ".")
        return float(nums) if nums else np.nan


def load_events() -> tuple[pd.DataFrame, pd.DataFrame, dict[str, float]]:
    events = pd.read_csv(C1_CLEAN, encoding="utf-8-sig")
    events = events[events["keep_for_main_model"].astype(str).str.lower().eq("true")].copy()
    events = events[(pd.to_numeric(events["week_num"], errors="coerce").between(11, 25)) & pd.to_numeric(events["y_concentration"], errors="coerce").notna()].copy()
    for col in ["week_num", "bmi", "weight", "age", "height", "y_concentration"]:
        events[col] = pd.to_numeric(events[col], errors="coerce")
    events["y_ge_4pct"] = events["y_concentration"] >= THRESHOLD
    events["pregnancy_count_num"] = events["pregnancy_count"].map(normalize_count)
    events["birth_count_num"] = events["birth_count"].map(normalize_count)
    events["assisted_reproduction_flag"] = events["assisted_reproduction"].astype(str).str.lower().eq("true").astype(int)
    events = events.sort_values(["mother_id", "week_num", "test_date_key", "event_id"]).reset_index(drop=True)
    first_cols = ["mother_id", "week_num", "bmi", "weight", "age", "height", "pregnancy_count_num", "birth_count_num", "assisted_reproduction_flag"]
    first = events.dropna(subset=["mother_id"]).drop_duplicates("mother_id")[first_cols].copy()
    first = first.rename(
        columns={
            "week_num": "baseline_week",
            "bmi": "baseline_bmi",
            "weight": "baseline_weight",
            "age": "baseline_age",
            "height": "baseline_height",
            "pregnancy_count_num": "baseline_pregnancy_count",
            "birth_count_num": "baseline_birth_count",
        }
    )
    counts = events.groupby("mother_id", as_index=False).agg(event_count=("event_id", "count"), ever_reached_4pct=("y_ge_4pct", "max"))
    mothers = first.merge(counts, on="mother_id", how="left")
    mothers["ever_reached_4pct"] = mothers["ever_reached_4pct"].astype(bool)
    for col in ["baseline_bmi", "baseline_weight", "baseline_age", "baseline_height", "baseline_pregnancy_count", "baseline_birth_count"]:
        mothers[col] = pd.to_numeric(mothers[col], errors="coerce")
    keep_mothers = mothers.dropna(subset=["baseline_bmi", "baseline_age", "baseline_height", "baseline_weight", "baseline_pregnancy_count", "baseline_birth_count"])["mother_id"]
    events = events[events["mother_id"].isin(keep_mothers)].copy()
    mothers = mothers[mothers["mother_id"].isin(keep_mothers)].reset_index(drop=True)
    events = events.merge(mothers.drop(columns=["event_count", "ever_reached_4pct"]), on="mother_id", how="left")
    if "assisted_reproduction_flag_x" in events.columns:
        events["assisted_reproduction_flag"] = events["assisted_reproduction_flag_y"].fillna(events["assisted_reproduction_flag_x"])
        events = events.drop(columns=["assisted_reproduction_flag_x", "assisted_reproduction_flag_y"], errors="ignore")
    means = compute_means(events)
    events = add_terms(events, means)
    mothers = add_terms(mothers, means)
    return events, mothers, means


def compute_means(df: pd.DataFrame) -> dict[str, float]:
    return {
        "week": float(df["week_num"].mean()) if "week_num" in df else 0.0,
        "baseline_bmi": float(df["baseline_bmi"].mean()),
        "baseline_weight": float(df["baseline_weight"].mean()),
        "baseline_age": float(df["baseline_age"].mean()),
        "baseline_height": float(df["baseline_height"].mean()),
        "pregnancy": float(df["baseline_pregnancy_count"].mean()),
        "birth": float(df["baseline_birth_count"].mean()),
    }


def add_terms(df: pd.DataFrame, means: dict[str, float]) -> pd.DataFrame:
    out = df.copy()
    week = out["week_num"] if "week_num" in out else out.get("baseline_week", pd.Series(np.repeat(means["week"], len(out)), index=out.index))
    out["week_c"] = pd.to_numeric(week, errors="coerce") - means["week"]
    out["baseline_bmi_c"] = pd.to_numeric(out["baseline_bmi"], errors="coerce") - means["baseline_bmi"]
    out["baseline_weight_c"] = pd.to_numeric(out["baseline_weight"], errors="coerce") - means["baseline_weight"]
    out["baseline_age_c"] = pd.to_numeric(out["baseline_age"], errors="coerce") - means["baseline_age"]
    out["baseline_height_c"] = pd.to_numeric(out["baseline_height"], errors="coerce") - means["baseline_height"]
    out["pregnancy_count_c"] = pd.to_numeric(out["baseline_pregnancy_count"], errors="coerce") - means["pregnancy"]
    out["birth_count_c"] = pd.to_numeric(out["baseline_birth_count"], errors="coerce") - means["birth"]
    out["week_c2"] = out["week_c"] ** 2
    out["baseline_bmi_c2"] = out["baseline_bmi_c"] ** 2
    out["week_bmi"] = out["week_c"] * out["baseline_bmi_c"]
    return out


def sample_audit(events: pd.DataFrame, mothers: pd.DataFrame) -> pd.DataFrame:
    counts = events.groupby("mother_id").size()
    rows = [
        {"metric": "status", "value": "draft", "note": "C3-v0.1第一轮草案"},
        {"metric": "event_count", "value": int(len(events)), "note": "C1冻结输入筛选后事件数"},
        {"metric": "mother_count", "value": int(events["mother_id"].nunique()), "note": "孕妇数"},
        {"metric": "tests_per_mother_min", "value": int(counts.min()), "note": ""},
        {"metric": "tests_per_mother_median", "value": float(counts.median()), "note": ""},
        {"metric": "tests_per_mother_max", "value": int(counts.max()), "note": ""},
        {"metric": "repeated_mother_count", "value": int((counts > 1).sum()), "note": ""},
        {"metric": "event_pass_rate", "value": float(events["y_ge_4pct"].mean()), "note": "事件级Y>=4%比例"},
        {"metric": "ever_pass_mother_count", "value": int(mothers["ever_reached_4pct"].sum()), "note": "至少一次达标孕妇数"},
        {"metric": "assisted_reproduction_mother_count", "value": int(mothers["assisted_reproduction_flag"].sum()), "note": "仅报告，不进入主模型"},
    ]
    reversal = 0
    left = interval = right = 0
    for _, g in events.sort_values(["week_num", "test_date_key", "event_id"]).groupby("mother_id"):
        y = g["y_ge_4pct"].astype(int).to_numpy()
        reversal += int(np.any(np.diff(y) < 0))
        if y.sum() == 0:
            right += 1
        elif y[0] == 1:
            left += 1
        else:
            interval += 1
    rows.extend(
        [
            {"metric": "left_censored_first_observed_pass", "value": left, "note": ""},
            {"metric": "interval_censored_first_pass", "value": interval, "note": ""},
            {"metric": "right_censored_no_observed_pass", "value": right, "note": ""},
            {"metric": "pass_reversal_mother_count", "value": reversal, "note": "出现先达标后不达标"},
        ]
    )
    return pd.DataFrame(rows)


def covariate_audit(events: pd.DataFrame, mothers: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for col in ["baseline_bmi", "baseline_weight", "baseline_age", "baseline_height", "baseline_pregnancy_count", "baseline_birth_count"]:
        s = pd.to_numeric(mothers[col], errors="coerce")
        variation_label = "随检测时点变化" if col in {"baseline_bmi", "baseline_weight"} else "母体内记录不一致"
        rows.append({"variable": col, "n": int(s.notna().sum()), "missing": int(s.isna().sum()), "mean": float(s.mean()), "sd": float(s.std()), "min": float(s.min()), "q25": float(s.quantile(0.25)), "median": float(s.median()), "q75": float(s.quantile(0.75)), "max": float(s.max()), "within_mother_variation_count": within_inconsistent(events, col), "variation_label": variation_label})
    rows.append({"variable": "assisted_reproduction_flag", "n": int(len(mothers)), "missing": 0, "mean": float(mothers["assisted_reproduction_flag"].mean()), "sd": np.nan, "min": int(mothers["assisted_reproduction_flag"].min()), "q25": np.nan, "median": int(mothers["assisted_reproduction_flag"].median()), "q75": np.nan, "max": int(mothers["assisted_reproduction_flag"].max()), "within_mother_variation_count": within_inconsistent(events, "assisted_reproduction_flag"), "variation_label": "数据质量核查"})
    return pd.DataFrame(rows)


def within_inconsistent(events: pd.DataFrame, baseline_col: str) -> int:
    raw_map = {
        "baseline_bmi": "bmi",
        "baseline_weight": "weight",
        "baseline_age": "age",
        "baseline_height": "height",
        "baseline_pregnancy_count": "pregnancy_count_num",
        "baseline_birth_count": "birth_count_num",
        "assisted_reproduction_flag": "assisted_reproduction_flag",
    }
    col = raw_map.get(baseline_col)
    if col not in events:
        return 0
    vals = events.groupby("mother_id")[col].nunique(dropna=True)
    return int((vals > 1).sum())


def collinearity(mothers: pd.DataFrame) -> pd.DataFrame:
    cols = ["baseline_bmi", "baseline_weight", "baseline_height", "baseline_age"]
    corr = mothers[cols].corr()
    rows = []
    for a in cols:
        for b in cols:
            if a < b:
                rows.append({"kind": "pearson_corr", "variable": f"{a}__{b}", "value": float(corr.loc[a, b]), "note": ""})
    X = mothers[["baseline_bmi", "baseline_weight", "baseline_height"]].to_numpy(float)
    X = (X - X.mean(axis=0)) / X.std(axis=0, ddof=1)
    for i, name in enumerate(["baseline_bmi", "baseline_weight", "baseline_height"]):
        y = X[:, i]
        Z = np.column_stack([np.ones(len(X)), np.delete(X, i, axis=1)])
        beta = np.linalg.lstsq(Z, y, rcond=None)[0]
        pred = Z @ beta
        r2 = 1 - np.sum((y - pred) ** 2) / np.sum((y - y.mean()) ** 2)
        rows.append({"kind": "VIF_body_scale", "variable": name, "value": float(1 / max(1 - r2, EPS)), "note": "BMI、体重、身高不同时进入主模型"})
    return pd.DataFrame(rows)


def design(df: pd.DataFrame, terms: list[str]) -> np.ndarray:
    return np.column_stack([np.ones(len(df))] + [df[t].to_numpy(float) for t in terms])


def fit_model(name: str, df: pd.DataFrame):
    spec = MODEL_SPECS[name]
    return c1.fit_lmm(f"C3_{name}", df, spec["terms"], spec["random"], maxiter=500)


def predict_mu(fit, df: pd.DataFrame, terms: list[str]) -> np.ndarray:
    return design(df, terms) @ fit.beta


def random_effect_variance(fit, df: pd.DataFrame) -> np.ndarray:
    if fit.random_structure == "random_slope_week" and fit.G.shape[0] >= 2:
        z0 = np.ones(len(df))
        z1 = df["week_c"].to_numpy(float)
        return fit.G[0, 0] * z0 + 2 * fit.G[0, 1] * z1 + fit.G[1, 1] * z1**2
    return np.repeat(float(fit.G[0, 0]), len(df))


def predict_prob(fit, df: pd.DataFrame, terms: list[str], sigma_m: float = SIGMA_M, kappa: float = 1.0) -> np.ndarray:
    mu = predict_mu(fit, df, terms)
    sigma_u2 = random_effect_variance(fit, df)
    sigma_e2 = float(fit.sigma_e2)
    sigma_b2 = max(sigma_e2 - SIGMA_M**2, 0.0)
    sigma = np.sqrt(np.maximum(sigma_u2 + sigma_b2 + (kappa * sigma_m) ** 2, EPS))
    return stats.norm.cdf((mu - THRESHOLD) / sigma)


def calibration(y: np.ndarray, p: np.ndarray) -> tuple[float, float]:
    p = np.clip(p, 1e-5, 1 - 1e-5)
    x = logit(p)
    y = y.astype(float)

    def nll(ab):
        eta = ab[0] + ab[1] * x
        q = np.clip(expit(eta), 1e-6, 1 - 1e-6)
        return float(-np.sum(y * np.log(q) + (1 - y) * np.log(1 - q)))

    try:
        res = optimize.minimize(nll, np.array([0.0, 1.0]), method="L-BFGS-B")
        return float(res.x[0]), float(res.x[1])
    except Exception:
        return np.nan, np.nan


def prob_metrics(y: np.ndarray, p: np.ndarray, y_cont: np.ndarray, mu: np.ndarray) -> dict:
    p = np.clip(p, 1e-6, 1 - 1e-6)
    intercept, slope = calibration(y, p)
    try:
        auc = float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else np.nan
    except Exception:
        auc = np.nan
    return {
        "brier": float(np.mean((y - p) ** 2)),
        "log_loss": float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))),
        "auc": auc,
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "rmse_y": float(np.sqrt(np.mean((y_cont - mu) ** 2))),
        "mae_y": float(np.mean(np.abs(y_cont - mu))),
    }


def predict_binary_fit(fit: dict[str, object], df: pd.DataFrame) -> np.ndarray:
    return expit(design(df, fit["terms"]) @ fit["beta"])


def cross_validate(events: pd.DataFrame, seed: int, repeats: int = 10) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, object]]:
    rows, pred_rows, assign_rows = [], [], []
    mother_y = events.groupby("mother_id")["y_ge_4pct"].max().astype(int)
    event_strata = events["mother_id"].map(mother_y).astype(int)
    cv_models = list(MODEL_SPECS.keys())
    for repeat in range(1, repeats + 1):
        splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=seed + repeat - 1)
        for fold, (train_idx, test_idx) in enumerate(splitter.split(events, y=event_strata, groups=events["mother_id"]), 1):
            train_raw = events.iloc[train_idx].copy()
            test_raw = events.iloc[test_idx].copy()
            for mid in sorted(test_raw["mother_id"].unique()):
                assign_rows.append({"repeat": repeat, "fold": fold, "mother_id": mid, "mother_ever_reached_4pct": int(mother_y.loc[mid])})
            means = compute_means(train_raw)
            train = add_terms(train_raw, means)
            test = add_terms(test_raw, means)
            y = test["y_ge_4pct"].astype(int).to_numpy()
            yc = test["y_concentration"].to_numpy(float)
            train_prev = float(train["y_ge_4pct"].mean())
            for model_name in cv_models:
                spec = MODEL_SPECS[model_name]
                try:
                    if spec["model_type"] == "constant":
                        p = np.repeat(train_prev, len(test))
                        mu = np.repeat(float(train["y_concentration"].mean()), len(test))
                        converged = True
                        msg = "training-fold prevalence baseline"
                    elif spec["model_type"] == "binary_cluster_logit":
                        bfit = fit_logistic(train, spec["terms"])
                        p = predict_binary_fit(bfit, test)
                        mu = p * THRESHOLD
                        converged = bool(bfit["converged"])
                        msg = "mother-cluster handled in repeated grouped CV; " + bfit["message"]
                    else:
                        fit = fit_model(model_name, train)
                        p = predict_prob(fit, test, spec["terms"])
                        mu = predict_mu(fit, test, spec["terms"])
                        converged = bool(fit.converged)
                        msg = fit.message
                    met = prob_metrics(y, p, yc, mu)
                except Exception as exc:
                    p = np.repeat(train_prev, len(test))
                    mu = np.repeat(float(train["y_concentration"].mean()), len(test))
                    met = prob_metrics(y, p, yc, mu)
                    converged = False
                    msg = str(exc)
                rows.append({"model": model_name, "repeat": repeat, "fold": fold, "train_mothers": int(train_raw["mother_id"].nunique()), "train_events": int(len(train_raw)), "valid_mothers": int(test_raw["mother_id"].nunique()), "valid_events": int(len(test_raw)), "train_event_pass_rate": train_prev, "valid_event_pass_rate": float(test_raw["y_ge_4pct"].mean()), "converged": converged, "message": msg} | met)
                for eid, mid, week, yy, pp, mm in zip(test["event_id"], test["mother_id"], test["week_num"], y, p, mu):
                    pred_rows.append({"model": model_name, "repeat": repeat, "fold": fold, "event_id": eid, "mother_id": mid, "week_num": week, "y_ge_4pct": int(yy), "pred_prob": float(pp), "pred_mu": float(mm)})
    folds = pd.DataFrame(rows)
    preds = pd.DataFrame(pred_rows)
    assignments = pd.DataFrame(assign_rows)
    summary_rows = []
    complexity = pd.DataFrame([{"model": k, "actual_parameter_count_or_declared_complexity": v["complexity"], "model_type": v["model_type"]} for k, v in MODEL_SPECS.items()])
    for model_name, sub_pred in preds.groupby("model", sort=True):
        y = sub_pred["y_ge_4pct"].astype(int).to_numpy()
        p = sub_pred["pred_prob"].astype(float).to_numpy()
        yc = events.set_index("event_id").loc[sub_pred["event_id"], "y_concentration"].to_numpy(float)
        mu = sub_pred["pred_mu"].astype(float).to_numpy()
        pooled = prob_metrics(y, p, yc, mu)
        sub_fold = folds[folds["model"].eq(model_name)]
        item = {"model": model_name, "oof_prediction_count": int(len(sub_pred)), "cv_converged_folds": int(sub_fold["converged"].sum()), "cv_total_folds": int(len(sub_fold))}
        item.update({f"pooled_oof_{k}": v for k, v in pooled.items()})
        item["brier_mean"] = float(sub_fold["brier"].mean())
        item["brier_se"] = float(sub_fold["brier"].std(ddof=1) / math.sqrt(sub_fold["brier"].notna().sum()))
        item["log_loss_mean"] = float(sub_fold["log_loss"].mean())
        item["log_loss_se"] = float(sub_fold["log_loss"].std(ddof=1) / math.sqrt(sub_fold["log_loss"].notna().sum()))
        summary_rows.append(item)
    summary = pd.DataFrame(summary_rows).merge(complexity, on="model", how="left")
    lmm_main = summary[summary["model"].isin(["M0", "M1", "M2", "M3"])].copy()
    best_idx = lmm_main["brier_mean"].idxmin()
    best_brier = float(lmm_main.loc[best_idx, "brier_mean"])
    one_se_limit = best_brier + float(lmm_main.loc[best_idx, "brier_se"])
    eligible = lmm_main[lmm_main["brier_mean"] <= one_se_limit].copy()
    selected = eligible.sort_values(["actual_parameter_count_or_declared_complexity", "brier_mean"]).iloc[0]["model"]
    decision = {
        "selected_model": selected,
        "best_lmm_brier": best_brier,
        "one_se_limit": one_se_limit,
        "m0_brier": float(summary.loc[summary["model"].eq("M0"), "brier_mean"].iloc[0]),
        "selection_rule": f"{repeats}x5 StratifiedGroupKFold; one-SE simplest LMM among M0-M3 by fold Brier",
        "probability_models_compared": cv_models,
    }
    return summary, folds, preds, assignments, decision


def fit_full_models(events: pd.DataFrame) -> tuple[dict[str, object], pd.DataFrame, pd.DataFrame, dict[str, float]]:
    means = compute_means(events)
    model_df = add_terms(events, means)
    fits, fit_rows, coeff_rows = {}, [], []
    for name, spec in MODEL_SPECS.items():
        if spec["model_type"] != "lmm":
            fit_rows.append({"model": name, "converged": "", "message": "not an LMM full-data fit; evaluated in probability CV", "aic": np.nan, "bic": np.nan, "loglike": np.nan, "sigma_e": np.nan, "sigma_u": np.nan, "icc": np.nan})
            continue
        try:
            fit = fit_model(name, model_df)
        except Exception as exc:
            fit_rows.append({"model": name, "converged": False, "message": str(exc)})
            continue
        fits[name] = fit
        fit_rows.append({"model": name, "converged": bool(fit.converged), "message": fit.message, "aic": fit.aic, "bic": fit.bic, "loglike": fit.loglike, "sigma_e": math.sqrt(fit.sigma_e2), "sigma_u": math.sqrt(float(fit.G[0, 0])), "icc": fit.icc})
        terms = ["Intercept"] + spec["terms"]
        for term, beta, se, lo, hi, pval in zip(terms, fit.beta, fit.se, fit.ci_low, fit.ci_high, fit.p_values):
            coeff_rows.append({"model": name, "term": term, "coefficient": beta, "std_error": se, "ci_low": lo, "ci_high": hi, "p_value": pval, "note": "draft"})
    return fits, pd.DataFrame(fit_rows), pd.DataFrame(coeff_rows), means


def standardized_effects(events: pd.DataFrame, coeffs: pd.DataFrame) -> pd.DataFrame:
    sd_y = float(events["y_concentration"].std(ddof=1))
    rows = []
    for _, row in coeffs.iterrows():
        term = row["term"]
        if term == "Intercept":
            continue
        if term in events.columns:
            sd_x = float(pd.to_numeric(events[term], errors="coerce").std(ddof=1))
        else:
            sd_x = np.nan
        rows.append(
            {
                "model": row["model"],
                "term": term,
                "coefficient": row["coefficient"],
                "sd_x": sd_x,
                "sd_y": sd_y,
                "standardized_effect_beta_sdX_over_sdY": float(row["coefficient"]) * sd_x / sd_y if pd.notna(sd_x) and sd_y > 0 else np.nan,
                "note": "标准化效应用于不同量纲变量的量级比较",
            }
        )
    return pd.DataFrame(rows)


def m2_monotonicity_check(fit, mothers: pd.DataFrame, means: dict[str, float]) -> pd.DataFrame:
    terms = MODEL_SPECS["M2"]["terms"]
    rows = []
    max_drop = 0.0
    decreasing = 0
    for _, m in mothers.iterrows():
        d = pd.DataFrame([m.to_dict() for _ in WEEK_GRID])
        d["week_num"] = WEEK_GRID
        d = add_terms(d, means)
        mu = predict_mu(fit, d, terms)
        diffs = np.diff(mu)
        min_diff = float(diffs.min()) if len(diffs) else 0.0
        drop = float(max(0.0, -min_diff))
        max_drop = max(max_drop, drop)
        is_decreasing = bool(np.any(diffs < -1e-10))
        decreasing += int(is_decreasing)
        rows.append({"mother_id": m["mother_id"], "has_decreasing_segment": is_decreasing, "min_adjacent_mu_diff": min_diff, "max_adjacent_drop": drop})
    summary = pd.DataFrame(
        [
            {"mother_id": "__SUMMARY__", "has_decreasing_segment": decreasing > 0, "min_adjacent_mu_diff": np.nan, "max_adjacent_drop": max_drop, "decreasing_mother_count": decreasing, "decreasing_mother_ratio": decreasing / len(mothers)}
        ]
    )
    return pd.concat([summary, pd.DataFrame(rows)], ignore_index=True)


def m4_random_slope_sensitivity(events: pd.DataFrame, mothers: pd.DataFrame, means: dict[str, float], cuts_by_k: dict[int, list[float]]) -> tuple[pd.DataFrame, pd.DataFrame]:
    terms = MODEL_SPECS["M0"]["terms"]
    rows = []
    rec_rows = []
    try:
        fit = c1.fit_lmm("C3_M4_random_slope_on_M0", events, terms, "random_slope_week", maxiter=500)
        g = fit.G
        rows.append(
            {
                "base_fixed_effect_model": "M0",
                "converged": bool(fit.converged),
                "message": fit.message,
                "aic": fit.aic,
                "bic": fit.bic,
                "sigma_e": math.sqrt(fit.sigma_e2),
                "random_intercept_var": float(g[0, 0]),
                "random_slope_var": float(g[1, 1]) if g.shape[0] > 1 else np.nan,
                "random_intercept_slope_cov": float(g[0, 1]) if g.shape[0] > 1 else np.nan,
            }
        )
        if fit.converged:
            # Sensitivity probability uses week-specific random-effect variance z(t)'Gz(t).
            blocks = []
            for week in WEEK_GRID:
                d = mothers.copy()
                d["week_num"] = week
                d = add_terms(d, means)
                mu = predict_mu(fit, d, terms)
                wc = float(week - means["week"])
                random_var = float(np.array([1.0, wc]) @ g @ np.array([1.0, wc]))
                sigma_b2 = max(float(fit.sigma_e2) - SIGMA_M**2, 0.0)
                sigma = math.sqrt(max(random_var + sigma_b2 + SIGMA_M**2, EPS))
                blocks.append(stats.norm.cdf((mu - THRESHOLD) / sigma))
            probs = np.column_stack(blocks)
            for K, cuts in cuts_by_k.items():
                grid = summarize_grid("M4_random_slope_on_M0", mothers, events, cuts, probs)
                rec = recommend(grid.assign(point_lcb=grid["p_group_mean"]), "point_lcb")
                for _, row in rec.iterrows():
                    rec_rows.append({"K": K, "group_id": int(row["group_id"]), "bmi_interval": row["bmi_interval"], "status": row["status"], "recommended_week_point": row["recommended_week"], "p_group_mean": row["p_group_mean"]})
    except Exception as exc:
        rows.append({"base_fixed_effect_model": "M0", "converged": False, "message": str(exc)})
    return pd.DataFrame(rows), pd.DataFrame(rec_rows)


def cut_grid(mothers: pd.DataFrame) -> list[float]:
    lo = math.ceil(float(mothers["baseline_bmi"].min()) * 2) / 2
    hi = math.floor(float(mothers["baseline_bmi"].max()) * 2) / 2
    return [x / 2 for x in range(int(lo * 2) + 1, int(hi * 2))]


def assign_groups(bmi: np.ndarray, cuts: list[float]) -> np.ndarray:
    return np.searchsorted(np.asarray(cuts), np.asarray(bmi), side="right")


def interval_labels(cuts: list[float]) -> list[str]:
    edges = [DISPLAY_LOW] + cuts + [DISPLAY_HIGH]
    labels = []
    for i in range(len(edges) - 1):
        labels.append(f"[{edges[i]:.1f}, {edges[i+1]:.1f}{']' if i == len(edges)-2 else ')'}")
    return labels


def time_risk(week: float) -> float:
    if week <= 12:
        return 0.0
    return (week - 12.0) / 13.0


def mother_prob_matrix(model_name: str, fit, mothers: pd.DataFrame, means: dict[str, float], sigma_m: float = SIGMA_M, kappa: float = 1.0, week_grid: np.ndarray = WEEK_GRID) -> np.ndarray:
    terms = MODEL_SPECS[model_name]["terms"]
    blocks = []
    for week in week_grid:
        d = mothers.copy()
        d["week_num"] = week
        d = add_terms(d, means)
        blocks.append(predict_prob(fit, d, terms, sigma_m=sigma_m, kappa=kappa))
    return np.column_stack(blocks)


def summarize_grid(model_name: str, mothers: pd.DataFrame, events: pd.DataFrame, cuts: list[float], probs: np.ndarray, week_grid: np.ndarray = WEEK_GRID) -> pd.DataFrame:
    groups = assign_groups(mothers["baseline_bmi"].to_numpy(float), cuts)
    event_groups = assign_groups(events["baseline_bmi"].to_numpy(float), cuts)
    labels = interval_labels(cuts)
    rows = []
    for gid in range(len(cuts) + 1):
        idx = np.where(groups == gid)[0]
        eidx = np.where(event_groups == gid)[0]
        if len(idx) == 0:
            continue
        gp = probs[idx, :]
        for j, week in enumerate(week_grid):
            vals = gp[:, j]
            rows.append(
                {
                    "model": model_name,
                    "K": len(cuts) + 1,
                    "group_id": gid + 1,
                    "bmi_interval": labels[gid],
                    "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                    "week": float(week),
                    "p_group_mean": float(np.mean(vals)),
                    "individual_p_min": float(np.min(vals)),
                    "individual_p_q10": float(np.percentile(vals, 10)),
                    "individual_p_median": float(np.median(vals)),
                    "individual_share_ge_0p90": float(np.mean(vals >= Q_MAIN)),
                    "mother_count": int(len(idx)),
                    "event_count": int(len(eidx)),
                    "ever_reached_mother_count": int(mothers.iloc[idx]["ever_reached_4pct"].sum()),
                    "fail_risk": float(1 - np.mean(vals)),
                    "time_risk": time_risk(float(week)),
                    "total_risk": float(1 - np.mean(vals) + time_risk(float(week))),
                }
            )
    return pd.DataFrame(rows)


def recommend(grid: pd.DataFrame, reliability_col: str) -> pd.DataFrame:
    rows = []
    for gid, sub in grid.groupby("group_id", sort=True):
        sub = sub.sort_values(["week", "total_risk"])
        feasible = sub[pd.to_numeric(sub[reliability_col], errors="coerce") >= Q_MAIN]
        if feasible.empty:
            ref = sub.sort_values("week").iloc[-1]
            week = ""
            status = "undecided_25w_reliability"
        else:
            ref = feasible.sort_values("week").iloc[0]
            week = float(ref["week"])
            status = "ok"
        rows.append(
            {
                "model": ref["model"],
                "K": int(ref["K"]),
                "group_id": int(gid),
                "bmi_interval": ref["bmi_interval"],
                "cutpoints": ref["cutpoints"],
                "status": status,
                "recommended_week": week,
                "p_group_mean": float(ref["p_group_mean"]),
                reliability_col: float(ref[reliability_col]) if pd.notna(ref[reliability_col]) else np.nan,
                "bootstrap_ok_count": int(ref["bootstrap_ok_count"]) if "bootstrap_ok_count" in ref and pd.notna(ref["bootstrap_ok_count"]) else "",
                "fail_risk": float(ref["fail_risk"]),
                "time_risk": float(ref["time_risk"]),
                "total_risk": float(ref["total_risk"]),
                "individual_p_min": float(ref["individual_p_min"]),
                "individual_p_q10": float(ref["individual_p_q10"]),
                "individual_p_median": float(ref["individual_p_median"]),
                "individual_share_ge_0p90": float(ref["individual_share_ge_0p90"]),
                "mother_count": int(ref["mother_count"]) if "mother_count" in ref and pd.notna(ref["mother_count"]) else "",
                "event_count": int(ref["event_count"]) if "event_count" in ref and pd.notna(ref["event_count"]) else "",
                "ever_reached_mother_count": int(ref["ever_reached_mother_count"]) if "ever_reached_mother_count" in ref and pd.notna(ref["ever_reached_mother_count"]) else "",
                "at_25_boundary": bool(pd.notna(ref["week"]) and np.isclose(float(ref["week"]), 25.0)),
            }
        )
    return pd.DataFrame(rows)


def candidate_constraints(mothers: pd.DataFrame, events: pd.DataFrame, cuts: list[float]) -> tuple[bool, str]:
    mg = assign_groups(mothers["baseline_bmi"].to_numpy(float), cuts)
    eg = assign_groups(events["baseline_bmi"].to_numpy(float), cuts)
    reasons = []
    for gid in range(len(cuts) + 1):
        gm = mothers.iloc[np.where(mg == gid)[0]]
        if len(gm) < MIN_MOTHERS:
            reasons.append(f"group{gid+1}_mother_lt_{MIN_MOTHERS}")
        if int(np.sum(eg == gid)) < MIN_EVENTS:
            reasons.append(f"group{gid+1}_event_lt_{MIN_EVENTS}")
        if int(gm["ever_reached_4pct"].sum()) < MIN_REACHED:
            reasons.append(f"group{gid+1}_ever_pass_lt_{MIN_REACHED}")
    return len(reasons) == 0, ";".join(reasons)


def interval_count_lookup(mothers: pd.DataFrame, events: pd.DataFrame, grid_values: list[float]) -> dict[tuple[float, float], dict[str, int]]:
    edges = [DISPLAY_LOW] + grid_values + [DISPLAY_HIGH]
    lookup = {}
    bmi_m = mothers["baseline_bmi"].to_numpy(float)
    bmi_e = events["baseline_bmi"].to_numpy(float)
    for lo in edges[:-1]:
        for hi in edges[edges.index(lo) + 1 :]:
            m_mask = (bmi_m >= lo) & (bmi_m < hi)
            e_mask = (bmi_e >= lo) & (bmi_e < hi)
            lookup[(lo, hi)] = {
                "mother_count": int(m_mask.sum()),
                "event_count": int(e_mask.sum()),
                "ever_reached_mother_count": int(mothers.iloc[np.where(m_mask)[0]]["ever_reached_4pct"].sum()),
            }
    return lookup


def feasible_by_intervals(cuts: list[float], lookup: dict[tuple[float, float], dict[str, int]]) -> tuple[bool, str]:
    edges = [DISPLAY_LOW] + cuts + [DISPLAY_HIGH]
    reasons = []
    for i in range(len(edges) - 1):
        item = lookup[(edges[i], edges[i + 1])]
        if item["mother_count"] < MIN_MOTHERS:
            reasons.append(f"group{i+1}_mother_lt_{MIN_MOTHERS}")
        if item["event_count"] < MIN_EVENTS:
            reasons.append(f"group{i+1}_event_lt_{MIN_EVENTS}")
        if item["ever_reached_mother_count"] < MIN_REACHED:
            reasons.append(f"group{i+1}_ever_pass_lt_{MIN_REACHED}")
    return len(reasons) == 0, ";".join(reasons)


def candidate_failure_summary(rows: list[dict]) -> pd.DataFrame:
    if not rows:
        return pd.DataFrame(columns=["K", "failed_reason", "count"])
    return pd.DataFrame(rows).groupby(["K", "failed_reason"], dropna=False).size().reset_index(name="count")


def evaluate_candidates(model_name: str, fit, mothers: pd.DataFrame, events: pd.DataFrame, means: dict[str, float]) -> tuple[pd.DataFrame, pd.DataFrame, dict[int, list[float]], pd.DataFrame]:
    probs = mother_prob_matrix(model_name, fit, mothers, means)
    rows, fail_rows, best_by_k, best_grids = [], [], {}, []
    grid_values = cut_grid(mothers)
    lookup = interval_count_lookup(mothers, events, grid_values)
    for K in K_VALUES:
        scored = []
        for cuts in combinations(grid_values, K - 1):
            cuts = list(cuts)
            ok, reason = feasible_by_intervals(cuts, lookup)
            if ok:
                grid = summarize_grid(model_name, mothers, events, cuts, probs)
                rec = recommend(grid.assign(point_lcb=grid["p_group_mean"]), "point_lcb")
                rec_counts = rec[["group_id", "mother_count"]] if "mother_count" in rec.columns else grid.groupby("group_id")["mother_count"].first().reset_index()
                rec2 = rec.merge(rec_counts, on="group_id", how="left", suffixes=("", "_from_grid")) if "mother_count" not in rec.columns else rec.copy()
                weeks = pd.to_numeric(rec2["recommended_week"], errors="coerce")
                mother_weights = pd.to_numeric(rec2["mother_count"], errors="coerce").fillna(0)
                valid = weeks.notna()
                unresolved_mothers = int(mother_weights[~valid].sum())
                weighted_week = float(np.average(weeks[valid], weights=mother_weights[valid])) if valid.any() and mother_weights[valid].sum() > 0 else np.nan
                row = (
                    {
                        "K": K,
                        "cutpoints": ";".join(f"{c:.1f}" for c in cuts),
                        "count_constraints_passed": True,
                        "failed_reason": "",
                        "ok_group_count_point": int(rec["status"].eq("ok").sum()),
                        "undecided_group_count_point": int((rec["status"] != "ok").sum()),
                        "unresolved_mother_count_point": unresolved_mothers,
                        "weighted_mean_recommended_week_point": weighted_week,
                        "mean_total_risk_point_auxiliary": float(rec["total_risk"].mean()),
                        "latest_recommended_week_point": float(pd.to_numeric(rec["recommended_week"], errors="coerce").max()),
                        "min_p_group_at_decision_point": float(rec["p_group_mean"].min()),
                    }
                )
                scored.append(row)
                rows.append(row)
            else:
                fail_rows.append({"K": K, "failed_reason": reason if reason else "unknown"})
        if scored:
            best = pd.DataFrame(scored).sort_values(["unresolved_mother_count_point", "weighted_mean_recommended_week_point", "latest_recommended_week_point"]).iloc[0]
            cuts = [float(x) for x in str(best["cutpoints"]).split(";") if x]
            best_by_k[K] = cuts
            best_grids.append(summarize_grid(model_name, mothers, events, cuts, probs))
    return pd.DataFrame(rows), candidate_failure_summary(fail_rows), best_by_k, pd.concat(best_grids, ignore_index=True)


def add_bootstrap_lcb(point_grid: pd.DataFrame, boot_prob: pd.DataFrame) -> pd.DataFrame:
    if boot_prob.empty:
        out = point_grid.copy()
        out["bootstrap_lcb95"] = np.nan
        out["bootstrap_median"] = np.nan
        out["bootstrap_ucb95"] = np.nan
        out["bootstrap_ok_count"] = 0
        return out
    q = boot_prob.groupby(["K", "group_id", "week"])["p_group_mean"].agg(bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)), bootstrap_median=lambda s: float(np.percentile(s, 50)), bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)), bootstrap_ok_count="count").reset_index()
    return point_grid.merge(q, on=["K", "group_id", "week"], how="left")


def resample_mothers(events: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    base = events.reset_index(drop=True)
    ids = base["mother_id"].drop_duplicates().to_numpy()
    groups = {m: idx.to_numpy() for m, idx in base.groupby("mother_id").groups.items()}
    pieces = []
    for i, mid in enumerate(rng.choice(ids, size=len(ids), replace=True), 1):
        p = base.iloc[groups[mid]].copy()
        p["mother_id"] = f"{mid}__boot{i}"
        pieces.append(p)
    return pd.concat(pieces, ignore_index=True)


def build_mothers(events: pd.DataFrame) -> pd.DataFrame:
    cols = ["mother_id", "baseline_week", "baseline_bmi", "baseline_weight", "baseline_age", "baseline_height", "baseline_pregnancy_count", "baseline_birth_count", "assisted_reproduction_flag"]
    mothers = events.drop_duplicates("mother_id")[cols].copy()
    agg = events.groupby("mother_id", as_index=False).agg(event_count=("event_id", "count"), ever_reached_4pct=("y_ge_4pct", "max"))
    return mothers.merge(agg, on="mother_id", how="left")


DETECTION_SCENARIOS = [(SIGMA_M, k, f"kappa={k}") for k in KAPPA_GRID] + [(SIGMA_M_LOW, 1.0, "sigma_m_low"), (SIGMA_M_HIGH, 1.0, "sigma_m_high")]


def bootstrap_fixed(model_name: str, events: pd.DataFrame, cuts_by_k: dict[int, list[float]], n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    prob_rows, timing_rows, status_rows, det_rows = [], [], [], []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C3 fixed-cuts bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            means = compute_means(sample)
            sample = add_terms(sample, means)
            fit = fit_model(model_name, sample)
            if not bool(fit.converged):
                status_rows.append({"bootstrap_phase": "fixed_candidate", "bootstrap_id": b, "status": "not_converged", "converged": False, "note": fit.message})
                continue
            moms = build_mothers(sample)
            moms = add_terms(moms, means)
            probs = mother_prob_matrix(model_name, fit, moms, means)
            for K, cuts in cuts_by_k.items():
                grid = summarize_grid(model_name, moms, sample, cuts, probs)
                for _, row in grid.iterrows():
                    prob_rows.append({"bootstrap_id": b, "K": K, "group_id": int(row["group_id"]), "week": float(row["week"]), "p_group_mean": float(row["p_group_mean"])})
                rec = recommend(grid.assign(point_lcb=grid["p_group_mean"]), "point_lcb")
                for _, row in rec.iterrows():
                    timing_rows.append({"bootstrap_id": b, "K": K, "group_id": int(row["group_id"]), "status": row["status"], "recommended_week": row["recommended_week"], "at_25_boundary": row["at_25_boundary"]})
            for sigma_m, kappa, label in DETECTION_SCENARIOS:
                scen_probs = mother_prob_matrix(model_name, fit, moms, means, sigma_m=sigma_m, kappa=kappa)
                for K, cuts in cuts_by_k.items():
                    scen_grid = summarize_grid(model_name, moms, sample, cuts, scen_probs)
                    for _, row in scen_grid.iterrows():
                        det_rows.append({"bootstrap_id": b, "scenario": label, "sigma_m": sigma_m, "kappa": kappa, "K": K, "group_id": int(row["group_id"]), "week": float(row["week"]), "p_group_mean": float(row["p_group_mean"])})
            status_rows.append({"bootstrap_phase": "fixed_candidate", "bootstrap_id": b, "status": "ok", "converged": True, "note": ""})
        except Exception as exc:
            status_rows.append({"bootstrap_phase": "fixed_candidate", "bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})
    return pd.DataFrame(prob_rows), pd.DataFrame(timing_rows), pd.DataFrame(status_rows), pd.DataFrame(det_rows)


def bootstrap_boundary(model_name: str, events: pd.DataFrame, n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    rows = []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C3 K/cutpoint bootstrap {b}/{n_boot}", flush=True)
        try:
            sample = resample_mothers(events, rng)
            means = compute_means(sample)
            sample = add_terms(sample, means)
            fit = fit_model(model_name, sample)
            if not bool(fit.converged):
                rows.append({"bootstrap_phase": "boundary_stability", "bootstrap_id": b, "status": "not_converged", "converged": False, "note": fit.message})
                continue
            moms = add_terms(build_mothers(sample), means)
            cand, _, best_by_k, _ = evaluate_candidates(model_name, fit, moms, sample, means)
            valid = cand.dropna(subset=["weighted_mean_recommended_week_point"])
            if valid.empty:
                rows.append({"bootstrap_phase": "boundary_stability", "bootstrap_id": b, "status": "no_valid_candidate", "converged": True, "note": ""})
                continue
            best = valid.sort_values(["unresolved_mother_count_point", "weighted_mean_recommended_week_point", "latest_recommended_week_point", "K"]).iloc[0]
            rows.append({"bootstrap_phase": "boundary_stability", "bootstrap_id": b, "status": "ok", "converged": True, "K": int(best["K"]), "cutpoints": best["cutpoints"], "note": ""})
        except Exception as exc:
            rows.append({"bootstrap_phase": "boundary_stability", "bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})
    raw = pd.DataFrame(rows)
    ok = raw[raw["status"].eq("ok")]
    freq = ok.groupby(["K", "cutpoints"]).size().reset_index(name="selected_count") if not ok.empty else pd.DataFrame(columns=["K", "cutpoints", "selected_count"])
    if not freq.empty:
        freq["selected_frequency"] = freq["selected_count"] / len(ok)
    return raw, freq


def bootstrap_status_summary(status_frames: list[pd.DataFrame]) -> pd.DataFrame:
    status = pd.concat(status_frames, ignore_index=True)
    return status.groupby(["bootstrap_phase", "status"], dropna=False).size().reset_index(name="count")


def bootstrap_timing_summary(timing: pd.DataFrame, status: pd.DataFrame) -> pd.DataFrame:
    attempts = int(status["bootstrap_id"].nunique()) if not status.empty else 0
    strict = int(status["status"].eq("ok").sum()) if not status.empty else 0
    rows = []
    if timing.empty:
        return pd.DataFrame(columns=["K", "group_id", "bootstrap_attempts", "strict_converged_iterations", "valid_recommend_count", "no_feasible_ratio_among_converged", "recommended_week_median", "recommended_week_ci_low_2p5", "recommended_week_ci_high_97p5", "boundary_25_ratio_among_valid"])
    for (K, gid), sub in timing.groupby(["K", "group_id"], sort=True):
        valid_mask = pd.to_numeric(sub["recommended_week"], errors="coerce").notna()
        valid_sub = sub[valid_mask].copy()
        vals = pd.to_numeric(valid_sub["recommended_week"], errors="coerce").to_numpy(float)
        rows.append({"K": int(K), "group_id": int(gid), "bootstrap_attempts": attempts, "strict_converged_iterations": strict, "valid_recommend_count": int(len(vals)), "no_feasible_ratio_among_converged": float(1 - len(vals) / strict) if strict else np.nan, "recommended_week_median": float(np.percentile(vals, 50)) if len(vals) else np.nan, "recommended_week_ci_low_2p5": float(np.percentile(vals, 2.5)) if len(vals) else np.nan, "recommended_week_ci_high_97p5": float(np.percentile(vals, 97.5)) if len(vals) else np.nan, "boundary_25_ratio_among_valid": float(valid_sub["at_25_boundary"].astype(str).str.lower().eq("true").mean()) if len(vals) else np.nan})
    return pd.DataFrame(rows)


def k_compare(rec: pd.DataFrame, status: pd.DataFrame, cand: pd.DataFrame) -> pd.DataFrame:
    attempts = int(status["bootstrap_id"].nunique()) if not status.empty else 0
    strict = int(status["status"].eq("ok").sum()) if not status.empty else 0
    rows = []
    for K, sub in rec.groupby("K", sort=True):
        weeks = pd.to_numeric(sub["recommended_week"], errors="coerce")
        cutpoints = sub["cutpoints"].iloc[0]
        chosen = cand[(cand["K"].eq(K)) & (cand["cutpoints"].eq(cutpoints))]
        chosen_row = chosen.iloc[0].to_dict() if not chosen.empty else {}
        rows.append({"K": int(K), "cutpoints": cutpoints, "candidate_count_constraints_passed": int(cand[(cand["K"].eq(K)) & (cand["count_constraints_passed"].eq(True))].shape[0]), "bootstrap_attempts": attempts, "strict_converged_iterations": strict, "ok_group_count_lcb": int(sub["status"].eq("ok").sum()), "undecided_group_count_lcb": int((sub["status"] != "ok").sum()), "unresolved_mother_count_point_objective": chosen_row.get("unresolved_mother_count_point", np.nan), "weighted_mean_recommended_week_point_objective": chosen_row.get("weighted_mean_recommended_week_point", np.nan), "latest_recommended_week_among_ok": float(weeks.max()), "min_lcb_at_decision": float(pd.to_numeric(sub["bootstrap_lcb95"], errors="coerce").min()), "mean_total_risk_auxiliary": float(sub["total_risk"].mean()), "draft_note": "not frozen; grouping comparison prioritizes unresolved mother count and mother-count weighted timing, not unweighted group risk"})
    return pd.DataFrame(rows)


def runtime_summary(stage_rows: list[dict], bootstrap_n: int, boundary_bootstrap_n: int, cv_repeats: int) -> pd.DataFrame:
    stage = pd.DataFrame(stage_rows)
    rows = []
    for _, row in stage.iterrows():
        name = row["stage"]
        elapsed = float(row["elapsed_seconds"])
        rate = ""
        projected_1000_seconds = ""
        if name == "fixed_candidate_bootstrap" and bootstrap_n:
            rate = elapsed / bootstrap_n
            projected_1000_seconds = rate * 1000
        elif name == "boundary_bootstrap" and boundary_bootstrap_n:
            rate = elapsed / boundary_bootstrap_n
            projected_1000_seconds = rate * 1000
        elif name == "fixed_c2_k4_bootstrap_compare" and bootstrap_n:
            rate = elapsed / bootstrap_n
            projected_1000_seconds = rate * 1000
        rows.append(
            {
                "stage": name,
                "elapsed_seconds": elapsed,
                "elapsed_minutes": elapsed / 60,
                "iterations": bootstrap_n if name in {"fixed_candidate_bootstrap", "fixed_c2_k4_bootstrap_compare"} else boundary_bootstrap_n if name == "boundary_bootstrap" else "",
                "seconds_per_iteration": rate,
                "projected_1000_seconds": projected_1000_seconds,
                "projected_1000_minutes": projected_1000_seconds / 60 if projected_1000_seconds != "" else "",
                "cv_repeats": cv_repeats if name == "stratified_group_repeated_cv_model_comparison" else "",
            }
        )
    return pd.DataFrame(rows)


def technical_error() -> pd.DataFrame:
    rep = pd.read_csv(C1_TECH, encoding="utf-8-sig")
    n2 = int((pd.to_numeric(rep["tech_rep_n"], errors="coerce").fillna(0).astype(int) == 2).sum()) if "tech_rep_n" in rep else 18
    return pd.DataFrame([{"sigma_m": SIGMA_M, "sigma_m_ci_low": SIGMA_M_LOW, "sigma_m_ci_high": SIGMA_M_HIGH, "technical_repeat_event_count": n2, "source": "C1-v1.0 c1_technical_replicates.csv", "note": "沿用C2/C3任务单技术误差口径"}])


def detection_sensitivity(model_name: str, fit, mothers: pd.DataFrame, events: pd.DataFrame, means: dict[str, float], cuts_by_k: dict[int, list[float]], boot_detection: pd.DataFrame) -> pd.DataFrame:
    rows = []
    if boot_detection.empty:
        return pd.DataFrame(columns=["scenario", "sigma_m", "kappa", "K", "group_id", "bmi_interval", "status", "recommended_week", "p_group_mean", "bootstrap_lcb95", "bootstrap_ok_count", "note"])
    q = boot_detection.groupby(["scenario", "sigma_m", "kappa", "K", "group_id", "week"])["p_group_mean"].agg(bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)), bootstrap_ok_count="count").reset_index()
    for sigma_m, kappa, label in DETECTION_SCENARIOS:
        probs = mother_prob_matrix(model_name, fit, mothers, means, sigma_m=sigma_m, kappa=kappa)
        for K, cuts in cuts_by_k.items():
            grid = summarize_grid(model_name, mothers, events, cuts, probs)
            merged = grid.merge(q[q["scenario"].eq(label)], on=["K", "group_id", "week"], how="left", suffixes=("", "_boot"))
            rec = recommend(merged, "bootstrap_lcb95")
            for _, row in rec.iterrows():
                rows.append({"scenario": label, "sigma_m": sigma_m, "kappa": kappa, "K": K, "group_id": int(row["group_id"]), "bmi_interval": row["bmi_interval"], "status": row["status"], "recommended_week": row["recommended_week"], "p_group_mean": row["p_group_mean"], "bootstrap_lcb95": row["bootstrap_lcb95"], "bootstrap_ok_count": row.get("bootstrap_ok_count", np.nan), "note": "检测误差敏感性采用固定分组严格收敛bootstrap的组平均LCB95口径"})
    return pd.DataFrame(rows)


def covariate_definition_sensitivity(events: pd.DataFrame, mothers: pd.DataFrame, model_name: str, cuts_by_k: dict[int, list[float]]) -> pd.DataFrame:
    alt = events.copy()
    med = events.groupby("mother_id").agg(baseline_bmi=("bmi", "median"), baseline_weight=("weight", "median"), baseline_age=("age", "median"), baseline_height=("height", "median"), baseline_pregnancy_count=("pregnancy_count_num", "median"), baseline_birth_count=("birth_count_num", "median"), assisted_reproduction_flag=("assisted_reproduction_flag", "max")).reset_index()
    alt = alt.drop(columns=["baseline_bmi", "baseline_weight", "baseline_age", "baseline_height", "baseline_pregnancy_count", "baseline_birth_count"], errors="ignore").merge(med, on="mother_id", how="left")
    if "assisted_reproduction_flag_x" in alt.columns:
        alt["assisted_reproduction_flag"] = alt["assisted_reproduction_flag_y"].fillna(alt["assisted_reproduction_flag_x"])
        alt = alt.drop(columns=["assisted_reproduction_flag_x", "assisted_reproduction_flag_y"], errors="ignore")
    means = compute_means(alt)
    alt = add_terms(alt, means)
    fit = fit_model(model_name, alt)
    moms = add_terms(build_mothers(alt), means)
    probs = mother_prob_matrix(model_name, fit, moms, means)
    rows = []
    for K, cuts in cuts_by_k.items():
        rec = recommend(summarize_grid(model_name, moms, alt, cuts, probs).assign(point_lcb=lambda d: d["p_group_mean"]), "point_lcb")
        for _, row in rec.iterrows():
            rows.append({"covariate_definition": "within_mother_median_or_mode", "K": K, "group_id": int(row["group_id"]), "status": row["status"], "recommended_week_point": row["recommended_week"], "p_group_mean": row["p_group_mean"], "converged": bool(fit.converged)})
    return pd.DataFrame(rows)


def fit_logistic(events: pd.DataFrame, terms: list[str]):
    df = events.dropna(subset=["y_ge_4pct"] + terms).copy()
    X = design(df, terms)
    y = df["y_ge_4pct"].astype(float).to_numpy()

    def nll(beta):
        p = np.clip(expit(X @ beta), 1e-6, 1 - 1e-6)
        return float(-np.sum(y * np.log(p) + (1 - y) * np.log(1 - p)) + 1e-6 * np.sum(beta[1:] ** 2))

    start = np.zeros(X.shape[1])
    start[0] = logit(np.clip(y.mean(), 1e-6, 1 - 1e-6))
    res = optimize.minimize(nll, start, method="L-BFGS-B", bounds=[(None, None)] + [(0, None) if t == "week_c" else (None, None) for t in terms], options={"maxiter": 1000})
    return {"beta": res.x, "terms": terms, "converged": bool(res.success), "message": str(res.message)}


def binary_sensitivity(events: pd.DataFrame, mothers: pd.DataFrame, means: dict[str, float], selected_model: str, cuts_by_k: dict[int, list[float]], n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    terms = MODEL_SPECS[selected_model]["terms"]
    fit = fit_logistic(events, terms)
    rng = np.random.default_rng(seed)
    boot_rows, status_rows = [], []
    for b in range(1, n_boot + 1):
        try:
            sample = resample_mothers(events, rng)
            b_means = compute_means(sample)
            sample = add_terms(sample, b_means)
            b_fit = fit_logistic(sample, terms)
            if not b_fit["converged"]:
                status_rows.append({"bootstrap_phase": "binary_cluster_logit", "bootstrap_id": b, "status": "not_converged", "converged": False, "note": b_fit["message"]})
                continue
            moms = add_terms(build_mothers(sample), b_means)
            for K, cuts in cuts_by_k.items():
                blocks = []
                for week in WEEK_GRID:
                    d = moms.copy()
                    d["week_num"] = week
                    d = add_terms(d, b_means)
                    blocks.append(expit(design(d, terms) @ b_fit["beta"]))
                grid = summarize_grid("binary_cluster_logit_sensitivity", moms, sample, cuts, np.column_stack(blocks))
                for _, row in grid.iterrows():
                    boot_rows.append({"bootstrap_id": b, "K": K, "group_id": int(row["group_id"]), "week": float(row["week"]), "p_group_mean": float(row["p_group_mean"])})
            status_rows.append({"bootstrap_phase": "binary_cluster_logit", "bootstrap_id": b, "status": "ok", "converged": True, "note": ""})
        except Exception as exc:
            status_rows.append({"bootstrap_phase": "binary_cluster_logit", "bootstrap_id": b, "status": "failed", "converged": False, "note": str(exc)})
    boot = pd.DataFrame(boot_rows)
    if boot.empty:
        lcb = pd.DataFrame(columns=["K", "group_id", "week", "bootstrap_lcb95", "bootstrap_ok_count"])
    else:
        lcb = boot.groupby(["K", "group_id", "week"])["p_group_mean"].agg(bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)), bootstrap_ok_count="count").reset_index()
    rows = []
    for K, cuts in cuts_by_k.items():
        blocks = []
        for week in WEEK_GRID:
            d = mothers.copy()
            d["week_num"] = week
            d = add_terms(d, means)
            p = expit(design(d, terms) @ fit["beta"])
            blocks.append(p)
        probs = np.column_stack(blocks)
        point = summarize_grid("binary_cluster_logit_sensitivity", mothers, events, cuts, probs)
        point = point.merge(lcb[lcb["K"].eq(K)], on=["K", "group_id", "week"], how="left")
        rec = recommend(point, "bootstrap_lcb95")
        for _, row in rec.iterrows():
            rows.append({"model_type": "binary_cluster_logit_sensitivity", "cluster_method": "mother_cluster_bootstrap_logit", "K": K, "group_id": int(row["group_id"]), "status": row["status"], "recommended_week": row["recommended_week"], "p_group_mean": row["p_group_mean"], "bootstrap_lcb95": row["bootstrap_lcb95"], "bootstrap_ok_count": row.get("bootstrap_ok_count", np.nan), "point_fit_converged": fit["converged"], "point_fit_message": fit["message"]})
    return pd.DataFrame(rows), pd.DataFrame(status_rows)


def fixed_c2_k4_results(model_name: str, fit, mothers: pd.DataFrame, events: pd.DataFrame, means: dict[str, float], n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    cuts = [29.5, 31.5, 34.5]
    probs = mother_prob_matrix(model_name, fit, mothers, means)
    point = summarize_grid(model_name, mothers, events, cuts, probs)
    boot_prob, boot_timing, boot_status, _ = bootstrap_fixed(model_name, events, {4: cuts}, n_boot, seed)
    lcb = add_bootstrap_lcb(point, boot_prob)
    rec = recommend(lcb, "bootstrap_lcb95")
    return lcb, rec, boot_timing, boot_status


def compare_c2(fixed_c2_rec: pd.DataFrame) -> pd.DataFrame:
    c2_path = ROOT / "results" / "C2-v1.0" / "12_k4_handoff" / "c2_k4_main_recommended_timing.csv"
    if not c2_path.exists():
        return pd.DataFrame([{"note": "C2 main recommended timing file not found"}])
    c2 = pd.read_csv(c2_path, encoding="utf-8-sig")
    c3 = fixed_c2_rec.copy()
    c3["join_key"] = c3["bmi_interval"].astype(str) + "|" + c3["cutpoints"].astype(str)
    c2["join_key"] = c2["bmi_interval"].astype(str) + "|" + c2["cutpoints"].astype(str)
    out = c3[["K", "group_id", "bmi_interval", "cutpoints", "status", "recommended_week", "join_key"]].merge(
        c2[["bmi_interval", "cutpoints", "recommended_week", "status", "join_key"]],
        on="join_key",
        how="left",
        suffixes=("_c3", "_c2"),
    )
    out["comparison_basis"] = "fixed_C2_K4_cutpoints_same_bmi_interval"
    out["week_delta_c3_minus_c2"] = pd.to_numeric(out["recommended_week_c3"], errors="coerce") - pd.to_numeric(out["recommended_week_c2"], errors="coerce")
    return out


def make_figures(coeffs: pd.DataFrame, prob: pd.DataFrame, rec: pd.DataFrame, sens: pd.DataFrame, boundary_freq: pd.DataFrame, c2cmp: pd.DataFrame) -> None:
    FIG_DATA_DIR.mkdir(parents=True, exist_ok=True)
    setup_style()
    selected_coeffs = coeffs[coeffs["model"].eq(coeffs["model"].iloc[0])].copy() if not coeffs.empty else coeffs
    coeffs.to_csv(FIG_DATA_DIR / "c3_fig01_coefficients_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4))
    plot_df = coeffs[coeffs["term"].ne("Intercept")].copy()
    if not plot_df.empty:
        plot_df["label"] = plot_df["model"] + ":" + plot_df["term"]
        y = np.arange(len(plot_df))
        ax.errorbar(plot_df["coefficient"], y, xerr=[plot_df["coefficient"] - plot_df["ci_low"], plot_df["ci_high"] - plot_df["coefficient"]], fmt="o", color="#2F6F73", ecolor="#C49A46", capsize=2)
        ax.axvline(0, color="#777777", lw=1)
        ax.set_yticks(y)
        ax.set_yticklabels(plot_df["label"], fontsize=6)
    ax.set_title("C3候选模型固定效应估计")
    ax.set_xlabel("系数估计及95%CI")
    fig.tight_layout()
    savefig(fig, "c3_fig01_covariate_effects")

    prob.to_csv(FIG_DATA_DIR / "c3_fig02_probability_curves_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4))
    show = prob[prob["K"].eq(prob["K"].min())].copy()
    for gid, sub in show.groupby("group_id"):
        ax.plot(sub["week"], sub["p_group_mean"], lw=1.8, label=f"第{gid}组")
        if "bootstrap_lcb95" in sub:
            ax.plot(sub["week"], sub["bootstrap_lcb95"], lw=1, ls="--", alpha=0.75)
    ax.axhline(Q_MAIN, color="#A63D40", lw=1.2, ls=":")
    ax.set_title("组平均达标概率与bootstrap下界")
    ax.set_xlabel("孕周")
    ax.set_ylabel("概率")
    ax.legend(ncol=2, fontsize=7)
    fig.tight_layout()
    savefig(fig, "c3_fig02_probability_lcb_curves")

    rec.to_csv(FIG_DATA_DIR / "c3_fig03_k_timing_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4))
    ok = rec.copy()
    ok["x"] = ok["K"].astype(str) + "-G" + ok["group_id"].astype(str)
    vals = pd.to_numeric(ok["recommended_week"], errors="coerce")
    colors = np.where(ok["status"].eq("ok"), "#3B8C7A", "#B75D69")
    ax.bar(ok["x"], vals.fillna(25), color=colors, width=0.72)
    ax.set_title("K=3/4/5分组推荐时点草案")
    ax.set_xlabel("K与组别")
    ax.set_ylabel("推荐孕周；未决按25周显示")
    ax.tick_params(axis="x", labelrotation=45)
    fig.tight_layout()
    savefig(fig, "c3_fig03_k_timing_compare")

    sens.to_csv(FIG_DATA_DIR / "c3_fig04_detection_error_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4))
    ss = sens[sens["scenario"].astype(str).str.startswith("kappa=")].copy()
    if not ss.empty:
        ss["kappa_value"] = pd.to_numeric(ss["kappa"], errors="coerce")
        for (K, gid), sub in ss.groupby(["K", "group_id"]):
            ax.plot(sub["kappa_value"], pd.to_numeric(sub["recommended_week_point"], errors="coerce"), marker="o", lw=1.2, label=f"K{K}-G{gid}")
    ax.set_title("检测误差倍数敏感性")
    ax.set_xlabel("kappa")
    ax.set_ylabel("点估计推荐孕周")
    ax.legend(fontsize=6, ncol=3)
    fig.tight_layout()
    savefig(fig, "c3_fig04_detection_error_sensitivity")

    boundary_freq.to_csv(FIG_DATA_DIR / "c3_fig05_boundary_stability_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 4))
    if not boundary_freq.empty:
        bf = boundary_freq.sort_values("selected_count", ascending=True).tail(12)
        ax.barh(bf["K"].astype(str) + ":" + bf["cutpoints"], bf["selected_count"], color="#6E7F3F")
    ax.set_title("K与切点bootstrap选择频率")
    ax.set_xlabel("选择次数")
    fig.tight_layout()
    savefig(fig, "c3_fig05_boundary_stability")

    c2cmp.to_csv(FIG_DATA_DIR / "c3_fig06_c2_c3_compare_source.csv", index=False, encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 3.8))
    if "recommended_week_c2" in c2cmp:
        y = np.arange(len(c2cmp))
        ax.scatter(pd.to_numeric(c2cmp["recommended_week_c2"], errors="coerce"), y, color="#C49A46", label="C2")
        ax.scatter(pd.to_numeric(c2cmp["recommended_week_c3"], errors="coerce"), y, color="#2F6F73", label="C3")
        for i, row in c2cmp.iterrows():
            ax.plot([pd.to_numeric(row["recommended_week_c2"], errors="coerce"), pd.to_numeric(row["recommended_week_c3"], errors="coerce")], [i, i], color="#999999", lw=1)
        ax.set_yticks(y)
        ax.set_yticklabels(c2cmp["bmi_interval"])
        ax.legend()
    ax.set_title("C2与C3固定K4推荐时点对照")
    ax.set_xlabel("孕周")
    fig.tight_layout()
    savefig(fig, "c3_fig06_c2_c3_timing_compare")


def write_handoff(decision: dict, summary: pd.DataFrame, ksum: pd.DataFrame, status_sum: pd.DataFrame, rec: pd.DataFrame, boundary_freq: pd.DataFrame) -> None:
    selected = decision["selected_model"]
    high = rec[rec["status"].ne("ok")]
    text = f"""# C3第一轮结果包交付说明_v0.1

状态：draft，未冻结，仅供建模手复核；不得交论文手写正文。

## 本轮口径
- 输入：仅使用 C1-v1.0 冻结文件，哈希已逐项核验。
- 主模型：LMM派生达标概率候选模型，按重复StratifiedGroupKFold的Brier与one-SE规则暂选；二项logit和M4随机斜率进入概率模型比较。
- 分组：重新比较 K=3、4、5；C2 K4只作为对照，不继承为C3结论。
- 可靠性：严格收敛孕妇簇bootstrap的组平均概率2.5%分位数，约束为LCB95>=0.90。
- 状态：全部输出标记为draft，不自动冻结K或切点。

## 初步回答
1. one-SE规则当前选择：{selected}。
2. 概率模型比较：见 `c3_model_comparison.csv`，当前只可作为中审依据，暂不写成正式结论。
3. K=3/4/5可行情况：见 `c3_k_compare_summary.csv`。
4. 切点稳定性：见 `c3_boundary_stability_frequency.csv`，不要只引用单次最优切点。
5. C3相对C2变化：见 `c3_vs_c2_comparison.csv`。
6. 最高BMI组状态：若 `c3_recommended_timing.csv` 中最高组为 `undecided_25w_reliability`，应列为25周内可靠性未决。
7. 检测误差影响：见 `c3_detection_error_sensitivity.csv`。
8. bootstrap收敛：见 `c3_bootstrap_status_summary.csv`。

## 主要文件
- `c3_model_comparison.csv`
- `c3_k_compare_summary.csv`
- `c3_reach_probability_by_group_week.csv`
- `c3_recommended_timing.csv`
- `c3_bootstrap_status.csv`
- `c3_bootstrap_timing_summary.csv`
- `c3_boundary_stability_frequency.csv`
- `c3_run_manifest.json`
"""
    (OUT_DIR / "C3第一轮结果包交付说明_v0.1.md").write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--boundary-bootstrap", type=int, default=1000)
    parser.add_argument("--cv-repeats", type=int, default=10)
    parser.add_argument("--cv-seed", type=int, default=3301)
    parser.add_argument("--fixed-bootstrap-seed", type=int, default=3302)
    parser.add_argument("--boundary-bootstrap-seed", type=int, default=3303)
    args = parser.parse_args()
    t0 = time.time()
    stage_rows = []

    def mark(stage: str, start: float) -> None:
        stage_rows.append({"stage": stage, "elapsed_seconds": round(time.time() - start, 3)})

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for child in OUT_DIR.iterdir():
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            shutil.rmtree(child)
    CODE_DIR.mkdir(parents=True, exist_ok=True)
    if FIG_DIR.exists():
        shutil.rmtree(FIG_DIR)
    if FIG_DATA_DIR.exists():
        shutil.rmtree(FIG_DATA_DIR)

    s = time.time()
    input_hashes = verify_inputs()
    events, mothers, means = load_events()
    mark("input_hash_and_load", s)
    input_hashes.to_csv(OUT_DIR / "c3_input_hashes.csv", index=False, encoding="utf-8-sig")
    c2_refs = c2_reference_inputs()
    c2_refs.to_csv(OUT_DIR / "c3_c2_reference_inputs.csv", index=False, encoding="utf-8-sig")
    sample_audit(events, mothers).to_csv(OUT_DIR / "c3_sample_audit.csv", index=False, encoding="utf-8-sig")
    covariate_audit(events, mothers).to_csv(OUT_DIR / "c3_baseline_covariate_audit.csv", index=False, encoding="utf-8-sig")
    collinearity(mothers).to_csv(OUT_DIR / "c3_collinearity.csv", index=False, encoding="utf-8-sig")
    technical_error().to_csv(OUT_DIR / "c3_technical_error.csv", index=False, encoding="utf-8-sig")

    s = time.time()
    cv_summary, cv_folds, cv_preds, cv_assignments, decision = cross_validate(events, args.cv_seed, repeats=args.cv_repeats)
    mark("stratified_group_repeated_cv_model_comparison", s)
    s = time.time()
    fits, fit_metrics, coeffs, full_means = fit_full_models(events)
    mark("full_model_fit", s)
    selected_model = str(decision["selected_model"])
    model_comp = cv_summary.merge(fit_metrics, on="model", how="left")
    model_comp["one_se_selected"] = model_comp["model"].eq(selected_model)
    model_comp["selection_note"] = decision["selection_rule"]
    model_comp.to_csv(OUT_DIR / "c3_model_comparison.csv", index=False, encoding="utf-8-sig")
    coeffs.to_csv(OUT_DIR / "c3_model_coefficients.csv", index=False, encoding="utf-8-sig")
    standardized_effects(add_terms(events, full_means), coeffs).to_csv(OUT_DIR / "c3_standardized_effects.csv", index=False, encoding="utf-8-sig")
    if "M2" in fits:
        m2_monotonicity_check(fits["M2"], mothers, full_means).to_csv(OUT_DIR / "c3_M2_monotonicity_check.csv", index=False, encoding="utf-8-sig")
    cv_folds.to_csv(OUT_DIR / "c3_cv_fold_results.csv", index=False, encoding="utf-8-sig")
    cv_preds.to_csv(OUT_DIR / "c3_cv_event_predictions.csv", index=False, encoding="utf-8-sig")
    cv_assignments.to_csv(OUT_DIR / "c3_cv_mother_fold_assignments.csv", index=False, encoding="utf-8-sig")

    fit = fits[selected_model]
    s = time.time()
    candidate_df, candidate_fail_summary, best_by_k, point_grid = evaluate_candidates(selected_model, fit, mothers, events, full_means)
    mark("candidate_search_point", s)
    candidate_df.to_csv(OUT_DIR / "c3_group_candidates.csv", index=False, encoding="utf-8-sig")
    candidate_fail_summary.to_csv(OUT_DIR / "c3_group_candidate_failure_summary.csv", index=False, encoding="utf-8-sig")
    c2_k4 = [29.5, 31.5, 34.5]
    if 4 not in best_by_k:
        best_by_k[4] = c2_k4

    s = time.time()
    boot_prob, boot_timing, boot_status, boot_detection = bootstrap_fixed(selected_model, events, best_by_k, args.bootstrap, args.fixed_bootstrap_seed)
    mark("fixed_candidate_bootstrap", s)
    boot_prob.to_csv(OUT_DIR / "c3_bootstrap_raw_probability.csv", index=False, encoding="utf-8-sig")
    boot_timing.to_csv(OUT_DIR / "c3_bootstrap_raw_timing.csv", index=False, encoding="utf-8-sig")
    boot_status.to_csv(OUT_DIR / "c3_bootstrap_status.csv", index=False, encoding="utf-8-sig")
    boot_detection.to_csv(OUT_DIR / "c3_detection_error_bootstrap_raw_probability.csv", index=False, encoding="utf-8-sig")
    prob_lcb = add_bootstrap_lcb(point_grid, boot_prob)
    rec = []
    for K, sub in prob_lcb.groupby("K", sort=True):
        rec.append(recommend(sub, "bootstrap_lcb95"))
    rec_df = pd.concat(rec, ignore_index=True)
    prob_lcb.to_csv(OUT_DIR / "c3_reach_probability_by_group_week.csv", index=False, encoding="utf-8-sig")
    rec_df.to_csv(OUT_DIR / "c3_recommended_timing.csv", index=False, encoding="utf-8-sig")
    k_compare(rec_df, boot_status, candidate_df).to_csv(OUT_DIR / "c3_k_compare_summary.csv", index=False, encoding="utf-8-sig")
    bootstrap_timing_summary(boot_timing, boot_status).to_csv(OUT_DIR / "c3_bootstrap_timing_summary.csv", index=False, encoding="utf-8-sig")

    s = time.time()
    boundary_raw, boundary_freq = bootstrap_boundary(selected_model, events, args.boundary_bootstrap, args.boundary_bootstrap_seed)
    mark("boundary_bootstrap", s)
    boundary_raw.to_csv(OUT_DIR / "c3_boundary_stability_raw.csv", index=False, encoding="utf-8-sig")
    boundary_freq.to_csv(OUT_DIR / "c3_boundary_stability_frequency.csv", index=False, encoding="utf-8-sig")

    s = time.time()
    fixed_c2_grid, fixed_c2_rec, fixed_c2_timing, fixed_c2_status = fixed_c2_k4_results(selected_model, fit, mothers, events, full_means, args.bootstrap, args.fixed_bootstrap_seed + 10000)
    mark("fixed_c2_k4_bootstrap_compare", s)
    fixed_c2_grid.to_csv(OUT_DIR / "c3_fixed_C2_K4_reach_probability_by_group_week.csv", index=False, encoding="utf-8-sig")
    fixed_c2_rec.to_csv(OUT_DIR / "c3_fixed_C2_K4_recommended_timing.csv", index=False, encoding="utf-8-sig")
    fixed_c2_status.to_csv(OUT_DIR / "c3_fixed_C2_K4_bootstrap_status.csv", index=False, encoding="utf-8-sig")

    detection_sensitivity(selected_model, fit, mothers, events, full_means, best_by_k, boot_detection).to_csv(OUT_DIR / "c3_detection_error_sensitivity.csv", index=False, encoding="utf-8-sig")
    covariate_definition_sensitivity(events, mothers, selected_model, best_by_k).to_csv(OUT_DIR / "c3_covariate_definition_sensitivity.csv", index=False, encoding="utf-8-sig")
    binary_df, binary_status = binary_sensitivity(events, mothers, full_means, selected_model, best_by_k, args.bootstrap, args.fixed_bootstrap_seed + 20000)
    binary_df.to_csv(OUT_DIR / "c3_binary_model_sensitivity.csv", index=False, encoding="utf-8-sig")
    binary_status.to_csv(OUT_DIR / "c3_binary_model_bootstrap_status.csv", index=False, encoding="utf-8-sig")
    m4_df, m4_rec = m4_random_slope_sensitivity(add_terms(events, full_means), mothers, full_means, best_by_k)
    m4_df.to_csv(OUT_DIR / "c3_M4_random_slope_sensitivity.csv", index=False, encoding="utf-8-sig")
    m4_rec.to_csv(OUT_DIR / "c3_M4_recommended_timing_sensitivity.csv", index=False, encoding="utf-8-sig")
    c2cmp = compare_c2(fixed_c2_rec)
    c2cmp.to_csv(OUT_DIR / "c3_vs_c2_comparison.csv", index=False, encoding="utf-8-sig")

    status_sum = bootstrap_status_summary([boot_status, boundary_raw, fixed_c2_status.assign(bootstrap_phase="fixed_c2_k4"), binary_status])
    status_sum.to_csv(OUT_DIR / "c3_bootstrap_status_summary.csv", index=False, encoding="utf-8-sig")
    stage_rows.append({"stage": "total_before_manifest", "elapsed_seconds": round(time.time() - t0, 3)})
    pd.DataFrame(stage_rows).to_csv(OUT_DIR / "c3_stage_timing.csv", index=False, encoding="utf-8-sig")
    runtime = runtime_summary(stage_rows, args.bootstrap, args.boundary_bootstrap, args.cv_repeats)
    runtime.to_csv(OUT_DIR / "c3_runtime_summary.csv", index=False, encoding="utf-8-sig")

    shutil.copy2(Path(__file__), CODE_DIR / Path(__file__).name)
    shutil.copy2(C1_CODE, CODE_DIR / C1_CODE.name)
    manifest = {
        "status": "draft",
        "task": "C3 first-round modeling calculation",
        "run_command": "python problem_c_nipt/code/c3_first_round.py --bootstrap {} --boundary-bootstrap {} --cv-repeats {}".format(args.bootstrap, args.boundary_bootstrap, args.cv_repeats),
        "input_hashes": input_hashes.to_dict(orient="records"),
        "c2_reference_inputs": c2_refs.to_dict(orient="records"),
        "selected_model": selected_model,
        "decision": decision,
        "seeds": {"cv": args.cv_seed, "fixed_grouping_bootstrap": args.fixed_bootstrap_seed, "boundary_bootstrap": args.boundary_bootstrap_seed, "detection_error_sensitivity": "computed inside fixed_grouping_bootstrap strict converged iterations; no independent RNG"},
        "bootstrap_n": args.bootstrap,
        "boundary_bootstrap_n": args.boundary_bootstrap,
        "cv_repeats": args.cv_repeats,
        "cv_folds_per_repeat": 5,
        "figures_generated": False,
        "python": sys.version,
        "platform": platform.platform(),
        "packages": {"numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__, "matplotlib": matplotlib.__version__},
        "elapsed_seconds": round(time.time() - t0, 3),
        "note": "C3未冻结，不修改C1/C2，不启动C4。",
    }
    (OUT_DIR / "c3_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    write_handoff(decision, model_comp, pd.read_csv(OUT_DIR / "c3_k_compare_summary.csv", encoding="utf-8-sig"), status_sum, rec_df, boundary_freq)
    files = []
    for p in sorted(OUT_DIR.rglob("*")):
        if p.is_file() and p.name != "C3-v0.1第一轮文件索引.csv":
            files.append({"relative_path": str(p.relative_to(OUT_DIR)).replace("\\", "/"), "bytes": p.stat().st_size, "sha256": sha256(p)})
    pd.DataFrame(files).to_csv(OUT_DIR / "C3-v0.1第一轮文件索引.csv", index=False, encoding="utf-8-sig")
    print(f"C3 first-round draft outputs written to {OUT_DIR}")


if __name__ == "__main__":
    main()
