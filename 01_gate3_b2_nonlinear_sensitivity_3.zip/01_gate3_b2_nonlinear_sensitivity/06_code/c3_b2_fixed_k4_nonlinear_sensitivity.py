from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels

import c3_first_round as c3
import c3_binary_model_selection_patch as sel


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "results" / "C3-v1.0" / "01_gate3_b2_nonlinear_sensitivity"
CODE_DIR = OUT_DIR / "06_code"

MODEL = "B2"
CORR = "independence"
K4_CUTS = [29.5, 31.5, 34.5]
Q_VALUES = [0.80, 0.85, 0.90, 0.95]
WEEK_GRID = c3.WEEK_GRID

B1_LCB_PATH = ROOT / "results" / "C3-v1.0" / "00_frozen" / "04_fixed_k4_decision" / "raw_hard_label" / "c3_B1_fixed_K4_probability_bootstrap_lcb.csv"
B1_REC_PATH = ROOT / "results" / "C3-v1.0" / "00_frozen" / "04_fixed_k4_decision" / "raw_hard_label" / "c3_B1_fixed_K4_threshold_sensitivity_bootstrap_lcb.csv"
B1_STATUS_PATH = ROOT / "results" / "C3-v1.0" / "00_frozen" / "04_fixed_k4_decision" / "raw_hard_label" / "c3_B1_fixed_K4_bootstrap_status_summary.csv"
C3_FROZEN_MANIFEST = ROOT / "results" / "C3-v1.0" / "00_frozen" / "c3_v1_frozen_manifest.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def group_bounds(mothers: pd.DataFrame, cuts: list[float]) -> list[tuple[float, float]]:
    lo = math.floor(float(mothers["baseline_bmi"].min()) * 2) / 2
    hi = math.ceil(float(mothers["baseline_bmi"].max()) * 2) / 2 + 0.5
    edges = [lo] + cuts + [hi]
    return [(float(edges[i]), float(edges[i + 1])) for i in range(len(edges) - 1)]


def group_label(lo: float, hi: float, last: bool) -> str:
    return f"[{lo:.1f}, {hi:.1f}{']' if last else ')'}"


def assign_groups(bmi: np.ndarray, cuts: list[float]) -> np.ndarray:
    return np.searchsorted(np.asarray(cuts, dtype=float), np.asarray(bmi, dtype=float), side="right")


def prediction_frame(mothers: pd.DataFrame, week: float, means: dict[str, float]) -> pd.DataFrame:
    df = mothers.copy()
    df["week_num"] = float(week)
    return c3.add_terms(df, means)


def group_probability_grid(fit: sel.GEEBinaryFit, mothers: pd.DataFrame, means: dict[str, float], cuts: list[float]) -> pd.DataFrame:
    grouped = mothers.copy()
    grouped["group_id0"] = assign_groups(grouped["baseline_bmi"].to_numpy(float), cuts)
    bounds = group_bounds(mothers, cuts)
    rows = []
    for gid in range(len(cuts) + 1):
        gm = grouped[grouped["group_id0"].eq(gid)].copy()
        if gm.empty:
            continue
        for week in WEEK_GRID:
            pred = prediction_frame(gm, float(week), means)
            probs = sel.predict_fit(fit, pred)
            rows.append(
                {
                    "model": fit.model,
                    "corr_structure": fit.corr_structure,
                    "sensitivity_type": "nonlinear_sensitivity",
                    "K": 4,
                    "cutpoints": ";".join(f"{x:.1f}" for x in cuts),
                    "group_id": gid + 1,
                    "bmi_interval": group_label(bounds[gid][0], bounds[gid][1], gid == len(cuts)),
                    "week": float(week),
                    "p_group_mean": float(np.mean(probs)),
                    "individual_p_min": float(np.min(probs)),
                    "individual_p_q10": float(np.percentile(probs, 10)),
                    "individual_p_median": float(np.percentile(probs, 50)),
                    "individual_share_ge_0p90": float(np.mean(probs >= 0.90)),
                    "mother_count": int(len(gm)),
                    "note": "fixed C2/C3 K4 cutpoints; B2 nonlinear GEE decision-layer sensitivity",
                }
            )
    return pd.DataFrame(rows)


def fixed_k4_bootstrap(events: pd.DataFrame, n_boot: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(seed)
    prob_rows, status_rows = [], []
    for b in range(1, n_boot + 1):
        if b == 1 or b % 100 == 0:
            print(f"C3 B2 fixed-K4 nonlinear bootstrap {b}/{n_boot}", flush=True)
        sample = c3.resample_mothers(events, rng)
        means = c3.compute_means(sample)
        sample = c3.add_terms(sample, means)
        sample_mothers = c3.build_mothers(sample)
        try:
            fit = sel.fit_gee_binary(sample, MODEL, CORR)
            if not fit.converged:
                status_rows.append(
                    {
                        "bootstrap_id": b,
                        "model": MODEL,
                        "corr_structure": CORR,
                        "status": "not_converged",
                        "converged": False,
                        "iterations": fit.iterations,
                        "alpha": fit.alpha,
                        "note": fit.message,
                    }
                )
                continue
            grid = group_probability_grid(fit, sample_mothers, means, K4_CUTS)
            for _, row in grid.iterrows():
                prob_rows.append(
                    {
                        "bootstrap_id": b,
                        "model": MODEL,
                        "corr_structure": CORR,
                        "K": 4,
                        "group_id": int(row["group_id"]),
                        "week": float(row["week"]),
                        "p_group_mean": float(row["p_group_mean"]),
                    }
                )
            status_rows.append(
                {
                    "bootstrap_id": b,
                    "model": MODEL,
                    "corr_structure": CORR,
                    "status": "ok",
                    "converged": True,
                    "iterations": fit.iterations,
                    "alpha": fit.alpha,
                    "note": fit.message,
                }
            )
        except Exception as exc:
            status_rows.append(
                {
                    "bootstrap_id": b,
                    "model": MODEL,
                    "corr_structure": CORR,
                    "status": "failed",
                    "converged": False,
                    "iterations": "",
                    "alpha": "",
                    "note": str(exc),
                }
            )
    return pd.DataFrame(prob_rows), pd.DataFrame(status_rows)


def add_bootstrap_lcb(point: pd.DataFrame, boot: pd.DataFrame) -> pd.DataFrame:
    quant = (
        boot.groupby(["model", "corr_structure", "K", "group_id", "week"])["p_group_mean"]
        .agg(
            bootstrap_lcb95=lambda s: float(np.percentile(s, 2.5)),
            bootstrap_median=lambda s: float(np.percentile(s, 50)),
            bootstrap_ucb95=lambda s: float(np.percentile(s, 97.5)),
            bootstrap_ok_count="count",
        )
        .reset_index()
    )
    return point.merge(quant, on=["model", "corr_structure", "K", "group_id", "week"], how="left")


def threshold_recommendation(grid: pd.DataFrame) -> pd.DataFrame:
    rows = []
    work = grid.copy()
    work["fail_risk"] = 1.0 - work["p_group_mean"].astype(float)
    work["time_risk"] = np.where(work["week"].astype(float) <= 12.0, 0.0, (work["week"].astype(float) - 12.0) / 13.0)
    work["total_risk"] = work["fail_risk"] + work["time_risk"]
    for (model, corr, q, gid), sub in (
        work.assign(_key=1)
        .merge(pd.DataFrame({"reliability_threshold_q": Q_VALUES, "_key": 1}), on="_key")
        .drop(columns="_key")
        .groupby(["model", "corr_structure", "reliability_threshold_q", "group_id"], sort=True)
    ):
        sub = sub.sort_values("week")
        feasible = sub[sub["bootstrap_lcb95"] >= q]
        if feasible.empty:
            ref = sub.iloc[-1]
            rows.append(
                {
                    "model": model,
                    "corr_structure": corr,
                    "sensitivity_type": "nonlinear_sensitivity",
                    "reliability_threshold_q": q,
                    "K": 4,
                    "cutpoints": ref["cutpoints"],
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "status": "undecided_25w_reliability",
                    "recommended_week": np.nan,
                    "p_group_mean": float(ref["p_group_mean"]),
                    "bootstrap_lcb95": float(ref["bootstrap_lcb95"]),
                    "fail_risk": float(ref["fail_risk"]),
                    "time_risk": float(ref["time_risk"]),
                    "total_risk": float(ref["total_risk"]),
                    "individual_p_min": float(ref["individual_p_min"]),
                    "individual_p_q10": float(ref["individual_p_q10"]),
                    "individual_p_median": float(ref["individual_p_median"]),
                    "individual_share_ge_0p90": float(ref["individual_share_ge_0p90"]),
                    "note": "LCB threshold not reached by 25w; do not force 25w as recommendation",
                }
            )
        else:
            ref = feasible.sort_values(["total_risk", "week"]).iloc[0]
            rows.append(
                {
                    "model": model,
                    "corr_structure": corr,
                    "sensitivity_type": "nonlinear_sensitivity",
                    "reliability_threshold_q": q,
                    "K": 4,
                    "cutpoints": ref["cutpoints"],
                    "group_id": int(gid),
                    "bmi_interval": ref["bmi_interval"],
                    "status": "ok",
                    "recommended_week": float(ref["week"]),
                    "p_group_mean": float(ref["p_group_mean"]),
                    "bootstrap_lcb95": float(ref["bootstrap_lcb95"]),
                    "fail_risk": float(ref["fail_risk"]),
                    "time_risk": float(ref["time_risk"]),
                    "total_risk": float(ref["total_risk"]),
                    "individual_p_min": float(ref["individual_p_min"]),
                    "individual_p_q10": float(ref["individual_p_q10"]),
                    "individual_p_median": float(ref["individual_p_median"]),
                    "individual_share_ge_0p90": float(ref["individual_share_ge_0p90"]),
                    "note": "among weeks meeting bootstrap LCB threshold, choose minimum total risk; ties choose earliest week",
                }
            )
    return pd.DataFrame(rows)


def bootstrap_status_summary(status: pd.DataFrame) -> pd.DataFrame:
    return (
        status.groupby(["model", "corr_structure"], sort=True)
        .agg(
            bootstrap_attempts=("bootstrap_id", "nunique"),
            strict_converged_iterations=("status", lambda s: int((s == "ok").sum())),
            not_converged_count=("status", lambda s: int((s == "not_converged").sum())),
            failed_count=("status", lambda s: int((s == "failed").sum())),
            failed_or_not_converged_ids=("bootstrap_id", lambda s: ";".join(str(int(x)) for x in s[status.loc[s.index, "status"].ne("ok")])),
        )
        .reset_index()
    )


def compare_b1_b2(b2_grid: pd.DataFrame, b2_rec: pd.DataFrame) -> pd.DataFrame:
    b1_grid = pd.read_csv(B1_LCB_PATH, encoding="utf-8-sig")
    b1_rec = pd.read_csv(B1_REC_PATH, encoding="utf-8-sig")
    b1_25 = b1_grid[(b1_grid["model"].eq("B1")) & (b1_grid["corr_structure"].eq("independence")) & (b1_grid["week"].eq(25.0))]
    b2_25 = b2_grid[(b2_grid["week"].eq(25.0))]
    b1_q90 = b1_rec[(b1_rec["model"].eq("B1")) & (b1_rec["corr_structure"].eq("independence")) & (b1_rec["reliability_threshold_q"].eq(0.90))]
    b2_q90 = b2_rec[b2_rec["reliability_threshold_q"].eq(0.90)]

    rows = []
    for gid in sorted(b2_25["group_id"].unique()):
        b1p = b1_25[b1_25["group_id"].eq(gid)].iloc[0]
        b2p = b2_25[b2_25["group_id"].eq(gid)].iloc[0]
        b1r = b1_q90[b1_q90["group_id"].eq(gid)].iloc[0]
        b2r = b2_q90[b2_q90["group_id"].eq(gid)].iloc[0]
        b1_week = np.nan if pd.isna(b1r["recommended_week"]) else float(b1r["recommended_week"])
        b2_week = np.nan if pd.isna(b2r["recommended_week"]) else float(b2r["recommended_week"])
        b1_status_norm = str(b1r["status"]).replace("undecided", "unresolved")
        b2_status_norm = str(b2r["status"]).replace("undecided", "unresolved")
        rows.append(
            {
                "group_id": int(gid),
                "bmi_interval": b2p["bmi_interval"],
                "B1_model_role": "main_binary_decision_model",
                "B1_p25": float(b1p["p_group_mean"]),
                "B1_lcb95_25w": float(b1p["bootstrap_lcb95"]),
                "B1_q90_status": b1r["status"],
                "B1_q90_recommended_week": b1_week,
                "B2_model_role": "nonlinear_sensitivity",
                "B2_p25": float(b2p["p_group_mean"]),
                "B2_lcb95_25w": float(b2p["bootstrap_lcb95"]),
                "B2_q90_status": b2r["status"],
                "B2_q90_recommended_week": b2_week,
                "changes_main_q90_conclusion": bool((b1_status_norm != b2_status_norm) or (pd.isna(b1_week) != pd.isna(b2_week)) or (not pd.isna(b1_week) and not pd.isna(b2_week) and abs(b1_week - b2_week) > 1e-9)),
                "note": "B2 is sensitivity only; this table does not alter frozen B1 main model.",
            }
        )
    return pd.DataFrame(rows)


def source_hashes() -> pd.DataFrame:
    paths = [
        ROOT / "code" / "c3_b2_fixed_k4_nonlinear_sensitivity.py",
        ROOT / "code" / "c3_binary_model_selection_patch.py",
        ROOT / "code" / "c3_first_round.py",
        B1_LCB_PATH,
        B1_REC_PATH,
        B1_STATUS_PATH,
        C3_FROZEN_MANIFEST,
    ]
    rows = []
    for path in paths:
        rows.append(
            {
                "relative_path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "exists": path.exists(),
                "sha256": sha256(path) if path.exists() else "",
                "source_role": "code_or_frozen_reference",
            }
        )
    return pd.DataFrame(rows)


def write_summary(rec: pd.DataFrame, status_summary: pd.DataFrame, comparison: pd.DataFrame, elapsed: float, n_boot: int, seed: int) -> None:
    q90 = rec[rec["reliability_threshold_q"].eq(0.90)].sort_values("group_id")
    q90_lines = []
    for _, row in q90.iterrows():
        week = "未决" if pd.isna(row["recommended_week"]) else f"{float(row['recommended_week']):.1f}周"
        q90_lines.append(f"- G{int(row['group_id'])} {row['bmi_interval']}：{row['status']}，{week}，25周 LCB95={float(row['bootstrap_lcb95']):.6f}")
    changed = int(comparison["changes_main_q90_conclusion"].sum())
    strict_ok = int(status_summary.iloc[0]["strict_converged_iterations"]) if not status_summary.empty else 0
    text = f"""# C3 B2非线性敏感性决策层补充说明

状态：nonlinear_sensitivity / formal。该补充只闭合 B2 nonlinear GEE 从模型比较层到固定 K4 决策层的证据链；不修改 C3-v1.0 已冻结的 B1 主模型、固定 K4 切点、正文主口径和任何 C1/C2 结果。

## 1. 模型与口径

- 模型：B2 working-independence hard-label GEE。
- 公式：B1 基础上加入 `week_c2`、`baseline_bmi_c2`、`week_bmi`。
- 标签：`I(Y_observed >= 0.04)`。
- 分组：固定 K=4，BMI 切点 29.5 / 31.5 / 34.5。
- 网格：11-25 周，步长 0.5 周。
- 推荐规则：先满足 bootstrap LCB95 >= q，再在可行孕周中最小化风险函数 R=1-p+L(t)；风险并列取最早；25 周内无可行点则标记未决。
- q=0.90 是本文人工设定的可靠性阈值，不是题面或临床给定阈值。

## 2. Bootstrap

- 次数：{n_boot}
- seed：{seed}
- 严格收敛次数：{strict_ok}/{n_boot}
- 未严格收敛或失败编号见 `c3_B2_fixed_K4_bootstrap_status.csv`。

## 3. q=0.90 结果

{chr(10).join(q90_lines)}

## 4. 与 B1 主模型对照

B1 vs B2 对照表见 `c3_B1_vs_B2_fixed_K4_q90_decision_comparison.csv`。在 q=0.90 下，B2 相比 B1 改变主结论的组数为 {changed}。若发生变化，仅作为非线性敏感性证据，不自动改写 B1 主模型结论。

## 5. 运行信息

耗时约 {elapsed:.2f} 秒。所有输出只作为 C3 Gate 3 补充材料。
"""
    (OUT_DIR / "C3_B2非线性敏感性决策层补充说明.md").write_text(text, encoding="utf-8")


def write_manifest(elapsed: float, n_boot: int, seed: int, status_summary: pd.DataFrame) -> None:
    manifest = {
        "status": "nonlinear_sensitivity_formal",
        "scope": "C3 Gate 3 B2 nonlinear sensitivity decision-layer closure",
        "does_not_modify": ["C1 frozen outputs", "C2 frozen outputs", "C3-v1.0 frozen B1 main outputs"],
        "run_command": f"python problem_c_nipt/code/c3_b2_fixed_k4_nonlinear_sensitivity.py --bootstrap {n_boot} --bootstrap-seed {seed}",
        "model": {
            "name": "B2",
            "role": "nonlinear_sensitivity",
            "working_correlation": "independence",
            "family": "binomial",
            "link": "logit",
            "implementation": "statsmodels.api.GEE",
            "terms": sel.BINARY_SPECS[MODEL]["terms"],
            "label": "I(Y_observed >= 0.04)",
        },
        "decision口径": {
            "K": 4,
            "cutpoints": K4_CUTS,
            "week_grid": "11.0 to 25.0 by 0.5",
            "q_values": Q_VALUES,
            "q90_note": "q=0.90 is study-defined/manual, not problem-stated or clinical.",
        },
        "bootstrap": {
            "n": n_boot,
            "seed": seed,
            "cluster": "mother_id",
            "duplicate_mothers_renumbered": True,
            "strict_convergence_only": True,
            "status_summary": status_summary.to_dict(orient="records"),
        },
        "packages": {
            "python": sys.version,
            "platform": platform.platform(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "statsmodels": statsmodels.__version__,
        },
        "source_hashes": source_hashes().to_dict(orient="records"),
        "elapsed_seconds": round(elapsed, 3),
    }
    (OUT_DIR / "c3_B2_fixed_K4_nonlinear_sensitivity_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def update_file_index() -> None:
    rows = []
    for p in sorted(OUT_DIR.rglob("*")):
        if p.is_file() and p.name != "c3_B2_nonlinear_sensitivity_file_index.csv":
            rows.append(
                {
                    "relative_path": str(p.relative_to(OUT_DIR)).replace("\\", "/"),
                    "bytes": p.stat().st_size,
                    "sha256": sha256(p),
                    "status": "formal",
                    "role": "nonlinear_sensitivity",
                }
            )
    pd.DataFrame(rows).to_csv(OUT_DIR / "c3_B2_nonlinear_sensitivity_file_index.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap", type=int, default=1000)
    parser.add_argument("--bootstrap-seed", type=int, default=5401)
    args = parser.parse_args()
    t0 = time.time()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    CODE_DIR.mkdir(parents=True, exist_ok=True)

    events, mothers, means = c3.load_events()
    fit = sel.fit_gee_binary(events, MODEL, CORR)
    if not fit.converged:
        raise RuntimeError("Full-sample B2 independence GEE did not strictly converge; stop before bootstrap outputs are interpreted.")
    point = group_probability_grid(fit, mothers, means, K4_CUTS)
    point.to_csv(OUT_DIR / "c3_B2_fixed_K4_point_probability_by_group_week.csv", index=False, encoding="utf-8-sig")

    boot, status = fixed_k4_bootstrap(events, args.bootstrap, args.bootstrap_seed)
    boot.to_csv(OUT_DIR / "c3_B2_fixed_K4_bootstrap_raw_probability.csv", index=False, encoding="utf-8-sig")
    status.to_csv(OUT_DIR / "c3_B2_fixed_K4_bootstrap_status.csv", index=False, encoding="utf-8-sig")
    status_summary = bootstrap_status_summary(status)
    status_summary.to_csv(OUT_DIR / "c3_B2_fixed_K4_bootstrap_status_summary.csv", index=False, encoding="utf-8-sig")

    lcb = add_bootstrap_lcb(point, boot)
    lcb.to_csv(OUT_DIR / "c3_B2_fixed_K4_probability_bootstrap_lcb.csv", index=False, encoding="utf-8-sig")
    rec = threshold_recommendation(lcb)
    rec.to_csv(OUT_DIR / "c3_B2_fixed_K4_threshold_sensitivity_bootstrap_lcb.csv", index=False, encoding="utf-8-sig")

    comparison = compare_b1_b2(lcb, rec)
    comparison.to_csv(OUT_DIR / "c3_B1_vs_B2_fixed_K4_q90_decision_comparison.csv", index=False, encoding="utf-8-sig")

    source_hashes().to_csv(OUT_DIR / "c3_B2_source_and_reference_hashes.csv", index=False, encoding="utf-8-sig")
    elapsed = time.time() - t0
    write_summary(rec, status_summary, comparison, elapsed, args.bootstrap, args.bootstrap_seed)
    write_manifest(elapsed, args.bootstrap, args.bootstrap_seed, status_summary)

    shutil.copy2(Path(__file__), CODE_DIR / Path(__file__).name)
    shutil.copy2(ROOT / "code" / "c3_binary_model_selection_patch.py", CODE_DIR / "c3_binary_model_selection_patch.py")
    shutil.copy2(ROOT / "code" / "c3_first_round.py", CODE_DIR / "c3_first_round.py")
    update_file_index()
    print(f"C3 B2 nonlinear sensitivity outputs written to {OUT_DIR}")


if __name__ == "__main__":
    main()
