from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import sys
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels
import statsmodels.api as sm
from scipy import optimize
from scipy.special import expit, logit
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold

import c3_first_round as c3


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "results" / "C3-v0.1" / "02_binary_model_selection_patch"
CODE_DIR = OUT_DIR / "06_code"

Q_VALUES = [0.80, 0.85, 0.90, 0.95]
K4_CUTS = [29.5, 31.5, 34.5]
WEEK_GRID = c3.WEEK_GRID
EPS = 1e-7

BINARY_SPECS = {
    "B0": {"terms": ["week_c", "baseline_bmi_c"], "complexity": 3, "note": "week + BMI"},
    "B1": {
        "terms": ["week_c", "baseline_bmi_c", "baseline_age_c", "baseline_height_c", "pregnancy_count_c", "birth_count_c"],
        "complexity": 7,
        "note": "B0 + age + height + pregnancy_count + birth_count",
    },
    "B2": {
        "terms": [
            "week_c",
            "baseline_bmi_c",
            "baseline_age_c",
            "baseline_height_c",
            "pregnancy_count_c",
            "birth_count_c",
            "week_c2",
            "baseline_bmi_c2",
            "week_bmi",
        ],
        "complexity": 10,
        "note": "B1 + week^2 + BMI^2 + week*BMI",
    },
    "B3": {
        "terms": ["week_c", "baseline_weight_c", "baseline_age_c", "baseline_height_c", "pregnancy_count_c", "birth_count_c"],
        "complexity": 7,
        "note": "week + weight + age + height + pregnancy_count + birth_count",
    },
}


@dataclass
class GEEBinaryFit:
    model: str
    corr_structure: str
    terms: list[str]
    beta: np.ndarray
    robust_se: np.ndarray
    robust_cov: np.ndarray
    alpha: float
    converged: bool
    iterations: int
    message: str
    n_obs: int
    n_clusters: int


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def design(df: pd.DataFrame, terms: list[str]) -> np.ndarray:
    return np.column_stack([np.ones(len(df))] + [pd.to_numeric(df[t], errors="coerce").to_numpy(float) for t in terms])


def fit_gee_binary(df: pd.DataFrame, model: str, corr: str, max_iter: int = 200, tol: float = 1e-8) -> GEEBinaryFit:
    if model not in BINARY_SPECS:
        raise ValueError(model)
    if corr not in {"independence", "exchangeable"}:
        raise ValueError(corr)
    terms = BINARY_SPECS[model]["terms"]
    use = df.dropna(subset=["mother_id", "y_ge_4pct", *terms]).copy()
    X = design(use, terms)
    y = use["y_ge_4pct"].astype(int).to_numpy()
    groups = use["mother_id"].astype(str).to_numpy()
    cov_struct = sm.cov_struct.Independence() if corr == "independence" else sm.cov_struct.Exchangeable()
    gee = sm.GEE(y, X, groups=groups, family=sm.families.Binomial(), cov_struct=cov_struct)
    try:
        result = gee.fit(maxiter=max_iter, ctol=tol, cov_type="robust")
    except Exception as first_error:
        try:
            glm = sm.GLM(y, X, family=sm.families.Binomial()).fit(maxiter=200)
            result = gee.fit(start_params=np.asarray(glm.params, dtype=float), maxiter=max_iter, ctol=tol, cov_type="robust")
        except Exception as second_error:
            raise RuntimeError(f"statsmodels GEE failed after GLM initialization retry: {first_error}; retry: {second_error}") from second_error

    dep = getattr(result.cov_struct, "dep_params", 0.0)
    alpha = float(np.ravel(dep)[0]) if dep is not None and np.size(dep) else 0.0
    hist = getattr(result, "fit_history", {}) or {}
    params_hist = hist.get("params", [])
    iterations = len(params_hist) - 1 if isinstance(params_hist, list) and params_hist else int(getattr(result, "iteration", 0))
    beta = np.asarray(result.params, dtype=float)
    robust_cov = np.asarray(result.cov_params(), dtype=float)
    robust_cov = (robust_cov + robust_cov.T) / 2
    robust_se = np.asarray(result.bse, dtype=float)
    converged = bool(getattr(result, "converged", True)) and np.all(np.isfinite(beta)) and np.all(np.isfinite(robust_se))
    msg = "statsmodels GEE converged" if converged else "statsmodels GEE did not strictly converge or returned non-finite estimates"
    return GEEBinaryFit(
        model=model,
        corr_structure=corr,
        terms=terms,
        beta=beta,
        robust_se=robust_se,
        robust_cov=robust_cov,
        alpha=alpha,
        converged=bool(converged),
        iterations=int(iterations),
        message=msg,
        n_obs=int(len(use)),
        n_clusters=int(pd.Series(groups).nunique()),
    )


def predict_fit(fit: GEEBinaryFit, df: pd.DataFrame) -> np.ndarray:
    return np.clip(expit(design(df, fit.terms) @ fit.beta), EPS, 1 - EPS)


def calibration(y: np.ndarray, p: np.ndarray) -> tuple[float, float, bool]:
    p = np.clip(np.asarray(p, dtype=float), 1e-5, 1 - 1e-5)
    y = np.asarray(y, dtype=float)
    x = logit(p)

    def nll(ab: np.ndarray) -> float:
        q = np.clip(expit(ab[0] + ab[1] * x), EPS, 1 - EPS)
        return float(-np.sum(y * np.log(q) + (1 - y) * np.log(1 - q)))

    res = optimize.minimize(nll, np.array([0.0, 1.0]), method="L-BFGS-B")
    return float(res.x[0]), float(res.x[1]), bool(res.success)


def prob_metrics(y: np.ndarray, p: np.ndarray) -> dict:
    p = np.clip(np.asarray(p, dtype=float), EPS, 1 - EPS)
    y = np.asarray(y, dtype=float)
    intercept, slope, ok = calibration(y, p)
    try:
        auc = float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else np.nan
    except Exception:
        auc = np.nan
    return {
        "brier": float(np.mean((y - p) ** 2)),
        "log_loss": float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))),
        "auc": auc,
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "calibration_fit_converged": ok,
    }


def cross_validate(events: pd.DataFrame, repeats: int, folds: int, seed: int) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    mother_y = events.groupby("mother_id")["y_ge_4pct"].max().astype(int)
    strata = events["mother_id"].map(mother_y).astype(int)
    fold_rows, pred_rows, assign_rows, failure_rows = [], [], [], []
    candidate_keys = [(name, "independence") for name in BINARY_SPECS] + [(name, "exchangeable") for name in BINARY_SPECS]

    for repeat in range(1, repeats + 1):
        splitter = StratifiedGroupKFold(n_splits=folds, shuffle=True, random_state=seed + repeat - 1)
        for fold, (train_idx, valid_idx) in enumerate(splitter.split(events, y=strata, groups=events["mother_id"]), 1):
            train = events.iloc[train_idx].copy()
            valid = events.iloc[valid_idx].copy()
            for mid in sorted(valid["mother_id"].astype(str).unique()):
                assign_rows.append({"repeat": repeat, "fold": fold, "mother_id": mid, "mother_ever_reached_4pct": int(mother_y.loc[mid])})
            y = valid["y_ge_4pct"].astype(int).to_numpy()
            const_p = np.repeat(float(train["y_ge_4pct"].mean()), len(valid))
            const_metrics = prob_metrics(y, const_p)
            fold_rows.append(
                {
                    "repeat": repeat,
                    "fold": fold,
                    "model": "constant_train_event_rate",
                    "corr_structure": "none",
                    "converged": True,
                    "train_events": int(len(train)),
                    "valid_events": int(len(valid)),
                    "train_mothers": int(train["mother_id"].nunique()),
                    "valid_mothers": int(valid["mother_id"].nunique()),
                    "train_event_pass_rate": float(train["y_ge_4pct"].mean()),
                    "valid_event_pass_rate": float(valid["y_ge_4pct"].mean()),
                    "alpha": np.nan,
                    "message": "training fold event pass-rate baseline",
                }
                | const_metrics
            )
            for i, (_, row) in enumerate(valid.iterrows()):
                pred_rows.append(
                    {
                        "repeat": repeat,
                        "fold": fold,
                        "model": "constant_train_event_rate",
                        "corr_structure": "none",
                        "event_id": row["event_id"],
                        "mother_id": row["mother_id"],
                        "actual_week": float(row["week_num"]),
                        "baseline_bmi": float(row["baseline_bmi"]),
                        "observed_y_ge_4pct": int(row["y_ge_4pct"]),
                        "predicted_probability": float(const_p[i]),
                    }
                )

            for model, corr in candidate_keys:
                try:
                    fit = fit_gee_binary(train, model, corr)
                    if not fit.converged:
                        raise RuntimeError(fit.message)
                    p = predict_fit(fit, valid)
                    metrics = prob_metrics(y, p)
                    fold_rows.append(
                        {
                            "repeat": repeat,
                            "fold": fold,
                            "model": model,
                            "corr_structure": corr,
                            "converged": True,
                            "train_events": int(len(train)),
                            "valid_events": int(len(valid)),
                            "train_mothers": int(train["mother_id"].nunique()),
                            "valid_mothers": int(valid["mother_id"].nunique()),
                            "train_event_pass_rate": float(train["y_ge_4pct"].mean()),
                            "valid_event_pass_rate": float(valid["y_ge_4pct"].mean()),
                            "alpha": fit.alpha,
                            "message": fit.message,
                        }
                        | metrics
                    )
                    for i, (_, row) in enumerate(valid.iterrows()):
                        pred_rows.append(
                            {
                                "repeat": repeat,
                                "fold": fold,
                                "model": model,
                                "corr_structure": corr,
                                "event_id": row["event_id"],
                                "mother_id": row["mother_id"],
                                "actual_week": float(row["week_num"]),
                                "baseline_bmi": float(row["baseline_bmi"]),
                                "observed_y_ge_4pct": int(row["y_ge_4pct"]),
                                "predicted_probability": float(p[i]),
                            }
                        )
                except Exception as exc:
                    failure_rows.append({"repeat": repeat, "fold": fold, "model": model, "corr_structure": corr, "status": "failed_after_retry", "message": str(exc)})
                    fold_rows.append(
                        {
                            "repeat": repeat,
                            "fold": fold,
                            "model": model,
                            "corr_structure": corr,
                            "converged": False,
                            "train_events": int(len(train)),
                            "valid_events": int(len(valid)),
                            "train_mothers": int(train["mother_id"].nunique()),
                            "valid_mothers": int(valid["mother_id"].nunique()),
                            "train_event_pass_rate": float(train["y_ge_4pct"].mean()),
                            "valid_event_pass_rate": float(valid["y_ge_4pct"].mean()),
                            "alpha": np.nan,
                            "message": str(exc),
                            "brier": np.nan,
                            "log_loss": np.nan,
                            "auc": np.nan,
                            "calibration_intercept": np.nan,
                            "calibration_slope": np.nan,
                            "calibration_fit_converged": False,
                        }
                    )

    folds_df = pd.DataFrame(fold_rows)
    pred_df = pd.DataFrame(pred_rows)
    summary_rows = []
    total_folds = repeats * folds
    for (model, corr), sub in pred_df.groupby(["model", "corr_structure"], sort=True):
        y = sub["observed_y_ge_4pct"].to_numpy(int)
        p = sub["predicted_probability"].to_numpy(float)
        metrics = prob_metrics(y, p)
        fold_sub = folds_df[(folds_df["model"].eq(model)) & (folds_df["corr_structure"].eq(corr))]
        summary_rows.append(
            {
                "model": model,
                "corr_structure": corr,
                "complexity": BINARY_SPECS.get(model, {"complexity": 1})["complexity"],
                "term_note": BINARY_SPECS.get(model, {"note": "constant baseline"})["note"],
                "cv_total_folds": total_folds,
                "cv_success_folds": int(fold_sub["converged"].sum()),
                "eligible_for_formal_ranking": bool(int(fold_sub["converged"].sum()) == total_folds),
                "oof_prediction_count": int(len(sub)),
                "fold_brier_mean": float(fold_sub["brier"].mean()),
                "fold_brier_se": float(fold_sub["brier"].std(ddof=1) / math.sqrt(fold_sub["brier"].notna().sum())) if fold_sub["brier"].notna().sum() > 1 else np.nan,
                "fold_log_loss_mean": float(fold_sub["log_loss"].mean()),
                "fold_log_loss_se": float(fold_sub["log_loss"].std(ddof=1) / math.sqrt(fold_sub["log_loss"].notna().sum())) if fold_sub["log_loss"].notna().sum() > 1 else np.nan,
            }
            | {f"pooled_oof_{k}": v for k, v in metrics.items()}
        )
    return pd.DataFrame(summary_rows), folds_df, pred_df, pd.DataFrame(assign_rows), pd.DataFrame(failure_rows)


def near_0p90_calibration(pred: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (model, corr), sub in pred.groupby(["model", "corr_structure"], sort=True):
        for label, lo, hi in [("near_0p90_[0.85,0.95]", 0.85, 0.95), ("tight_0p90_[0.88,0.92]", 0.88, 0.92)]:
            part = sub[(sub["predicted_probability"] >= lo) & (sub["predicted_probability"] <= hi)]
            rows.append(
                {
                    "model": model,
                    "corr_structure": corr,
                    "calibration_window": label,
                    "n_events": int(len(part)),
                    "mean_predicted_probability": float(part["predicted_probability"].mean()) if len(part) else np.nan,
                    "observed_pass_rate": float(part["observed_y_ge_4pct"].mean()) if len(part) else np.nan,
                }
            )
    return pd.DataFrame(rows)


def select_binary_model(summary: pd.DataFrame) -> pd.DataFrame:
    cand = summary[(summary["corr_structure"].eq("independence")) & (summary["model"].isin(BINARY_SPECS)) & (summary["eligible_for_formal_ranking"])].copy()
    if cand.empty:
        return pd.DataFrame([{"selected_model": "", "reason": "no B0-B3 working-independence model reached 50/50 strict CV success"}])
    best = cand.sort_values(["fold_brier_mean", "complexity"]).iloc[0]
    selected = cand[cand["model"].eq("B1")].iloc[0]
    return pd.DataFrame(
        [
            {
                "selected_model": selected["model"],
                "selected_corr_structure": selected["corr_structure"],
                "best_brier_model": best["model"],
                "best_fold_brier_mean": best["fold_brier_mean"],
                "best_fold_brier_se_deprecated": best["fold_brier_se"],
                "one_se_threshold": np.nan,
                "selected_fold_brier_mean": selected["fold_brier_mean"],
                "selected_complexity": int(selected["complexity"]),
                "selection_rule": "B1 selected by modeling review after repeat-level SE and macro-mother metrics; fold-level one-SE is deprecated because repeated CV folds are not independent",
                "status": "draft_model_selection_patch",
            }
        ]
    )


def paired_mother_bootstrap(pred: pd.DataFrame, n_boot: int, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    work = pred[pred["model"].isin(BINARY_SPECS)].copy()
    work["brier_loss"] = (work["observed_y_ge_4pct"] - work["predicted_probability"]) ** 2
    p = np.clip(work["predicted_probability"].to_numpy(float), EPS, 1 - EPS)
    work["log_loss_event"] = -(work["observed_y_ge_4pct"].to_numpy(float) * np.log(p) + (1 - work["observed_y_ge_4pct"].to_numpy(float)) * np.log(1 - p))
    keys = sorted(set(zip(work["model"], work["corr_structure"])))
    rows = []
    for i, (m1, c1) in enumerate(keys):
        for m2, c2 in keys[i + 1 :]:
            a = work[(work["model"].eq(m1)) & (work["corr_structure"].eq(c1))]
            b = work[(work["model"].eq(m2)) & (work["corr_structure"].eq(c2))]
            merged = a.merge(
                b,
                on=["repeat", "fold", "event_id", "mother_id", "observed_y_ge_4pct"],
                suffixes=("_a", "_b"),
                how="inner",
            )
            if merged.empty:
                continue
            per_mother = merged.groupby("mother_id").agg(
                brier_diff=("brier_loss_a", "mean"),
                brier_b=("brier_loss_b", "mean"),
                log_diff=("log_loss_event_a", "mean"),
                log_b=("log_loss_event_b", "mean"),
            )
            per_mother["brier_diff"] = per_mother["brier_diff"] - per_mother["brier_b"]
            per_mother["log_loss_diff"] = per_mother["log_diff"] - per_mother["log_b"]
            moms = per_mother.index.to_numpy()
            brier_vals, log_vals = [], []
            for _ in range(n_boot):
                sample = rng.choice(moms, size=len(moms), replace=True)
                brier_vals.append(float(per_mother.loc[sample, "brier_diff"].mean()))
                log_vals.append(float(per_mother.loc[sample, "log_loss_diff"].mean()))
            rows.append(
                {
                    "model_a": m1,
                    "corr_a": c1,
                    "model_b": m2,
                    "corr_b": c2,
                    "common_oof_events": int(len(merged)),
                    "common_mothers": int(len(moms)),
                    "brier_diff_a_minus_b": float(per_mother["brier_diff"].mean()),
                    "brier_diff_ci_low_2p5": float(np.percentile(brier_vals, 2.5)),
                    "brier_diff_ci_high_97p5": float(np.percentile(brier_vals, 97.5)),
                    "log_loss_diff_a_minus_b": float(per_mother["log_loss_diff"].mean()),
                    "log_loss_diff_ci_low_2p5": float(np.percentile(log_vals, 2.5)),
                    "log_loss_diff_ci_high_97p5": float(np.percentile(log_vals, 97.5)),
                    "bootstrap_unit": "mother_id",
                    "bootstrap_n": n_boot,
                }
            )
    return pd.DataFrame(rows)


def coefficient_table(events: pd.DataFrame) -> tuple[pd.DataFrame, list[GEEBinaryFit]]:
    fits = []
    rows = []
    for model in BINARY_SPECS:
        for corr in ["independence", "exchangeable"]:
            fit = fit_gee_binary(events, model, corr)
            fits.append(fit)
            terms = ["Intercept"] + fit.terms
            for i, term in enumerate(terms):
                beta = float(fit.beta[i])
                se = float(fit.robust_se[i])
                z = beta / se if se > 0 and np.isfinite(se) else np.nan
                p = float(2 * (1 - scipy.stats.norm.cdf(abs(z)))) if np.isfinite(z) else np.nan
                rows.append(
                    {
                        "model": model,
                        "corr_structure": corr,
                        "term": term,
                        "coef": beta,
                        "robust_se": se,
                        "ci_low_95": beta - 1.96 * se,
                        "ci_high_95": beta + 1.96 * se,
                        "z_value": z,
                        "p_value": p,
                        "alpha_exchangeable": fit.alpha,
                        "converged": fit.converged,
                        "iterations": fit.iterations,
                        "n_obs": fit.n_obs,
                        "n_clusters": fit.n_clusters,
                        "implementation": "statsmodels.api.GEE",
                    }
                )
    return pd.DataFrame(rows), fits


def group_label(lo: float, hi: float, last: bool) -> str:
    return f"[{lo:.1f}, {hi:.1f}{']' if last else ')'}"


def group_bounds(mothers: pd.DataFrame, cuts: list[float]) -> list[tuple[float, float]]:
    lo = math.floor(float(mothers["baseline_bmi"].min()) * 2) / 2
    hi = math.ceil(float(mothers["baseline_bmi"].max()) * 2) / 2 + 0.5
    edges = [lo] + cuts + [hi]
    return [(float(edges[i]), float(edges[i + 1])) for i in range(len(edges) - 1)]


def assign_groups(bmi: np.ndarray, cuts: list[float]) -> np.ndarray:
    return np.searchsorted(np.asarray(cuts, dtype=float), np.asarray(bmi, dtype=float), side="right")


def point_probability_grid(fits: list[GEEBinaryFit], mothers: pd.DataFrame, cuts: list[float]) -> pd.DataFrame:
    grouped = mothers.copy()
    grouped["group_id0"] = assign_groups(grouped["baseline_bmi"].to_numpy(float), cuts)
    bounds = group_bounds(mothers, cuts)
    rows = []
    for fit in fits:
        for gid in range(len(cuts) + 1):
            gm = grouped[grouped["group_id0"].eq(gid)].copy()
            if gm.empty:
                continue
            for week in WEEK_GRID:
                pred_df = gm.copy()
                pred_df["week_num"] = float(week)
                pred_df = c3.add_terms(pred_df, c3.compute_means(events_global))
                probs = predict_fit(fit, pred_df)
                rows.append(
                    {
                        "model": fit.model,
                        "corr_structure": fit.corr_structure,
                        "K": 4,
                        "cutpoints": ";".join(f"{x:.1f}" for x in cuts),
                        "group_id": gid + 1,
                        "bmi_interval": group_label(bounds[gid][0], bounds[gid][1], gid == len(cuts)),
                        "week": float(week),
                        "p_group_mean": float(np.mean(probs)),
                        "individual_p_min": float(np.min(probs)),
                        "individual_p_q10": float(np.percentile(probs, 10)),
                        "individual_p_median": float(np.percentile(probs, 50)),
                        "individual_share_ge_0p90": float(np.mean(probs >= 0.90)),
                        "mother_count": int(len(gm)),
                        "note": "point prediction only; bootstrap LCB will be computed after model selection",
                    }
                )
    return pd.DataFrame(rows)


def threshold_timing(grid: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (model, corr, gid), sub in grid.groupby(["model", "corr_structure", "group_id"], sort=True):
        sub = sub.sort_values("week")
        for q in Q_VALUES:
            feasible = sub[sub["p_group_mean"] >= q]
            if feasible.empty:
                ref = sub.iloc[-1]
                rows.append(
                    {
                        "model": model,
                        "corr_structure": corr,
                        "reliability_threshold_q": q,
                        "group_id": int(gid),
                        "bmi_interval": ref["bmi_interval"],
                        "status": "undecided_point_probability",
                        "earliest_feasible_week": np.nan,
                        "p_group_mean_at_decision": float(ref["p_group_mean"]),
                        "note": "q not reached by 25w under point prediction; do not force 25w as recommendation",
                    }
                )
            else:
                ref = feasible.iloc[0]
                rows.append(
                    {
                        "model": model,
                        "corr_structure": corr,
                        "reliability_threshold_q": q,
                        "group_id": int(gid),
                        "bmi_interval": ref["bmi_interval"],
                        "status": "ok_point_probability",
                        "earliest_feasible_week": float(ref["week"]),
                        "p_group_mean_at_decision": float(ref["p_group_mean"]),
                        "note": "point prediction only; final timing requires selected-model cluster bootstrap LCB",
                    }
                )
    return pd.DataFrame(rows)


def write_docs(selection: pd.DataFrame, elapsed: float, args: argparse.Namespace) -> None:
    selected = selection.iloc[0].to_dict() if not selection.empty else {}
    text = f"""# C3 二项聚类模型选择补丁 v0.2

状态：draft，仅供建模手中审；不生成正式图片，不写正式推荐时点，不修改 C1/C2。

## 本轮完成

按建模手要求新增 B0-B3 的二项 Logit-GEE 模型比较。主工作相关结构为 working-independence，exchangeable GEE 作为相关结构敏感性。所有 GEE 均使用 `statsmodels.api.GEE` 官方实现，孕妇编号作为 cluster，稳健 sandwich 方差。

## 候选模型

- B0：week + BMI
- B1：week + BMI + age + height + pregnancy_count + birth_count
- B2：B1 + week^2 + BMI^2 + week*BMI
- B3：week + weight + age + height + pregnancy_count + birth_count

所有变量均采用首次检测/基线定义，与 C3 现有 M0-M3 的变量口径一致。

## CV 和选择规则

CV 为 {args.cv_repeats} 次重复 x {args.cv_folds} 折 StratifiedGroupKFold，孕妇整簇分折。OOF Brier 为主指标，Log Loss、AUC、校准截距/斜率为辅。未收敛或异常折不做常数回填；若重试后仍失败，该模型该折记为失败并不参与正式排名。正式候选要求 {args.cv_repeats * args.cv_folds}/{args.cv_repeats * args.cv_folds} 严格成功。

本轮不再使用折级 one-SE 选择 B0。建模手复核后将二项主决策模型候选修正为：`{selected.get('selected_model', '')}`，相关结构：`{selected.get('selected_corr_structure', '')}`。repeat 级 SE、孕妇等权 macro 指标及 B1 固定 K4 bootstrap 结果见 `c3_b1_fixed_k4_bootstrap.py` 生成的后续文件。

## 固定 K4 输出

本轮固定沿用 C2 K4 切点 29.5 / 31.5 / 34.5，只输出点预测逐周概率和 q=0.80/0.85/0.90/0.95 的点预测最早达标时点。若 q=0.90 下 25 周内未达标，已如实标记 `undecided_point_probability`，未强行把 25 周写成推荐时点。

## 运行

命令：`python problem_c_nipt/code/c3_binary_model_selection_patch.py --cv-repeats {args.cv_repeats} --cv-folds {args.cv_folds} --paired-bootstrap {args.paired_bootstrap}`

耗时：{elapsed:.2f} 秒。
"""
    (OUT_DIR / "C3_B0-B3二项GEE模型选择补丁说明.md").write_text(text, encoding="utf-8")


def file_index() -> pd.DataFrame:
    rows = []
    for p in sorted(OUT_DIR.rglob("*")):
        if p.is_file() and p.name != "c3_binary_model_selection_file_index.csv":
            rows.append({"relative_path": str(p.relative_to(OUT_DIR)).replace("\\", "/"), "bytes": p.stat().st_size, "sha256": sha256(p), "status": "draft"})
    return pd.DataFrame(rows)


events_global = pd.DataFrame()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cv-repeats", type=int, default=10)
    parser.add_argument("--cv-folds", type=int, default=5)
    parser.add_argument("--cv-seed", type=int, default=5101)
    parser.add_argument("--paired-bootstrap", type=int, default=1000)
    parser.add_argument("--paired-bootstrap-seed", type=int, default=5102)
    args = parser.parse_args()
    t0 = time.time()

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for child in OUT_DIR.iterdir():
        if child.is_file():
            child.unlink()
        elif child.is_dir():
            shutil.rmtree(child)
    CODE_DIR.mkdir(parents=True, exist_ok=True)

    input_hash = c3.verify_inputs()
    input_hash.to_csv(OUT_DIR / "c3_binary_model_selection_input_hashes.csv", index=False, encoding="utf-8-sig")
    events, mothers, means = c3.load_events()
    global events_global
    events_global = events.copy()
    events[["event_id", "mother_id", "week_num", "baseline_bmi", "baseline_weight", "baseline_age", "baseline_height", "baseline_pregnancy_count", "baseline_birth_count", "y_concentration", "y_ge_4pct"]].to_csv(
        OUT_DIR / "c3_binary_model_selection_analysis_events.csv", index=False, encoding="utf-8-sig"
    )

    cv_summary, cv_folds, cv_pred, cv_assign, cv_failures = cross_validate(events, args.cv_repeats, args.cv_folds, args.cv_seed)
    cv_summary.to_csv(OUT_DIR / "c3_B0_B3_cv_model_comparison.csv", index=False, encoding="utf-8-sig")
    cv_folds.to_csv(OUT_DIR / "c3_B0_B3_cv_fold_results.csv", index=False, encoding="utf-8-sig")
    cv_pred.to_csv(OUT_DIR / "c3_B0_B3_oof_predictions.csv", index=False, encoding="utf-8-sig")
    cv_assign.to_csv(OUT_DIR / "c3_B0_B3_cv_mother_fold_assignments.csv", index=False, encoding="utf-8-sig")
    cv_failures.to_csv(OUT_DIR / "c3_B0_B3_cv_failures.csv", index=False, encoding="utf-8-sig")
    near_0p90_calibration(cv_pred).to_csv(OUT_DIR / "c3_B0_B3_near_0p90_calibration.csv", index=False, encoding="utf-8-sig")
    paired_mother_bootstrap(cv_pred, args.paired_bootstrap, args.paired_bootstrap_seed).to_csv(OUT_DIR / "c3_B0_B3_paired_mother_bootstrap_loss_diff.csv", index=False, encoding="utf-8-sig")

    selection = select_binary_model(cv_summary)
    selection.to_csv(OUT_DIR / "c3_B0_B3_model_selection_decision.csv", index=False, encoding="utf-8-sig")

    coef, fits = coefficient_table(events)
    coef.to_csv(OUT_DIR / "c3_B0_B3_full_sample_gee_coefficients.csv", index=False, encoding="utf-8-sig")
    point = point_probability_grid(fits, mothers, K4_CUTS)
    point.to_csv(OUT_DIR / "c3_B0_B3_fixed_K4_point_probability_by_group_week.csv", index=False, encoding="utf-8-sig")
    threshold_timing(point).to_csv(OUT_DIR / "c3_B0_B3_fixed_K4_threshold_sensitivity_point.csv", index=False, encoding="utf-8-sig")

    elapsed = time.time() - t0
    manifest = {
        "status": "draft",
        "module": "C3 B0-B3 clustered binary model selection patch",
        "does_not_modify": ["C1 frozen outputs", "C2 frozen outputs", "C3 previous draft outputs"],
        "run_command": f"python problem_c_nipt/code/c3_binary_model_selection_patch.py --cv-repeats {args.cv_repeats} --cv-folds {args.cv_folds} --paired-bootstrap {args.paired_bootstrap}",
        "cv": {"method": "StratifiedGroupKFold by mother cluster", "repeats": args.cv_repeats, "folds": args.cv_folds, "seed": args.cv_seed},
        "paired_loss_bootstrap": {"unit": "mother_id", "n": args.paired_bootstrap, "seed": args.paired_bootstrap_seed},
        "gee": {"implementation": "statsmodels.api.GEE", "family": "binomial", "link": "logit", "primary_working_correlation": "independence", "sensitivity_working_correlation": "exchangeable", "covariance": "cluster robust sandwich"},
        "fixed_k4_cutpoints_for_point_prediction": K4_CUTS,
        "threshold_sensitivity_q": Q_VALUES,
        "packages": {"python": sys.version, "platform": platform.platform(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__, "statsmodels": statsmodels.__version__},
        "elapsed_seconds": round(elapsed, 3),
    }
    (OUT_DIR / "c3_binary_model_selection_run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    write_docs(selection, elapsed, args)
    shutil.copy2(Path(__file__), CODE_DIR / Path(__file__).name)
    shutil.copy2(ROOT / "code" / "c3_first_round.py", CODE_DIR / "c3_first_round.py")
    file_index().to_csv(OUT_DIR / "c3_binary_model_selection_file_index.csv", index=False, encoding="utf-8-sig")
    print(f"C3 binary model selection patch outputs written to {OUT_DIR}")


if __name__ == "__main__":
    main()
