`timescale 1ns / 1ps

module ALU
#(
    parameter DATA_WIDTH = 8,
    parameter OP_WIDTH   = 4
)
(
    input  [DATA_WIDTH - 1 : 0] alu_a,
    input  [DATA_WIDTH - 1 : 0] alu_b,
    input  [OP_WIDTH   - 1 : 0] alu_op,
    output reg [DATA_WIDTH - 1 : 0] alu_res,
    output wire zero
);

// Calculate ceil(log2(DATA_WIDTH)) in Verilog-2001 style.
function integer clog2;
    input integer value;
    integer i;
    begin
        value = value - 1;
        for (i = 0; value > 0; i = i + 1)
            value = value >> 1;
        clog2 = (i == 0) ? 1 : i;
    end
endfunction

localparam SHAMT_WIDTH = clog2(DATA_WIDTH);
wire [SHAMT_WIDTH - 1 : 0] shamt;
assign shamt = alu_b[SHAMT_WIDTH - 1 : 0];

always @(*) begin
    case (alu_op)
        4'b0000: alu_res = alu_a + alu_b;                                      // ADD
        4'b0001: alu_res = alu_a - alu_b;                                      // SUB
        4'b0010: alu_res = alu_a << shamt;                                     // SLL
        4'b0011: alu_res = ($signed(alu_a) < $signed(alu_b)) ?
                              {{(DATA_WIDTH-1){1'b0}}, 1'b1} :
                              {DATA_WIDTH{1'b0}};                             // SLT
        4'b0100: alu_res = alu_a ^ alu_b;                                      // XOR
        4'b0101: alu_res = alu_a >> shamt;                                     // SRL
        4'b0110: alu_res = $signed(alu_a) >>> shamt;                           // SRA
        4'b0111: alu_res = alu_a | alu_b;                                      // OR
        4'b1000: alu_res = alu_a & alu_b;                                      // AND
        4'b1001: alu_res = (alu_a < alu_b) ?
                              {{(DATA_WIDTH-1){1'b0}}, 1'b1} :
                              {DATA_WIDTH{1'b0}};                             // SLTU
        default: alu_res = {DATA_WIDTH{1'b0}};
    endcase
end

assign zero = (alu_res == {DATA_WIDTH{1'b0}});

endmodule
