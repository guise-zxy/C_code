# 实验2 ALU设计实验代码说明

文件说明：
- `ALU.v`：参数化 ALU，默认 8 位；将 `DATA_WIDTH` 改为 32 即为 32 位 ALU。
- `ALU_tb.v`：8 位 ALU 自检测试文件。
- `ALU32_tb.v`：32 位 ALU 自检测试文件。
- `alu.xdc`：基于实验指导书图 2.3 的上板引脚约束。

Vivado 使用建议：
1. 建立 RTL Project，添加 `ALU.v`。
2. 仿真任务一：添加 `ALU_tb.v` 为 Simulation Source，运行 Behavioral Simulation。
3. 仿真任务三：添加 `ALU32_tb.v` 为 Simulation Source，运行 Behavioral Simulation。
4. 上板任务二：添加 `alu.xdc` 为 Constraints，Top 选择 `ALU`，默认参数为 8 位。
