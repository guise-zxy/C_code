`timescale 1ns / 1ns

module ALU32_tb();
    reg  [31:0] alu_a;
    reg  [31:0] alu_b;
    reg  [3:0]  alu_op;
    wire [31:0] alu_res;
    wire        zero;

    ALU #(.DATA_WIDTH(32), .OP_WIDTH(4)) u_alu (
        .alu_a  (alu_a),
        .alu_b  (alu_b),
        .alu_op (alu_op),
        .alu_res(alu_res),
        .zero   (zero)
    );

    task check;
        input [31:0] a;
        input [31:0] b;
        input [3:0]  op;
        input [31:0] expected_res;
        input        expected_zero;
        begin
            alu_a = a;
            alu_b = b;
            alu_op = op;
            #10;
            if (alu_res !== expected_res || zero !== expected_zero) begin
                $display("FAIL op=%b a=%h b=%h res=%h zero=%b, expected res=%h zero=%b",
                         op, a, b, alu_res, zero, expected_res, expected_zero);
            end else begin
                $display("PASS op=%b a=%h b=%h res=%h zero=%b",
                         op, a, b, alu_res, zero);
            end
        end
    endtask

    initial begin
        check(32'h00000044, 32'h00000042, 4'b0000, 32'h00000086, 1'b0); // ADD
        check(32'h00000044, 32'h00000042, 4'b0001, 32'h00000002, 1'b0); // SUB
        check(32'h00000044, 32'h00000042, 4'b0010, 32'h00000110, 1'b0); // SLL, shamt=2
        check(32'h00000044, 32'h00000042, 4'b0011, 32'h00000000, 1'b1); // SLT
        check(32'h00000044, 32'h00000042, 4'b0100, 32'h00000006, 1'b0); // XOR
        check(32'h00000044, 32'h00000042, 4'b0101, 32'h00000011, 1'b0); // SRL
        check(32'h00000044, 32'h00000042, 4'b0110, 32'h00000011, 1'b0); // SRA
        check(32'h00000044, 32'h00000042, 4'b0111, 32'h00000046, 1'b0); // OR
        check(32'h00000044, 32'h00000042, 4'b1000, 32'h00000040, 1'b0); // AND
        check(32'h00000044, 32'h00000042, 4'b1001, 32'h00000000, 1'b1); // SLTU

        check(32'hFFFFFFFE, 32'hFFFFFFFE, 4'b0001, 32'h00000000, 1'b1); // SUB equal
        check(32'hFFFFFFFE, 32'hFFFFFFFF, 4'b0011, 32'h00000001, 1'b0); // signed -2 < -1
        check(32'hFFFFFFFE, 32'hFFFFFFFF, 4'b0110, 32'hFFFFFFFF, 1'b0); // SRA, shamt=31
        check(32'hFFFFFFFE, 32'hFFFFFFFF, 4'b1001, 32'h00000001, 1'b0); // unsigned FFFE < FFFF

        #10;
        $finish;
    end
endmodule
