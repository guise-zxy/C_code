# ALU experiment pin constraints for xc7k325t teaching board
# Port mapping follows the pin mapping figure in Experiment 2 guide.
# SW: pushed up = high level. LED: high level = on.

set_property IOSTANDARD LVCMOS33 [get_ports {alu_a[*]}]
set_property IOSTANDARD LVCMOS33 [get_ports {alu_b[*]}]
set_property IOSTANDARD LVCMOS33 [get_ports {alu_op[*]}]
set_property IOSTANDARD LVCMOS33 [get_ports {alu_res[*]}]
set_property IOSTANDARD LVCMOS33 [get_ports zero]

# alu_a[7:0] -> SW64..SW57
set_property PACKAGE_PIN L27 [get_ports {alu_a[7]}]
set_property PACKAGE_PIN L26 [get_ports {alu_a[6]}]
set_property PACKAGE_PIN L30 [get_ports {alu_a[5]}]
set_property PACKAGE_PIN K30 [get_ports {alu_a[4]}]
set_property PACKAGE_PIN K26 [get_ports {alu_a[3]}]
set_property PACKAGE_PIN J29 [get_ports {alu_a[2]}]
set_property PACKAGE_PIN J28 [get_ports {alu_a[1]}]
set_property PACKAGE_PIN H29 [get_ports {alu_a[0]}]

# alu_b[7:0] -> SW32..SW25
set_property PACKAGE_PIN W24 [get_ports {alu_b[7]}]
set_property PACKAGE_PIN V24 [get_ports {alu_b[6]}]
set_property PACKAGE_PIN V25 [get_ports {alu_b[5]}]
set_property PACKAGE_PIN W26 [get_ports {alu_b[4]}]
set_property PACKAGE_PIN V26 [get_ports {alu_b[3]}]
set_property PACKAGE_PIN U25 [get_ports {alu_b[2]}]
set_property PACKAGE_PIN V30 [get_ports {alu_b[1]}]
set_property PACKAGE_PIN V29 [get_ports {alu_b[0]}]

# alu_op[3:0] -> SW48..SW45
set_property PACKAGE_PIN J22 [get_ports {alu_op[3]}]
set_property PACKAGE_PIN J21 [get_ports {alu_op[2]}]
set_property PACKAGE_PIN K21 [get_ports {alu_op[1]}]
set_property PACKAGE_PIN L22 [get_ports {alu_op[0]}]

# alu_res[7:0] -> LED32..LED25
set_property PACKAGE_PIN B27 [get_ports {alu_res[7]}]
set_property PACKAGE_PIN A27 [get_ports {alu_res[6]}]
set_property PACKAGE_PIN A26 [get_ports {alu_res[5]}]
set_property PACKAGE_PIN B25 [get_ports {alu_res[4]}]
set_property PACKAGE_PIN A25 [get_ports {alu_res[3]}]
set_property PACKAGE_PIN B24 [get_ports {alu_res[2]}]
set_property PACKAGE_PIN B23 [get_ports {alu_res[1]}]
set_property PACKAGE_PIN A23 [get_ports {alu_res[0]}]

# zero flag -> LED1
set_property PACKAGE_PIN G24 [get_ports zero]
