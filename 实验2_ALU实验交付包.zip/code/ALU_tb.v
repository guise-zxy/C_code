`timescale 1ns / 1ns

module ALU_tb();
    reg  [7:0] alu_a;
    reg  [7:0] alu_b;
    reg  [3:0] alu_op;
    wire [7:0] alu_res;
    wire       zero;

    ALU #(.DATA_WIDTH(8), .OP_WIDTH(4)) u_alu (
        .alu_a  (alu_a),
        .alu_b  (alu_b),
        .alu_op (alu_op),
        .alu_res(alu_res),
        .zero   (zero)
    );

    task check;
        input [7:0] a;
        input [7:0] b;
        input [3:0] op;
        input [7:0] expected_res;
        input       expected_zero;
        begin
            alu_a = a;
            alu_b = b;
            alu_op = op;
            #10;
            if (alu_res !== expected_res || zero !== expected_zero) begin
                $display("FAIL op=%b a=%h b=%h res=%h zero=%b, expected res=%h zero=%b",
                         op, a, b, alu_res, zero, expected_res, expected_zero);
            end else begin
                $display("PASS op=%b a=%h b=%h res=%h zero=%b",
                         op, a, b, alu_res, zero);
            end
        end
    endtask

    initial begin
        check(8'b01000100, 8'b01000010, 4'b0000, 8'h86, 1'b0); // ADD
        check(8'b01000100, 8'b01000010, 4'b0001, 8'h02, 1'b0); // SUB
        check(8'b01000100, 8'b01000010, 4'b0010, 8'h10, 1'b0); // SLL
        check(8'b01000100, 8'b01000010, 4'b0011, 8'h00, 1'b1); // SLT
        check(8'b01000100, 8'b01000010, 4'b0100, 8'h06, 1'b0); // XOR
        check(8'b01000100, 8'b01000010, 4'b0101, 8'h11, 1'b0); // SRL
        check(8'b01000100, 8'b01000010, 4'b0110, 8'h11, 1'b0); // SRA
        check(8'b01000100, 8'b01000010, 4'b0111, 8'h46, 1'b0); // OR
        check(8'b01000100, 8'b01000010, 4'b1000, 8'h40, 1'b0); // AND
        check(8'b01000100, 8'b01000010, 4'b1001, 8'h00, 1'b1); // SLTU

        check(8'b11111110, 8'b11111110, 4'b0001, 8'h00, 1'b1); // SUB equal
        check(8'b11111110, 8'b11111111, 4'b0011, 8'h01, 1'b0); // signed -2 < -1
        check(8'b11111110, 8'b11111111, 4'b0110, 8'hFF, 1'b0); // arithmetic right shift
        check(8'b11111110, 8'b11111111, 4'b1001, 8'h01, 1'b0); // unsigned FE < FF

        #10;
        $finish;
    end
endmodule
