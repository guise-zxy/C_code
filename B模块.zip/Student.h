#pragma once

#include "User.h"

// 学生用户：继承 User，重写身份标识和菜单。
class Student : public User {
public:
    Student();
    Student(const std::string& username, const std::string& password, const std::string& name);

    std::string getRole() const override;
    void showMenu() const override;
};
