#pragma once

#include <string>

// 用户基类：保存所有用户（学生 / 管理员）共有的信息。
// Student 和 Admin 都从这里派生。本类是抽象类，不能直接实例化。
class User {
protected:
    std::string username;  // 账号
    std::string password;  // 密码
    std::string name;      // 姓名

public:
    User();
    User(const std::string& username, const std::string& password, const std::string& name);
    virtual ~User() = default;

    // 只读访问器：外部只能读取，不能直接改内部字段（封装）。
    std::string getUsername() const;
    std::string getPassword() const;
    std::string getName() const;

    // 登录校验辅助函数：在类内部比对密码，调用方不必把密码取出来自己比。
    bool checkPassword(const std::string& input) const;

    // 纯虚函数：身份标识与菜单展示，交给子类各自实现，体现多态。
    virtual std::string getRole() const = 0;
    virtual void showMenu() const = 0;
};
