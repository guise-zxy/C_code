#include "Student.h"

#include <iostream>

// 委托给基类的默认构造。
Student::Student() : User() {}

// 把账号、密码、姓名直接交给基类构造函数处理。
Student::Student(const std::string& username, const std::string& password, const std::string& name)
    : User(username, password, name) {}

std::string Student::getRole() const {
    return "student";
}

// 学生菜单。选项编号与 SystemManager::studentMenu 的 switch 一一对应。
void Student::showMenu() const {
    std::cout << "\n===== Student Menu =====\n";
    std::cout << "1. Show rooms\n";
    std::cout << "2. Show seat status by time slot\n";
    std::cout << "3. Reserve seat\n";
    std::cout << "4. Show my reservations\n";
    std::cout << "5. Cancel reservation\n";
    std::cout << "0. Logout\n";
    std::cout << "Choose: ";
}
