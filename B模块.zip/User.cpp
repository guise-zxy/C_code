#include "User.h"

// 默认构造：三个字段都初始化为空字符串，避免出现未初始化的脏值。
User::User() : username(""), password(""), name("") {}

// 带参构造：用初始化列表把账号、密码、姓名一次性填好。
User::User(const std::string& username, const std::string& password, const std::string& name)
    : username(username), password(password), name(name) {}

std::string User::getUsername() const {
    return username;
}

std::string User::getPassword() const {
    return password;
}

std::string User::getName() const {
    return name;
}

bool User::checkPassword(const std::string& input) const {
    return password == input;
}
