#pragma once

#include "User.h"

// 管理员用户：继承 User，重写身份标识和菜单。
class Admin : public User {
public:
    Admin();
    Admin(const std::string& username, const std::string& password, const std::string& name);

    std::string getRole() const override;
    void showMenu() const override;
};
