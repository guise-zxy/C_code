xsim {work.clock_board_display_tb} -autoloadwcfg -runall
