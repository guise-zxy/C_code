xsim {work.time_counter_debug_tb} -autoloadwcfg -runall
