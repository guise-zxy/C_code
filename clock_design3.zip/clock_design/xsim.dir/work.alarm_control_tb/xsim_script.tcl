xsim {work.alarm_control_tb} -autoloadwcfg -runall
