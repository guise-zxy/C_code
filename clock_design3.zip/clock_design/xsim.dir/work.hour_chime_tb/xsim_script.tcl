xsim {work.hour_chime_tb} -autoloadwcfg -runall
