xsim {work.clock_core_tb} -autoloadwcfg -runall
