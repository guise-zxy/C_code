`timescale 1ns / 1ps

module clock_core_top #(
    parameter CLK_FREQ_HZ = 50000000,
    parameter SCAN_FREQ_HZ = 1000,
    parameter DEBOUNCE_MS = 20,
    parameter SEG_ACTIVE_LOW = 1'b0,
    parameter AN_ACTIVE_LOW  = 1'b0
) (
    input  wire clk,
    input  wire rst_n,
    input  wire key_mode,
    input  wire key_add,
    input  wire key_sub,
    output wire [7:0] seg,
    output wire [3:0] an,
    output wire [4:0] dbg_hour,
    output wire [5:0] dbg_min,
    output wire [5:0] dbg_sec,
    output wire [3:0] dbg_state,
    output wire dbg_hour_chime,
    output wire [4:0] dbg_alarm_hour,
    output wire [5:0] dbg_alarm_min,
    output wire dbg_alarm_active,
    output wire [4:0] dbg_month,
    output wire [5:0] dbg_day,
    output wire dbg_stopwatch_mode,
    output wire dbg_stopwatch_running,
    output wire [6:0] dbg_stopwatch_min,
    output wire [5:0] dbg_stopwatch_sec,
    output wire [6:0] dbg_stopwatch_cs,
    output wire dbg_countdown_mode,
    output wire dbg_countdown_running,
    output wire dbg_countdown_alarm_pulse,
    output wire [5:0] dbg_countdown_min,
    output wire [5:0] dbg_countdown_sec
);
    localparam integer DB_SAMPLE_HZ    = (CLK_FREQ_HZ < 1000) ? CLK_FREQ_HZ : 1000;
    localparam integer DEBOUNCE_TICKS  = (((DB_SAMPLE_HZ * DEBOUNCE_MS) + 999) / 1000);
    localparam integer DB_STABLE_TICKS = (DEBOUNCE_TICKS < 2) ? 2 : DEBOUNCE_TICKS;
    localparam integer LONG_PRESS_MS   = 300;
    localparam integer LONG_PRESS_TICKS = (((DB_SAMPLE_HZ * LONG_PRESS_MS) + 999) / 1000 < 2) ? 2 : ((DB_SAMPLE_HZ * LONG_PRESS_MS) + 999) / 1000;
    localparam [3:0] STOPWATCH_STATE = 4'd8;
    localparam [3:0] COUNTDOWN_STATE = 4'd9;

    wire tick_1hz;
    wire tick_10ms;
    wire tick_scan;
    wire tick_debounce;
    wire blink_1hz;
    wire mode_short_pulse;
    wire mode_long_pulse;
    wire add_pulse;
    wire sub_pulse;
    wire mode_step_pulse;
    wire alarm_cancel_pulse;
    wire stopwatch_toggle_pulse;
    wire stopwatch_reset_pulse;
    wire stopwatch_mode_toggle_pulse;
    wire countdown_toggle_pulse;
    wire countdown_mode_toggle_pulse;
    wire force_run_pulse;
    wire [4:0] hour;
    wire [5:0] min;
    wire [5:0] sec;
    wire [4:0] alarm_hour;
    wire [5:0] alarm_min;
    wire [4:0] month;
    wire [5:0] day;
    wire [3:0] state;
    wire hour_chime_pulse;
    wire alarm_match_pulse;
    wire alarm_active;
    wire stopwatch_running;
    wire [6:0] stopwatch_min;
    wire [5:0] stopwatch_sec;
    wire [6:0] stopwatch_cs;
    wire countdown_running;
    wire countdown_alarm_pulse;
    wire [5:0] countdown_min;
    wire [5:0] countdown_sec;
    reg [1:0] aux_mode;

    wire stopwatch_mode = (aux_mode == 2'd1);
    wire countdown_mode = (aux_mode == 2'd2);

    clk_div #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .SCAN_FREQ_HZ(SCAN_FREQ_HZ)
    ) u_clk_div (
        .clk(clk),
        .rst_n(rst_n),
        .tick_1hz(tick_1hz),
        .tick_10ms(tick_10ms),
        .tick_scan(tick_scan),
        .tick_debounce(tick_debounce),
        .blink_1hz(blink_1hz)
    );

    key_press_classifier #(
        .STABLE_TICKS(DB_STABLE_TICKS)
        ,
        .LONG_TICKS(LONG_PRESS_TICKS)
    ) u_mode_classifier (
        .clk(clk),
        .rst_n(rst_n),
        .sample_tick(tick_debounce),
        .key_in(key_mode),
        .short_pulse(mode_short_pulse),
        .long_pulse(mode_long_pulse),
        .key_state()
    );

    debounce #(
        .STABLE_TICKS(DB_STABLE_TICKS)
    ) u_db_add (
        .clk(clk),
        .rst_n(rst_n),
        .sample_tick(tick_debounce),
        .key_in(key_add),
        .key_pulse(add_pulse)
    );

    debounce #(
        .STABLE_TICKS(DB_STABLE_TICKS)
    ) u_db_sub (
        .clk(clk),
        .rst_n(rst_n),
        .sample_tick(tick_debounce),
        .key_in(key_sub),
        .key_pulse(sub_pulse)
    );

    assign mode_step_pulse             = mode_short_pulse & ~alarm_active & (aux_mode == 2'd0);
    assign alarm_cancel_pulse          = mode_short_pulse & alarm_active;
    assign stopwatch_toggle_pulse      = mode_short_pulse & ~alarm_active & stopwatch_mode;
    assign stopwatch_reset_pulse       = add_pulse & stopwatch_mode;
    assign stopwatch_mode_toggle_pulse = mode_long_pulse & ~alarm_active & (aux_mode != 2'd2);
    assign countdown_mode_toggle_pulse = mode_long_pulse & ~alarm_active & (aux_mode == 2'd2);
    assign countdown_toggle_pulse      = mode_short_pulse & ~alarm_active & countdown_mode;
    assign force_run_pulse             = mode_long_pulse & ~alarm_active;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            aux_mode <= 2'd0;
        end else if (mode_long_pulse && ~alarm_active) begin
            case (aux_mode)
                2'd0: aux_mode <= 2'd1;
                2'd1: aux_mode <= 2'd2;
                default: aux_mode <= 2'd0;
            endcase
        end
    end

    clock_fsm u_clock_fsm (
        .clk(clk),
        .rst_n(rst_n),
        .force_run_pulse(force_run_pulse),
        .key_mode_pulse(mode_step_pulse),
        .state(state)
    );

    time_counter u_time_counter (
        .clk(clk),
        .rst_n(rst_n),
        .tick_1hz(tick_1hz),
        .state(state),
        .key_add_pulse(add_pulse),
        .key_sub_pulse(sub_pulse),
        .hour(hour),
        .min(min),
        .sec(sec),
        .alarm_hour(alarm_hour),
        .alarm_min(alarm_min),
        .month(month),
        .day(day),
        .hour_chime_pulse(hour_chime_pulse),
        .alarm_match_pulse(alarm_match_pulse)
    );

    alarm_control #(
        .ALARM_SECONDS(30)
    ) u_alarm_control (
        .clk(clk),
        .rst_n(rst_n),
        .tick_1hz(tick_1hz),
        .start_pulse(alarm_match_pulse),
        .cancel_pulse(alarm_cancel_pulse),
        .alarm_active(alarm_active)
    );

    stopwatch_counter u_stopwatch_counter (
        .clk(clk),
        .rst_n(rst_n),
        .tick_10ms(tick_10ms),
        .mode_active(stopwatch_mode),
        .toggle_run_pulse(stopwatch_toggle_pulse),
        .reset_pulse(stopwatch_reset_pulse),
        .running(stopwatch_running),
        .min(stopwatch_min),
        .sec(stopwatch_sec),
        .cs(stopwatch_cs)
    );

    countdown_counter u_countdown_counter (
        .clk(clk),
        .rst_n(rst_n),
        .tick_1hz(tick_1hz),
        .mode_active(countdown_mode),
        .toggle_run_pulse(countdown_toggle_pulse),
        .add_pulse(add_pulse),
        .sub_pulse(sub_pulse),
        .running(countdown_running),
        .alarm_pulse(countdown_alarm_pulse),
        .min(countdown_min),
        .sec(countdown_sec)
    );

    seg_scan #(
        .SEG_ACTIVE_LOW(SEG_ACTIVE_LOW),
        .AN_ACTIVE_LOW(AN_ACTIVE_LOW)
    ) u_seg_scan (
        .clk(clk),
        .rst_n(rst_n),
        .tick_scan(tick_scan),
        .blink_1hz(blink_1hz),
        .state(state),
        .hour(hour),
        .min(min),
        .month(month),
        .day(day),
        .stopwatch_mode(stopwatch_mode),
        .stopwatch_min(stopwatch_min),
        .stopwatch_sec(stopwatch_sec),
        .countdown_mode(countdown_mode),
        .countdown_min(countdown_min),
        .countdown_sec(countdown_sec),
        .seg(seg),
        .an(an)
    );

    assign dbg_hour         = hour;
    assign dbg_min          = min;
    assign dbg_sec          = sec;
    assign dbg_state        = stopwatch_mode ? STOPWATCH_STATE :
                              countdown_mode ? COUNTDOWN_STATE : state;
    assign dbg_hour_chime   = hour_chime_pulse;
    assign dbg_alarm_hour   = alarm_hour;
    assign dbg_alarm_min    = alarm_min;
    assign dbg_alarm_active = alarm_active;
    assign dbg_month        = month;
    assign dbg_day          = day;
    assign dbg_stopwatch_mode    = stopwatch_mode;
    assign dbg_stopwatch_running = stopwatch_running;
    assign dbg_stopwatch_min     = stopwatch_min;
    assign dbg_stopwatch_sec     = stopwatch_sec;
    assign dbg_stopwatch_cs      = stopwatch_cs;
    assign dbg_countdown_mode       = countdown_mode;
    assign dbg_countdown_running    = countdown_running;
    assign dbg_countdown_alarm_pulse = countdown_alarm_pulse;
    assign dbg_countdown_min        = countdown_min;
    assign dbg_countdown_sec        = countdown_sec;
endmodule
