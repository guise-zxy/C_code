`timescale 1ns / 1ps

module debounce #(
    parameter integer STABLE_TICKS = 2
) (
    input  wire clk,
    input  wire rst_n,
    input  wire sample_tick,
    input  wire key_in,
    output reg  key_pulse
);
    reg key_sync0;
    reg key_sync1;
    reg key_state;
    integer stable_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_sync0  <= 1'b0;
            key_sync1  <= 1'b0;
            key_state  <= 1'b0;
            key_pulse  <= 1'b0;
            stable_cnt <= 0;
        end else begin
            key_sync0 <= key_in;
            key_sync1 <= key_sync0;
            key_pulse <= 1'b0;

            if (sample_tick) begin
                if (key_sync1 == key_state) begin
                    stable_cnt <= 0;
                end else if (stable_cnt >= (STABLE_TICKS - 1)) begin
                    key_state  <= key_sync1;
                    stable_cnt <= 0;
                    if (key_sync1) begin
                        key_pulse <= 1'b1;
                    end
                end else begin
                    stable_cnt <= stable_cnt + 1;
                end
            end
        end
    end
endmodule
