`timescale 1ns / 1ps

module hour_chime #(
    parameter integer CLK_FREQ_HZ = 200000000,
    parameter integer TONE_FREQ_HZ = 2000,
    parameter integer CHIME_SECONDS = 1
) (
    input  wire clk,
    input  wire rst_n,
    input  wire start_pulse,
    input  wire hold_enable,
    output reg  beep
);
    localparam integer ACTIVE_CYCLES = ((CLK_FREQ_HZ * CHIME_SECONDS) < 1) ? 1 : (CLK_FREQ_HZ * CHIME_SECONDS);
    localparam integer HALF_TONE_DIV = ((CLK_FREQ_HZ / (TONE_FREQ_HZ * 2)) < 1) ? 1 : (CLK_FREQ_HZ / (TONE_FREQ_HZ * 2));

    integer active_cnt;
    integer tone_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active_cnt <= 0;
            tone_cnt   <= 0;
            beep       <= 1'b0;
        end else if (start_pulse) begin
            active_cnt <= ACTIVE_CYCLES;
            tone_cnt   <= 0;
            beep       <= 1'b0;
        end else if (hold_enable) begin
            active_cnt <= 0;
            if (HALF_TONE_DIV == 1) begin
                beep <= ~beep;
            end else if (tone_cnt == (HALF_TONE_DIV - 1)) begin
                tone_cnt <= 0;
                beep     <= ~beep;
            end else begin
                tone_cnt <= tone_cnt + 1;
            end
        end else if (active_cnt > 0) begin
            if (active_cnt == 1) begin
                active_cnt <= 0;
                tone_cnt   <= 0;
                beep       <= 1'b0;
            end else begin
                active_cnt <= active_cnt - 1;
                if (HALF_TONE_DIV == 1) begin
                    beep <= ~beep;
                end else if (tone_cnt == (HALF_TONE_DIV - 1)) begin
                    tone_cnt <= 0;
                    beep     <= ~beep;
                end else begin
                    tone_cnt <= tone_cnt + 1;
                end
            end
        end else begin
            tone_cnt <= 0;
            beep     <= 1'b0;
        end
    end
endmodule
