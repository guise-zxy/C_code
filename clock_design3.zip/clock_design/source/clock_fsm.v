`timescale 1ns / 1ps

module clock_fsm (
    input  wire clk,
    input  wire rst_n,
    input  wire force_run_pulse,
    input  wire key_mode_pulse,
    output reg  [3:0] state
);
    localparam [3:0] RUN            = 4'd0;
    localparam [3:0] SET_HOUR       = 4'd1;
    localparam [3:0] SET_MIN        = 4'd2;
    localparam [3:0] SET_ALARM_HOUR = 4'd3;
    localparam [3:0] SET_ALARM_MIN  = 4'd4;
    localparam [3:0] DATE_VIEW      = 4'd5;
    localparam [3:0] SET_MONTH      = 4'd6;
    localparam [3:0] SET_DAY        = 4'd7;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= RUN;
        end else if (force_run_pulse) begin
            state <= RUN;
        end else if (key_mode_pulse) begin
            case (state)
                RUN:            state <= SET_HOUR;
                SET_HOUR:       state <= SET_MIN;
                SET_MIN:        state <= SET_ALARM_HOUR;
                SET_ALARM_HOUR: state <= SET_ALARM_MIN;
                SET_ALARM_MIN:  state <= DATE_VIEW;
                DATE_VIEW:      state <= SET_MONTH;
                SET_MONTH:      state <= SET_DAY;
                default:        state <= RUN;
            endcase
        end
    end
endmodule
