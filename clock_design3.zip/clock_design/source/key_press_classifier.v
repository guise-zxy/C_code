`timescale 1ns / 1ps

module key_press_classifier #(
    parameter integer STABLE_TICKS = 2,
    parameter integer LONG_TICKS = 300
) (
    input  wire clk,
    input  wire rst_n,
    input  wire sample_tick,
    input  wire key_in,
    output reg  short_pulse,
    output reg  long_pulse,
    output reg  key_state
);
    reg key_sync0;
    reg key_sync1;
    reg long_fired;
    integer stable_cnt;
    integer hold_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_sync0    <= 1'b0;
            key_sync1    <= 1'b0;
            key_state    <= 1'b0;
            short_pulse  <= 1'b0;
            long_pulse   <= 1'b0;
            long_fired   <= 1'b0;
            stable_cnt   <= 0;
            hold_cnt     <= 0;
        end else begin
            key_sync0   <= key_in;
            key_sync1   <= key_sync0;
            short_pulse <= 1'b0;
            long_pulse  <= 1'b0;

            if (sample_tick) begin
                if (key_sync1 == key_state) begin
                    stable_cnt <= 0;
                end else if (stable_cnt >= (STABLE_TICKS - 1)) begin
                    key_state  <= key_sync1;
                    stable_cnt <= 0;
                    if (key_sync1) begin
                        hold_cnt   <= 0;
                        long_fired <= 1'b0;
                    end else begin
                        if (!long_fired) begin
                            short_pulse <= 1'b1;
                        end
                        hold_cnt   <= 0;
                        long_fired <= 1'b0;
                    end
                end else begin
                    stable_cnt <= stable_cnt + 1;
                end

                if (key_state && !long_fired) begin
                    if (hold_cnt >= (LONG_TICKS - 1)) begin
                        long_pulse  <= 1'b1;
                        long_fired  <= 1'b1;
                    end else begin
                        hold_cnt <= hold_cnt + 1;
                    end
                end else if (!key_state) begin
                    hold_cnt <= 0;
                end
            end
        end
    end
endmodule
