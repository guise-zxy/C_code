`timescale 1ns / 1ps

module clk_div #(
    parameter CLK_FREQ_HZ = 50000000,
    parameter SCAN_FREQ_HZ = 1000
) (
    input  wire clk,
    input  wire rst_n,
    output reg  tick_1hz,
    output reg  tick_10ms,
    output reg  tick_scan,
    output reg  tick_debounce,
    output reg  blink_1hz
);
    localparam integer SEC_DIV      = (CLK_FREQ_HZ < 1) ? 1 : CLK_FREQ_HZ;
    localparam integer CENTI_DIV    = ((CLK_FREQ_HZ / 100) < 1) ? 1 : (CLK_FREQ_HZ / 100);
    localparam integer HALF_SEC_DIV = ((CLK_FREQ_HZ / 2) < 1) ? 1 : (CLK_FREQ_HZ / 2);
    localparam integer SCAN_DIV     = ((CLK_FREQ_HZ / SCAN_FREQ_HZ) < 1) ? 1 : (CLK_FREQ_HZ / SCAN_FREQ_HZ);
    localparam integer DB_DIV       = ((CLK_FREQ_HZ / 1000) < 1) ? 1 : (CLK_FREQ_HZ / 1000);

    integer sec_cnt;
    integer centi_cnt;
    integer scan_cnt;
    integer db_cnt;
    integer blink_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sec_cnt       <= 0;
            centi_cnt     <= 0;
            scan_cnt      <= 0;
            db_cnt        <= 0;
            blink_cnt     <= 0;
            tick_1hz      <= 1'b0;
            tick_10ms     <= 1'b0;
            tick_scan     <= 1'b0;
            tick_debounce <= 1'b0;
            blink_1hz     <= 1'b1;
        end else begin
            tick_1hz      <= 1'b0;
            tick_10ms     <= 1'b0;
            tick_scan     <= 1'b0;
            tick_debounce <= 1'b0;

            if (sec_cnt == (SEC_DIV - 1)) begin
                sec_cnt  <= 0;
                tick_1hz <= 1'b1;
            end else begin
                sec_cnt  <= sec_cnt + 1;
            end

            if (centi_cnt == (CENTI_DIV - 1)) begin
                centi_cnt  <= 0;
                tick_10ms  <= 1'b1;
            end else begin
                centi_cnt  <= centi_cnt + 1;
            end

            if (scan_cnt == (SCAN_DIV - 1)) begin
                scan_cnt  <= 0;
                tick_scan <= 1'b1;
            end else begin
                scan_cnt  <= scan_cnt + 1;
            end

            if (db_cnt == (DB_DIV - 1)) begin
                db_cnt        <= 0;
                tick_debounce <= 1'b1;
            end else begin
                db_cnt        <= db_cnt + 1;
            end

            if (blink_cnt == (HALF_SEC_DIV - 1)) begin
                blink_cnt <= 0;
                blink_1hz <= ~blink_1hz;
            end else begin
                blink_cnt <= blink_cnt + 1;
            end
        end
    end
endmodule
