`timescale 1ns / 1ps

module stopwatch_counter (
    input  wire clk,
    input  wire rst_n,
    input  wire tick_10ms,
    input  wire mode_active,
    input  wire toggle_run_pulse,
    input  wire reset_pulse,
    output reg  running,
    output reg  [6:0] min,
    output reg  [5:0] sec,
    output reg  [6:0] cs
);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            running <= 1'b0;
            min     <= 7'd0;
            sec     <= 6'd0;
            cs      <= 7'd0;
        end else begin
            if (!mode_active) begin
                running <= 1'b0;
            end

            if (reset_pulse) begin
                running <= 1'b0;
                min     <= 7'd0;
                sec     <= 6'd0;
                cs      <= 7'd0;
            end else begin
                if (toggle_run_pulse) begin
                    running <= ~running;
                end

                if (running && tick_10ms) begin
                    if (cs == 7'd99) begin
                        cs <= 7'd0;
                        if (sec == 6'd59) begin
                            sec <= 6'd0;
                            if (min == 7'd99) begin
                                min <= 7'd0;
                            end else begin
                                min <= min + 7'd1;
                            end
                        end else begin
                            sec <= sec + 6'd1;
                        end
                    end else begin
                        cs <= cs + 7'd1;
                    end
                end
            end
        end
    end
endmodule
