`timescale 1ns / 1ps

module clock_board_top #(
    parameter integer CLK_FREQ_HZ = 200000000,
    parameter integer CORE_SCAN_FREQ_HZ = 1000,
    parameter integer DEBOUNCE_MS = 20,
    parameter integer BOARD_SCAN_FREQ_HZ = 1000,
    parameter SEG_ACTIVE_HIGH = 1'b1,
    parameter CS_ACTIVE_HIGH  = 1'b1
) (
    input  wire clk_p,
    input  wire clk_n,
    input  wire key1_n,
    input  wire key2_n,
    input  wire key3_n,
    input  wire key4_n,
    output wire led1_a,
    output wire led1_b,
    output wire led1_c,
    output wire led1_d,
    output wire led1_e,
    output wire led1_f,
    output wire led1_g,
    output wire led1_dp,
    output wire led1_cs1,
    output wire led1_cs2,
    output wire led2_a,
    output wire led2_b,
    output wire led2_c,
    output wire led2_d,
    output wire led2_e,
    output wire led2_f,
    output wire led2_g,
    output wire led2_dp,
    output wire led2_cs1,
    output wire led2_cs2,
    output wire led3_a,
    output wire led3_b,
    output wire led3_c,
    output wire led3_d,
    output wire led3_e,
    output wire led3_f,
    output wire led3_g,
    output wire led3_dp,
    output wire led3_cs1,
    output wire led3_cs2,
    output wire beep
);
    wire clk_200m;
    wire rst_n;
    wire key_mode;
    wire key_add;
    wire key_sub;
    wire [7:0] core_seg_unused;
    wire [3:0] core_an_unused;
    wire [4:0] dbg_hour;
    wire [5:0] dbg_min;
    wire [5:0] dbg_sec;
    wire [4:0] dbg_alarm_hour;
    wire [5:0] dbg_alarm_min;
    wire [4:0] dbg_month;
    wire [5:0] dbg_day;
    wire [3:0] dbg_state;
    wire dbg_hour_chime;
    wire dbg_alarm_active;
    wire dbg_stopwatch_mode;
    wire dbg_stopwatch_running;
    wire [6:0] dbg_stopwatch_min;
    wire [5:0] dbg_stopwatch_sec;
    wire [6:0] dbg_stopwatch_cs;
    wire dbg_countdown_mode;
    wire dbg_countdown_running;
    wire dbg_countdown_alarm_pulse;
    wire [5:0] dbg_countdown_min;
    wire [5:0] dbg_countdown_sec;
    wire [1:0] brightness_level;
    wire countdown_beep;
    wire hourly_beep;
    wire alarm_beep;

    localparam integer HALF_SEC_DIV = ((CLK_FREQ_HZ / 2) < 1) ? 1 : (CLK_FREQ_HZ / 2);

    integer blink_cnt;
    reg blink_1hz;

    IBUFDS u_ibufds_clk (
        .I (clk_p),
        .IB(clk_n),
        .O (clk_200m)
    );

    assign rst_n    = key4_n;
    assign key_mode = ~key1_n;
    assign key_add  = ~key2_n;
    assign key_sub  = ~key3_n;

    always @(posedge clk_200m or negedge rst_n) begin
        if (!rst_n) begin
            blink_cnt <= 0;
            blink_1hz <= 1'b1;
        end else if (blink_cnt == (HALF_SEC_DIV - 1)) begin
            blink_cnt <= 0;
            blink_1hz <= ~blink_1hz;
        end else begin
            blink_cnt <= blink_cnt + 1;
        end
    end

    clock_core_top #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .SCAN_FREQ_HZ(CORE_SCAN_FREQ_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS),
        .SEG_ACTIVE_LOW(1'b0),
        .AN_ACTIVE_LOW(1'b0)
    ) u_clock_core (
        .clk(clk_200m),
        .rst_n(rst_n),
        .key_mode(key_mode),
        .key_add(key_add),
        .key_sub(key_sub),
        .seg(core_seg_unused),
        .an(core_an_unused),
        .dbg_hour(dbg_hour),
        .dbg_min(dbg_min),
        .dbg_sec(dbg_sec),
        .dbg_state(dbg_state),
        .dbg_hour_chime(dbg_hour_chime),
        .dbg_alarm_hour(dbg_alarm_hour),
        .dbg_alarm_min(dbg_alarm_min),
        .dbg_alarm_active(dbg_alarm_active),
        .dbg_month(dbg_month),
        .dbg_day(dbg_day),
        .dbg_stopwatch_mode(dbg_stopwatch_mode),
        .dbg_stopwatch_running(dbg_stopwatch_running),
        .dbg_stopwatch_min(dbg_stopwatch_min),
        .dbg_stopwatch_sec(dbg_stopwatch_sec),
        .dbg_stopwatch_cs(dbg_stopwatch_cs),
        .dbg_countdown_mode(dbg_countdown_mode),
        .dbg_countdown_running(dbg_countdown_running),
        .dbg_countdown_alarm_pulse(dbg_countdown_alarm_pulse),
        .dbg_countdown_min(dbg_countdown_min),
        .dbg_countdown_sec(dbg_countdown_sec)
    );

    hour_chime #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .TONE_FREQ_HZ(2000),
        .CHIME_SECONDS(1)
    ) u_hour_chime (
        .clk(clk_200m),
        .rst_n(rst_n),
        .start_pulse(dbg_hour_chime),
        .hold_enable(1'b0),
        .beep(hourly_beep)
    );

    hour_chime #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .TONE_FREQ_HZ(2000),
        .CHIME_SECONDS(1)
    ) u_alarm_tone (
        .clk(clk_200m),
        .rst_n(rst_n),
        .start_pulse(1'b0),
        .hold_enable(dbg_alarm_active),
        .beep(alarm_beep)
    );

    hour_chime #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .TONE_FREQ_HZ(2500),
        .CHIME_SECONDS(1)
    ) u_countdown_tone (
        .clk(clk_200m),
        .rst_n(rst_n),
        .start_pulse(dbg_countdown_alarm_pulse),
        .hold_enable(1'b0),
        .beep(countdown_beep)
    );

    assign beep = hourly_beep | alarm_beep | countdown_beep;

    auto_brightness u_auto_brightness (
        .hour(dbg_hour),
        .level(brightness_level)
    );

    clock_board_display #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ),
        .SCAN_FREQ_HZ(BOARD_SCAN_FREQ_HZ),
        .SEG_ACTIVE_HIGH(SEG_ACTIVE_HIGH),
        .CS_ACTIVE_HIGH(CS_ACTIVE_HIGH)
    ) u_board_display (
        .clk(clk_200m),
        .rst_n(rst_n),
        .blink_1hz(blink_1hz),
        .state(dbg_state),
        .hour(dbg_hour),
        .min(dbg_min),
        .sec(dbg_sec),
        .alarm_hour(dbg_alarm_hour),
        .alarm_min(dbg_alarm_min),
        .month(dbg_month),
        .day(dbg_day),
        .stopwatch_mode(dbg_stopwatch_mode),
        .stopwatch_min(dbg_stopwatch_min),
        .stopwatch_sec(dbg_stopwatch_sec),
        .stopwatch_cs(dbg_stopwatch_cs),
        .countdown_mode(dbg_countdown_mode),
        .countdown_min(dbg_countdown_min),
        .countdown_sec(dbg_countdown_sec),
        .brightness_level(brightness_level),
        .led1_a(led1_a),
        .led1_b(led1_b),
        .led1_c(led1_c),
        .led1_d(led1_d),
        .led1_e(led1_e),
        .led1_f(led1_f),
        .led1_g(led1_g),
        .led1_dp(led1_dp),
        .led1_cs1(led1_cs1),
        .led1_cs2(led1_cs2),
        .led2_a(led2_a),
        .led2_b(led2_b),
        .led2_c(led2_c),
        .led2_d(led2_d),
        .led2_e(led2_e),
        .led2_f(led2_f),
        .led2_g(led2_g),
        .led2_dp(led2_dp),
        .led2_cs1(led2_cs1),
        .led2_cs2(led2_cs2),
        .led3_a(led3_a),
        .led3_b(led3_b),
        .led3_c(led3_c),
        .led3_d(led3_d),
        .led3_e(led3_e),
        .led3_f(led3_f),
        .led3_g(led3_g),
        .led3_dp(led3_dp),
        .led3_cs1(led3_cs1),
        .led3_cs2(led3_cs2)
    );
endmodule
