`timescale 1ns / 1ps

module auto_brightness (
    input  wire [4:0] hour,
    output reg  [1:0] level
);
    always @(*) begin
        if (hour >= 5'd22 || hour <= 5'd5) begin
            level = 2'd0;
        end else if (hour <= 5'd7) begin
            level = 2'd1;
        end else if (hour <= 5'd18) begin
            level = 2'd3;
        end else begin
            level = 2'd2;
        end
    end
endmodule
