`timescale 1ns / 1ps

module time_counter (
    input  wire clk,
    input  wire rst_n,
    input  wire tick_1hz,
    input  wire [3:0] state,
    input  wire key_add_pulse,
    input  wire key_sub_pulse,
    output reg  [4:0] hour,
    output reg  [5:0] min,
    output reg  [5:0] sec,
    output reg  [4:0] alarm_hour,
    output reg  [5:0] alarm_min,
    output reg  [4:0] month,
    output reg  [5:0] day,
    output reg  hour_chime_pulse,
    output reg  alarm_match_pulse
);
    localparam [3:0] RUN            = 4'd0;
    localparam [3:0] SET_HOUR       = 4'd1;
    localparam [3:0] SET_MIN        = 4'd2;
    localparam [3:0] SET_ALARM_HOUR = 4'd3;
    localparam [3:0] SET_ALARM_MIN  = 4'd4;
    localparam [3:0] SET_MONTH      = 4'd6;
    localparam [3:0] SET_DAY        = 4'd7;

    reg [4:0] next_hour;
    reg [5:0] next_min;
    reg [4:0] next_month;
    reg [5:0] next_day;
    reg [4:0] month_candidate;
    reg [5:0] day_candidate;

    function [5:0] max_day_in_month;
        input [4:0] month_value;
        begin
            case (month_value)
                5'd1, 5'd3, 5'd5, 5'd7, 5'd8, 5'd10, 5'd12: max_day_in_month = 6'd31;
                5'd4, 5'd6, 5'd9, 5'd11: max_day_in_month = 6'd30;
                5'd2: max_day_in_month = 6'd28;
                default: max_day_in_month = 6'd31;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hour              <= 5'd0;
            min               <= 6'd0;
            sec               <= 6'd0;
            alarm_hour        <= 5'd0;
            alarm_min         <= 6'd0;
            month             <= 5'd1;
            day               <= 6'd1;
            hour_chime_pulse  <= 1'b0;
            alarm_match_pulse <= 1'b0;
        end else begin
            hour_chime_pulse  <= 1'b0;
            alarm_match_pulse <= 1'b0;
            next_hour         = hour;
            next_min          = min;
            next_month        = month;
            next_day          = day;

            if ((state == SET_HOUR) && key_add_pulse) begin
                hour <= (hour == 5'd23) ? 5'd0 : (hour + 5'd1);
            end else if ((state == SET_HOUR) && key_sub_pulse) begin
                hour <= (hour == 5'd0) ? 5'd23 : (hour - 5'd1);
            end else if ((state == SET_MIN) && key_add_pulse) begin
                min <= (min == 6'd59) ? 6'd0 : (min + 6'd1);
            end else if ((state == SET_MIN) && key_sub_pulse) begin
                min <= (min == 6'd0) ? 6'd59 : (min - 6'd1);
            end else if ((state == SET_ALARM_HOUR) && key_add_pulse) begin
                alarm_hour <= (alarm_hour == 5'd23) ? 5'd0 : (alarm_hour + 5'd1);
            end else if ((state == SET_ALARM_HOUR) && key_sub_pulse) begin
                alarm_hour <= (alarm_hour == 5'd0) ? 5'd23 : (alarm_hour - 5'd1);
            end else if ((state == SET_ALARM_MIN) && key_add_pulse) begin
                alarm_min <= (alarm_min == 6'd59) ? 6'd0 : (alarm_min + 6'd1);
            end else if ((state == SET_ALARM_MIN) && key_sub_pulse) begin
                alarm_min <= (alarm_min == 6'd0) ? 6'd59 : (alarm_min - 6'd1);
            end else if ((state == SET_MONTH) && key_add_pulse) begin
                month_candidate = (month == 5'd12) ? 5'd1 : (month + 5'd1);
                month <= month_candidate;
                if (day > max_day_in_month(month_candidate)) begin
                    day <= max_day_in_month(month_candidate);
                end
            end else if ((state == SET_MONTH) && key_sub_pulse) begin
                month_candidate = (month == 5'd1) ? 5'd12 : (month - 5'd1);
                month <= month_candidate;
                if (day > max_day_in_month(month_candidate)) begin
                    day <= max_day_in_month(month_candidate);
                end
            end else if ((state == SET_DAY) && key_add_pulse) begin
                day_candidate = (day == max_day_in_month(month)) ? 6'd1 : (day + 6'd1);
                day <= day_candidate;
            end else if ((state == SET_DAY) && key_sub_pulse) begin
                day_candidate = (day == 6'd1) ? max_day_in_month(month) : (day - 6'd1);
                day <= day_candidate;
            end else if ((state == RUN) && tick_1hz) begin
                if (sec == 6'd59) begin
                    sec <= 6'd0;
                    if (min == 6'd59) begin
                        next_min = 6'd0;
                        if (hour == 5'd23) begin
                            next_hour = 5'd0;
                            if (day == max_day_in_month(month)) begin
                                next_day = 6'd1;
                                next_month = (month == 5'd12) ? 5'd1 : (month + 5'd1);
                            end else begin
                                next_day = day + 6'd1;
                            end
                            month <= next_month;
                            day   <= next_day;
                        end else begin
                            next_hour = hour + 5'd1;
                            hour_chime_pulse <= 1'b1;
                        end
                        min  <= next_min;
                        hour <= next_hour;
                    end else begin
                        next_min = min + 6'd1;
                        min      <= next_min;
                    end

                    if ((next_hour == alarm_hour) && (next_min == alarm_min)) begin
                        alarm_match_pulse <= 1'b1;
                    end
                end else begin
                    sec <= sec + 6'd1;
                end
            end
        end
    end
endmodule
