`timescale 1ns / 1ps

module alarm_control #(
    parameter integer ALARM_SECONDS = 30
) (
    input  wire clk,
    input  wire rst_n,
    input  wire tick_1hz,
    input  wire start_pulse,
    input  wire cancel_pulse,
    output reg  alarm_active
);
    integer remain_sec;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            remain_sec   <= 0;
            alarm_active <= 1'b0;
        end else if (cancel_pulse) begin
            remain_sec   <= 0;
            alarm_active <= 1'b0;
        end else if (start_pulse) begin
            remain_sec   <= ALARM_SECONDS;
            alarm_active <= 1'b1;
        end else if (alarm_active && tick_1hz) begin
            if (remain_sec <= 1) begin
                remain_sec   <= 0;
                alarm_active <= 1'b0;
            end else begin
                remain_sec <= remain_sec - 1;
            end
        end
    end
endmodule
