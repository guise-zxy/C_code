`timescale 1ns / 1ps

module seg_scan #(
    parameter SEG_ACTIVE_LOW = 1'b0,
    parameter AN_ACTIVE_LOW  = 1'b0
) (
    input  wire clk,
    input  wire rst_n,
    input  wire tick_scan,
    input  wire blink_1hz,
    input  wire [3:0] state,
    input  wire [4:0] hour,
    input  wire [5:0] min,
    input  wire [4:0] month,
    input  wire [5:0] day,
    input  wire stopwatch_mode,
    input  wire [6:0] stopwatch_min,
    input  wire [5:0] stopwatch_sec,
    input  wire countdown_mode,
    input  wire [5:0] countdown_min,
    input  wire [5:0] countdown_sec,
    output reg  [7:0] seg,
    output reg  [3:0] an
);
    localparam [3:0] SET_HOUR  = 4'd1;
    localparam [3:0] SET_MIN   = 4'd2;
    localparam [3:0] DATE_VIEW = 4'd5;
    localparam [3:0] SET_MONTH = 4'd6;
    localparam [3:0] SET_DAY   = 4'd7;

    reg [1:0] scan_sel;
    reg [3:0] digit_val;
    reg [6:0] seg_raw;
    reg [3:0] an_raw;
    reg       digit_blank;

    wire [3:0] hour_tens  = hour / 10;
    wire [3:0] hour_ones  = hour % 10;
    wire [3:0] min_tens   = min / 10;
    wire [3:0] min_ones   = min % 10;
    wire [3:0] month_tens = month / 10;
    wire [3:0] month_ones = month % 10;
    wire [3:0] day_tens   = day / 10;
    wire [3:0] day_ones   = day % 10;
    wire [3:0] sw_min_tens = stopwatch_min / 10;
    wire [3:0] sw_min_ones = stopwatch_min % 10;
    wire [3:0] sw_sec_tens = stopwatch_sec / 10;
    wire [3:0] sw_sec_ones = stopwatch_sec % 10;
    wire [3:0] cd_min_tens = countdown_min / 10;
    wire [3:0] cd_min_ones = countdown_min % 10;
    wire [3:0] cd_sec_tens = countdown_sec / 10;
    wire [3:0] cd_sec_ones = countdown_sec % 10;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scan_sel <= 2'd0;
        end else if (tick_scan) begin
            scan_sel <= scan_sel + 2'd1;
        end
    end

    always @(*) begin
        digit_val   = 4'd0;
        an_raw      = 4'b0001;
        digit_blank = 1'b0;
        seg_raw     = 7'b1111110;

        case (scan_sel)
            2'd0: begin
                digit_val = hour_tens;
                an_raw    = 4'b0001;
            end
            2'd1: begin
                digit_val = hour_ones;
                an_raw    = 4'b0010;
            end
            2'd2: begin
                digit_val = min_tens;
                an_raw    = 4'b0100;
            end
            default: begin
                digit_val = min_ones;
                an_raw    = 4'b1000;
            end
        endcase

        if (stopwatch_mode) begin
            case (scan_sel)
                2'd0: digit_val = sw_min_tens;
                2'd1: digit_val = sw_min_ones;
                2'd2: digit_val = sw_sec_tens;
                default: digit_val = sw_sec_ones;
            endcase
        end else if (countdown_mode) begin
            case (scan_sel)
                2'd0: digit_val = cd_min_tens;
                2'd1: digit_val = cd_min_ones;
                2'd2: digit_val = cd_sec_tens;
                default: digit_val = cd_sec_ones;
            endcase
        end else if ((state == DATE_VIEW) || (state == SET_MONTH) || (state == SET_DAY)) begin
            case (scan_sel)
                2'd0: digit_val = month_tens;
                2'd1: digit_val = month_ones;
                2'd2: digit_val = day_tens;
                default: digit_val = day_ones;
            endcase
        end

        if (!stopwatch_mode && !countdown_mode && (state == SET_HOUR) && !blink_1hz && ((scan_sel == 2'd0) || (scan_sel == 2'd1))) begin
            digit_blank = 1'b1;
        end
        if (!stopwatch_mode && !countdown_mode && (state == SET_MIN) && !blink_1hz && ((scan_sel == 2'd2) || (scan_sel == 2'd3))) begin
            digit_blank = 1'b1;
        end
        if (!stopwatch_mode && !countdown_mode && (state == SET_MONTH) && !blink_1hz && ((scan_sel == 2'd0) || (scan_sel == 2'd1))) begin
            digit_blank = 1'b1;
        end
        if (!stopwatch_mode && !countdown_mode && (state == SET_DAY) && !blink_1hz && ((scan_sel == 2'd2) || (scan_sel == 2'd3))) begin
            digit_blank = 1'b1;
        end

        case (digit_val)
            4'd0: seg_raw = 7'b1111110;
            4'd1: seg_raw = 7'b0110000;
            4'd2: seg_raw = 7'b1101101;
            4'd3: seg_raw = 7'b1111001;
            4'd4: seg_raw = 7'b0110011;
            4'd5: seg_raw = 7'b1011011;
            4'd6: seg_raw = 7'b1011111;
            4'd7: seg_raw = 7'b1110000;
            4'd8: seg_raw = 7'b1111111;
            4'd9: seg_raw = 7'b1111011;
            default: seg_raw = 7'b0000000;
        endcase
    end

    always @(*) begin
        if (digit_blank) begin
            seg = SEG_ACTIVE_LOW ? 8'hff : 8'h00;
        end else begin
            seg = SEG_ACTIVE_LOW ? {1'b1, ~seg_raw} : {1'b0, seg_raw};
        end

        if (AN_ACTIVE_LOW) begin
            an = ~an_raw;
        end else begin
            an = an_raw;
        end
    end
endmodule
