`timescale 1ns / 1ps

module clock_board_display #(
    parameter integer CLK_FREQ_HZ = 200000000,
    parameter integer SCAN_FREQ_HZ = 1000,
    parameter SEG_ACTIVE_HIGH = 1'b1,
    parameter CS_ACTIVE_HIGH  = 1'b1
) (
    input  wire clk,
    input  wire rst_n,
    input  wire blink_1hz,
    input  wire [3:0] state,
    input  wire [4:0] hour,
    input  wire [5:0] min,
    input  wire [5:0] sec,
    input  wire [4:0] alarm_hour,
    input  wire [5:0] alarm_min,
    input  wire [4:0] month,
    input  wire [5:0] day,
    input  wire stopwatch_mode,
    input  wire [6:0] stopwatch_min,
    input  wire [5:0] stopwatch_sec,
    input  wire [6:0] stopwatch_cs,
    input  wire countdown_mode,
    input  wire [5:0] countdown_min,
    input  wire [5:0] countdown_sec,
    input  wire [1:0] brightness_level,
    output reg  led1_a,
    output reg  led1_b,
    output reg  led1_c,
    output reg  led1_d,
    output reg  led1_e,
    output reg  led1_f,
    output reg  led1_g,
    output reg  led1_dp,
    output reg  led1_cs1,
    output reg  led1_cs2,
    output reg  led2_a,
    output reg  led2_b,
    output reg  led2_c,
    output reg  led2_d,
    output reg  led2_e,
    output reg  led2_f,
    output reg  led2_g,
    output reg  led2_dp,
    output reg  led2_cs1,
    output reg  led2_cs2,
    output reg  led3_a,
    output reg  led3_b,
    output reg  led3_c,
    output reg  led3_d,
    output reg  led3_e,
    output reg  led3_f,
    output reg  led3_g,
    output reg  led3_dp,
    output reg  led3_cs1,
    output reg  led3_cs2
);
    localparam [3:0] SET_HOUR       = 4'd1;
    localparam [3:0] SET_MIN        = 4'd2;
    localparam [3:0] SET_ALARM_HOUR = 4'd3;
    localparam [3:0] SET_ALARM_MIN  = 4'd4;
    localparam [3:0] DATE_VIEW      = 4'd5;
    localparam [3:0] SET_MONTH      = 4'd6;
    localparam [3:0] SET_DAY        = 4'd7;
    localparam integer SCAN_DIV = ((CLK_FREQ_HZ / SCAN_FREQ_HZ) < 1) ? 1 : (CLK_FREQ_HZ / SCAN_FREQ_HZ);

    reg scan_sel;
    integer scan_cnt;
    reg [3:0] led1_digit;
    reg [3:0] led2_digit;
    reg [3:0] led3_digit;
    reg led1_blank;
    reg led2_blank;
    reg led3_blank;
    reg [6:0] led1_seg_raw;
    reg [6:0] led2_seg_raw;
    reg [6:0] led3_seg_raw;
    reg led1_cs1_raw;
    reg led1_cs2_raw;
    reg led2_cs1_raw;
    reg led2_cs2_raw;
    reg led3_cs1_raw;
    reg led3_cs2_raw;
    reg [15:0] pwm_cnt;
    reg pwm_on;

    wire [3:0] hour_tens  = hour / 10;
    wire [3:0] hour_ones  = hour % 10;
    wire [3:0] min_tens   = min / 10;
    wire [3:0] min_ones   = min % 10;
    wire [3:0] sec_tens   = sec / 10;
    wire [3:0] sec_ones   = sec % 10;
    wire [3:0] alarm_h_tens = alarm_hour / 10;
    wire [3:0] alarm_h_ones = alarm_hour % 10;
    wire [3:0] alarm_m_tens = alarm_min / 10;
    wire [3:0] alarm_m_ones = alarm_min % 10;
    wire [3:0] month_tens   = month / 10;
    wire [3:0] month_ones   = month % 10;
    wire [3:0] day_tens     = day / 10;
    wire [3:0] day_ones     = day % 10;
    wire [3:0] sw_min_tens  = stopwatch_min / 10;
    wire [3:0] sw_min_ones  = stopwatch_min % 10;
    wire [3:0] sw_sec_tens  = stopwatch_sec / 10;
    wire [3:0] sw_sec_ones  = stopwatch_sec % 10;
    wire [3:0] sw_cs_tens   = stopwatch_cs / 10;
    wire [3:0] sw_cs_ones   = stopwatch_cs % 10;
    wire [3:0] cd_min_tens  = countdown_min / 10;
    wire [3:0] cd_min_ones  = countdown_min % 10;
    wire [3:0] cd_sec_tens  = countdown_sec / 10;
    wire [3:0] cd_sec_ones  = countdown_sec % 10;

    function [6:0] seg7;
        input [3:0] digit;
        begin
            case (digit)
                4'd0: seg7 = 7'b1111110;
                4'd1: seg7 = 7'b0110000;
                4'd2: seg7 = 7'b1101101;
                4'd3: seg7 = 7'b1111001;
                4'd4: seg7 = 7'b0110011;
                4'd5: seg7 = 7'b1011011;
                4'd6: seg7 = 7'b1011111;
                4'd7: seg7 = 7'b1110000;
                4'd8: seg7 = 7'b1111111;
                4'd9: seg7 = 7'b1111011;
                default: seg7 = 7'b0000000;
            endcase
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scan_cnt <= 0;
            scan_sel <= 1'b0;
            pwm_cnt  <= 16'd0;
        end else if (scan_cnt == (SCAN_DIV - 1)) begin
            scan_cnt <= 0;
            scan_sel <= ~scan_sel;
            pwm_cnt  <= pwm_cnt + 16'd1;
        end else begin
            scan_cnt <= scan_cnt + 1;
        end
    end

    always @(*) begin
        case (brightness_level)
            2'd0: pwm_on = (pwm_cnt[3:0] < 4'd3);
            2'd1: pwm_on = (pwm_cnt[3:0] < 4'd6);
            2'd2: pwm_on = (pwm_cnt[3:0] < 4'd10);
            default: pwm_on = 1'b1;
        endcase
    end

    always @(*) begin
        led1_digit = scan_sel ? sec_ones : sec_tens;
        led2_digit = scan_sel ? min_ones : min_tens;
        led3_digit = scan_sel ? hour_ones : hour_tens;

        led1_blank = 1'b0;
        led2_blank = (state == SET_MIN)  && !blink_1hz;
        led3_blank = (state == SET_HOUR) && !blink_1hz;

        if (stopwatch_mode) begin
            led1_digit = scan_sel ? sw_cs_ones  : sw_cs_tens;
            led2_digit = scan_sel ? sw_sec_ones : sw_sec_tens;
            led3_digit = scan_sel ? sw_min_ones : sw_min_tens;
            led1_blank = 1'b0;
            led2_blank = 1'b0;
            led3_blank = 1'b0;
        end else if (countdown_mode) begin
            led1_digit = 4'd0;
            led2_digit = scan_sel ? cd_sec_ones : cd_sec_tens;
            led3_digit = scan_sel ? cd_min_ones : cd_min_tens;
            led1_blank = 1'b1;
            led2_blank = 1'b0;
            led3_blank = 1'b0;
        end else if (state == SET_ALARM_HOUR || state == SET_ALARM_MIN) begin
            led1_digit = 4'd0;
            led2_digit = scan_sel ? alarm_m_ones : alarm_m_tens;
            led3_digit = scan_sel ? alarm_h_ones : alarm_h_tens;
            led1_blank = 1'b1;
            led2_blank = (state == SET_ALARM_MIN)  && !blink_1hz;
            led3_blank = (state == SET_ALARM_HOUR) && !blink_1hz;
        end else if (state == DATE_VIEW || state == SET_MONTH || state == SET_DAY) begin
            led1_digit = 4'd0;
            led2_digit = scan_sel ? day_ones   : day_tens;
            led3_digit = scan_sel ? month_ones : month_tens;
            led1_blank = 1'b1;
            led2_blank = (state == SET_DAY)   && !blink_1hz;
            led3_blank = (state == SET_MONTH) && !blink_1hz;
        end

        led1_seg_raw = (led1_blank || !pwm_on) ? 7'b0000000 : seg7(led1_digit);
        led2_seg_raw = (led2_blank || !pwm_on) ? 7'b0000000 : seg7(led2_digit);
        led3_seg_raw = (led3_blank || !pwm_on) ? 7'b0000000 : seg7(led3_digit);

        led1_cs1_raw = ~scan_sel;
        led1_cs2_raw =  scan_sel;
        led2_cs1_raw = ~scan_sel;
        led2_cs2_raw =  scan_sel;
        led3_cs1_raw = ~scan_sel;
        led3_cs2_raw =  scan_sel;
    end

    always @(*) begin
        if (SEG_ACTIVE_HIGH) begin
            {led1_a, led1_b, led1_c, led1_d, led1_e, led1_f, led1_g} = led1_seg_raw;
            {led2_a, led2_b, led2_c, led2_d, led2_e, led2_f, led2_g} = led2_seg_raw;
            {led3_a, led3_b, led3_c, led3_d, led3_e, led3_f, led3_g} = led3_seg_raw;
            led1_dp = 1'b0;
            led2_dp = 1'b0;
            led3_dp = 1'b0;
        end else begin
            {led1_a, led1_b, led1_c, led1_d, led1_e, led1_f, led1_g} = ~led1_seg_raw;
            {led2_a, led2_b, led2_c, led2_d, led2_e, led2_f, led2_g} = ~led2_seg_raw;
            {led3_a, led3_b, led3_c, led3_d, led3_e, led3_f, led3_g} = ~led3_seg_raw;
            led1_dp = 1'b1;
            led2_dp = 1'b1;
            led3_dp = 1'b1;
        end

        if (CS_ACTIVE_HIGH) begin
            led1_cs1 = led1_cs1_raw;
            led1_cs2 = led1_cs2_raw;
            led2_cs1 = led2_cs1_raw;
            led2_cs2 = led2_cs2_raw;
            led3_cs1 = led3_cs1_raw;
            led3_cs2 = led3_cs2_raw;
        end else begin
            led1_cs1 = ~led1_cs1_raw;
            led1_cs2 = ~led1_cs2_raw;
            led2_cs1 = ~led2_cs1_raw;
            led2_cs2 = ~led2_cs2_raw;
            led3_cs1 = ~led3_cs1_raw;
            led3_cs2 = ~led3_cs2_raw;
        end
    end
endmodule
