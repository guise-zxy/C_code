`timescale 1ns / 1ps

module countdown_counter (
    input  wire clk,
    input  wire rst_n,
    input  wire tick_1hz,
    input  wire mode_active,
    input  wire toggle_run_pulse,
    input  wire add_pulse,
    input  wire sub_pulse,
    output reg  running,
    output reg  alarm_pulse,
    output reg  [5:0] min,
    output reg  [5:0] sec
);
    wire time_is_zero = (min == 6'd0) && (sec == 6'd0);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            running    <= 1'b0;
            alarm_pulse <= 1'b0;
            min        <= 6'd0;
            sec        <= 6'd0;
        end else begin
            alarm_pulse <= 1'b0;

            if (!mode_active) begin
                running <= 1'b0;
            end

            if (mode_active && !running) begin
                if (add_pulse) begin
                    if (min == 6'd59) begin
                        min <= 6'd0;
                    end else begin
                        min <= min + 6'd1;
                    end
                end

                if (sub_pulse) begin
                    if (min == 6'd0 && sec == 6'd0) begin
                        min <= 6'd59;
                        sec <= 6'd55;
                    end else if (sec >= 6'd5) begin
                        sec <= sec - 6'd5;
                    end else if (min != 6'd0) begin
                        min <= min - 6'd1;
                        sec <= sec + 6'd55;
                    end else begin
                        min <= 6'd0;
                        sec <= 6'd0;
                    end
                end
            end

            if (toggle_run_pulse) begin
                if (running) begin
                    running <= 1'b0;
                end else if (!time_is_zero) begin
                    running <= 1'b1;
                end
            end

            if (running && tick_1hz) begin
                if (sec == 6'd0) begin
                    if (min == 6'd0) begin
                        running <= 1'b0;
                    end else begin
                        min <= min - 6'd1;
                        sec <= 6'd59;
                    end
                end else begin
                    sec <= sec - 6'd1;
                end

                if ((min == 6'd0) && (sec == 6'd1)) begin
                    running     <= 1'b0;
                    alarm_pulse <= 1'b1;
                end
            end
        end
    end
endmodule
