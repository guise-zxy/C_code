## Differential 200MHz clock
set_property PACKAGE_PIN AD12 [get_ports clk_p]
set_property PACKAGE_PIN AD11 [get_ports clk_n]
set_property IOSTANDARD LVDS [get_ports {clk_p clk_n}]
create_clock -name sys_clk_200m -period 5.000 [get_ports clk_p]

## Independent push buttons, active low when pressed
set_property PACKAGE_PIN D11 [get_ports key1_n]
set_property PACKAGE_PIN C11 [get_ports key2_n]
set_property PACKAGE_PIN E14 [get_ports key3_n]
set_property PACKAGE_PIN B13 [get_ports key4_n]
set_property IOSTANDARD LVCMOS33 [get_ports {key1_n key2_n key3_n key4_n}]

## LED1 two-digit seven-segment, used for seconds
set_property PACKAGE_PIN K14 [get_ports led1_a]
set_property PACKAGE_PIN L15 [get_ports led1_b]
set_property PACKAGE_PIN H16 [get_ports led1_c]
set_property PACKAGE_PIN J16 [get_ports led1_d]
set_property PACKAGE_PIN K16 [get_ports led1_e]
set_property PACKAGE_PIN K15 [get_ports led1_f]
set_property PACKAGE_PIN L12 [get_ports led1_g]
set_property PACKAGE_PIN K13 [get_ports led1_dp]
set_property PACKAGE_PIN L16 [get_ports led1_cs1]
set_property PACKAGE_PIN L13 [get_ports led1_cs2]

## LED2 two-digit seven-segment, used for minutes
set_property PACKAGE_PIN J13 [get_ports led2_a]
set_property PACKAGE_PIN H11 [get_ports led2_b]
set_property PACKAGE_PIN J12 [get_ports led2_c]
set_property PACKAGE_PIN L11 [get_ports led2_d]
set_property PACKAGE_PIN J11 [get_ports led2_e]
set_property PACKAGE_PIN H12 [get_ports led2_f]
set_property PACKAGE_PIN F13 [get_ports led2_g]
set_property PACKAGE_PIN G13 [get_ports led2_dp]
set_property PACKAGE_PIN K11 [get_ports led2_cs1]
set_property PACKAGE_PIN J14 [get_ports led2_cs2]

## LED3 two-digit seven-segment, used for hours
set_property PACKAGE_PIN AG28 [get_ports led3_a]
set_property PACKAGE_PIN AG27 [get_ports led3_b]
set_property PACKAGE_PIN AF27 [get_ports led3_c]
set_property PACKAGE_PIN AC26 [get_ports led3_d]
set_property PACKAGE_PIN AF26 [get_ports led3_e]
set_property PACKAGE_PIN AH27 [get_ports led3_f]
set_property PACKAGE_PIN AJ26 [get_ports led3_g]
set_property PACKAGE_PIN AF30 [get_ports led3_dp]
set_property PACKAGE_PIN AH26 [get_ports led3_cs1]
set_property PACKAGE_PIN AF28 [get_ports led3_cs2]

## Buzzer
set_property PACKAGE_PIN W19 [get_ports beep]
set_property IOSTANDARD LVCMOS33 [get_ports beep]

set_property IOSTANDARD LVCMOS33 [get_ports {
    led1_a led1_b led1_c led1_d led1_e led1_f led1_g led1_dp led1_cs1 led1_cs2
    led2_a led2_b led2_c led2_d led2_e led2_f led2_g led2_dp led2_cs1 led2_cs2
    led3_a led3_b led3_c led3_d led3_e led3_f led3_g led3_dp led3_cs1 led3_cs2
}]
