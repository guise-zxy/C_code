set origin_dir [file dirname [info script]]
set out_dir [file normalize [file join $origin_dir build]]
file mkdir $out_dir

read_verilog [file join $origin_dir source clk_div.v]
read_verilog [file join $origin_dir source debounce.v]
read_verilog [file join $origin_dir source key_press_classifier.v]
read_verilog [file join $origin_dir source clock_fsm.v]
read_verilog [file join $origin_dir source time_counter.v]
read_verilog [file join $origin_dir source alarm_control.v]
read_verilog [file join $origin_dir source stopwatch_counter.v]
read_verilog [file join $origin_dir source countdown_counter.v]
read_verilog [file join $origin_dir source auto_brightness.v]
read_verilog [file join $origin_dir source seg_scan.v]
read_verilog [file join $origin_dir source clock_core_top.v]
read_verilog [file join $origin_dir source hour_chime.v]
read_verilog [file join $origin_dir source clock_board_display.v]
read_verilog [file join $origin_dir source clock_board_top.v]
read_xdc     [file join $origin_dir constraints clock_board_top.xdc]

synth_design -top clock_board_top -part xc7k325tffg900-2
set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]
opt_design
place_design
route_design

report_timing_summary -file [file join $out_dir timing_summary.rpt]
report_utilization -file [file join $out_dir utilization.rpt]
report_drc -file [file join $out_dir drc.rpt]

write_checkpoint -force [file join $out_dir clock_board_top_routed.dcp]
write_bitstream  -force [file join $out_dir clock_board_top.bit]
write_debug_probes -force [file join $out_dir clock_board_top.ltx]
