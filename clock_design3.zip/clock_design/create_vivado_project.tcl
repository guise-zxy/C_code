set origin_dir [file dirname [info script]]
set project_dir [file normalize [file join $origin_dir vivado_project]]
file mkdir $project_dir

set project_name clock_board_top
set part_name xc7k325tffg900-2

create_project $project_name $project_dir -part $part_name -force

set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]

add_files -norecurse [file join $origin_dir source clk_div.v]
add_files -norecurse [file join $origin_dir source debounce.v]
add_files -norecurse [file join $origin_dir source key_press_classifier.v]
add_files -norecurse [file join $origin_dir source clock_fsm.v]
add_files -norecurse [file join $origin_dir source time_counter.v]
add_files -norecurse [file join $origin_dir source alarm_control.v]
add_files -norecurse [file join $origin_dir source stopwatch_counter.v]
add_files -norecurse [file join $origin_dir source countdown_counter.v]
add_files -norecurse [file join $origin_dir source auto_brightness.v]
add_files -norecurse [file join $origin_dir source seg_scan.v]
add_files -norecurse [file join $origin_dir source clock_core_top.v]
add_files -norecurse [file join $origin_dir source hour_chime.v]
add_files -norecurse [file join $origin_dir source clock_board_display.v]
add_files -norecurse [file join $origin_dir source clock_board_top.v]

add_files -fileset constrs_1 -norecurse [file join $origin_dir constraints clock_board_top.xdc]

add_files -fileset sim_1 -norecurse [file join $origin_dir sim alarm_control_tb.v]
add_files -fileset sim_1 -norecurse [file join $origin_dir sim clock_board_display_tb.v]
add_files -fileset sim_1 -norecurse [file join $origin_dir sim clock_core_tb.v]
add_files -fileset sim_1 -norecurse [file join $origin_dir sim hour_chime_tb.v]

set_property top clock_board_top [current_fileset]
set_property top clock_core_tb [get_filesets sim_1]

update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

set_property source_mgmt_mode All [current_project]

save_project_as $project_name $project_dir -force
