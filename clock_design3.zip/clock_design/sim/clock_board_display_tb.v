`timescale 1ns / 1ps

module clock_board_display_tb;
    localparam [3:0] RUN            = 4'd0;
    localparam [3:0] SET_HOUR       = 4'd1;
    localparam [3:0] SET_MIN        = 4'd2;
    localparam [3:0] SET_ALARM_HOUR = 4'd3;
    localparam [3:0] SET_ALARM_MIN  = 4'd4;
    localparam [3:0] DATE_VIEW      = 4'd5;
    localparam [3:0] SET_MONTH      = 4'd6;
    localparam [3:0] SET_DAY        = 4'd7;
    localparam [3:0] STOPWATCH      = 4'd8;
    localparam [3:0] COUNTDOWN      = 4'd9;

    reg clk;
    reg rst_n;
    reg blink_1hz;
    reg [3:0] state;
    reg [4:0] hour;
    reg [5:0] min;
    reg [5:0] sec;
    reg [4:0] alarm_hour;
    reg [5:0] alarm_min;
    reg [4:0] month;
    reg [5:0] day;
    reg stopwatch_mode;
    reg [6:0] stopwatch_min;
    reg [5:0] stopwatch_sec;
    reg [6:0] stopwatch_cs;
    reg countdown_mode;
    reg [5:0] countdown_min;
    reg [5:0] countdown_sec;

    wire led1_a;
    wire led1_b;
    wire led1_c;
    wire led1_d;
    wire led1_e;
    wire led1_f;
    wire led1_g;
    wire led1_dp;
    wire led1_cs1;
    wire led1_cs2;
    wire led2_a;
    wire led2_b;
    wire led2_c;
    wire led2_d;
    wire led2_e;
    wire led2_f;
    wire led2_g;
    wire led2_dp;
    wire led2_cs1;
    wire led2_cs2;
    wire led3_a;
    wire led3_b;
    wire led3_c;
    wire led3_d;
    wire led3_e;
    wire led3_f;
    wire led3_g;
    wire led3_dp;
    wire led3_cs1;
    wire led3_cs2;

    integer sample_idx;
    reg saw_hour_tens;
    reg saw_hour_ones;
    reg saw_min_tens;
    reg saw_min_ones;
    reg saw_sec_tens;
    reg saw_sec_ones;
    reg saw_hour_blank;
    reg saw_min_blank;
    reg saw_sec_active;

    wire [6:0] led1_seg = {led1_a, led1_b, led1_c, led1_d, led1_e, led1_f, led1_g};
    wire [6:0] led2_seg = {led2_a, led2_b, led2_c, led2_d, led2_e, led2_f, led2_g};
    wire [6:0] led3_seg = {led3_a, led3_b, led3_c, led3_d, led3_e, led3_f, led3_g};

    clock_board_display #(
        .CLK_FREQ_HZ(100),
        .SCAN_FREQ_HZ(20),
        .SEG_ACTIVE_HIGH(1'b1),
        .CS_ACTIVE_HIGH(1'b1)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .blink_1hz(blink_1hz),
        .state(state),
        .hour(hour),
        .min(min),
        .sec(sec),
        .alarm_hour(alarm_hour),
        .alarm_min(alarm_min),
        .month(month),
        .day(day),
        .stopwatch_mode(stopwatch_mode),
        .stopwatch_min(stopwatch_min),
        .stopwatch_sec(stopwatch_sec),
        .stopwatch_cs(stopwatch_cs),
        .countdown_mode(countdown_mode),
        .countdown_min(countdown_min),
        .countdown_sec(countdown_sec),
        .led1_a(led1_a),
        .led1_b(led1_b),
        .led1_c(led1_c),
        .led1_d(led1_d),
        .led1_e(led1_e),
        .led1_f(led1_f),
        .led1_g(led1_g),
        .led1_dp(led1_dp),
        .led1_cs1(led1_cs1),
        .led1_cs2(led1_cs2),
        .led2_a(led2_a),
        .led2_b(led2_b),
        .led2_c(led2_c),
        .led2_d(led2_d),
        .led2_e(led2_e),
        .led2_f(led2_f),
        .led2_g(led2_g),
        .led2_dp(led2_dp),
        .led2_cs1(led2_cs1),
        .led2_cs2(led2_cs2),
        .led3_a(led3_a),
        .led3_b(led3_b),
        .led3_c(led3_c),
        .led3_d(led3_d),
        .led3_e(led3_e),
        .led3_f(led3_f),
        .led3_g(led3_g),
        .led3_dp(led3_dp),
        .led3_cs1(led3_cs1),
        .led3_cs2(led3_cs2)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    function [6:0] seg7;
        input [3:0] digit;
        begin
            case (digit)
                4'd0: seg7 = 7'b1111110;
                4'd1: seg7 = 7'b0110000;
                4'd2: seg7 = 7'b1101101;
                4'd3: seg7 = 7'b1111001;
                4'd4: seg7 = 7'b0110011;
                4'd5: seg7 = 7'b1011011;
                4'd6: seg7 = 7'b1011111;
                4'd7: seg7 = 7'b1110000;
                4'd8: seg7 = 7'b1111111;
                4'd9: seg7 = 7'b1111011;
                default: seg7 = 7'b0000000;
            endcase
        end
    endfunction

    initial begin
        rst_n = 1'b0;
        blink_1hz = 1'b1;
        state = RUN;
        hour = 5'd12;
        min  = 6'd34;
        sec  = 6'd56;
        alarm_hour = 5'd7;
        alarm_min  = 6'd45;
        month = 5'd11;
        day   = 6'd23;
        stopwatch_mode = 1'b0;
        stopwatch_min  = 7'd0;
        stopwatch_sec  = 6'd15;
        stopwatch_cs   = 7'd23;
        countdown_mode = 1'b0;
        countdown_min  = 6'd2;
        countdown_sec  = 6'd45;
        #40;
        rst_n = 1'b1;

        saw_hour_tens = 1'b0;
        saw_hour_ones = 1'b0;
        saw_min_tens  = 1'b0;
        saw_min_ones  = 1'b0;
        saw_sec_tens  = 1'b0;
        saw_sec_ones  = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (led3_cs1 && (led3_seg == seg7(4'd1))) saw_hour_tens = 1'b1;
            if (led3_cs2 && (led3_seg == seg7(4'd2))) saw_hour_ones = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd3))) saw_min_tens  = 1'b1;
            if (led2_cs2 && (led2_seg == seg7(4'd4))) saw_min_ones  = 1'b1;
            if (led1_cs1 && (led1_seg == seg7(4'd5))) saw_sec_tens  = 1'b1;
            if (led1_cs2 && (led1_seg == seg7(4'd6))) saw_sec_ones  = 1'b1;
        end
        if (!saw_hour_tens || !saw_hour_ones || !saw_min_tens || !saw_min_ones || !saw_sec_tens || !saw_sec_ones) begin
            $display("FAIL: RUN mode does not show HHMMSS as LED3/LED2/LED1");
            $finish;
        end

        state = SET_HOUR;
        blink_1hz = 1'b0;
        saw_hour_blank = 1'b0;
        saw_min_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led3_seg == 7'b0000000) && (led3_cs1 || led3_cs2)) saw_hour_blank = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd3))) saw_min_tens = 1'b1;
            if ((led1_seg != 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_hour_blank) begin
            $display("FAIL: SET_HOUR did not blank hour digits");
            $finish;
        end
        if (!saw_min_tens || !saw_sec_active) begin
            $display("FAIL: SET_HOUR should keep minute/second visible");
            $finish;
        end

        state = SET_MIN;
        saw_min_blank = 1'b0;
        saw_hour_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led2_seg == 7'b0000000) && (led2_cs1 || led2_cs2)) saw_min_blank = 1'b1;
            if (led3_cs1 && (led3_seg == seg7(4'd1))) saw_hour_tens = 1'b1;
            if ((led1_seg != 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_min_blank) begin
            $display("FAIL: SET_MIN did not blank minute digits");
            $finish;
        end
        if (!saw_hour_tens || !saw_sec_active) begin
            $display("FAIL: SET_MIN should keep hour/second visible");
            $finish;
        end

        state = SET_ALARM_HOUR;
        blink_1hz = 1'b0;
        saw_hour_blank = 1'b0;
        saw_min_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led3_seg == 7'b0000000) && (led3_cs1 || led3_cs2)) saw_hour_blank = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd4))) saw_min_tens = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_hour_blank) begin
            $display("FAIL: SET_ALARM_HOUR did not blank alarm hour digits");
            $finish;
        end
        if (!saw_min_tens || !saw_sec_active) begin
            $display("FAIL: SET_ALARM_HOUR should show alarm minute and blank LED1");
            $finish;
        end

        state = SET_ALARM_MIN;
        saw_min_blank = 1'b0;
        saw_hour_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led2_seg == 7'b0000000) && (led2_cs1 || led2_cs2)) saw_min_blank = 1'b1;
            if (led3_cs1 && (led3_seg == seg7(4'd0))) saw_hour_tens = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_min_blank) begin
            $display("FAIL: SET_ALARM_MIN did not blank alarm minute digits");
            $finish;
        end
        if (!saw_hour_tens || !saw_sec_active) begin
            $display("FAIL: SET_ALARM_MIN should show alarm hour and blank LED1");
            $finish;
        end

        state = DATE_VIEW;
        blink_1hz = 1'b1;
        saw_hour_tens = 1'b0;
        saw_min_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (led3_cs1 && (led3_seg == seg7(4'd1))) saw_hour_tens = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd2))) saw_min_tens = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_hour_tens || !saw_min_tens || !saw_sec_active) begin
            $display("FAIL: DATE_VIEW should show MMDD and blank LED1");
            $finish;
        end

        state = SET_MONTH;
        blink_1hz = 1'b0;
        saw_hour_blank = 1'b0;
        saw_min_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led3_seg == 7'b0000000) && (led3_cs1 || led3_cs2)) saw_hour_blank = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd2))) saw_min_tens = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_hour_blank || !saw_min_tens || !saw_sec_active) begin
            $display("FAIL: SET_MONTH should blink month, show day, and blank LED1");
            $finish;
        end

        state = SET_DAY;
        saw_min_blank = 1'b0;
        saw_hour_tens = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if ((led2_seg == 7'b0000000) && (led2_cs1 || led2_cs2)) saw_min_blank = 1'b1;
            if (led3_cs1 && (led3_seg == seg7(4'd1))) saw_hour_tens = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_min_blank || !saw_hour_tens || !saw_sec_active) begin
            $display("FAIL: SET_DAY should blink day, show month, and blank LED1");
            $finish;
        end

        state = STOPWATCH;
        blink_1hz = 1'b1;
        stopwatch_mode = 1'b1;
        hour = 5'd12;
        min  = 6'd34;
        sec  = 6'd56;
        saw_hour_tens = 1'b0;
        saw_hour_ones = 1'b0;
        saw_min_tens  = 1'b0;
        saw_min_ones  = 1'b0;
        saw_sec_tens  = 1'b0;
        saw_sec_ones  = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (led3_cs1 && (led3_seg == seg7(4'd0))) saw_hour_tens = 1'b1;
            if (led3_cs2 && (led3_seg == seg7(4'd0))) saw_hour_ones = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd1))) saw_min_tens  = 1'b1;
            if (led2_cs2 && (led2_seg == seg7(4'd5))) saw_min_ones  = 1'b1;
            if (led1_cs1 && (led1_seg == seg7(4'd2))) saw_sec_tens  = 1'b1;
            if (led1_cs2 && (led1_seg == seg7(4'd3))) saw_sec_ones  = 1'b1;
        end
        if (!saw_hour_tens || !saw_hour_ones || !saw_min_tens || !saw_min_ones || !saw_sec_tens || !saw_sec_ones) begin
            $display("FAIL: STOPWATCH mode should show MMSSCC as LED3/LED2/LED1");
            $finish;
        end

        state = COUNTDOWN;
        stopwatch_mode = 1'b0;
        countdown_mode = 1'b1;
        saw_hour_tens = 1'b0;
        saw_hour_ones = 1'b0;
        saw_min_tens  = 1'b0;
        saw_min_ones  = 1'b0;
        saw_sec_active = 1'b0;
        for (sample_idx = 0; sample_idx < 60; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (led3_cs1 && (led3_seg == seg7(4'd0))) saw_hour_tens = 1'b1;
            if (led3_cs2 && (led3_seg == seg7(4'd2))) saw_hour_ones = 1'b1;
            if (led2_cs1 && (led2_seg == seg7(4'd4))) saw_min_tens  = 1'b1;
            if (led2_cs2 && (led2_seg == seg7(4'd5))) saw_min_ones  = 1'b1;
            if ((led1_seg == 7'b0000000) && (led1_cs1 || led1_cs2)) saw_sec_active = 1'b1;
        end
        if (!saw_hour_tens || !saw_hour_ones || !saw_min_tens || !saw_min_ones || !saw_sec_active) begin
            $display("FAIL: COUNTDOWN mode should show MMSS on LED3/LED2 and blank LED1");
            $finish;
        end

        $display("PASS: board display adapter HHMMSS");
        $finish;
    end
endmodule
