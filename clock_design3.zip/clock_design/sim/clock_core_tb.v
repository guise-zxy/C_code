`timescale 1ns / 1ps

module clock_core_tb;
    localparam [3:0] RUN            = 4'd0;
    localparam [3:0] SET_HOUR       = 4'd1;
    localparam [3:0] SET_MIN        = 4'd2;
    localparam [3:0] SET_ALARM_HOUR = 4'd3;
    localparam [3:0] SET_ALARM_MIN  = 4'd4;
    localparam [3:0] DATE_VIEW      = 4'd5;
    localparam [3:0] SET_MONTH      = 4'd6;
    localparam [3:0] SET_DAY        = 4'd7;
    localparam [3:0] STOPWATCH      = 4'd8;
    localparam [3:0] COUNTDOWN      = 4'd9;

    reg clk;
    reg rst_n;
    reg key_mode;
    reg key_add;
    reg key_sub;
    integer sample_idx;
    reg saw_hour_blank;
    reg saw_min_visible;
    reg saw_min_blank;
    reg saw_hour_visible;
    reg saw_hour_chime;
    reg [5:0] sec_before_run;
    reg [6:0] stopwatch_cs_before;

    wire [7:0] seg;
    wire [3:0] an;
    wire [4:0] dbg_hour;
    wire [5:0] dbg_min;
    wire [5:0] dbg_sec;
    wire [3:0] dbg_state;
    wire dbg_hour_chime;
    wire [4:0] dbg_alarm_hour;
    wire [5:0] dbg_alarm_min;
    wire dbg_alarm_active;
    wire [4:0] dbg_month;
    wire [5:0] dbg_day;
    wire dbg_stopwatch_mode;
    wire dbg_stopwatch_running;
    wire [6:0] dbg_stopwatch_min;
    wire [5:0] dbg_stopwatch_sec;
    wire [6:0] dbg_stopwatch_cs;
    wire dbg_countdown_mode;
    wire dbg_countdown_running;
    wire dbg_countdown_alarm_pulse;
    wire [5:0] dbg_countdown_min;
    wire [5:0] dbg_countdown_sec;

    clock_core_top #(
        .CLK_FREQ_HZ(100),
        .SCAN_FREQ_HZ(20),
        .DEBOUNCE_MS(20),
        .SEG_ACTIVE_LOW(1'b0),
        .AN_ACTIVE_LOW(1'b0)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .key_mode(key_mode),
        .key_add(key_add),
        .key_sub(key_sub),
        .seg(seg),
        .an(an),
        .dbg_hour(dbg_hour),
        .dbg_min(dbg_min),
        .dbg_sec(dbg_sec),
        .dbg_state(dbg_state),
        .dbg_hour_chime(dbg_hour_chime),
        .dbg_alarm_hour(dbg_alarm_hour),
        .dbg_alarm_min(dbg_alarm_min),
        .dbg_alarm_active(dbg_alarm_active),
        .dbg_month(dbg_month),
        .dbg_day(dbg_day),
        .dbg_stopwatch_mode(dbg_stopwatch_mode),
        .dbg_stopwatch_running(dbg_stopwatch_running),
        .dbg_stopwatch_min(dbg_stopwatch_min),
        .dbg_stopwatch_sec(dbg_stopwatch_sec),
        .dbg_stopwatch_cs(dbg_stopwatch_cs),
        .dbg_countdown_mode(dbg_countdown_mode),
        .dbg_countdown_running(dbg_countdown_running),
        .dbg_countdown_alarm_pulse(dbg_countdown_alarm_pulse),
        .dbg_countdown_min(dbg_countdown_min),
        .dbg_countdown_sec(dbg_countdown_sec)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    task press_mode;
        begin
            key_mode = 1'b1;
            repeat (8) @(posedge clk);
            key_mode = 1'b0;
            repeat (8) @(posedge clk);
        end
    endtask

    task hold_mode_long;
        begin
            key_mode = 1'b1;
            repeat (50) @(posedge clk);
            key_mode = 1'b0;
            repeat (12) @(posedge clk);
        end
    endtask

    task press_add;
        begin
            key_add = 1'b1;
            repeat (8) @(posedge clk);
            key_add = 1'b0;
            repeat (8) @(posedge clk);
        end
    endtask

    task press_sub;
        begin
            key_sub = 1'b1;
            repeat (8) @(posedge clk);
            key_sub = 1'b0;
            repeat (8) @(posedge clk);
        end
    endtask

    task bounce_add_once;
        begin
            key_add = 1'b1; @(posedge clk);
            key_add = 1'b0; @(posedge clk);
            key_add = 1'b1; @(posedge clk);
            key_add = 1'b0; @(posedge clk);
            key_add = 1'b1;
            repeat (8) @(posedge clk);
            key_add = 1'b0;
            repeat (8) @(posedge clk);
        end
    endtask

    initial begin
        rst_n = 1'b0;
        key_mode = 1'b0;
        key_add  = 1'b0;
        key_sub  = 1'b0;
        #40;
        rst_n = 1'b1;
        #20;

        if (dbg_hour !== 5'd0 || dbg_min !== 6'd0 || dbg_sec !== 6'd0 || dbg_state !== RUN) begin
            $display("FAIL: reset state mismatch");
            $finish;
        end
        if (dbg_alarm_hour !== 5'd0 || dbg_alarm_min !== 6'd0 || dbg_alarm_active !== 1'b0) begin
            $display("FAIL: reset alarm state mismatch");
            $finish;
        end
        if (dbg_month !== 5'd1 || dbg_day !== 6'd1) begin
            $display("FAIL: reset date state mismatch");
            $finish;
        end

        repeat (110) @(posedge clk);
        #1;
        if (dbg_hour !== 5'd0 || dbg_min !== 6'd0 || dbg_sec !== 6'd1) begin
            $display("FAIL: second did not advance after 1Hz interval");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour = 5'd23;
        dut.u_time_counter.min  = 6'd59;
        dut.u_time_counter.sec  = 6'd58;
        dut.u_time_counter.month = 5'd1;
        dut.u_time_counter.day   = 6'd31;
        dut.u_time_counter.alarm_hour = 5'd12;
        dut.u_time_counter.alarm_min  = 6'd34;

        repeat (220) @(posedge clk);
        #1;
        if (dbg_hour !== 5'd0 || dbg_min !== 6'd0 || dbg_sec !== 6'd0) begin
            $display("FAIL: 24-hour wraparound mismatch");
            $finish;
        end
        if (dbg_month !== 5'd2 || dbg_day !== 6'd1) begin
            $display("FAIL: January month-end rollover mismatch");
            $finish;
        end
        if (dbg_hour_chime !== 1'b0) begin
            $display("FAIL: midnight wraparound should not trigger hourly chime");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour = 5'd0;
        dut.u_time_counter.min  = 6'd59;
        dut.u_time_counter.sec  = 6'd58;
        dut.u_time_counter.month = 5'd1;
        dut.u_time_counter.day   = 6'd1;
        dut.u_time_counter.alarm_hour = 5'd0;
        dut.u_time_counter.alarm_min  = 6'd0;

        saw_hour_chime = 1'b0;
        begin : hour_rollover_watch
            repeat (240) begin
                @(posedge clk);
                #1;
                if (dbg_hour_chime) begin
                    saw_hour_chime = 1'b1;
                end
                if (dbg_hour === 5'd1 && dbg_min === 6'd0 && dbg_sec === 6'd0) begin
                    disable hour_rollover_watch;
                end
            end
        end
        if (dbg_hour !== 5'd1 || dbg_min !== 6'd0 || dbg_sec !== 6'd0) begin
            $display("FAIL: hour rollover to 01:00:00 mismatch");
            $finish;
        end
        if (!saw_hour_chime) begin
            $display("FAIL: hour rollover did not trigger hourly chime pulse");
            $finish;
        end

        @(posedge clk);
        #1;
        if (dbg_hour_chime !== 1'b0) begin
            $display("FAIL: hourly chime pulse should last exactly one cycle");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour = 5'd0;
        dut.u_time_counter.min  = 6'd0;
        dut.u_time_counter.sec  = 6'd0;
        dut.u_time_counter.month = 5'd1;
        dut.u_time_counter.day   = 6'd1;

        press_mode();
        if (dbg_state !== SET_HOUR) begin
            $display("FAIL: mode did not enter SET_HOUR");
            $finish;
        end

        repeat (110) @(posedge clk);
        #1;
        if (dbg_hour !== 5'd0 || dbg_min !== 6'd0 || dbg_sec !== 6'd0) begin
            $display("FAIL: time advanced while in SET_HOUR");
            $finish;
        end

        bounce_add_once();
        if (dbg_hour !== 5'd1) begin
            $display("FAIL: bounced add did not produce exactly one hour increment");
            $finish;
        end

        press_sub();
        if (dbg_hour !== 5'd0) begin
            $display("FAIL: hour decrement did not return to zero");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_MIN) begin
            $display("FAIL: mode did not enter SET_MIN");
            $finish;
        end

        press_sub();
        if (dbg_min !== 6'd59) begin
            $display("FAIL: minute decrement did not wrap to 59");
            $finish;
        end

        press_add();
        if (dbg_min !== 6'd0) begin
            $display("FAIL: minute increment did not wrap back to 0");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_ALARM_HOUR) begin
            $display("FAIL: mode did not enter SET_ALARM_HOUR after SET_MIN");
            $finish;
        end

        press_add();
        if (dbg_alarm_hour !== 5'd1) begin
            $display("FAIL: alarm hour increment mismatch");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_ALARM_MIN) begin
            $display("FAIL: mode did not enter SET_ALARM_MIN");
            $finish;
        end

        press_sub();
        if (dbg_alarm_min !== 6'd59) begin
            $display("FAIL: alarm minute decrement did not wrap to 59");
            $finish;
        end

        press_add();
        if (dbg_alarm_min !== 6'd0) begin
            $display("FAIL: alarm minute increment did not wrap back to 0");
            $finish;
        end

        press_mode();
        if (dbg_state !== DATE_VIEW) begin
            $display("FAIL: mode did not enter DATE_VIEW after SET_ALARM_MIN");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_MONTH) begin
            $display("FAIL: mode did not enter SET_MONTH after DATE_VIEW");
            $finish;
        end

        press_add();
        if (dbg_month !== 5'd2) begin
            $display("FAIL: month increment mismatch");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_DAY) begin
            $display("FAIL: mode did not enter SET_DAY after SET_MONTH");
            $finish;
        end

        press_sub();
        if (dbg_day !== 6'd28) begin
            $display("FAIL: day decrement did not wrap to month max day");
            $finish;
        end

        press_add();
        if (dbg_day !== 6'd1) begin
            $display("FAIL: day increment did not wrap back to 1");
            $finish;
        end

        press_mode();
        if (dbg_state !== RUN) begin
            $display("FAIL: mode did not return to RUN after SET_DAY");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_HOUR) begin
            $display("FAIL: mode did not re-enter SET_HOUR for blink test");
            $finish;
        end

        wait (dut.u_clk_div.blink_1hz == 1'b0);
        saw_hour_blank  = 1'b0;
        saw_min_visible = 1'b0;
        for (sample_idx = 0; sample_idx < 40; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (((an == 4'b0001) || (an == 4'b0010)) && seg == 8'h00) begin
                saw_hour_blank = 1'b1;
            end
            if (((an == 4'b0100) || (an == 4'b1000)) && seg != 8'h00) begin
                saw_min_visible = 1'b1;
            end
        end
        if (!saw_hour_blank) begin
            $display("FAIL: hour digits were not blanked during SET_HOUR blink-off window");
            $finish;
        end
        if (!saw_min_visible) begin
            $display("FAIL: minute digits did not stay visible during SET_HOUR blink-off window");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_MIN) begin
            $display("FAIL: mode did not advance to SET_MIN after blink test");
            $finish;
        end

        wait (dut.u_clk_div.blink_1hz == 1'b0);
        saw_min_blank   = 1'b0;
        saw_hour_visible = 1'b0;
        for (sample_idx = 0; sample_idx < 40; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (((an == 4'b0100) || (an == 4'b1000)) && seg == 8'h00) begin
                saw_min_blank = 1'b1;
            end
            if (((an == 4'b0001) || (an == 4'b0010)) && seg != 8'h00) begin
                saw_hour_visible = 1'b1;
            end
        end
        if (!saw_min_blank) begin
            $display("FAIL: minute digits were not blanked during SET_MIN blink-off window");
            $finish;
        end
        if (!saw_hour_visible) begin
            $display("FAIL: hour digits did not stay visible during SET_MIN blink-off window");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_ALARM_HOUR) begin
            $display("FAIL: mode did not advance to SET_ALARM_HOUR after SET_MIN blink test");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_ALARM_MIN) begin
            $display("FAIL: mode did not advance to SET_ALARM_MIN after SET_ALARM_HOUR");
            $finish;
        end

        press_mode();
        if (dbg_state !== DATE_VIEW) begin
            $display("FAIL: mode did not advance to DATE_VIEW after alarm states");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_MONTH) begin
            $display("FAIL: mode did not advance to SET_MONTH after DATE_VIEW");
            $finish;
        end

        press_mode();
        if (dbg_state !== SET_DAY) begin
            $display("FAIL: mode did not advance to SET_DAY after SET_MONTH");
            $finish;
        end

        press_mode();
        if (dbg_state !== RUN) begin
            $display("FAIL: mode did not return to RUN after date states");
            $finish;
        end

        sec_before_run = dbg_sec;
        repeat (110) @(posedge clk);
        #1;
        if (dbg_sec === sec_before_run) begin
            $display("FAIL: RUN did not resume second counting");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour       = 5'd6;
        dut.u_time_counter.min        = 6'd29;
        dut.u_time_counter.sec        = 6'd58;
        dut.u_time_counter.alarm_hour = 5'd6;
        dut.u_time_counter.alarm_min  = 6'd30;

        begin : alarm_wait
            repeat (240) begin
                @(posedge clk);
                #1;
                if (dbg_alarm_active) begin
                    disable alarm_wait;
                end
            end
        end
        if (!dbg_alarm_active) begin
            $display("FAIL: alarm did not activate at matching time");
            $finish;
        end
        if (dbg_state !== RUN) begin
            $display("FAIL: alarm activation should not change mode state");
            $finish;
        end

        press_mode();
        if (dbg_alarm_active) begin
            $display("FAIL: mode key did not cancel active alarm");
            $finish;
        end
        if (dbg_state !== RUN) begin
            $display("FAIL: canceling active alarm should not advance mode state");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour  = 5'd23;
        dut.u_time_counter.min   = 6'd59;
        dut.u_time_counter.sec   = 6'd58;
        dut.u_time_counter.month = 5'd2;
        dut.u_time_counter.day   = 6'd28;
        dut.u_time_counter.alarm_hour = 5'd12;
        dut.u_time_counter.alarm_min  = 6'd34;

        repeat (220) @(posedge clk);
        #1;
        if (dbg_month !== 5'd3 || dbg_day !== 6'd1) begin
            $display("FAIL: February month-end rollover mismatch");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour  = 5'd23;
        dut.u_time_counter.min   = 6'd59;
        dut.u_time_counter.sec   = 6'd58;
        dut.u_time_counter.month = 5'd12;
        dut.u_time_counter.day   = 6'd31;

        repeat (220) @(posedge clk);
        #1;
        if (dbg_month !== 5'd1 || dbg_day !== 6'd1) begin
            $display("FAIL: year-end rollover mismatch");
            $finish;
        end

        @(negedge clk);
        dut.u_time_counter.hour  = 5'd12;
        dut.u_time_counter.min   = 6'd34;
        dut.u_time_counter.sec   = 6'd56;

        hold_mode_long();
        if (dbg_state !== STOPWATCH) begin
            $display("FAIL: long press mode did not enter stopwatch mode");
            $finish;
        end
        if (!dbg_stopwatch_mode) begin
            $display("FAIL: stopwatch mode flag did not assert");
            $finish;
        end

        press_mode();
        if (!dbg_stopwatch_running) begin
            $display("FAIL: stopwatch did not start on short mode press");
            $finish;
        end

        @(posedge clk);
        #1;
        stopwatch_cs_before = dbg_stopwatch_cs;
        repeat (5) @(posedge clk);
        #1;
        if (dbg_stopwatch_cs !== (stopwatch_cs_before + 7'd5)) begin
            $display("FAIL: stopwatch did not count 10ms ticks");
            $finish;
        end

        press_mode();
        if (dbg_stopwatch_running) begin
            $display("FAIL: stopwatch did not pause on second short mode press");
            $finish;
        end

        stopwatch_cs_before = dbg_stopwatch_cs;
        repeat (5) @(posedge clk);
        #1;
        if (dbg_stopwatch_cs !== stopwatch_cs_before) begin
            $display("FAIL: stopwatch advanced while paused");
            $finish;
        end

        press_add();
        if (dbg_stopwatch_min !== 7'd0 || dbg_stopwatch_sec !== 6'd0 || dbg_stopwatch_cs !== 7'd0) begin
            $display("FAIL: stopwatch reset did not clear MMSSCC");
            $finish;
        end

        @(negedge clk);
        dut.u_stopwatch_counter.min = 7'd0;
        dut.u_stopwatch_counter.sec = 6'd59;
        dut.u_stopwatch_counter.cs  = 7'd99;
        dut.u_stopwatch_counter.running = 1'b1;
        repeat (2) @(posedge clk);
        #1;
        if (dbg_stopwatch_min !== 7'd1 || dbg_stopwatch_sec !== 6'd0 || dbg_stopwatch_cs !== 7'd1) begin
            $display("FAIL: stopwatch did not roll over from 00:59.99 to 01:00.01");
            $finish;
        end

        hold_mode_long();
        if (dbg_state !== COUNTDOWN || !dbg_countdown_mode) begin
            $display("FAIL: second long press did not enter countdown mode");
            $finish;
        end

        press_mode();
        if (dbg_countdown_running) begin
            $display("FAIL: countdown should not start at 00:00");
            $finish;
        end

        press_add();
        if (dbg_countdown_min !== 6'd1 || dbg_countdown_sec !== 6'd0) begin
            $display("FAIL: countdown add did not set one minute");
            $finish;
        end

        press_sub();
        if (dbg_countdown_min !== 6'd0 || dbg_countdown_sec !== 6'd55) begin
            $display("FAIL: countdown sub did not subtract five seconds");
            $finish;
        end

        press_mode();
        if (!dbg_countdown_running) begin
            $display("FAIL: countdown did not start on short mode press");
            $finish;
        end

        repeat (110) @(posedge clk);
        #1;
        if (dbg_countdown_min !== 6'd0 || dbg_countdown_sec !== 6'd54) begin
            $display("FAIL: countdown did not decrement after one second");
            $finish;
        end

        press_mode();
        if (dbg_countdown_running) begin
            $display("FAIL: countdown did not pause on short mode press");
            $finish;
        end

        @(negedge clk);
        dut.u_countdown_counter.min = 6'd0;
        dut.u_countdown_counter.sec = 6'd1;
        dut.u_countdown_counter.running = 1'b1;
        begin : countdown_alarm_wait
            repeat (130) begin
                @(posedge clk);
                #1;
                if (dbg_countdown_alarm_pulse) begin
                    disable countdown_alarm_wait;
                end
            end
        end
        if (!dbg_countdown_alarm_pulse) begin
            $display("FAIL: countdown did not pulse alarm at zero");
            $finish;
        end
        if (dbg_countdown_running || dbg_countdown_min !== 6'd0 || dbg_countdown_sec !== 6'd0) begin
            $display("FAIL: countdown did not stop cleanly at zero");
            $finish;
        end

        @(posedge clk);
        #1;
        if (dbg_countdown_alarm_pulse) begin
            $display("FAIL: countdown alarm pulse should last exactly one cycle");
            $finish;
        end

        hold_mode_long();
        if (dbg_state !== RUN || dbg_stopwatch_mode || dbg_countdown_mode) begin
            $display("FAIL: third long press did not return to RUN");
            $finish;
        end

        $display("PASS: simple clock core base behavior");
        $finish;
    end
endmodule
