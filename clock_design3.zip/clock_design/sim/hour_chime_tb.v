`timescale 1ns / 1ps

module hour_chime_tb;
    reg clk;
    reg rst_n;
    reg start_pulse;
    integer sample_idx;
    integer toggle_count;
    reg last_beep;

    wire beep;

    hour_chime #(
        .CLK_FREQ_HZ(20),
        .TONE_FREQ_HZ(2),
        .CHIME_SECONDS(1)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .start_pulse(start_pulse),
        .hold_enable(1'b0),
        .beep(beep)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        rst_n = 1'b0;
        start_pulse = 1'b0;
        #30;
        rst_n = 1'b1;

        if (beep !== 1'b0) begin
            $display("FAIL: beep should be low after reset");
            $finish;
        end

        @(posedge clk);
        start_pulse = 1'b1;
        @(posedge clk);
        start_pulse = 1'b0;

        toggle_count = 0;
        last_beep = beep;
        for (sample_idx = 0; sample_idx < 25; sample_idx = sample_idx + 1) begin
            @(posedge clk);
            if (beep !== last_beep) begin
                toggle_count = toggle_count + 1;
            end
            last_beep = beep;
        end

        if (toggle_count == 0) begin
            $display("FAIL: beep never toggled during active chime window");
            $finish;
        end

        if (beep !== 1'b0) begin
            $display("FAIL: beep should return low after chime window");
            $finish;
        end

        repeat (10) @(posedge clk);
        if (beep !== 1'b0) begin
            $display("FAIL: beep should stay low while idle");
            $finish;
        end

        $display("PASS: hourly chime driver");
        $finish;
    end
endmodule
