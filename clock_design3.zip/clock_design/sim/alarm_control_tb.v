`timescale 1ns / 1ps

module alarm_control_tb;
    reg clk;
    reg rst_n;
    reg tick_1hz;
    reg start_pulse;
    reg cancel_pulse;
    integer idx;

    wire alarm_active;

    alarm_control #(
        .ALARM_SECONDS(30)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .tick_1hz(tick_1hz),
        .start_pulse(start_pulse),
        .cancel_pulse(cancel_pulse),
        .alarm_active(alarm_active)
    );

    initial clk = 1'b0;
    always #5 clk = ~clk;

    task pulse_tick_1hz;
        begin
            @(negedge clk);
            tick_1hz = 1'b1;
            @(negedge clk);
            tick_1hz = 1'b0;
            @(posedge clk);
            #1;
        end
    endtask

    initial begin
        rst_n = 1'b0;
        tick_1hz = 1'b0;
        start_pulse = 1'b0;
        cancel_pulse = 1'b0;
        #30;
        rst_n = 1'b1;

        @(negedge clk);
        start_pulse = 1'b1;
        @(negedge clk);
        start_pulse = 1'b0;
        @(posedge clk);
        #1;
        if (!alarm_active) begin
            $display("FAIL: start_pulse did not activate alarm");
            $finish;
        end

        for (idx = 0; idx < 29; idx = idx + 1) begin
            pulse_tick_1hz();
            if (!alarm_active) begin
                $display("FAIL: alarm expired before 30 seconds");
                $finish;
            end
        end

        pulse_tick_1hz();
        if (alarm_active) begin
            $display("FAIL: alarm stayed active after 30 seconds");
            $finish;
        end

        @(negedge clk);
        start_pulse = 1'b1;
        @(negedge clk);
        start_pulse = 1'b0;
        @(posedge clk);
        #1;
        if (!alarm_active) begin
            $display("FAIL: second start_pulse did not activate alarm");
            $finish;
        end

        @(negedge clk);
        cancel_pulse = 1'b1;
        @(negedge clk);
        cancel_pulse = 1'b0;
        @(posedge clk);
        #1;
        if (alarm_active) begin
            $display("FAIL: cancel_pulse did not clear alarm");
            $finish;
        end

        $display("PASS: alarm control");
        $finish;
    end
endmodule
